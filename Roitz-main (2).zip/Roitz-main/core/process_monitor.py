"""
core/process_monitor.py — Unified stdout/stderr capture for child processes.

Provides a thread-safe context manager for running subprocesses with:
- Real-time stdout/stderr capture (separate streams)
- Task ID association for output retrieval
- Integration with WorkerRegistry for resource coordination
- Integration with TaskMonitor for timeout enforcement
- Integration with error classification for retry logic
- Outcome-based result reporting (done/unverified/failed)
"""

from __future__ import annotations

import threading
import time
import uuid
import subprocess
import queue
from dataclasses import dataclass, field
from typing import Optional, Callable, Any
from pathlib import Path
from enum import Enum

from core.worker_registry import (
    WorkerRegistry,
    WorkerRecord,
    WorkerState,
    create_worker_record,
    get_global_registry,
)
from core.task_monitoring import TaskMonitor, TaskRecovery, STEP_TIMEOUT, get_backoff_delay
from core.error_classification import (
    ErrorClass,
    ClassifiedError,
    classify_error,
    is_retry_eligible,
)
from core.outcome import done, failed, unverified, started


class ProcessState(str, Enum):
    """Lifecycle states for a monitored process."""
    CREATED = "created"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMED_OUT = "timed_out"
    CANCELLED = "cancelled"


@dataclass
class ProcessResult:
    """Result of a monitored process execution."""
    task_id: str
    state: ProcessState
    returncode: Optional[int] = None
    stdout: str = ""
    stderr: str = ""
    error: Optional[str] = None
    started_at: float = field(default_factory=time.time)
    finished_at: Optional[float] = None
    duration: float = 0.0

    def to_outcome(self, action: str) -> str:
        """Convert to outcome format for model consumption."""
        if self.state == ProcessState.COMPLETED:
            if self.returncode == 0:
                return done(
                    action,
                    task_id=self.task_id,
                    returncode=self.returncode,
                    stdout_bytes=len(self.stdout.encode()),
                    stderr_bytes=len(self.stderr.encode()),
                    duration_ms=int(self.duration * 1000),
                )
            else:
                return failed(
                    action,
                    f"Process exited with code {self.returncode}",
                    task_id=self.task_id,
                    returncode=self.returncode,
                    stderr=self.stderr[-500:] if self.stderr else "",
                    duration_ms=int(self.duration * 1000),
                )
        elif self.state == ProcessState.FAILED:
            return failed(
                action,
                f"Process exited with code {self.returncode}" if self.returncode else (self.error or "Process failed"),
                task_id=self.task_id,
                returncode=self.returncode,
                stderr=self.stderr[-500:] if self.stderr else "",
                duration_ms=int(self.duration * 1000),
            )
        elif self.state == ProcessState.TIMED_OUT:
            return failed(
                action,
                f"Process timed out after {self.duration:.1f}s",
                task_id=self.task_id,
                stdout=self.stdout[-500:] if self.stdout else "",
                stderr=self.stderr[-500:] if self.stderr else "",
                duration_ms=int(self.duration * 1000),
            )
        elif self.state == ProcessState.CANCELLED:
            return failed(
                action,
                "Process was cancelled",
                task_id=self.task_id,
                stdout=self.stdout[-500:] if self.stdout else "",
                stderr=self.stderr[-500:] if self.stderr else "",
                duration_ms=int(self.duration * 1000),
            )
        else:
            return unverified(
                action,
                f"Process ended in state {self.state.value}",
                task_id=self.task_id,
                state=self.state.value,
            )


@dataclass
class ProcessMonitor:
    """
    Monitors a child process with unified stdout/stderr capture.

    Features:
    - Real-time output capture via background threads
    - Task ID tracking for output association
    - WorkerRegistry integration for resource coordination
    - Configurable timeouts with TaskMonitor
    - Cooperative cancellation support
    - Automatic retry with exponential backoff for idempotent operations
    - Outcome-based result reporting
    """

    task_id: str
    command: list[str]
    cwd: Optional[Path] = None
    env: Optional[dict[str, str]] = None
    timeout: float = STEP_TIMEOUT
    worker_registry: Optional[WorkerRegistry] = None
    player: Any = None
    cancel_event: Optional[threading.Event] = None
    is_idempotent: bool = False
    operation_name: str = "process_monitor"
    max_retries: int = 3
    capture_stdout: bool = True
    capture_stderr: bool = True

    # Internal state
    _process: Optional[subprocess.Popen] = field(default=None, init=False, repr=False)
    _stdout_thread: Optional[threading.Thread] = field(default=None, init=False, repr=False)
    _stderr_thread: Optional[threading.Thread] = field(default=None, init=False, repr=False)
    _stdout_queue: queue.Queue = field(default_factory=queue.Queue, init=False, repr=False)
    _stderr_queue: queue.Queue = field(default_factory=queue.Queue, init=False, repr=False)
    _stdout_chunks: list[str] = field(default_factory=list, init=False, repr=False)
    _stderr_chunks: list[str] = field(default_factory=list, init=False, repr=False)
    _worker_record: Optional[WorkerRecord] = field(default=None, init=False, repr=False)
    _state: ProcessState = field(default=ProcessState.CREATED, init=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)
    _result: Optional[ProcessResult] = field(default=None, init=False, repr=False)
    _retry_count: int = field(default=0, init=False)
    _start_time: float = field(default=0.0, init=False)

    def __post_init__(self):
        if self.worker_registry is None:
            self.worker_registry = get_global_registry()
        if self.cancel_event is None:
            self.cancel_event = threading.Event()
        if self.cwd is not None and not isinstance(self.cwd, Path):
            self.cwd = Path(self.cwd)

    @property
    def state(self) -> ProcessState:
        with self._lock:
            return self._state

    @property
    def result(self) -> Optional[ProcessResult]:
        with self._lock:
            return self._result

    def _set_state(self, state: ProcessState) -> None:
        with self._lock:
            self._state = state
            if self.player:
                try:
                    self.player.write_log(f"[ProcessMonitor:{self.task_id}] State: {state.value}")
                except Exception:
                    pass

    def _log(self, msg: str) -> None:
        print(f"[ProcessMonitor:{self.task_id}] {msg}")
        if self.player:
            try:
                self.player.write_log(f"[ProcessMonitor:{self.task_id}] {msg}")
            except Exception:
                pass

    def _read_stream(self, stream: Any, queue: queue.Queue, chunks: list[str], stream_name: str) -> None:
        """Background thread to read from a process stream."""
        try:
            for line in iter(stream.readline, b""):
                if self.cancel_event.is_set():
                    break
                decoded = line.decode("utf-8", errors="replace")
                queue.put(decoded)
                chunks.append(decoded)
        except Exception as e:
            self._log(f"Error reading {stream_name}: {e}")
        finally:
            stream.close()

    def _wait_for_process(self, timeout: float) -> bool:
        """Wait for process to complete, return True if completed within timeout."""
        if self._process is None:
            return True
        try:
            self._process.wait(timeout=timeout)
            return True
        except subprocess.TimeoutExpired:
            return False

    def _terminate_process(self) -> None:
        """Terminate the process and its children."""
        if self._process is None:
            return
        try:
            # On Windows, terminate() sends CTRL_BREAK_EVENT which may not work for all processes
            # Use kill() directly for more reliable termination
            import platform
            if platform.system() == "Windows":
                self._process.kill()
            else:
                self._process.terminate()
            # Wait a bit for graceful termination
            try:
                self._process.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                # Force kill if needed
                self._process.kill()
                self._process.wait(timeout=1.0)
        except Exception as e:
            self._log(f"Error terminating process: {e}")

    def _collect_output(self) -> tuple[str, str]:
        """Collect all captured stdout and stderr."""
        stdout = "".join(self._stdout_chunks)
        stderr = "".join(self._stderr_chunks)
        return stdout, stderr

    def _create_worker_record(self) -> WorkerRecord:
        """Create a worker record for this process with unique resource key."""
        import uuid
        params = {
            "command": self.command,
            "cwd": str(self.cwd) if self.cwd else None,
            "timeout": self.timeout,
        }
        # Use a unique resource key per task to allow concurrent processes
        # that don't actually share resources (like different working directories)
        unique_resource_key = f"process:{self.task_id}"

        return WorkerRecord(
            attempt_id=str(uuid.uuid4()),
            task_id=self.task_id,
            step_id=f"process:{self.task_id}",
            tool_name="claude_code_task",
            operation_name=self.operation_name,
            resource_keys=(unique_resource_key,),
            resource_scope="task",  # Per-task scope
            is_idempotent=self.is_idempotent,
        )

    def run(self, retry_on_failure: bool = True) -> ProcessResult:
        """
        Run the process with monitoring, timeout, and optional retry.

        Returns ProcessResult with captured output and state.
        """
        self._start_time = time.time()
        self._set_state(ProcessState.RUNNING)

        # Create worker record
        self._worker_record = self._create_worker_record()

        # Admission check with WorkerRegistry
        admitted, conflict_reason = self.worker_registry.admit_worker(self._worker_record)
        if not admitted:
            self._set_state(ProcessState.FAILED)
            error_msg = f"Resource admission blocked: {conflict_reason}"
            self._log(error_msg)
            self._result = ProcessResult(
                task_id=self.task_id,
                state=ProcessState.FAILED,
                error=error_msg,
                started_at=self._start_time,
                finished_at=time.time(),
                duration=time.time() - self._start_time,
            )
            return self._result

        # Mark worker as running
        current_thread = threading.current_thread()
        self._worker_record.mark_running(current_thread, self.cancel_event)

        # Retry loop
        while True:
            if self.cancel_event.is_set():
                self._set_state(ProcessState.CANCELLED)
                break

            # Start the process
            try:
                self._log(f"Starting process: {' '.join(self.command)}")
                self._process = subprocess.Popen(
                    self.command,
                    cwd=str(self.cwd) if self.cwd else None,
                    env=self.env,
                    stdout=subprocess.PIPE if self.capture_stdout else None,
                    stderr=subprocess.PIPE if self.capture_stderr else None,
                    stdin=subprocess.DEVNULL,
                )
            except Exception as e:
                error_msg = f"Failed to start process: {type(e).__name__}: {e}"
                self._log(error_msg)
                self._set_state(ProcessState.FAILED)
                self._result = ProcessResult(
                    task_id=self.task_id,
                    state=ProcessState.FAILED,
                    error=error_msg,
                    started_at=self._start_time,
                    finished_at=time.time(),
                    duration=time.time() - self._start_time,
                )
                break

            # Start output capture threads
            self._stdout_chunks = []
            self._stderr_chunks = []
            self._stdout_thread = None
            self._stderr_thread = None

            if self.capture_stdout and self._process.stdout:
                self._stdout_thread = threading.Thread(
                    target=self._read_stream,
                    args=(self._process.stdout, self._stdout_queue, self._stdout_chunks, "stdout"),
                    daemon=True,
                    name=f"proc-stdout-{self.task_id[:8]}",
                )
                self._stdout_thread.start()

            if self.capture_stderr and self._process.stderr:
                self._stderr_thread = threading.Thread(
                    target=self._read_stream,
                    args=(self._process.stderr, self._stderr_queue, self._stderr_chunks, "stderr"),
                    daemon=True,
                    name=f"proc-stderr-{self.task_id[:8]}",
                )
                self._stderr_thread.start()

            # Wait for completion with timeout
            completed = self._wait_for_process(self.timeout)

            # Check for cancellation during wait
            if self.cancel_event.is_set():
                self._log("Cancellation requested during process execution")
                self._terminate_process()
                self._set_state(ProcessState.CANCELLED)
                break

            if not completed:
                # Timeout occurred
                self._log(f"Process timed out after {self.timeout}s")
                self._terminate_process()
                self._set_state(ProcessState.TIMED_OUT)
                # Wait for output threads to finish
                if self._stdout_thread:
                    self._stdout_thread.join(timeout=1.0)
                if self._stderr_thread:
                    self._stderr_thread.join(timeout=1.0)
                # Collect partial output
                stdout, stderr = self._collect_output()
                duration = time.time() - self._start_time
                self._result = ProcessResult(
                    task_id=self.task_id,
                    state=ProcessState.TIMED_OUT,
                    returncode=None,
                    stdout=stdout,
                    stderr=stderr,
                    error=f"Process timed out after {self.timeout}s",
                    started_at=self._start_time,
                    finished_at=time.time(),
                    duration=duration,
                )
                self._worker_record.mark_timed_out()
                break
            else:
                # Process completed
                returncode = self._process.returncode
                # Wait for output threads to finish
                if self._stdout_thread:
                    self._stdout_thread.join(timeout=1.0)
                if self._stderr_thread:
                    self._stderr_thread.join(timeout=1.0)

                stdout, stderr = self._collect_output()
                duration = time.time() - self._start_time

                if returncode == 0:
                    self._set_state(ProcessState.COMPLETED)
                    self._result = ProcessResult(
                        task_id=self.task_id,
                        state=ProcessState.COMPLETED,
                        returncode=returncode,
                        stdout=stdout,
                        stderr=stderr,
                        started_at=self._start_time,
                        finished_at=time.time(),
                        duration=duration,
                    )
                    self._worker_record.mark_completed("done")
                    self._log(f"Process completed successfully in {duration:.1f}s")
                else:
                    error_msg = f"Process exited with code {returncode}"
                    self._log(error_msg)

                    # Check if we should retry
                    classified = classify_error(Exception(f"returncode={returncode}: {stderr[:200]}"))
                    if retry_on_failure and is_retry_eligible(classified, self.is_idempotent) and self._retry_count < self.max_retries:
                        self._retry_count += 1
                        delay = get_backoff_delay(self._retry_count)
                        self._log(f"Retrying (attempt {self._retry_count}/{self.max_retries}) after {delay}s backoff")
                        time.sleep(delay)
                        # Clean up worker record for retry
                        self.worker_registry.release_resources(self._worker_record.attempt_id)
                        self._worker_record = self._create_worker_record()
                        admitted, conflict_reason = self.worker_registry.admit_worker(self._worker_record)
                        if not admitted:
                            self._set_state(ProcessState.FAILED)
                            self._result = ProcessResult(
                                task_id=self.task_id,
                                state=ProcessState.FAILED,
                                error=f"Retry blocked by resource conflict: {conflict_reason}",
                                started_at=self._start_time,
                                finished_at=time.time(),
                                duration=time.time() - self._start_time,
                            )
                        else:
                            self._worker_record.mark_running(current_thread, self.cancel_event)
                            continue
                    else:
                        self._set_state(ProcessState.FAILED)
                        self._result = ProcessResult(
                            task_id=self.task_id,
                            state=ProcessState.FAILED,
                            returncode=returncode,
                            stdout=stdout,
                            stderr=stderr,
                            error=error_msg,
                            started_at=self._start_time,
                            finished_at=time.time(),
                            duration=duration,
                        )
                        self._worker_record.mark_failed(error_msg)
                break

        # Cleanup
        if self._worker_record:
            self._worker_record.mark_terminated()
            self.worker_registry.release_resources(self._worker_record.attempt_id)

        if self._result is None:
            self._result = ProcessResult(
                task_id=self.task_id,
                state=self._state,
                started_at=self._start_time,
                finished_at=time.time(),
                duration=time.time() - self._start_time,
            )

        return self._result

    def cancel(self) -> None:
        """Request cooperative cancellation of the process."""
        self._log("Cancellation requested")
        self.cancel_event.set()
        if self._process and self._process.poll() is None:
            self._terminate_process()

    def get_partial_output(self) -> tuple[str, str]:
        """Get current captured output without waiting for completion."""
        return "".join(self._stdout_chunks), "".join(self._stderr_chunks)


def run_process(
    task_id: str,
    command: list[str],
    cwd: Optional[Path] = None,
    env: Optional[dict[str, str]] = None,
    timeout: float = STEP_TIMEOUT,
    worker_registry: Optional[WorkerRegistry] = None,
    player: Any = None,
    cancel_event: Optional[threading.Event] = None,
    is_idempotent: bool = False,
    operation_name: str = "process_monitor",
    max_retries: int = 3,
) -> ProcessResult:
    """
    Convenience function to run a process with monitoring.

    This is the primary entry point for running monitored processes.
    """
    monitor = ProcessMonitor(
        task_id=task_id,
        command=command,
        cwd=cwd,
        env=env,
        timeout=timeout,
        worker_registry=worker_registry,
        player=player,
        cancel_event=cancel_event,
        is_idempotent=is_idempotent,
        operation_name=operation_name,
        max_retries=max_retries,
    )
    return monitor.run()


def run_claude_code_task(
    task_id: str,
    prompt: str,
    cwd: Optional[Path] = None,
    timeout: float = 300.0,  # 5 minutes default for Claude Code
    worker_registry: Optional[WorkerRegistry] = None,
    player: Any = None,
    cancel_event: Optional[threading.Event] = None,
    additional_args: Optional[list[str]] = None,
) -> ProcessResult:
    """
    Run a Claude Code task with monitoring.

    This is a specialized function for running `claude -p <prompt>` commands
    with proper output capture and task ID association.

    Args:
        task_id: Unique identifier for this task
        prompt: The prompt to send to Claude Code
        cwd: Working directory (defaults to current)
        timeout: Maximum time to wait for completion
        worker_registry: WorkerRegistry for resource coordination
        player: Player for UI logging
        cancel_event: Cancellation event
        additional_args: Additional arguments to pass to claude command

    Returns:
        ProcessResult with captured stdout/stderr and state
    """
    # Build the claude command
    # Use --print for non-interactive output, --output-format=json for structured output
    cmd = [
        "claude",
        "-p",
        "--output-format", "json",
        prompt,
    ]

    if additional_args:
        cmd.extend(additional_args)

    return run_process(
        task_id=task_id,
        command=cmd,
        cwd=cwd,
        timeout=timeout,
        worker_registry=worker_registry,
        player=player,
        cancel_event=cancel_event,
        is_idempotent=False,  # Claude Code tasks are generally not idempotent
        operation_name="claude_code_task",
        max_retries=1,  # Only 1 retry for LLM calls
    )