"""
Plugin discovery, validation, collision detection, and dispatch.

Discovery runs once (JarvisLive.__init__ calls discover_plugins()); the resulting
PluginRegistry is cached for the process lifetime. Enable/disable state is re-read
from config on every call to get_tool_declarations() / run() / list_for_ui(), so
toggling a plugin does not require restarting the app or re-importing anything.
"""
from __future__ import annotations

import importlib.util
import inspect
import re
import sys
import threading
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from core.permission_guard import get_permission_guard
from core.permission_manager import PermissionResult
from memory.config_manager import get_plugin_enabled, get_plugin_config

_NAME_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$")
_DEFAULT_PARAMS = {"type": "OBJECT", "properties": {}}


def _get_operation_name(tool_name: str, parameters: dict) -> str | None:
    """Form the operation_name from tool name and parameters.

    Different tools use different parameter keys for the sub-action:
    - file_controller, computer_control, browser_control: "action"
    - dev_agent: "mode" (values: improve, build, status)
    - send_message: "platform"
    - Other plugins: try "action" first, then "platform"
    """
    if tool_name in ("file_controller", "computer_control", "browser_control"):
        action = parameters.get("action", "").lower().strip()
        if action:
            return f"{tool_name}:{action}"
    elif tool_name == "dev_agent":
        mode = parameters.get("mode", "").lower().strip()
        if mode:
            return f"{tool_name}:{mode}"
    elif tool_name == "send_message":
        platform = parameters.get("platform", "").lower().strip()
        if platform:
            return f"{tool_name}:{platform}"
    else:
        # Other plugins: try "action" first, then "platform"
        action = parameters.get("action", "")
        if action:
            return f"{tool_name}:{action.lower().strip()}"
        platform = parameters.get("platform", "")
        if platform:
            return f"{tool_name}:{platform.lower().strip()}"
    return tool_name

# Optional, and the same contract actions use: a plugin that takes a moment can
# say so, and the model carries on talking instead of waiting on it. See
# core/action_loader.py for what each value means.
_BEHAVIORS = ("BLOCKING", "NON_BLOCKING")
_SCHEDULING = ("WHEN_IDLE", "SILENT", "INTERRUPT")


def _opt_upper(value, allowed: tuple[str, ...]) -> Optional[str]:
    v = str(value or "").strip().upper()
    return v if v in allowed else None

def _opt_tier(value) -> Optional[str]:
    """"core" or "extra" from a declaration, or None when it did not say.

    Anything else is treated as "did not say" rather than as an error: a typo
    should fall back to the default ranking, not stop a working tool loading.
    """
    text = str(value or "").strip().lower()
    return text if text in ("core", "extra") else None


def _opt_text(value) -> Optional[str]:
    text = str(value or "").strip()
    return text or None


@dataclass
class PluginRecord:
    name: str
    description: str = ""
    parameters: dict = field(default_factory=lambda: dict(_DEFAULT_PARAMS))
    run: Optional[Callable] = None
    file: str = ""
    valid: bool = False
    error: str = ""
    settings: Optional[dict] = None   # optional PLUGIN_SETTINGS schema (config fields)
    behavior: Optional[str] = None    # None = the API's default (blocking)
    scheduling: Optional[str] = None  # None = the API's default (WHEN_IDLE)
    # Read by providers/schema.py when a small model gets a tool budget; never
    # sent to any API — main.py strips both before the Gemini config is built.
    #   tier   "core" | "extra" — this file's own opinion of whether it should
    #          survive a tight budget, instead of that being decided by the
    #          order files happen to be discovered in.
    #   brief  a short description used in place of the long one when a budget
    #          is in force. Nothing is deleted: Gemini still gets the full text.
    tier: Optional[str] = None
    brief: Optional[str] = None


class PluginRegistry:
    def __init__(self, plugins: dict[str, PluginRecord], logger: Callable[[str], None],
                 notify: Callable[[str], None] | None = None,
                 plugins_dir: Path | None = None,
                 core_tool_names: set[str] | None = None):
        self._plugins = plugins          # name -> PluginRecord, VALID entries only
        self._all_records: list[PluginRecord] = []   # valid + invalid, for UI listing
        self._logger = logger
        self._notify = notify or (lambda _msg: None)
        self._plugins_dir = plugins_dir
        self._core_tool_names = core_tool_names or set()
        self._file_mtimes: dict[str, float] = {}
        self._file_to_plugin: dict[str, str] = {}
        self._lock = threading.Lock()
        self._watcher_thread: Optional[threading.Thread] = None
        self._watcher_stop_event = threading.Event()
        self._on_change_callbacks: list[Callable[[], None]] = []

    # -- called by main.py at LiveConnectConfig build time --
    def get_tool_declarations(self) -> list[dict]:
        with self._lock:
            decls = []
            for name, rec in self._plugins.items():
                if get_plugin_enabled(name):
                    decl = {
                        "name": rec.name,
                        "description": rec.description,
                        "parameters": rec.parameters,
                    }
                    if rec.behavior:
                        decl["behavior"] = rec.behavior
                    if rec.tier:
                        decl["tier"] = rec.tier
                    if rec.brief:
                        decl["brief"] = rec.brief
                    decls.append(decl)
            return decls

    def has(self, name: str) -> bool:
        with self._lock:
            return name in self._plugins

    def names(self) -> set[str]:
        with self._lock:
            return set(self._plugins.keys())

    def scheduling(self, name: str) -> Optional[str]:
        with self._lock:
            rec = self._plugins.get(name)
            return rec.scheduling if rec else None

    # -- called by main.py from _execute_tool's else branch --
    def run(self, name: str, parameters: dict, player=None, session_memory=None, cancel_event=None, identity=None) -> str:
        with self._lock:
            rec = self._plugins.get(name)
            if rec is None or not rec.valid:
                return f"Plugin '{name}' is not available."
            if not get_plugin_enabled(name):
                return f"The '{name}' plugin is currently disabled."
            run_fn = rec.run

        # Permission check — required if operation is registered in OPERATION_SPECS
        from core.permission_guard import OPERATION_SPECS
        operation_name = _get_operation_name(name, parameters)
        check_target = None
        if operation_name and operation_name in OPERATION_SPECS:
            check_target = operation_name
        elif name in OPERATION_SPECS:
            check_target = name

        if check_target:
            guard = get_permission_guard()
            result = guard.check_operation(check_target, parameters)

            if not result.allowed:
                if result.reason == "approval_required":
                    return result.instruction
                from core import outcome
                return outcome.failed(check_target, result.reason)

            spec = OPERATION_SPECS.get(check_target)
            if spec and spec.capability == "proc.exec" and spec.template_id:
                from core.command_templates import validate_template
                validation = validate_template(spec.template_id, spec.get_template_args(parameters))
                if not validation.allowed:
                    from core import outcome
                    return outcome.failed("proc.exec", validation.reason)
                parameters["_validated_command"] = validation.command
                parameters["_validated_cwd"] = validation.cwd

        if identity is not None:
            from core.identity import set_current_identity, clear_current_identity
            set_current_identity(identity)
        try:
            return _call_run(run_fn, parameters, player, session_memory, cancel_event, identity=identity) or "Done."
        except Exception as e:
            self._logger(f"Plugin '{name}' crashed during run(): {e}")
            self._notify(f"Plugin '{name}' failed — see the console for details.")
            traceback.print_exc()
            return f"Sir, the '{name}' plugin failed: {e}"
        finally:
            if identity is not None:
                from core.identity import clear_current_identity
                clear_current_identity()

    # -- called by ui.py's settings tab to render per-plugin config forms --
    def settings_schemas(self) -> list[dict]:
        with self._lock:
            seen: set[str] = set()
            out: list[dict] = []
            for name, rec in self._plugins.items():
                if not rec.settings or not get_plugin_enabled(name):
                    continue
                ns = rec.settings.get("namespace") or rec.name
                if ns in seen:
                    continue
                seen.add(ns)
                out.append({
                    "plugin":    rec.name,
                    "namespace": ns,
                    "title":     rec.settings.get("title") or rec.name,
                    "fields":    rec.settings.get("fields", []),
                    "values":    get_plugin_config(ns),
                    "action":    rec.settings.get("action"),
                })
            return out

    # -- called by ui.py's Plugin Manager overlay --
    def list_for_ui(self) -> list[dict]:
        with self._lock:
            out = []
            for rec in self._all_records:
                out.append({
                    "name": rec.name,
                    "description": rec.description,
                    "file": rec.file,
                    "valid": rec.valid,
                    "error": rec.error,
                    "enabled": get_plugin_enabled(rec.name) if rec.valid else False,
                })
            return out

    def _load_or_reload_file_locked(self, path: Path) -> PluginRecord:
        other_plugins = {rec.name: rec.file for rec in self._plugins.values() if rec.file != path.name}
        old_plugin_name = self._file_to_plugin.get(path.name)
        try:
            rec = _load_plugin_from_file_path(path, self._plugins_dir, self._core_tool_names, other_plugins)
        except Exception as e:
            rec = PluginRecord(name=path.stem, file=path.name,
                                error=_load_error(path, self._plugins_dir, e))
            traceback.print_exc()

        if old_plugin_name:
            self._plugins.pop(old_plugin_name, None)
            self._file_to_plugin.pop(path.name, None)

        self._all_records = [r for r in self._all_records if r.file != path.name]
        self._all_records.append(rec)
        self._all_records.sort(key=lambda r: r.file)

        if rec.valid:
            self._plugins[rec.name] = rec
            self._file_to_plugin[path.name] = rec.name
            self._logger(f"Plugin loaded/reloaded: {rec.name} ({path.name})")
            self._notify(f"Plugin '{rec.name}' loaded.")
        else:
            self._logger(f"Plugin rejected: {path.name} — {rec.error}")
            self._notify(f"Plugin '{path.name}' failed to load — see console.")
        return rec

    def _unload_file_locked(self, filename: str) -> Optional[str]:
        plugin_name = self._file_to_plugin.pop(filename, None)
        self._file_mtimes.pop(filename, None)
        if plugin_name and plugin_name in self._plugins:
            del self._plugins[plugin_name]
        self._all_records = [r for r in self._all_records if r.file != filename]

        stem = Path(filename).stem
        module_name = f"plugins.{stem}"
        sys.modules.pop(module_name, None)

        self._logger(f"Plugin removed: {filename}")
        if plugin_name:
            self._notify(f"Plugin '{plugin_name}' removed.")
        return plugin_name

    def check_for_updates(self) -> dict[str, list[str]]:
        results = {"added": [], "modified": [], "deleted": []}
        if not self._plugins_dir or not self._plugins_dir.is_dir():
            return results

        callbacks_to_fire = []
        with self._lock:
            try:
                disk_files = {
                    p.name: p for p in self._plugins_dir.glob("*.py")
                    if not p.name.startswith("_")
                }
            except OSError:
                return results

            deleted_files = [fname for fname in self._file_mtimes if fname not in disk_files]
            for fname in deleted_files:
                self._unload_file_locked(fname)
                results["deleted"].append(fname)

            for fname, path in disk_files.items():
                try:
                    mtime = path.stat().st_mtime
                except OSError:
                    continue

                if fname not in self._file_mtimes:
                    self._load_or_reload_file_locked(path)
                    try:
                        self._file_mtimes[fname] = path.stat().st_mtime
                    except OSError:
                        pass
                    results["added"].append(fname)
                elif mtime > self._file_mtimes[fname]:
                    self._load_or_reload_file_locked(path)
                    try:
                        self._file_mtimes[fname] = path.stat().st_mtime
                    except OSError:
                        pass
                    results["modified"].append(fname)

            if any(results.values()):
                callbacks_to_fire = list(self._on_change_callbacks)

        for cb in callbacks_to_fire:
            try:
                cb()
            except Exception as e:
                self._logger(f"Error in plugin on_change callback: {e}")

        return results

    def register_on_change(self, callback: Callable[[], None]) -> None:
        with self._lock:
            if callback not in self._on_change_callbacks:
                self._on_change_callbacks.append(callback)

    def start_watcher(self, interval_seconds: float = 2.0) -> None:
        with self._lock:
            if self._watcher_thread is not None and self._watcher_thread.is_alive():
                return
            self._watcher_stop_event.clear()
            self._watcher_thread = threading.Thread(
                target=self._watcher_loop,
                args=(interval_seconds,),
                name="PluginWatcher",
                daemon=True,
            )
            self._watcher_thread.start()
            self._logger(f"Plugin auto-reload watcher started (interval {interval_seconds}s).")

    def stop_watcher(self, timeout: float = 3.0) -> None:
        self._watcher_stop_event.set()
        with self._lock:
            thread = self._watcher_thread
            self._watcher_thread = None
        if thread is not None and thread.is_alive():
            thread.join(timeout=timeout)
            self._logger("Plugin auto-reload watcher stopped.")

    def _watcher_loop(self, interval_seconds: float) -> None:
        while not self._watcher_stop_event.wait(timeout=interval_seconds):
            try:
                self.check_for_updates()
            except Exception as e:
                self._logger(f"Plugin watcher error: {e}")


def _call_run(run_fn, parameters, player, session_memory, cancel_event=None, identity=None):
    """Invoke run() passing only the kwargs it actually declares (or all of them
    if it has **kwargs), so a minimal `def run(parameters):` plugin still works."""
    sig = inspect.signature(run_fn)
    has_var_kw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
    kwargs = {}
    if has_var_kw or "player" in sig.parameters:
        kwargs["player"] = player
    if has_var_kw or "session_memory" in sig.parameters:
        kwargs["session_memory"] = session_memory
    if has_var_kw or "cancel_event" in sig.parameters:
        kwargs["cancel_event"] = cancel_event
    if has_var_kw or "identity" in sig.parameters:
        kwargs["identity"] = identity
    return run_fn(parameters, **kwargs)


def _validate(module, filename: str) -> PluginRecord:
    """Returns a PluginRecord; .valid=False + .error set on any problem. Never raises."""
    plugin_meta = getattr(module, "PLUGIN", None)
    if not isinstance(plugin_meta, dict):
        return PluginRecord(name=Path(filename).stem, file=filename,
                             error="Missing PLUGIN dict constant.")

    name = plugin_meta.get("name")
    if not isinstance(name, str) or not _NAME_RE.match(name):
        return PluginRecord(name=str(name or Path(filename).stem), file=filename,
                             error="PLUGIN['name'] missing or not a valid identifier "
                                   "(letters/digits/underscore, must start with letter/underscore).")

    description = plugin_meta.get("description")
    if not isinstance(description, str) or not description.strip():
        return PluginRecord(name=name, file=filename,
                             error="PLUGIN['description'] missing or empty.")

    parameters = plugin_meta.get("parameters", _DEFAULT_PARAMS)
    if not isinstance(parameters, dict) or parameters.get("type") != "OBJECT":
        return PluginRecord(name=name, file=filename,
                             error="PLUGIN['parameters'] must be a dict with \"type\": \"OBJECT\".")

    run_fn = getattr(module, "run", None)
    if not callable(run_fn):
        return PluginRecord(name=name, file=filename,
                             error="Missing callable run(parameters, ...) function.")

    # Optional, self-describing settings schema (rendered by the settings UI).
    # A malformed schema is ignored, never fatal — the plugin still loads.
    settings = getattr(module, "PLUGIN_SETTINGS", None)
    if not (isinstance(settings, dict) and isinstance(settings.get("fields"), list)):
        settings = None

    return PluginRecord(name=name, description=description.strip(), parameters=parameters,
                         run=run_fn, file=filename, valid=True, error="", settings=settings,
                         behavior=_opt_upper(plugin_meta.get("behavior"), _BEHAVIORS),
                         scheduling=_opt_upper(plugin_meta.get("scheduling"), _SCHEDULING),
                         tier=_opt_tier(plugin_meta.get("tier")),
                         brief=_opt_text(plugin_meta.get("brief")))


# The app's own top-level packages. Named explicitly rather than only probed on
# disk, because the case that matters most is the folder being ABSENT: a plugin
# importing core.undo on a build with no core/ at all must still be told to
# update, not to install something called "core".
_FIRST_PARTY = {"core", "memory", "actions", "plugins", "dashboard", "config"}


def _is_first_party(top: str, plugins_dir: Path) -> bool:
    """True when `top` names part of this app rather than a third-party package.

    The disk probe is the second half so a package added to the project later is
    recognised without anyone remembering to edit the set above.
    """
    if top in _FIRST_PARTY:
        return True
    root = plugins_dir.parent
    try:
        return (root / top).is_dir() or (root / f"{top}.py").is_file()
    except OSError:
        return False


def _load_error(path: Path, plugins_dir: Path, exc: Exception) -> str:
    """Turn an import failure into something the person who downloaded the file
    can act on.

    Plugins are shared one file at a time, but some of them sit on a helper —
    anything named with a leading underscore, which this loader deliberately
    skips so it is never treated as a plugin of its own. Download the plugin
    without its helper and Python reports `No module named 'plugins._x'`, which
    is accurate and tells a non-programmer nothing. Naming the missing file, and
    saying it belongs next to this one, turns a support question into a
    thirty-second fix. Nothing here is specific to any plugin: the helper's name
    comes from the exception itself.
    """
    if isinstance(exc, ModuleNotFoundError):
        missing = (getattr(exc, "name", "") or "").split(".")
        if len(missing) == 2 and missing[0] == "plugins" and missing[1].startswith("_"):
            helper = missing[1] + ".py"
            return (f"Needs the shared file '{helper}', which is not in "
                    f"{plugins_dir.name}/. It comes with this plugin — download "
                    f"'{helper}' into the same folder as {path.name} and restart.")
        if missing and missing[0] not in ("plugins",):
            if _is_first_party(missing[0], plugins_dir):
                # 'pip install core' is not merely unhelpful — it is dangerous
                # advice. These names belong to this project, and telling
                # somebody to install a same-named stranger from an index is a
                # supply-chain hazard dressed up as a fix. A plugin written
                # against a newer Mark reaches this line, and the honest answer
                # is that the app is behind the plugin, not that a package is
                # absent.
                needed = "/".join(missing) + ".py"
                return (f"Needs '{needed}', which is part of this app rather than "
                        f"something to install — your copy doesn't have it, so it "
                        f"comes with a newer version. Update the app; there is "
                        f"nothing to pip install.")
            return (f"Needs a package that is not installed: "
                    f"pip install {missing[0]}")
    return f"Failed to load: {exc}"


def _load_plugin_from_file_path(path: Path, plugins_dir: Path, core_tool_names: set[str], other_plugins: dict[str, str]) -> PluginRecord:
    module_name = f"plugins.{path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError("could not build import spec")
    if module_name in sys.modules:
        module = sys.modules[module_name]
    else:
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        raise

    rec = _validate(module, path.name)

    if rec.valid and rec.name in core_tool_names:
        rec = PluginRecord(name=rec.name, file=path.name,
                            error=f"Name '{rec.name}' collides with a core tool — rejected.")
    elif rec.valid and rec.name in other_plugins:
        other = other_plugins[rec.name]
        rec = PluginRecord(name=rec.name, file=path.name,
                            error=f"Name '{rec.name}' already used by plugin '{other}' — rejected.")
    return rec


def discover_plugins(plugins_dir: Path, core_tool_names: set[str],
                      logger: Callable[[str], None] = print,
                      notify: Callable[[str], None] | None = None) -> PluginRegistry:
    """
    Scans plugins_dir for *.py files (skips files starting with '_', e.g. __init__.py,
    _template.py, and any shared-helper modules an author prefixes with '_').
    Import errors, validation errors, and name collisions are logged and the offending
    file is skipped — they NEVER raise out of this function and never abort the scan
    of remaining files.
    """
    plugins_dir.mkdir(parents=True, exist_ok=True)
    valid: dict[str, PluginRecord] = {}
    all_records: list[PluginRecord] = []
    file_mtimes: dict[str, float] = {}
    file_to_plugin: dict[str, str] = {}

    files = sorted(plugins_dir.glob("*.py"), key=lambda p: p.name)  # deterministic order
    for path in files:
        if path.name.startswith("_"):
            continue
        try:
            file_mtimes[path.name] = path.stat().st_mtime
        except OSError:
            pass

        other_plugins = {rec.name: rec.file for rec in valid.values()}
        try:
            rec = _load_plugin_from_file_path(path, plugins_dir, core_tool_names, other_plugins)
        except Exception as e:
            rec = PluginRecord(name=path.stem, file=path.name,
                                error=_load_error(path, plugins_dir, e))
            traceback.print_exc()

        all_records.append(rec)
        if rec.valid:
            valid[rec.name] = rec
            file_to_plugin[path.name] = rec.name
            logger(f"Plugin loaded: {rec.name} ({path.name})")
        else:
            logger(f"Plugin rejected: {path.name} — {rec.error}")

    notify = notify or (lambda _msg: None)
    registry = PluginRegistry(
        plugins=valid,
        logger=logger,
        notify=notify,
        plugins_dir=plugins_dir,
        core_tool_names=core_tool_names,
    )
    registry._all_records = all_records
    registry._file_mtimes = file_mtimes
    registry._file_to_plugin = file_to_plugin

    rejected = len(all_records) - len(valid)
    logger(f"Plugin discovery complete: {len(valid)} active, "
           f"{rejected} rejected, {len(all_records)} total.")
    # The activity log is the user's conversation, not a boot transcript: a
    # plugin that loaded correctly is not news, so only a failure surfaces there
    # — and then as one line, because the per-plugin detail is on the console.
    if rejected:
        notify(f"{rejected} plugin(s) could not be loaded — see the console.")
    return registry
