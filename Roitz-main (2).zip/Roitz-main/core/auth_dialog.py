"""
core/auth_dialog.py — owner authentication dialog with concurrent request support.

Thread-safe pending-request dictionary keyed by unique token_hash.
Mirrors core/confirm.py pattern: bind() called from main.py, UI callbacks emit Qt signals.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Callable, Optional

from core.auth_rate_limiter import get_rate_limiter
from core.permission_fingerprint import ApprovalToken

# Qt callbacks (bound at startup from main.py)
_show_cb: Optional[Callable[[str, str, str], None]] = None   # title, detail, token_hash
_hide_cb: Optional[Callable[[], None]] = None
_log_cb:  Optional[Callable[[str], None]] = None

# Thread-safe pending auth requests — keyed by token_hash (one per request)
_pending_auth: dict[str, "_PendingAuth"] = {}
_auth_lock = threading.Lock()

AUTH_TIMEOUT_SECONDS = 60.0


@dataclass
class _PendingAuth:
    """One pending authentication request."""
    token: ApprovalToken
    resolve_cb: Callable[[bool], None]   # called on worker thread with verified result
    at: float
    task_id: Optional[str] = None        # associated task_id for cancellation


def bind(show, hide, log=None) -> None:
    """Wire this module to the HUD. Called once from main.py at startup.

    Args:
        show: Callable(token_hash: str, title: str, detail: str) -> None
              Must be thread-safe (emit Qt signal from worker thread)
        hide: Callable() -> None
              Must be thread-safe (emit Qt signal from worker thread)
        log:  Optional callable for activity logging
    """
    global _show_cb, _hide_cb, _log_cb
    _show_cb, _hide_cb, _log_cb = show, hide, log


def _log(msg: str) -> None:
    if _log_cb:
        try:
            _log_cb(msg)
        except Exception:
            pass


def request_auth(token: ApprovalToken, title: str, detail: str,
                 resolve_cb: Callable[[bool], None], task_id: Optional[str] = None) -> str:
    """Called from worker thread. Returns instruction for model.

    Creates unique ApprovalToken, shows auth dialog, returns [AUTH_REQUIRED] instruction.
    """
    global _pending_auth

    if _show_cb is None:
        return "Authentication interface not available."

    identity = token.identity

    # Rate limit check (by stable identity, NOT nonce)
    # Check lockout BEFORE creating pending entry
    allowed, lockout = get_rate_limiter().check_lockout(
        identity.capability, identity.project_id, identity.template_id, identity.requesting_component
    )
    if not allowed:
        return f"Authentication locked. Try again in {int(lockout)} seconds."

    token_hash = token.token_hash()

    # Register pending request
    with _auth_lock:
        _pending_auth[token_hash] = _PendingAuth(
            token=token, resolve_cb=resolve_cb, at=time.monotonic(), task_id=task_id
        )

    try:
        _show_cb(token_hash, title, detail)
    except Exception as e:
        with _auth_lock:
            _pending_auth.pop(token_hash, None)
        get_rate_limiter().record_cancel_or_timeout(
            identity.capability, identity.project_id, identity.template_id, identity.requesting_component
        )
        return f"Could not show authentication dialog: {e}"

    _log(f"AUTH: Awaiting owner secret — {title} [{token_hash[:8]}]")
    return (
        f"[AUTH_REQUIRED] Owner authentication required for: {title}. "
        f"Tell the user to enter the owner secret in the authentication dialog."
    )


def resolve_auth(token_hash: str, accepted: bool, provided_secret: bytes) -> None:
    """Called from Qt thread (dialog OK/Cancel). provided_secret is bytes for zeroing.

    Looks up pending request by token_hash, verifies secret on worker thread.
    """
    with _auth_lock:
        pending = _pending_auth.pop(token_hash, None)

    if _hide_cb:
        try:
            _hide_cb()
        except Exception:
            pass

    if pending is None:
        return

    identity = pending.token.identity

    if time.monotonic() - pending.at > AUTH_TIMEOUT_SECONDS:
        _log(f"AUTH: Timeout — {identity.identity_key()}")
        get_rate_limiter().record_cancel_or_timeout(
            identity.capability, identity.project_id, identity.template_id, identity.requesting_component
        )
        _call_resolve(pending, False)
        return

    if not accepted:
        _log(f"AUTH: Cancelled — {identity.identity_key()}")
        get_rate_limiter().record_cancel_or_timeout(
            identity.capability, identity.project_id, identity.template_id, identity.requesting_component
        )
        _call_resolve(pending, False)
        return

    # Verify secret on worker thread (not Qt thread)
    def _verify_worker():
        from core.permission_manager import get_permission_manager
        pm = get_permission_manager()

        # Convert to mutable bytearray for best-effort zeroing
        secret_arr = bytearray(provided_secret)
        try:
            verified = pm._verify_owner_secret(bytes(secret_arr))
        finally:
            # Best-effort zeroing (Python limitation: immutable copies may persist)
            for i in range(len(secret_arr)):
                secret_arr[i] = 0

        if verified:
            get_rate_limiter().record_successful_verification(
                identity.capability, identity.project_id, identity.template_id, identity.requesting_component
            )
        else:
            # Failed verification counts toward lockout
            get_rate_limiter().record_failed_verification(
                identity.capability, identity.project_id, identity.template_id, identity.requesting_component
            )

        _log(f"AUTH: {'Verified' if verified else 'Failed'} — {identity.identity_key()}")
        _call_resolve(pending, verified)

    threading.Thread(target=_verify_worker, daemon=True, name="auth-verify").start()


def _call_resolve(pending: _PendingAuth, verified: bool) -> None:
    try:
        pending.resolve_cb(verified)
    except Exception as e:
        _log(f"AUTH: Resolve callback failed: {e}")


def cleanup_expired() -> None:
    """Remove expired pending requests. Call periodically."""
    now = time.monotonic()
    with _auth_lock:
        expired = [
            h for h, p in _pending_auth.items()
            if now - p.at > AUTH_TIMEOUT_SECONDS
        ]
        for h in expired:
            _log(f"AUTH: Expired pending — {h[:8]}")
            _pending_auth.pop(h, None)

    get_rate_limiter().cleanup_expired()


def cancel_for_task(task_id: str) -> int:
    """
    Cancel all pending authentication requests for the specified task.

    Called when a task is interrupted (e.g., voice barge-in). Removes the
    pending auth from tracking and hides the UI. Does NOT call the resolve
    callback, because the corresponding approval token is marked as cancelled
    in PermissionManager and should remain unusable.

    Returns the number of cancelled auth requests.
    """
    if not task_id:
        return 0

    cancelled = 0

    with _auth_lock:
        # Find all pending auth for this task
        for token_hash, pending in list(_pending_auth.items()):
            if pending.task_id == task_id:
                _pending_auth.pop(token_hash, None)
                identity = pending.token.identity
                _log(f"AUTH: Cancelled by interrupt — {identity.identity_key()} (task {task_id})")
                get_rate_limiter().record_cancel_or_timeout(
                    identity.capability, identity.project_id, identity.template_id, identity.requesting_component
                )
                cancelled += 1

    # Hide UI once if any were cancelled
    if cancelled > 0 and _hide_cb:
        try:
            _hide_cb()
        except Exception:
            pass

    return cancelled