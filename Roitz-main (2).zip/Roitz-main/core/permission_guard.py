"""
core/permission_guard.py — central enforcement point for actions and plugins.

Validates exact operation with parameters, consumes approval tokens atomically.
"""

from __future__ import annotations

from typing import Callable, Optional
from dataclasses import dataclass
from pathlib import Path
from enum import Enum

from core.permission_fingerprint import OperationIdentity, ApprovalToken
from core.permission_manager import PermissionManager, PermissionResult
from core.command_templates import validate_template
from memory.config_manager import BASE_DIR


class ResourceScope(str, Enum):
    """Scope of resources affected by the operation."""
    LOCAL_FILE = "local_file"        # Single file/folder on local filesystem
    LOCAL_SYSTEM = "local_system"    # System-wide settings, processes, hardware
    NETWORK_EGRESS = "network_egress" # Outbound network calls
    USER_PROFILE = "user_profile"    # User's personal data, credentials, sessions
    REMOTE_SERVICE = "remote_service" # External service APIs (Telegram, WhatsApp, etc.)


@dataclass
class OperationSpec:
    """Maps an action/plugin operation to its permission requirements and metadata."""
    capability: str
    template_id: str | None = None          # For proc.exec
    get_project: Callable[[dict], Path] = lambda _: BASE_DIR
    get_template_args: Callable[[dict], dict] = lambda _: {}
    additional_caps: tuple[str, ...] = ()   # Additional capabilities required
    # Phase 2: Operation metadata for recovery decisions
    idempotent: bool = False                # Safe to retry without side effects
    read_only: bool = False                 # Does not mutate state
    resource_scope: ResourceScope = ResourceScope.LOCAL_FILE


# Registry of all sensitive operations
# Each action/plugin operation name maps to its permission spec
# Phase 2: Added idempotent, read_only, resource_scope for recovery decisions
OPERATION_SPECS: dict[str, OperationSpec] = {
    # file_controller operations (14)
    "file_controller:list":              OperationSpec("fs.read",                                 idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:read":              OperationSpec("fs.read",                                 idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:create_file":       OperationSpec("fs.write",                                idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:create_folder":     OperationSpec("fs.write",                                idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:write":             OperationSpec("fs.write",                                idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:delete":            OperationSpec("fs.delete",                               idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:move":              OperationSpec("fs.move",                                 idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:copy":              OperationSpec("fs.write",                                idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:rename":            OperationSpec("fs.move",                                 idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:find":              OperationSpec("fs.read",                                 idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:largest":           OperationSpec("fs.read",                                 idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:disk_usage":        OperationSpec("fs.read",                                 idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:info":              OperationSpec("fs.read",                                 idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_FILE),
    "file_controller:organize_desktop":  OperationSpec("fs.move",                                 idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_FILE),

    # computer_control operations (24)
    # Input simulation - all simulate keyboard/mouse input
    "computer_control:type":           OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:smart_type":     OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:click":          OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:left_click":     OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:double_click":   OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:right_click":    OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:hotkey":         OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:press":          OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:move":           OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:drag":           OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:scroll":         OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:paste":          OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:clear_field":    OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:copy":           OperationSpec("input.simulate",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),  # Sends ctrl+c hotkey
    # Screen capture - read-only display access
    "computer_control:screen_find":    OperationSpec("screen.capture",                         idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:screenshot":     OperationSpec("screen.capture",                         idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    # Combined: screen capture + input simulation
    "computer_control:screen_click":   OperationSpec("screen.capture",                        idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM,
                                                    additional_caps=("input.simulate",)),
    # Application management
    "computer_control:close_app":      OperationSpec("app.manage",                              idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:close_application": OperationSpec("app.manage",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:quit_app":       OperationSpec("app.manage",                              idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:focus_window":   OperationSpec("app.manage",                              idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    # Screen recording
    "computer_control:record_start":   OperationSpec("screen.capture",                         idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:record_stop":    OperationSpec("screen.capture",                         idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:record_status":  OperationSpec("screen.capture",                        idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    # Read-only utilities - no exclusive resource, no side effects
    "computer_control:wait":           OperationSpec("system.monitor",                         idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:random_data":    OperationSpec("system.monitor",                         idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_control:user_data":      OperationSpec("fs.read",                                idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_FILE),

    # browser_control operations (20)
    # Navigation actions — involve network egress, can trigger server-side effects
    "browser_control:go_to":       OperationSpec("browser.navigate",                        idempotent=False, read_only=False, resource_scope=ResourceScope.NETWORK_EGRESS),
    "browser_control:search":      OperationSpec("browser.navigate",                        idempotent=False, read_only=False, resource_scope=ResourceScope.NETWORK_EGRESS),
    "browser_control:new_tab":     OperationSpec("browser.navigate",                        idempotent=False, read_only=False, resource_scope=ResourceScope.NETWORK_EGRESS),
    "browser_control:back":        OperationSpec("browser.navigate",                        idempotent=False, read_only=False, resource_scope=ResourceScope.NETWORK_EGRESS),
    "browser_control:forward":     OperationSpec("browser.navigate",                        idempotent=False, read_only=False, resource_scope=ResourceScope.NETWORK_EGRESS),
    "browser_control:reload":      OperationSpec("browser.navigate",                        idempotent=False, read_only=False, resource_scope=ResourceScope.NETWORK_EGRESS),
    # Interactive page actions — modify page state, operate on local browser process
    "browser_control:click":       OperationSpec("browser.interact",                        idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:type":        OperationSpec("browser.interact",                        idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:scroll":      OperationSpec("browser.interact",                        idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:fill_form":   OperationSpec("browser.interact",                        idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:smart_click": OperationSpec("browser.interact",                        idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:smart_type":  OperationSpec("browser.interact",                        idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:press":       OperationSpec("browser.interact",                        idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:close_tab":   OperationSpec("browser.interact",                        idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    # Read-only page actions
    "browser_control:screenshot":  OperationSpec("screen.capture",                          idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:get_text":    OperationSpec("browser.read",                            idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:get_url":     OperationSpec("browser.read",                            idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    # Session management — modify session registry state
    "browser_control:switch":      OperationSpec("browser.manage",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:list_browsers": OperationSpec("browser.read",                          idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:close":       OperationSpec("browser.manage",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "browser_control:close_all":   OperationSpec("browser.manage",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),

    # dev_agent operations (3)
    # improve: modifies existing folder (writes files, runs tests, subprocesses) - not idempotent, not read_only
    # Uses subprocesses for pip install, running tests, etc. -> needs proc.exec + net.egress
    "dev_agent:improve": OperationSpec("fs.write",
                                        get_project=lambda p: Path(p.get("folder", ".")),
                                        idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM,
                                        additional_caps=("proc.exec", "net.egress")),
    # build: creates new project (writes files, runs commands, installs packages, opens VSCode)
    # Uses subprocesses + app.manage (opens VSCode) -> needs proc.exec + net.egress + app.manage
    "dev_agent:build": OperationSpec("proc.exec", "pytest_project",
                                      get_project=lambda p: Path(p.get("folder", ".")),
                                      get_template_args=lambda p: {"test_path": p.get("test_path", "")},
                                      idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM,
                                      additional_caps=("proc.exec", "net.egress", "app.manage")),
    # status: reads job state - idempotent, read_only
    "dev_agent:status": OperationSpec("fs.read",
                                       get_project=lambda p: Path(p.get("folder", ".")),
                                       idempotent=True, read_only=True, resource_scope=ResourceScope.LOCAL_FILE),

    # send_message operations (6)
    "send_message:whatsapp":       OperationSpec("messaging.send",                          idempotent=False, read_only=False, resource_scope=ResourceScope.REMOTE_SERVICE),
    "send_message:telegram":       OperationSpec("messaging.send",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM,
                                                    additional_caps=("input.simulate", "app.manage")),
    "send_message:instagram":      OperationSpec("messaging.send",                          idempotent=False, read_only=False, resource_scope=ResourceScope.REMOTE_SERVICE,
                                                    additional_caps=("net.egress", "input.simulate")),
    "send_message:signal":         OperationSpec("messaging.send",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM,
                                                    additional_caps=("input.simulate", "app.manage")),
    "send_message:discord":        OperationSpec("messaging.send",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM,
                                                    additional_caps=("input.simulate", "app.manage")),
    "send_message:messenger":      OperationSpec("messaging.send",                          idempotent=False, read_only=False, resource_scope=ResourceScope.REMOTE_SERVICE,
                                                    additional_caps=("net.egress", "input.simulate")),

    # telegram_bot operations (9)
    "telegram_bot:command":        OperationSpec("remote.command",                          idempotent=False, read_only=False, resource_scope=ResourceScope.REMOTE_SERVICE),
    "telegram_bot:poll":           OperationSpec("net.egress",                              idempotent=True,  read_only=True,  resource_scope=ResourceScope.NETWORK_EGRESS),
    "telegram_bot:send":           OperationSpec("messaging.send",                          idempotent=False, read_only=False, resource_scope=ResourceScope.REMOTE_SERVICE,
                                                    additional_caps=("net.egress",)),
    # telegram_bot management actions (called via plugin run())
    "telegram_bot:configure":      OperationSpec("net.egress",                              idempotent=False, read_only=False, resource_scope=ResourceScope.USER_PROFILE),   # saves token (write)
    "telegram_bot:pair":           OperationSpec("fs.write",                                idempotent=True,  read_only=False, resource_scope=ResourceScope.USER_PROFILE),   # saves owner config
    "telegram_bot:unpair":         OperationSpec("fs.write",                                idempotent=True,  read_only=False, resource_scope=ResourceScope.USER_PROFILE),   # clears config
    "telegram_bot:status":         OperationSpec("fs.read",                                 idempotent=True,  read_only=True,  resource_scope=ResourceScope.USER_PROFILE),   # reads config
    "telegram_bot:start_polling":  OperationSpec("net.egress",                              idempotent=False, read_only=False, resource_scope=ResourceScope.NETWORK_EGRESS),  # starts polling
    "telegram_bot:stop_polling":   OperationSpec("net.egress",                              idempotent=False, read_only=False, resource_scope=ResourceScope.NETWORK_EGRESS),  # stops polling (state change)

    # Inline tools (main.py) - 8 handlers
    # save_memory: writes personal facts to long-term memory
    "save_memory":                 OperationSpec("memory.write",                            idempotent=False, read_only=False, resource_scope=ResourceScope.USER_PROFILE),
    # recall_memory: reads personal facts from long-term memory
    "recall_memory":               OperationSpec("fs.read",                                 idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_FILE),
    # undo: reverses the last file/system change
    "undo":                        OperationSpec("fs.move",                                 idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_FILE),
    # undo:list: lists undoable actions (read-only)
    "undo:list":                   OperationSpec("fs.read",                                 idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_FILE),
    # screen_process: captures screen/camera (already has permission check in main.py)
    "screen_process:screen":       OperationSpec("screen.capture",                          idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    "screen_process:camera":       OperationSpec("screen.capture",                          idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    # close_camera: closes the live camera view
    "close_camera":                OperationSpec("screen.capture",                          idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    # system_status: reads system metrics
    "system_status":               OperationSpec("system.monitor",                          idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    # manage_monitor: add/remove/list background monitoring topics
    "manage_monitor:add":          OperationSpec("net.egress",                              idempotent=False, read_only=False, resource_scope=ResourceScope.NETWORK_EGRESS),
    "manage_monitor:remove":       OperationSpec("net.egress",                              idempotent=False, read_only=False, resource_scope=ResourceScope.NETWORK_EGRESS),
    "manage_monitor:list":         OperationSpec("net.egress",                              idempotent=True,  read_only=True,  resource_scope=ResourceScope.NETWORK_EGRESS),
    # shutdown_jarvis: shuts down the assistant completely
    "shutdown_jarvis":             OperationSpec("system.shutdown",                         idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),

    # claude_code_task management operations
    "claude_code_task":            OperationSpec("proc.exec",                               idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "get_claude_code_result":      OperationSpec("system.monitor",                          idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    "cancel_claude_code_task":     OperationSpec("system.monitor",                          idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "list_claude_code_tasks":      OperationSpec("system.monitor",                          idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),

    # open_app: launches applications (requires app.manage approval)
    "open_app":                    OperationSpec("app.manage",                              idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),

    # computer_settings operations (50+ hotkey/window ops via pyautogui)
    # Volume/brightness: read system state then modify (not idempotent, not read-only)
    "computer_settings:volume_up":     OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:volume_down":   OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:volume_set":    OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:mute":          OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:brightness_up": OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:brightness_down": OperationSpec("input.simulate",                     idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    # Window management: hotkeys sent to focused window
    "computer_settings:close_window":  OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:full_screen":   OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:minimize":      OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:maximize":      OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:snap_left":     OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:snap_right":    OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:switch_window": OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:show_desktop":  OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    # Browser-like hotkeys
    "computer_settings:refresh_page":  OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:close_tab":     OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:new_tab":       OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:next_tab":      OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:prev_tab":      OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:go_back":       OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:go_forward":    OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:zoom_in":       OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:zoom_out":      OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:zoom_reset":    OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:find_on_page":  OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    # Scroll/page navigation
    "computer_settings:scroll_up":     OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:scroll_down":   OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:scroll_top":    OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:scroll_bottom": OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:page_up":       OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:page_down":     OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    # Clipboard/editing
    "computer_settings:copy":          OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:paste":         OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:cut":           OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:undo":          OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:redo":          OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:select_all":    OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:save":          OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    # Special keys
    "computer_settings:enter":         OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:escape":        OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:press_key":     OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:type_text":     OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    # System-level (irreversible - require owner approval via _IRREVERSIBLE gate)
    "computer_settings:screenshot":    OperationSpec("screen.capture",                       idempotent=True,  read_only=True,  resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:lock_screen":   OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:open_settings": OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:file_explorer": OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:open_run":      OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:dark_mode":     OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:toggle_wifi":   OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:restart":       OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:shutdown":      OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:sleep_display": OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:pause_video":   OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
    "computer_settings:reload_n":      OperationSpec("input.simulate",                       idempotent=False, read_only=False, resource_scope=ResourceScope.LOCAL_SYSTEM),
}


class PermissionGuard:
    """Central enforcement point — validates exact operation, consumes approval."""

    def __init__(self, pm: PermissionManager):
        self.pm = pm
        self._initialized = False

    def initialize(self) -> None:
        self._initialized = True

    def check_operation(self, operation_name: str, parameters: dict) -> PermissionResult:
        """Validate exact operation with parameters. Consumes approval if needed."""
        if not self._initialized:
            return PermissionResult(False, "guard_uninitialized")

        spec = OPERATION_SPECS.get(operation_name)
        if not spec:
            # Unknown operation — deny by default
            return PermissionResult(False, f"unknown_operation:{operation_name}")

        project = spec.get_project(parameters)
        identity = OperationIdentity.create(
            capability=spec.capability,
            project_path=project,
            template_id=spec.template_id or spec.capability,
            args=spec.get_template_args(parameters),
            requesting_component=operation_name.split(":")[0],
        )

        # Check persistent grant first
        grant_result = self.pm.check(
            spec.capability, project,
            template_id=spec.template_id,
            args=spec.get_template_args(parameters),
            requesting_component=operation_name.split(":")[0],
        )
        if grant_result.allowed:
            # Check additional capabilities
            for cap in spec.additional_caps:
                add_result = self.pm.check(cap, project, requesting_component=operation_name.split(":")[0])
                if not add_result.allowed:
                    return add_result
            return grant_result

        # No grant — check if approval can be requested
        if not grant_result.requires_approval:
            return grant_result  # Denied, no approval available

        # Request approval
        return grant_result

    def consume_approval(self, token: ApprovalToken, verified: bool) -> PermissionResult:
        """Atomically consume one-time approval token. Called by auth_dialog callback."""
        if not self._initialized:
            return PermissionResult(False, "guard_uninitialized")
        return self.pm._consume_approval(token, verified)

    def wrap_handler(self, handler: Callable, operation_name: str) -> Callable:
        """Wrap action/plugin handler for model-triggered execution."""
        def guarded(parameters: dict, **ctx) -> str:
            result = self.check_operation(operation_name, parameters)
            if not result.allowed:
                if result.reason == "approval_required":
                    return result.instruction  # Model reads this, asks user to auth
                from core import outcome
                return outcome.failed(operation_name, result.reason)

            # For proc.exec: validate command template
            spec = OPERATION_SPECS.get(operation_name)
            if spec and spec.capability == "proc.exec" and spec.template_id:
                validation = validate_template(spec.template_id, spec.get_template_args(parameters))
                if not validation.allowed:
                    from core import outcome
                    return outcome.failed("proc.exec", validation.reason)
                # Store validated command for handler to use
                parameters["_validated_command"] = validation.command
                parameters["_validated_cwd"] = validation.cwd

            return handler(parameters, **ctx)
        return guarded


# Global instance
_guard: PermissionGuard | None = None


def get_permission_guard() -> PermissionGuard:
    global _guard
    if _guard is None:
        from core.permission_manager import get_permission_manager
        _guard = PermissionGuard(get_permission_manager())
    return _guard


def reset_global_guard() -> None:
    """Reset the global permission guard (for testing)."""
    global _guard
    _guard = None


def initialize_global_guard() -> PermissionGuard:
    """Initialize the global permission guard (for testing)."""
    guard = get_permission_guard()
    guard.initialize()
    return guard


def guarded_call(operation_name: str, parameters: dict, handler: Callable) -> str:
    """Call handler with permission check. Use for internal action-to-action calls."""
    guard = get_permission_guard()
    result = guard.check_operation(operation_name, parameters)
    if not result.allowed:
        from core import outcome
        return outcome.failed(operation_name, result.reason)
    return handler(parameters)