"""
core/permission_fingerprint.py — canonical operation identity and approval tokens.

Separates STABLE operation identity (for rate limiting, grant lookup) from
ONE-TIME approval tokens (nonce-bound, for exact-match verification).
"""

from __future__ import annotations

import hashlib
import json
import secrets
from dataclasses import dataclass, replace
from typing import Any
from pathlib import Path


# Supported types with type tags for canonical serialization
_TYPE_TAGS = {
    str: "s", int: "i", float: "f", bool: "b", type(None): "n",
    list: "l", dict: "d",
}


def _canonical_value(v: Any) -> bytes:
    """Serialize single value with type preservation."""
    if isinstance(v, str):
        return b"s:" + json.dumps(v, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    elif isinstance(v, bool):
        return b"b:" + (b"1" if v else b"0")
    elif isinstance(v, int):
        return b"i:" + str(v).encode("ascii")
    elif isinstance(v, float):
        if not (v == v and abs(v) != float("inf")):  # NaN/inf rejected
            raise ValueError("Non-finite float not allowed")
        return b"f:" + json.dumps(v, separators=(",", ":")).encode("ascii")
    elif v is None:
        return b"n:"
    elif isinstance(v, list):
        return b"l:" + b"".join(_canonical_value(item) for item in v)
    elif isinstance(v, dict):
        return b"d:" + _canonical_mapping(v)
    else:
        raise TypeError(f"Unsupported type: {type(v)}")


def _canonical_mapping(obj: dict[str, Any]) -> bytes:
    """Deterministic dict serialization: sorted keys, typed values."""
    if not obj:
        return b"{}"
    parts = []
    for k in sorted(obj.keys()):
        if not isinstance(k, str):
            raise TypeError("Dict keys must be strings")
        parts.append(k.encode("utf-8"))
        parts.append(b":")
        parts.append(_canonical_value(obj[k]))
    return b"{" + b",".join(parts) + b"}"


@dataclass(frozen=True, slots=True)
class OperationIdentity:
    """Stable operation identity — NO nonce, used for rate limiting and grant lookup.

    Immutable snapshot of the exact operation being requested.
    """
    capability: str
    project_id: str          # Canonical absolute path
    template_id: str         # Exact template identifier
    arguments: dict[str, Any] # Typed arguments (immutable snapshot)
    requesting_component: str

    def __post_init__(self):
        # Normalize project_id to absolute path with forward slashes
        normalized = str(Path(self.project_id).resolve()).replace("\\", "/").rstrip("/")
        object.__setattr__(self, "project_id", normalized)
        # Freeze arguments as canonical JSON (deterministic, type-preserving)
        object.__setattr__(self, "arguments",
                          json.loads(json.dumps(self.arguments, sort_keys=True)))

    def identity_key(self) -> str:
        """Key for rate limiting and grant lookup — NO nonce."""
        return f"{self.capability}|{self.project_id}|{self.template_id}|{self.requesting_component}"

    def canonical_bytes(self) -> bytes:
        """Full canonical representation for hashing."""
        return b"".join([
            b"cap:", self.capability.encode("utf-8"),
            b"|prj:", self.project_id.encode("utf-8"),
            b"|tpl:", self.template_id.encode("utf-8"),
            b"|arg:", _canonical_mapping(self.arguments),
            b"|req:", self.requesting_component.encode("utf-8"),
        ])

    def identity_hash(self) -> str:
        """SHA-256 of canonical identity (32 hex chars)."""
        return hashlib.sha256(self.canonical_bytes()).hexdigest()[:32]

    @classmethod
    def create(cls, capability: str, project_path: Path, template_id: str,
               args: dict[str, Any], requesting_component: str) -> "OperationIdentity":
        from memory.config_manager import BASE_DIR

        base_resolved = BASE_DIR.resolve()
        project_resolved = project_path.resolve()
        if not project_resolved.is_relative_to(base_resolved):
            raise ValueError(f"Project path {project_path} outside permitted scope {BASE_DIR}")

        return cls(
            capability=capability,
            project_id=str(project_resolved),
            template_id=template_id,
            arguments=args,
            requesting_component=requesting_component,
        )


@dataclass(frozen=True, slots=True)
class ApprovalToken:
    """One-time approval token — includes nonce, bound to exact OperationIdentity.

    Each request gets a unique token. Verification consumes the token atomically.
    """
    identity: OperationIdentity
    nonce: bytes  # 16 random bytes

    def token_hash(self) -> str:
        """SHA-256 of identity + nonce — unique per request."""
        return hashlib.sha256(self.identity.canonical_bytes() + b"|non:" + self.nonce).hexdigest()[:32]

    @classmethod
    def create(cls, identity: OperationIdentity) -> "ApprovalToken":
        return cls(identity=identity, nonce=secrets.token_bytes(16))