"""
Monitoring and recovery implementation for autonomous tasks (Task 3 Batch 3).
"""

import threading
import time
import json
from dataclasses import dataclass, field
from typing import Optional, Callable, Union
from enum import Enum

from core.autonomous_agent import StepState, TaskState, ExecutionResult, TaskPlan, TaskStep
from core.error_classification import (
    ErrorClass,
    ClassifiedError,
    classify_error,
    classify_error_string,
    classify_error_string_wrapped,
    is_retry_eligible,
)

# Config
STEP_TIMEOUT = 60.0  # seconds
TOTAL_TASK_TIMEOUT = 600.0  # seconds
MAX_RETRIES = 3

# Backward-compatible alias for existing code
ErrorClassification = ErrorClass

def get_backoff_delay(retry_count: int) -> float:
    """Exponential backoff: 1s, 2s, 4s."""
    return float(2 ** (retry_count - 1))

class TaskMonitor:
    """Monitors task execution, enforces timeouts, and handles retries."""

    def __init__(self, plan: TaskPlan, player=None):
        self.plan = plan
        self.player = player
        self.start_time = time.time()
        self.lock = threading.Lock()

    def check_overall_timeout(self) -> bool:
        return (time.time() - self.start_time) > TOTAL_TASK_TIMEOUT

    def report_progress(self, message: str):
        if self.player:
            self.player.write_log(f"[TaskMonitor] {message}")
        print(f"[TaskMonitor] {message}")

class TaskRecovery:
    """Handles recovery of failed steps."""

    @staticmethod
    def handle_failure(step: TaskStep, error: Union[str, BaseException, ClassifiedError], is_idempotent: bool = False) -> bool:
        """
        Determines if a step should be retried.

        Args:
            step: The task step that failed.
            error: Error message (str), exception (BaseException), or ClassifiedError.
            is_idempotent: Whether the operation is idempotent (safe to retry).
        """
        # Classify the error
        if isinstance(error, ClassifiedError):
            classified = error
        elif isinstance(error, BaseException):
            classified = classify_error(error)
        else:
            # Backward compatibility: string-based classification wrapped in ClassifiedError
            classified = classify_error_string_wrapped(str(error))

        # Check retry eligibility using typed classification
        if not is_retry_eligible(classified, is_idempotent):
            return False
        if step.retry_count >= MAX_RETRIES:
            return False
        return True
