"""
core/windows_acl.py — Windows ACL verification and secure file/directory creation.

Verifies EXACTLY: 2 ACEs (Owner + SYSTEM), FILE_ALL_ACCESS, no inheritance, protected DACL.
"""

from __future__ import annotations

import os
import platform
from pathlib import Path

# Module-level imports for patching in tests
try:
    import ntsecuritycon
except ImportError:
    ntsecuritycon = None
try:
    import win32security
except ImportError:
    win32security = None
try:
    import win32api
except ImportError:
    win32api = None
try:
    import win32con
except ImportError:
    win32con = None
try:
    import win32file
except ImportError:
    win32file = None


def _log_internal(msg: str) -> None:
    # Avoid circular import — called from core/permission_manager.py after bind
    try:
        from core.auth_dialog import _log
        _log(msg)
    except Exception:
        pass


def _get_current_user_sid():
    if win32api is None or win32con is None or win32security is None:
        raise RuntimeError("pywin32 not available")
    pid = os.getpid()
    handle = win32api.OpenProcess(win32con.PROCESS_QUERY_INFORMATION, False, pid)
    token = win32security.OpenProcessToken(handle, win32con.TOKEN_QUERY)
    return win32security.GetTokenInformation(token, win32security.TokenUser)[0]


def _get_system_sid():
    if win32security is None:
        raise RuntimeError("pywin32 not available")
    return win32security.CreateWellKnownSid(win32security.WinLocalSystemSid)


def _build_restrictive_dacl():
    if win32security is None or ntsecuritycon is None:
        raise RuntimeError("pywin32 not available")
    user_sid = _get_current_user_sid()
    system_sid = _get_system_sid()
    dacl = win32security.ACL()
    dacl.AddAccessAllowedAce(win32security.ACL_REVISION, ntsecuritycon.FILE_ALL_ACCESS, user_sid)
    dacl.AddAccessAllowedAce(win32security.ACL_REVISION, ntsecuritycon.FILE_ALL_ACCESS, system_sid)
    return dacl


def _build_restrictive_sd(dacl):
    if win32security is None:
        raise RuntimeError("pywin32 not available")
    sd = win32security.SECURITY_DESCRIPTOR()
    sd.SetSecurityDescriptorDacl(1, dacl, 0)  # present=1, defaulted=0
    # SE_DACL_PROTECTED flag (0x1000) prevents inheritance
    # SetSecurityDescriptorControl(value, mask) - set bit 0x1000 in control
    sd.SetSecurityDescriptorControl(0x1000, 0x1000)
    return sd


def verify_restrictive_acl(path: Path) -> bool:
    """Verify EXACTLY: 2 ACEs (Owner+SYSTEM), FILE_ALL_ACCESS, no inheritance, protected DACL."""
    if platform.system() != "Windows":
        try:
            # On Unix: 0o600 for files, 0o700 for dirs
            mode = os.stat(path).st_mode & 0o777
            if path.is_file():
                return mode == 0o600
            else:
                return mode == 0o700
        except Exception:
            return False

    if win32security is None or ntsecuritycon is None:
        return False

    try:
        user_sid = _get_current_user_sid()
        system_sid = _get_system_sid()

        sd = win32security.GetFileSecurity(
            str(path),
            win32security.DACL_SECURITY_INFORMATION | win32security.OWNER_SECURITY_INFORMATION
        )
        dacl = sd.GetSecurityDescriptorDacl()

        if dacl is None:
            return False

        # Check protected DACL (no inheritance)
        control, _ = sd.GetSecurityDescriptorControl()
        if not (control & 0x1000):  # SE_DACL_PROTECTED
            return False

        ace_count = dacl.GetAceCount()
        if ace_count != 2:
            return False

        # PySID objects are unhashable, so use list for tracking
        expected_sids = [user_sid, system_sid]
        found_sids = []

        for i in range(ace_count):
            ace = dacl.GetAce(i)
            # ACE structure: ((type, flags), mask, sid)
            ace_type, ace_flags = ace[0]
            ace_mask = ace[1]
            ace_sid = ace[2]

            if ace_type != win32security.ACCESS_ALLOWED_ACE_TYPE:
                return False
            if ace_flags != 0:  # No inheritance flags
                return False
            if ace_mask != ntsecuritycon.FILE_ALL_ACCESS:
                return False
            # Check SID matches expected (use string comparison for PySID)
            if not any(str(ace_sid) == str(es) for es in expected_sids):
                return False
            found_sids.append(ace_sid)

        # Verify both expected SIDs were found (exactly 2 ACEs, both match)
        return len(found_sids) == 2
    except Exception:
        return False


def secure_create_directory(path: Path) -> bool:
    """Create directory with protected DACL. Parent directories get default ACL."""
    if platform.system() != "Windows":
        try:
            path.mkdir(parents=True, exist_ok=True, mode=0o700)
            return os.stat(path).st_mode & 0o777 == 0o700
        except Exception:
            return False

    if win32file is None or win32con is None or win32security is None:
        return False

    try:
        dacl = _build_restrictive_dacl()
        sd = _build_restrictive_sd(dacl)
        sa = win32security.SECURITY_ATTRIBUTES()
        sa.SECURITY_DESCRIPTOR = sd
        sa.bInheritHandle = False

        # Create parent directories with default ACL
        path.parent.mkdir(parents=True, exist_ok=True)

        # Create target directory with restrictive ACL
        win32file.CreateDirectory(str(path), sa)
        return verify_restrictive_acl(path)
    except Exception as e:
        _log_internal(f"Secure dir create failed for {path}: {e}")
        return False


def secure_create_file(path: Path, content: bytes = b"") -> bool:
    """Create file with protected DACL atomically."""
    if platform.system() != "Windows":
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            try:
                os.write(fd, content)
            finally:
                os.close(fd)
            return os.stat(path).st_mode & 0o777 == 0o600
        except Exception:
            return False

    if win32file is None or win32con is None or win32security is None:
        return False

    try:
        dacl = _build_restrictive_dacl()
        sd = _build_restrictive_sd(dacl)
        sa = win32security.SECURITY_ATTRIBUTES()
        sa.SECURITY_DESCRIPTOR = sd
        sa.bInheritHandle = False

        path.parent.mkdir(parents=True, exist_ok=True)

        handle = win32file.CreateFile(
            str(path), win32con.GENERIC_WRITE, 0, sa,
            win32con.CREATE_NEW, win32con.FILE_ATTRIBUTE_NORMAL, None
        )
        try:
            if content:
                win32file.WriteFile(handle, content)
        finally:
            win32file.CloseHandle(handle)
        return verify_restrictive_acl(path)
    except Exception as e:
        _log_internal(f"Secure file create failed for {path}: {e}")
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass
        return False


def initialize_config_acl() -> tuple[bool, str]:
    """Startup: ensure config dir and owner_secret have correct ACLs.

    Returns (success, message). If owner_secret missing, returns (False, reason).
    """
    from memory.config_manager import CONFIG_DIR
    config_dir = CONFIG_DIR
    secret_file = config_dir / "owner_secret"

    # Ensure config directory exists with correct ACL
    if not config_dir.exists():
        if not secure_create_directory(config_dir):
            return False, "Failed to create config directory with restrictive ACL"
    elif not verify_restrictive_acl(config_dir):
        if not apply_restrictive_acl(config_dir):
            return False, "Config directory ACL verification failed"

    # owner_secret MUST exist for sensitive operations
    if not secret_file.exists():
        return False, "owner_secret not configured — sensitive operations denied"

    if not verify_restrictive_acl(secret_file):
        return False, "owner_secret ACL verification failed"

    return True, "ACL initialized successfully"


def apply_restrictive_acl(path: Path) -> bool:
    """Apply restrictive ACL to existing file/dir."""
    if platform.system() != "Windows":
        try:
            os.chmod(path, 0o600 if path.is_file() else 0o700)
            return verify_restrictive_acl(path)
        except Exception:
            return False

    if win32security is None:
        return False

    try:
        dacl = _build_restrictive_dacl()
        sd = _build_restrictive_sd(dacl)
        win32security.SetFileSecurity(str(path), win32security.DACL_SECURITY_INFORMATION, sd)
        return verify_restrictive_acl(path)
    except Exception as e:
        _log_internal(f"ACL apply failed for {path}: {e}")
        return False