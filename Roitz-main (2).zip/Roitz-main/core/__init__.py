"""
core package — shared infrastructure for JARVIS.

Exports:
- outcome: three-state tool results (done/unverified/failed/ask/started)
- confirm: UI-issued confirmation gate for irreversible actions
- undo: thread-safe undo stack
- gemini: model ladder with deadlines and fallback
- lazyimport: lazy module loading
- appidentity: process identity and self-protection
- permission_manager: capability-based permission system
- auth_dialog: owner authentication dialog
- auth_rate_limiter: authentication rate limiting
- permission_fingerprint: operation identity and approval tokens
- permission_store: pending approvals and persistent grants
- windows_acl: Windows ACL verification
- command_templates: approved command templates
- permission_guard: central enforcement for actions/plugins
"""

from .outcome import (
    done, unverified, failed, ask, started,
    untrusted, unwrap, is_problem,
    DONE, UNVERIFIED, FAILED, ASK, STARTED,
)
from .confirm import request as confirm_request, resolve as confirm_resolve, bind as confirm_bind, pending_title
from .undo import push_undo, can_undo, peek, history, undo_last, clear, MAX_DEPTH
from .gemini import text as gemini_text, as_json as gemini_as_json, call as gemini_call, FAST, SMART, SEARCH
from .lazyimport import LazyModule, installed
from .appidentity import running, snapshot, wait_for_launch, request_close, focus, own_pids, own_exes, launcher_name
from .permission_manager import get_permission_manager, PermissionManager
from .auth_dialog import bind as auth_bind, request_auth, resolve_auth
from .auth_rate_limiter import get_rate_limiter
from .permission_fingerprint import OperationIdentity, ApprovalToken
from .permission_store import PendingApproval, PermissionGrant, PermissionResult
from .windows_acl import verify_restrictive_acl, secure_create_directory, secure_create_file, initialize_config_acl
from .command_templates import initialize_templates, validate_template, get_template, list_templates
from .permission_guard import get_permission_guard, PermissionGuard, OPERATION_SPECS, guarded_call

__all__ = [
    # outcome
    "done", "unverified", "failed", "ask", "started",
    "untrusted", "unwrap", "is_problem",
    "DONE", "UNVERIFIED", "FAILED", "ASK", "STARTED",
    # confirm
    "confirm_request", "confirm_resolve", "confirm_bind", "pending_title",
    # undo
    "push_undo", "can_undo", "peek", "history", "undo_last", "clear", "MAX_DEPTH",
    # gemini
    "gemini_text", "gemini_as_json", "gemini_call", "FAST", "SMART", "SEARCH",
    # lazyimport
    "LazyModule", "installed",
    # appidentity
    "running", "snapshot", "wait_for_launch", "request_close", "focus", "own_pids", "own_exes", "launcher_name",
    # permission system
    "get_permission_manager", "PermissionManager",
    "auth_bind", "request_auth", "resolve_auth",
    "get_rate_limiter",
    "OperationIdentity", "ApprovalToken",
    "PendingApproval", "PermissionGrant", "PermissionResult",
    "verify_restrictive_acl", "secure_create_directory", "secure_create_file", "initialize_config_acl",
    "initialize_templates", "validate_template", "get_template", "list_templates",
    "get_permission_guard", "PermissionGuard", "OPERATION_SPECS", "guarded_call",
]