"""
core/permission_manager.py — central capability-based permission system.

- Capability registry with per-project scopes
- Explicit owner approval via authentication dialog
- JSONL audit logging
- Thread-safe operation
- Safe defaults (deny unknown)
"""

from __future__ import annotations

import json
import os
import platform
import threading
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from core.auth_dialog import request_auth, resolve_auth, cleanup_expired, bind as auth_bind
from core.auth_rate_limiter import get_rate_limiter
from core.command_templates import initialize_templates, validate_template, get_template
from core.permission_fingerprint import OperationIdentity, ApprovalToken
from core.permission_store import PendingApproval, PermissionGrant, PermissionResult
from core.windows_acl import initialize_config_acl, verify_restrictive_acl, secure_create_file
from memory.config_manager import BASE_DIR, CONFIG_DIR


# ──────────────────────────────────────────────────────────────────────────────
# Capability definitions
# ──────────────────────────────────────────────────────────────────────────────

# Each capability maps to a human-readable description and required scopes
CAPABILITIES: dict[str, dict] = {
    "fs.read": {
        "description": "Read files and list directories",
        "scopes": ["project"],
        "risk": "low",
    },
    "fs.write": {
        "description": "Create or modify files",
        "scopes": ["project"],
        "risk": "medium",
    },
    "fs.delete": {
        "description": "Delete files or directories",
        "scopes": ["project"],
        "risk": "high",
    },
    "fs.move": {
        "description": "Move or rename files/directories",
        "scopes": ["project"],
        "risk": "medium",
    },
    "proc.exec": {
        "description": "Execute approved command templates",
        "scopes": ["project", "template"],
        "risk": "high",
    },
    "input.simulate": {
        "description": "Simulate keyboard/mouse input",
        "scopes": ["global"],
        "risk": "high",
    },
    "screen.capture": {
        "description": "Capture screen or camera frames",
        "scopes": ["global"],
        "risk": "medium",
    },
    "browser.navigate": {
        "description": "Navigate browser to URL",
        "scopes": ["global"],
        "risk": "medium",
    },
    "browser.execute": {
        "description": "Execute JavaScript in browser",
        "scopes": ["global"],
        "risk": "high",
    },
    "messaging.send": {
        "description": "Send messages via WhatsApp/Telegram",
        "scopes": ["global"],
        "risk": "high",
    },
    "net.egress": {
        "description": "Make outbound network connections",
        "scopes": ["global"],
        "risk": "high",
    },
    "remote.command": {
        "description": "Execute remote control commands via Telegram",
        "scopes": ["global"],
        "risk": "high",
    },
    "system.monitor": {
        "description": "Read system metrics (CPU, RAM, GPU, temperature)",
        "scopes": ["global"],
        "risk": "low",
    },
    "system.shutdown": {
        "description": "Shut down the JARVIS assistant",
        "scopes": ["global"],
        "risk": "high",
    },
    "memory.write": {
        "description": "Write personal facts to long-term memory",
        "scopes": ["global"],
        "risk": "high",
    },
    "app.manage": {
        "description": "Manage applications (close, focus)",
        "scopes": ["global"],
        "risk": "high",
    },
}

# Operations requiring explicit owner approval (even with grant)
OWNER_APPROVAL_REQUIRED = {
    "fs.delete",
    "fs.move",          # Can be destructive
    "proc.exec",        # Template-dependent
    "input.simulate",   # Can affect other apps
    "messaging.send",
    "net.egress",
    "remote.command",   # Remote control via Telegram
    "system.shutdown",  # Shuts down the assistant
    "memory.write",     # Write personal facts to long-term memory
    "app.manage",       # Manage applications (close, focus)
}

# Operations that are read-only / low risk (auto-allow if in scope)
AUTO_ALLOW = {
    "fs.read",
    "screen.capture",
    "browser.navigate",
    "system.monitor",
}


# ──────────────────────────────────────────────────────────────────────────────
# Persistent grant storage
# ──────────────────────────────────────────────────────────────────────────────

_PERMISSIONS_FILE = CONFIG_DIR / "permissions.json"
_permissions_lock = threading.Lock()
_grants_cache: dict[str, PermissionGrant] = {}  # identity_hash -> grant


def _load_grants() -> dict[str, PermissionGrant]:
    global _grants_cache
    with _permissions_lock:
        if _grants_cache:
            return _grants_cache
        if not _PERMISSIONS_FILE.exists():
            _grants_cache = {}
            return _grants_cache
        try:
            data = json.loads(_PERMISSIONS_FILE.read_text(encoding="utf-8"))
            grants = {}
            for item in data.get("grants", []):
                grant = PermissionGrant(**item)
                if not grant.is_expired():
                    grants[grant.identity_hash] = grant
            _grants_cache = grants
            return grants
        except Exception:
            _grants_cache = {}
            return _grants_cache


def _save_grants(grants: dict[str, PermissionGrant]) -> None:
    with _permissions_lock:
        _grants_cache = grants
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        data = {"grants": [asdict(g) for g in grants.values()]}
        _PERMISSIONS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


# ──────────────────────────────────────────────────────────────────────────────
# Audit logging
# ──────────────────────────────────────────────────────────────────────────────

_AUDIT_FILE = CONFIG_DIR / "permissions_audit.jsonl"
_audit_lock = threading.Lock()


def _audit_log(entry: dict) -> None:
    """Append to JSONL audit log. Never raises."""
    try:
        with _audit_lock:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            entry["timestamp"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
            existing = _AUDIT_FILE.read_text(encoding="utf-8") if _AUDIT_FILE.exists() else ""
            _AUDIT_FILE.write_text(
                existing + json.dumps(entry) + "\n",
                encoding="utf-8"
            )
    except Exception:
        pass


# ──────────────────────────────────────────────────────────────────────────────
# Pending approvals (in-memory, per-request)
# ──────────────────────────────────────────────────────────────────────────────

_pending_lock = threading.Lock()
_pending_approvals: dict[str, PendingApproval] = {}  # token_hash -> approval


# ──────────────────────────────────────────────────────────────────────────────
# PermissionManager
# ──────────────────────────────────────────────────────────────────────────────

_manager_instance: Optional["PermissionManager"] = None
_manager_lock = threading.Lock()


class PermissionManager:
    """Central permission management."""

    def __init__(self):
        self._initialized = False
        self._ui_bound = False
        self._config_acl_ok = False
        self._owner_secret_hash: bytes | None = None

    def initialize(self) -> tuple[bool, str]:
        """Full initialization: ACL check, command templates, owner secret load."""
        if self._initialized:
            return True, "Already initialized"

        # 1. Verify Windows ACLs / Unix perms on config
        acl_ok, acl_msg = initialize_config_acl()
        self._config_acl_ok = acl_ok
        if not acl_ok:
            return False, acl_msg

        # 2. Load owner secret hash
        secret_file = CONFIG_DIR / "owner_secret"
        try:
            self._owner_secret_hash = secret_file.read_bytes()
        except Exception:
            return False, "Failed to read owner_secret"

        # 3. Initialize command templates
        initialize_templates(BASE_DIR)

        # 4. Bind auth dialog callbacks (set by main.py after UI ready)
        auth_bind(
            show=self._show_auth,
            hide=self._hide_auth,
            log=self._log
        )

        self._initialized = True
        return True, "Permission manager initialized"

    # Callbacks set by main.py
    def _show_auth(self, token_hash: str, title: str, detail: str) -> None:
        """Override in main.py after UI ready."""
        pass

    def _hide_auth(self) -> None:
        pass

    def _log(self, msg: str) -> None:
        pass

    def bind_ui(self, show, hide, log) -> None:
        """Called by main.py after UI is created."""
        self._show_auth = show
        self._hide_auth = hide
        self._log = log
        self._ui_bound = True

    def _verify_owner_secret(self, provided: bytes) -> bool:
        """Constant-time comparison of provided secret with stored hash."""
        import hmac
        if self._owner_secret_hash is None:
            return False
        # Stored format: "argon2id$v=19$m=...,t=...,p=...$salt$hash"
        # We verify using argon2-cffi
        try:
            from argon2 import PasswordHasher
            ph = PasswordHasher()
            ph.verify(self._owner_secret_hash.decode("utf-8"), provided.decode("utf-8"))
            return True
        except Exception:
            return False

    # ──────────────────────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────────────────────

    def check(self, capability: str, project_path: Path, *,
              template_id: str | None = None,
              args: dict | None = None,
              requesting_component: str = "unknown") -> PermissionResult:
        """Check if an operation is allowed.

        Returns PermissionResult with allowed=True/False and reason.
        If approval required, includes instruction for model and token.
        """
        if not self._initialized:
            return PermissionResult(False, "not_initialized")

        if not self._config_acl_ok:
            return PermissionResult(False, "config_acl_failed")

        if capability not in CAPABILITIES:
            return PermissionResult(False, f"unknown_capability:{capability}")

        # Build operation identity
        try:
            identity = OperationIdentity.create(
                capability=capability,
                project_path=project_path,
                template_id=template_id or capability,
                args=args or {},
                requesting_component=requesting_component,
            )
        except ValueError as e:
            return PermissionResult(False, f"invalid_project:{e}")

        # Check persistent grant
        grant_result = self._check_grant(identity)
        if grant_result.allowed:
            _audit_log({
                "event": "grant_allowed",
                "capability": capability,
                "project": identity.project_id,
                "template": identity.template_id,
                "component": requesting_component,
            })
            return grant_result

        # No grant — check if approval can be requested
        if not grant_result.requires_approval:
            return grant_result  # Denied, no approval path

        # Request approval (creates token, shows auth dialog)
        token = ApprovalToken.create(identity)
        approval_instruction = self._request_approval(identity, token)

        return PermissionResult(
            False, "approval_required",
            instruction=approval_instruction,
            identity=identity,
            token=token,
            requires_approval=True,
        )

    def _check_grant(self, identity: OperationIdentity) -> PermissionResult:
        """Check persistent grants for exact identity match."""
        grants = _load_grants()
        grant = grants.get(identity.identity_hash())
        if grant:
            return PermissionResult(True, "granted", identity=identity)

        # Check if capability is auto-allow
        if identity.capability in AUTO_ALLOW:
            # Verify project scope
            return PermissionResult(True, "auto_allow", identity=identity)

        # Check if capability requires owner approval
        if identity.capability in OWNER_APPROVAL_REQUIRED:
            return PermissionResult(False, "owner_approval_required",
                                    requires_approval=True, identity=identity)

        # Unknown capability — deny
        return PermissionResult(False, "no_grant", requires_approval=False, identity=identity)

    def _request_approval(self, identity: OperationIdentity, token: ApprovalToken, task_id: Optional[str] = None) -> str:
        """Register pending approval and show auth dialog. Returns instruction for model."""
        token_hash = token.token_hash()

        with _pending_lock:
            _pending_approvals[token_hash] = PendingApproval(token=token, task_id=task_id)

        title = f"{identity.capability} — {identity.template_id}"
        detail = (
            f"Component: {identity.requesting_component}\n"
            f"Project: {identity.project_id}\n"
            f"Arguments: {json.dumps(identity.arguments, separators=(',', ':'))}"
        )

        def _resolve_cb(verified: bool):
            self._consume_approval(token, verified)

        return request_auth(token, title, detail, _resolve_cb, task_id=task_id)

    def _consume_approval(self, token: ApprovalToken, verified: bool) -> PermissionResult:
        """Atomically consume one-time approval token."""
        token_hash = token.token_hash()

        with _pending_lock:
            pending = _pending_approvals.get(token_hash)
            if not pending or pending.consumed:
                return PermissionResult(False, "approval_not_found_or_consumed")
            if pending.cancelled:
                _pending_approvals.pop(token_hash, None)
                return PermissionResult(False, "approval_cancelled_by_interrupt")
            if time.monotonic() > pending.expires_at:
                _pending_approvals.pop(token_hash, None)
                return PermissionResult(False, "approval_expired")

            # EXACT identity match (prevents substitution)
            if pending.token.identity.canonical_bytes() != token.identity.canonical_bytes():
                return PermissionResult(False, "identity_mismatch")

            if not verified:
                _pending_approvals.pop(token_hash, None)
                return PermissionResult(False, "auth_not_verified")

            pending.verified = True
            pending.consumed = True

        # Grant persistent permission for this exact identity
        grant = PermissionGrant(
            capability=token.identity.capability,
            project_id=token.identity.project_id,
            granted_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            expires_at=None,
            approved_by="owner",
            identity_hash=token.identity.identity_hash(),
        )
        grants = _load_grants()
        grants[grant.identity_hash] = grant
        _save_grants(grants)

        _audit_log({
            "event": "approval_consumed",
            "capability": token.identity.capability,
            "project": token.identity.project_id,
            "template": token.identity.template_id,
            "component": token.identity.requesting_component,
            "granted": True,
        })

        # Remove pending
        with _pending_lock:
            _pending_approvals.pop(token_hash, None)

        return PermissionResult(True, "approved", identity=token.identity)

    def cancel_for_task(self, task_id: str) -> int:
        """
        Cancel all pending approvals for the specified task.

        Called when a task is interrupted (e.g., voice barge-in). Marks
        each matching pending approval as cancelled so it cannot be consumed.
        Also cancels the corresponding auth dialog.

        Returns the number of cancelled approvals.
        """
        if not task_id:
            return 0

        cancelled = 0
        with _pending_lock:
            for pending in _pending_approvals.values():
                if pending.task_id == task_id and not pending.cancelled and not pending.consumed:
                    pending.cancelled = True
                    cancelled += 1

        if cancelled > 0:
            # Also cancel the auth dialog for this task
            from core.auth_dialog import cancel_for_task as cancel_auth_for_task
            cancel_auth_for_task(task_id)

            # Remove any grants that were created for this task
            grants = _load_grants()
            grants_to_remove = [
                grant.identity_hash
                for grant in grants.values()
                if grant.approved_by == "owner" and grant.task_id == task_id
            ]
            for identity_hash in grants_to_remove:
                grants.pop(identity_hash, None)
            _save_grants(grants)

        return cancelled

    def grant_permission(self, capability: str, project_path: Path, *,
                         template_id: str | None = None,
                         args: dict | None = None) -> PermissionResult:
        """Manually grant permission (for testing or admin)."""
        if not self._initialized:
            return PermissionResult(False, "not_initialized")

        identity = OperationIdentity.create(
            capability=capability,
            project_path=project_path,
            template_id=template_id or capability,
            args=args or {},
            requesting_component="manual",
        )

        grant = PermissionGrant(
            capability=capability,
            project_id=identity.project_id,
            granted_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            expires_at=None,
            approved_by="owner",
            identity_hash=identity.identity_hash(),
        )
        grants = _load_grants()
        grants[grant.identity_hash] = grant
        _save_grants(grants)
        return PermissionResult(True, "granted_manually", identity=identity)

    def revoke_permission(self, capability: str, project_path: Path, *,
                          template_id: str | None = None,
                          args: dict | None = None) -> bool:
        """Revoke a persistent grant."""
        identity = OperationIdentity.create(
            capability=capability,
            project_path=project_path,
            template_id=template_id or capability,
            args=args or {},
            requesting_component="manual",
        )
        grants = _load_grants()
        if identity.identity_hash() in grants:
            del grants[identity.identity_hash()]
            _save_grants(grants)
            return True
        return False

    def list_grants(self) -> list[PermissionGrant]:
        return list(_load_grants().values())

    def validate_proc_exec(self, template_id: str, args: dict) -> tuple[bool, str, list[str] | None]:
        """Validate a proc.exec command template."""
        result = validate_template(template_id, args)
        return result.allowed, result.reason, result.command

    def get_template(self, template_id: str):
        return get_template(template_id)

    def cleanup(self) -> None:
        """Periodic cleanup of expired pending approvals."""
        cleanup_expired()


def get_permission_manager() -> PermissionManager:
    global _manager_instance
    with _manager_lock:
        if _manager_instance is None:
            _manager_instance = PermissionManager()
        return _manager_instance


def reset_permission_manager() -> None:
    """Reset the global permission manager (for testing)."""
    global _manager_instance
    with _manager_lock:
        _manager_instance = None


def initialize_permission_manager_for_test() -> PermissionManager:
    """Initialize the permission manager for testing (skips ACL and owner secret checks)."""
    global _manager_instance
    with _manager_lock:
        if _manager_instance is None:
            _manager_instance = PermissionManager()
        # Initialize without ACL check and owner secret
        _manager_instance._config_acl_ok = True
        _manager_instance._owner_secret_hash = b"test_hash"
        _manager_instance._initialized = True
        # Initialize command templates
        from core.command_templates import initialize_templates
        from memory.config_manager import BASE_DIR
        initialize_templates(BASE_DIR)
        return _manager_instance