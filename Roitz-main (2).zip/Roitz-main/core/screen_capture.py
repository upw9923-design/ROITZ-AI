"""
core/screen_capture.py — Unified Screen Capture API.

Centralized capture functions supporting:
- Primary monitor capture (default)
- Multi-monitor selection by index
- Arbitrary region capture (x, y, width, height)
- Monitor enumeration and validation
- Image compression/encoding

All functions handle compression and return (bytes, mime_type) tuples.
Camera capture remains in actions/screen_processor.py.
"""
from __future__ import annotations

import io
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Tuple

from core.lazyimport import LazyModule, installed

try:
    import mss
    import mss.tools
    _MSS = True
except ImportError:
    _MSS = False

try:
    import PIL.Image
    _PIL = True
except ImportError:
    _PIL = False


# ──────────────────────────────────────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────────────────────────────────────

_IMG_MAX_W = 1280
_IMG_MAX_H = 720
_JPEG_Q    = 82


# ──────────────────────────────────────────────────────────────────────────────
# Data Classes
# ──────────────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class MonitorInfo:
    """Information about a detected monitor."""
    index: int              # mss monitor index (0 = all, 1..n = individual)
    x: int                  # Left coordinate
    y: int                  # Top coordinate
    width: int              # Width in pixels
    height: int             # Height in pixels
    is_primary: bool        # True for the primary monitor (index 1 on Windows/macOS)

    @property
    def name(self) -> str:
        """Human-readable monitor name."""
        if self.index == 0:
            return "All Monitors (combined)"
        return f"Monitor {self.index}" + (" (primary)" if self.is_primary else "")


@dataclass(frozen=True)
class CaptureRegion:
    """A rectangular screen region to capture."""
    x: int
    y: int
    width: int
    height: int

    def __post_init__(self) -> None:
        if self.width <= 0 or self.height <= 0:
            raise ValueError("Region width and height must be positive")
        if self.x < 0 or self.y < 0:
            raise ValueError("Region coordinates cannot be negative")


# ──────────────────────────────────────────────────────────────────────────────
# Internal Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _compress(img_bytes: bytes, source_format: str = "PNG") -> Tuple[bytes, str]:
    """Compress image bytes to JPEG with size limits."""
    if not _PIL:
        return img_bytes, f"image/{source_format.lower()}"

    try:
        img = PIL.Image.open(io.BytesIO(img_bytes)).convert("RGB")
        img.thumbnail((_IMG_MAX_W, _IMG_MAX_H), PIL.Image.BILINEAR)
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=_JPEG_Q, optimize=False)
        return buf.getvalue(), "image/jpeg"
    except Exception as e:
        print(f"[ScreenCapture] ⚠️  Image compress failed: {e}")
        return img_bytes, f"image/{source_format.lower()}"


def _get_monitors() -> list:
    """Get monitor list from mss. Returns list of monitor dicts."""
    if not _MSS:
        raise RuntimeError("mss is not installed. Run: pip install mss")

    with mss.mss() as sct:
        return sct.monitors  # [0] = all combined, [1..n] = individual screens


def get_monitor_info() -> list[MonitorInfo]:
    """
    Get information about all available monitors.

    Returns list of MonitorInfo, where index 0 is the combined virtual monitor
    and indices 1..n are individual physical monitors.
    """
    monitors = _get_monitors()
    info = []

    for i, mon in enumerate(monitors):
        is_primary = (i == 1)  # mss convention: monitor 1 is primary
        info.append(MonitorInfo(
            index=i,
            x=mon["left"],
            y=mon["top"],
            width=mon["width"],
            height=mon["height"],
            is_primary=is_primary,
        ))

    return info


def validate_monitor_index(monitor_index: int) -> None:
    """Validate that a monitor index exists. Raises ValueError if invalid."""
    monitors = _get_monitors()
    if monitor_index < 0 or monitor_index >= len(monitors):
        raise ValueError(
            f"Monitor index {monitor_index} out of range. "
            f"Available: 0 (all) to {len(monitors) - 1} ({len(monitors) - 1} physical monitors)"
        )


def validate_region(region: CaptureRegion, monitor_index: int = 0) -> None:
    """Validate that a region falls within the specified monitor bounds."""
    monitors = _get_monitors()
    target = monitors[monitor_index] if monitor_index < len(monitors) else monitors[0]

    if region.x < target["left"] or region.y < target["top"]:
        raise ValueError(
            f"Region origin ({region.x}, {region.y}) is outside monitor {monitor_index} "
            f"bounds ({target['left']}, {target['top']})"
        )

    if (region.x + region.width > target["left"] + target["width"] or
            region.y + region.height > target["top"] + target["height"]):
        raise ValueError(
            f"Region extends beyond monitor {monitor_index} bounds "
            f"({target['width']}x{target['height']} at {target['left']},{target['top']})"
        )


# ──────────────────────────────────────────────────────────────────────────────
# Public Capture API (Screen/Monitor only — camera stays in screen_processor)
# ──────────────────────────────────────────────────────────────────────────────

def capture_primary_monitor() -> Tuple[bytes, str]:
    """
    Capture the primary monitor (monitor index 1).

    Returns:
        (image_bytes, mime_type) tuple. MIME type is typically "image/jpeg"
        after compression, or "image/png" if PIL unavailable.

    Raises:
        RuntimeError: If mss is not installed or capture fails.
    """
    if not _MSS:
        raise RuntimeError("mss is not installed. Run: pip install mss")

    with mss.mss() as sct:
        monitors = sct.monitors
        # Monitor 1 is the primary monitor on Windows/macOS/Linux
        target = monitors[1] if len(monitors) > 1 else monitors[0]
        shot = sct.grab(target)
        png = mss.tools.to_png(shot.rgb, shot.size)

    return _compress(png, "PNG")


def capture_monitor(monitor_index: int) -> Tuple[bytes, str]:
    """
    Capture a specific monitor by index.

    Args:
        monitor_index: Monitor index (1..n for individual monitors, 0 for all combined).

    Returns:
        (image_bytes, mime_type) tuple.

    Raises:
        RuntimeError: If mss is not installed or capture fails.
        ValueError: If monitor_index is out of range.
    """
    if not _MSS:
        raise RuntimeError("mss is not installed. Run: pip install mss")

    validate_monitor_index(monitor_index)

    with mss.mss() as sct:
        monitors = sct.monitors
        target = monitors[monitor_index]
        shot = sct.grab(target)
        png = mss.tools.to_png(shot.rgb, shot.size)

    return _compress(png, "PNG")


def capture_region(
    x: int,
    y: int,
    width: int,
    height: int,
    monitor_index: int = 0
) -> Tuple[bytes, str]:
    """
    Capture an arbitrary rectangular region of the screen.

    Args:
        x: Left coordinate (absolute screen coordinates).
        y: Top coordinate (absolute screen coordinates).
        width: Region width in pixels.
        height: Region height in pixels.
        monitor_index: Monitor to capture from (0 = all monitors combined, 1..n = specific monitor).
                      The region coordinates are absolute screen coordinates regardless of monitor_index.

    Returns:
        (image_bytes, mime_type) tuple.

    Raises:
        RuntimeError: If mss is not installed or capture fails.
        ValueError: If region is invalid or out of bounds.
    """
    if not _MSS:
        raise RuntimeError("mss is not installed. Run: pip install mss")

    region = CaptureRegion(x=x, y=y, width=width, height=height)
    validate_monitor_index(monitor_index)
    validate_region(region, monitor_index)

    with mss.mss() as sct:
        # mss grab expects a dict with left, top, width, height
        target = {
            "left": region.x,
            "top": region.y,
            "width": region.width,
            "height": region.height,
        }
        shot = sct.grab(target)
        png = mss.tools.to_png(shot.rgb, shot.size)

    return _compress(png, "PNG")


def capture_region_relative(
    x: int,
    y: int,
    width: int,
    height: int,
    monitor_index: int = 1
) -> Tuple[bytes, str]:
    """
    Capture a region relative to a specific monitor's origin.

    Args:
        x: Left coordinate relative to the monitor's top-left.
        y: Top coordinate relative to the monitor's top-left.
        width: Region width in pixels.
        height: Region height in pixels.
        monitor_index: Monitor to capture from (1..n). Default is primary monitor (1).

    Returns:
        (image_bytes, mime_type) tuple.

    Raises:
        RuntimeError: If mss is not installed or capture fails.
        ValueError: If monitor_index is invalid or region is out of bounds.
    """
    if not _MSS:
        raise RuntimeError("mss is not installed. Run: pip install mss")

    validate_monitor_index(monitor_index)
    monitors = _get_monitors()
    monitor = monitors[monitor_index]

    # Convert relative to absolute coordinates
    abs_x = monitor["left"] + x
    abs_y = monitor["top"] + y

    region = CaptureRegion(x=abs_x, y=abs_y, width=width, height=height)
    validate_region(region, monitor_index)

    with mss.mss() as sct:
        target = {
            "left": region.x,
            "top": region.y,
            "width": region.width,
            "height": region.height,
        }
        shot = sct.grab(target)
        png = mss.tools.to_png(shot.rgb, shot.size)

    return _compress(png, "PNG")


# ──────────────────────────────────────────────────────────────────────────────
# Backward Compatibility Shims (screen only)
# ──────────────────────────────────────────────────────────────────────────────

def _capture_screen() -> Tuple[bytes, str]:
    """Backward compatibility shim for actions.screen_processor._capture_screen."""
    return capture_primary_monitor()