"""
core/error_classification.py — Typed error classification for autonomous tasks.

Provides reliable exception-type-based classification with platform-aware OS error handling.
Separates error classification from retry eligibility decisions.
"""

from __future__ import annotations

import errno
import platform
import sys
from dataclasses import dataclass
from enum import Enum
from typing import Any, Union


class ErrorClass(Enum):
    """Classification of an error for recovery purposes."""
    FATAL = "fatal"
    RECOVERABLE = "recoverable"
    NON_IDEMPOTENT_TIMEOUT = "non_idempotent_timeout"
    UNKNOWN = "unknown"
    INTERRUPTED = "interrupted"


@dataclass(frozen=True)
class ClassifiedError:
    """Result of classifying an exception."""
    error_class: ErrorClass
    reason: str
    errno: int | None = None
    exception_type: str = ""
    original: BaseException | None = None


# ──────────────────────────────────────────────────────────────────────────────
# Exception type → ErrorClass mapping (primary classification mechanism)
# ──────────────────────────────────────────────────────────────────────────────

# Exception types that are always FATAL (programming errors, invalid state)
_FATAL_EXCEPTION_TYPES: set[type[BaseException]] = {
    TypeError,
    ValueError,
    KeyError,
    IndexError,
    AttributeError,
    NameError,
    ImportError,
    ModuleNotFoundError,
    SyntaxError,
    IndentationError,
    MemoryError,
    RecursionError,
    NotImplementedError,
    AssertionError,
    PermissionError,
}

# Exception types that are RECOVERABLE (transient, environmental)
_RECOVERABLE_EXCEPTION_TYPES: set[type[BaseException]] = {
    ConnectionError,
    ConnectionRefusedError,
    ConnectionResetError,
    ConnectionAbortedError,
    # TimeoutError is handled separately to classify as NON_IDEMPOTENT_TIMEOUT
    BlockingIOError,
    InterruptedError,
    ChildProcessError,
    BrokenPipeError,
}

# OSError errno → ErrorClass mapping (POSIX)
# Windows errno values differ; we handle both where they overlap
_ERRNO_CLASSIFICATION: dict[int, ErrorClass] = {
    # FATAL - invalid arguments, permissions, missing resources
    errno.EACCES: ErrorClass.FATAL,           # Permission denied
    errno.EPERM: ErrorClass.FATAL,            # Operation not permitted
    errno.ENOENT: ErrorClass.FATAL,           # No such file or directory
    errno.EEXIST: ErrorClass.FATAL,           # File exists
    errno.EINVAL: ErrorClass.FATAL,           # Invalid argument
    errno.ENOTDIR: ErrorClass.FATAL,          # Not a directory
    errno.EISDIR: ErrorClass.FATAL,           # Is a directory
    errno.ENOTEMPTY: ErrorClass.FATAL,        # Directory not empty
    errno.EROFS: ErrorClass.FATAL,            # Read-only filesystem
    errno.ENOSPC: ErrorClass.FATAL,           # No space left on device
    errno.EDQUOT: ErrorClass.FATAL,           # Disk quota exceeded
    errno.ELOOP: ErrorClass.FATAL,            # Too many symbolic links
    errno.ENAMETOOLONG: ErrorClass.FATAL,     # Filename too long
    errno.ENOEXEC: ErrorClass.FATAL,          # Exec format error
    errno.EBADF: ErrorClass.FATAL,            # Bad file descriptor
    errno.EFAULT: ErrorClass.FATAL,           # Bad address
    errno.EINTR: ErrorClass.INTERRUPTED,      # Interrupted system call
    # RECOVERABLE - transient conditions
    errno.EAGAIN: ErrorClass.RECOVERABLE,     # Resource temporarily unavailable
    errno.EWOULDBLOCK: ErrorClass.RECOVERABLE,# Operation would block
    errno.ETIMEDOUT: ErrorClass.RECOVERABLE,  # Connection timed out
    errno.ECONNREFUSED: ErrorClass.RECOVERABLE,# Connection refused
    errno.ECONNRESET: ErrorClass.RECOVERABLE, # Connection reset by peer
    errno.ECONNABORTED: ErrorClass.RECOVERABLE,# Connection aborted
    errno.EPIPE: ErrorClass.RECOVERABLE,      # Broken pipe
    errno.EHOSTUNREACH: ErrorClass.RECOVERABLE,# Host unreachable
    errno.ENETUNREACH: ErrorClass.RECOVERABLE,# Network unreachable
    errno.ENETDOWN: ErrorClass.RECOVERABLE,   # Network down
    errno.ETXTBSY: ErrorClass.RECOVERABLE,    # Text file busy
    errno.EBUSY: ErrorClass.RECOVERABLE,      # Device or resource busy
}

# Windows-specific error codes (winerror.h)
# Only include codes that have clear classification; avoid guessing
_WINDOWS_ERRNO_CLASSIFICATION: dict[int, ErrorClass] = {
    5: ErrorClass.FATAL,          # ERROR_ACCESS_DENIED
    3: ErrorClass.FATAL,          # ERROR_PATH_NOT_FOUND
    2: ErrorClass.FATAL,          # ERROR_FILE_NOT_FOUND
    80: ErrorClass.FATAL,         # ERROR_FILE_EXISTS
    87: ErrorClass.FATAL,         # ERROR_INVALID_PARAMETER
    267: ErrorClass.FATAL,        # ERROR_DIRECTORY
    145: ErrorClass.FATAL,        # ERROR_DIR_NOT_EMPTY
    19: ErrorClass.FATAL,         # ERROR_WRITE_PROTECT
    112: ErrorClass.FATAL,        # ERROR_DISK_FULL
    183: ErrorClass.FATAL,        # ERROR_ALREADY_EXISTS
    995: ErrorClass.INTERRUPTED,  # ERROR_OPERATION_ABORTED
    6: ErrorClass.RECOVERABLE,    # ERROR_INVALID_HANDLE
    1450: ErrorClass.RECOVERABLE, # ERROR_NO_SYSTEM_RESOURCES
    10053: ErrorClass.RECOVERABLE,# WSAECONNABORTED
    10054: ErrorClass.RECOVERABLE,# WSAECONNRESET
    10060: ErrorClass.RECOVERABLE,# WSAETIMEDOUT
    10061: ErrorClass.RECOVERABLE,# WSAECONNREFUSED
    10065: ErrorClass.RECOVERABLE,# WSAEHOSTUNREACH
    10050: ErrorClass.RECOVERABLE,# WSANETDOWN
    10051: ErrorClass.RECOVERABLE,# WSANETUNREACH
    10055: ErrorClass.RECOVERABLE,# WSAENOBUFS
    32: ErrorClass.RECOVERABLE,   # ERROR_SHARING_VIOLATION
    33: ErrorClass.RECOVERABLE,   # ERROR_LOCK_VIOLATION
}


def _get_platform_errno_map() -> dict[int, ErrorClass]:
    """Return the appropriate errno classification map for the current platform."""
    if platform.system() == "Windows":
        # Merge Windows-specific with common POSIX codes that also exist on Windows
        merged = _ERRNO_CLASSIFICATION.copy()
        merged.update(_WINDOWS_ERRNO_CLASSIFICATION)
        return merged
    return _ERRNO_CLASSIFICATION


# ──────────────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────────────

def classify_error(exc: Union[BaseException, str]) -> Union[ClassifiedError, ErrorClass]:
    """
    Classify an exception or error string into an ErrorClass.

    For backward compatibility, if a string is passed, returns ErrorClass directly.
    For new code, pass a BaseException to get a ClassifiedError with full details.

    Classification priority (for exceptions):
    1. BaseException (KeyboardInterrupt, SystemExit) → INTERRUPTED
    2. OSError with known errno → platform-specific classification (takes precedence)
    3. Explicit exception type match (_FATAL_EXCEPTION_TYPES, _RECOVERABLE_EXCEPTION_TYPES)
    4. OSError with unknown errno → UNKNOWN
    5. Other Exception types → UNKNOWN (conservative: never auto-retry)
    6. Other BaseException → INTERRUPTED

    Args:
        exc: The exception to classify, or an error message string (legacy).

    Returns:
        ClassifiedError for exceptions, ErrorClass for strings (legacy).
    """
    # Backward compatibility: string input returns ErrorClass directly
    if isinstance(exc, str):
        return classify_error_string(exc)

    exc_type = type(exc)
    exc_type_name = exc_type.__name__

    # 1. BaseException (KeyboardInterrupt, SystemExit, GeneratorExit) → INTERRUPTED
    if isinstance(exc, BaseException) and not isinstance(exc, Exception):
        return ClassifiedError(
            error_class=ErrorClass.INTERRUPTED,
            reason=f"{exc_type_name} is a BaseException (not Exception)",
            exception_type=exc_type_name,
            original=exc,
        )

    # 2. OSError with errno classification (checked BEFORE exception type sets)
    # This ensures specific errno classification takes precedence over general type
    if isinstance(exc, OSError) and exc.errno is not None:
        errno_map = _get_platform_errno_map()
        classified = errno_map.get(exc.errno)
        if classified is not None:
            return ClassifiedError(
                error_class=classified,
                reason=f"OSError errno {exc.errno} classified as {classified.value}",
                errno=exc.errno,
                exception_type=exc_type_name,
                original=exc,
            )
        # Unknown errno → UNKNOWN (conservative)
        return ClassifiedError(
            error_class=ErrorClass.UNKNOWN,
            reason=f"OSError errno {exc.errno} not in classification map",
            errno=exc.errno,
            exception_type=exc_type_name,
            original=exc,
        )

    # 2b. TimeoutError (OSError subclass) without errno → NON_IDEMPOTENT_TIMEOUT
    # This covers step timeouts where we don't know if the operation completed
    if exc_type is TimeoutError:
        return ClassifiedError(
            error_class=ErrorClass.NON_IDEMPOTENT_TIMEOUT,
            reason="TimeoutError without specific errno; operation completion unknown",
            exception_type=exc_type_name,
            original=exc,
        )

    # 3. Explicit fatal exception types
    if exc_type in _FATAL_EXCEPTION_TYPES:
        return ClassifiedError(
            error_class=ErrorClass.FATAL,
            reason=f"{exc_type_name} is a programming/invariant error",
            exception_type=exc_type_name,
            original=exc,
        )

    # 4. Explicit recoverable exception types
    if exc_type in _RECOVERABLE_EXCEPTION_TYPES:
        return ClassifiedError(
            error_class=ErrorClass.RECOVERABLE,
            reason=f"{exc_type_name} is a transient environmental error",
            exception_type=exc_type_name,
            original=exc,
        )

    # 5. Other Exception subclasses → UNKNOWN (conservative: no auto-retry)
    if isinstance(exc, Exception):
        return ClassifiedError(
            error_class=ErrorClass.UNKNOWN,
            reason=f"Unknown exception type {exc_type_name}; conservative classification",
            exception_type=exc_type_name,
            original=exc,
        )

    # 6. Any other BaseException → INTERRUPTED
    return ClassifiedError(
        error_class=ErrorClass.INTERRUPTED,
        reason=f"{exc_type_name} is a BaseException subclass",
        exception_type=exc_type_name,
        original=exc,
    )


def is_retry_eligible(classified: ClassifiedError, is_idempotent: bool = False) -> bool:
    """
    Determine if a classified error is eligible for retry.

    This is a SEPARATE decision from classification. Callers should use this
    rather than checking error_class directly.

    Args:
        classified: The classified error.
        is_idempotent: Whether the failed operation is idempotent.

    Returns:
        True if the operation should be retried, False otherwise.
    """
    match classified.error_class:
        case ErrorClass.RECOVERABLE:
            return True
        case ErrorClass.NON_IDEMPOTENT_TIMEOUT:
            return is_idempotent
        case ErrorClass.FATAL | ErrorClass.UNKNOWN | ErrorClass.INTERRUPTED:
            return False
    return False


# ──────────────────────────────────────────────────────────────────────────────
# Backward compatibility shim (string-based classification)
# ──────────────────────────────────────────────────────────────────────────────

def classify_error_string(error_msg: str) -> ErrorClass:
    """
    Legacy string-based classification for backward compatibility.

    DO NOT USE for new code. Kept only for existing callers that pass strings.
    Returns ErrorClass directly for old API compatibility.
    """
    if not isinstance(error_msg, str):
        error_msg = str(error_msg)

    fatal_keywords = ["permission", "auth", "missing", "invalid", "circular", "denied", "not found", "does not exist"]
    for keyword in fatal_keywords:
        if keyword in error_msg.lower():
            return ErrorClass.FATAL

    recoverable_keywords = ["connection", "timeout", "reset", "refused", "unreachable", "temporary", "busy", "eagain", "ewouldblock"]
    for keyword in recoverable_keywords:
        if keyword in error_msg.lower():
            return ErrorClass.RECOVERABLE

    return ErrorClass.UNKNOWN


def classify_error_string_wrapped(error_msg: str) -> ClassifiedError:
    """
    String-based classification returning ClassifiedError for internal use.
    """
    ec = classify_error_string(error_msg)
    return ClassifiedError(
        error_class=ec,
        reason=f"Legacy string classification: {ec.value}",
        exception_type="str",
    )