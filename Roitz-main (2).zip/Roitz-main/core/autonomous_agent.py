"""
core/autonomous_agent.py — Foundation for autonomous task execution.

Provides TaskPlan, TaskStep, TaskState, Planner, and Executor primitives.
Reuses existing ActionRegistry, PluginRegistry, PermissionGuard, and gemini.as_json.
All logic runs in worker threads; UI updates via player methods (thread-safe signals).
"""
from __future__ import annotations

import json
import time
import threading
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional
from collections import defaultdict

from core.gemini import as_json, SMART
from core.permission_guard import get_permission_guard
from core.action_loader import ActionRegistry
from core.plugin_loader import PluginRegistry
from core.confirm import request as confirm_request, pending_title, TIMEOUT_SECONDS as CONFIRM_TIMEOUT
from core.auth_dialog import request_auth, resolve_auth
from core.permission_fingerprint import OperationIdentity, ApprovalToken
from core.undo import push_undo
from core.error_classification import ErrorClass, ClassifiedError
from core.worker_registry import (
    WorkerState,
    WorkerRecord,
    WorkerRegistry,
    create_worker_record,
    extract_resource_keys,
    get_global_registry,
    reset_global_registry,
)
from memory.config_manager import BASE_DIR


# ──────────────────────────────────────────────────────────────────────────────
# Task States
# ──────────────────────────────────────────────────────────────────────────────

class TaskState(str, Enum):
    CREATED = "created"
    PLANNING = "planning"
    AWAITING_APPROVAL = "awaiting_approval"
    RUNNING = "running"
    VERIFYING = "verifying"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"
    RECOVERY = "recovery"


class StepState(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    SKIPPED = "skipped"
    AWAITING_CONFIRMATION = "awaiting_confirmation"
    AWAITING_AUTH = "awaiting_auth"


# ──────────────────────────────────────────────────────────────────────────────
# Data Models
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class TaskStep:
    """A single executable step in a task plan."""
    id: str
    description: str
    tool: str                          # Action or plugin name
    parameters: dict = field(default_factory=dict)
    depends_on: list[str] = field(default_factory=list)  # Step IDs (for future DAG)
    requires_confirmation: bool = False
    status: StepState = StepState.PENDING
    result: Optional[str] = None
    error: Optional[str] = None
    retry_count: int = 0
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    # Confirmation fields (Batch 2)
    confirmation_key: Optional[str] = None
    approval_token: Optional[ApprovalToken] = None
    # Undo fields
    undo_label: Optional[str] = None
    undo_fn: Optional[Callable[[], str]] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "description": self.description,
            "tool": self.tool,
            "parameters": self.parameters,
            "depends_on": self.depends_on,
            "requires_confirmation": self.requires_confirmation,
            "status": self.status.value,
            "result": self.result,
            "error": self.error,
            "retry_count": self.retry_count,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "confirmation_key": self.confirmation_key,
            "approval_token": None,  # Don't serialize token
            "undo_label": self.undo_label,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "TaskStep":
        step = cls(
            id=data["id"],
            description=data["description"],
            tool=data["tool"],
            parameters=data.get("parameters", {}),
            depends_on=data.get("depends_on", []),
            requires_confirmation=data.get("requires_confirmation", False),
            status=StepState(data.get("status", "pending")),
            result=data.get("result"),
            error=data.get("error"),
            retry_count=data.get("retry_count", 0),
            started_at=data.get("started_at"),
            finished_at=data.get("finished_at"),
            confirmation_key=data.get("confirmation_key"),
            undo_label=data.get("undo_label"),
        )
        return step


@dataclass
class TaskPlan:
    """Complete task plan with metadata and ordered steps."""
    task_id: str
    goal: str
    steps: list[TaskStep] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    status: TaskState = TaskState.CREATED
    current_step_index: int = 0
    result: Optional[str] = None
    error: Optional[str] = None
    cancelled: bool = False
    # Confirmation handling (Batch 2)
    _pending_confirmation: Optional[Callable[[bool], None]] = field(default=None, repr=False)
    _confirmation_event: Optional[threading.Event] = field(default=None, repr=False)
    _confirmation_result: Optional[bool] = field(default=None, repr=False)

    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "goal": self.goal,
            "steps": [s.to_dict() for s in self.steps],
            "created_at": self.created_at,
            "status": self.status.value,
            "current_step_index": self.current_step_index,
            "result": self.result,
            "error": self.error,
            "cancelled": self.cancelled,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "TaskPlan":
        plan = cls(
            task_id=data["task_id"],
            goal=data["goal"],
            steps=[TaskStep.from_dict(s) for s in data.get("steps", [])],
            created_at=data.get("created_at", time.time()),
            status=TaskState(data.get("status", "created")),
            current_step_index=data.get("current_step_index", 0),
            result=data.get("result"),
            error=data.get("error"),
            cancelled=data.get("cancelled", False),
        )
        return plan


# ──────────────────────────────────────────────────────────────────────────────
# Planner
# ──────────────────────────────────────────────────────────────────────────────

class Planner:
    """
    Converts a user goal into a structured TaskPlan using gemini.as_json.

    Validates:
    - Required fields present
    - No empty plans
    - No circular dependencies
    - All referenced tools exist in ActionRegistry or PluginRegistry
    - Dependencies reference valid step IDs
    """

    MAX_STEPS = 20
    MIN_STEPS = 1

    def __init__(
        self,
        action_registry: ActionRegistry,
        plugin_registry: PluginRegistry,
        max_steps: int = MAX_STEPS,
    ):
        self.action_registry = action_registry
        self.plugin_registry = plugin_registry
        self.max_steps = max_steps

    def _get_available_tools(self) -> list[dict]:
        """Get all available tool declarations for the planner prompt."""
        tools = []
        for decl in self.action_registry.get_tool_declarations():
            tools.append({"name": decl["name"], "description": decl["description"]})
        for decl in self.plugin_registry.get_tool_declarations():
            tools.append({"name": decl["name"], "description": decl["description"]})
        return tools

    def _build_planner_prompt(self, goal: str, available_tools: list[dict]) -> str:
        tools_json = json.dumps(available_tools, indent=2)
        return f"""You are a task planner for an autonomous agent. Convert the user's goal into a structured execution plan.

User Goal: {goal}

Available Tools (use ONLY these exact names):
{tools_json}

Return ONLY valid JSON with this exact structure:
{{
  "steps": [
    {{
      "id": "step_1",
      "description": "Human-readable description of what this step does",
      "tool": "exact_tool_name_from_list_above",
      "parameters": {{"param": "value"}},
      "depends_on": [],
      "requires_confirmation": false
    }}
  ]
}}

Rules:
1. Steps execute SEQUENTIALLY in array order (depends_on is for future DAG support).
2. "tool" MUST be an exact name from the Available Tools list — NO invented names.
3. "parameters" must match the tool's expected schema (you know common patterns).
4. "requires_confirmation": true for destructive actions (fs.write, fs.delete, proc.exec, messaging.send, etc.).
5. Minimum 1 step, maximum {self.max_steps} steps.
6. No circular dependencies (depends_on only references earlier step IDs).
7. Return ONLY the JSON object — no markdown, no explanation.
"""

    def create_plan(self, goal: str) -> TaskPlan:
        """
        Generate a TaskPlan from a user goal.

        Raises:
            ValueError: If plan is invalid (empty, malformed, unknown tools, circular deps)
        """
        if not goal or not goal.strip():
            raise ValueError("Goal cannot be empty")

        available_tools = self._get_available_tools()
        if not available_tools:
            raise ValueError("No tools available for planning")

        prompt = self._build_planner_prompt(goal.strip(), available_tools)

        # Use SMART tier for planning (reasoning)
        plan_data = as_json(prompt, tier=SMART, timeout_ms=60000)

        if plan_data is None:
            raise ValueError("Planner returned no response (all models failed)")

        if not isinstance(plan_data, dict):
            raise ValueError(f"Planner returned non-object: {type(plan_data)}")

        steps_data = plan_data.get("steps")
        if not isinstance(steps_data, list) or not steps_data:
            raise ValueError("Plan must contain a non-empty 'steps' array")

        if len(steps_data) > self.max_steps:
            raise ValueError(f"Plan has {len(steps_data)} steps, maximum is {self.max_steps}")

        # First pass: collect all steps without validation
        raw_steps = []
        step_ids = set()
        known_tools = set(self.action_registry.names()) | set(self.plugin_registry.names())

        for i, step_data in enumerate(steps_data):
            if not isinstance(step_data, dict):
                raise ValueError(f"Step {i} is not an object")

            step_id = step_data.get("id", f"step_{i+1}")
            if step_id in step_ids:
                raise ValueError(f"Duplicate step ID: {step_id}")
            step_ids.add(step_id)

            tool_name = step_data.get("tool")
            if not tool_name or tool_name not in known_tools:
                raise ValueError(f"Step '{step_id}' references unknown tool: {tool_name}")

            depends_on = step_data.get("depends_on", [])
            if not isinstance(depends_on, list):
                raise ValueError(f"Step '{step_id}' depends_on must be a list")

            raw_steps.append({
                "id": step_id,
                "description": str(step_data.get("description", "")).strip() or f"Execute {tool_name}",
                "tool": tool_name,
                "parameters": step_data.get("parameters", {}) if isinstance(step_data.get("parameters"), dict) else {},
                "depends_on": depends_on,
                "requires_confirmation": bool(step_data.get("requires_confirmation", False)),
            })

        # Second pass: validate all dependencies (now all step_ids are known)
        steps = []
        for i, raw in enumerate(raw_steps):
            # Validate dependencies reference valid step IDs
            for dep in raw["depends_on"]:
                if dep not in step_ids:
                    raise ValueError(f"Step '{raw['id']}' depends on unknown step: {dep}")
                # In sequential mode, dependency must come before
                dep_idx = next((j for j, s in enumerate(raw_steps) if s["id"] == dep), -1)
                if dep_idx >= i:
                    raise ValueError(f"Step '{raw['id']}' depends on future step: {dep}")

            step = TaskStep(
                id=raw["id"],
                description=raw["description"],
                tool=raw["tool"],
                parameters=raw["parameters"],
                depends_on=raw["depends_on"],
                requires_confirmation=raw["requires_confirmation"],
            )
            steps.append(step)

        # Check for circular dependencies
        self._validate_no_cycles(steps)

        task_id = f"task_{uuid.uuid4().hex[:8]}"
        return TaskPlan(task_id=task_id, goal=goal.strip(), steps=steps)

    def _validate_no_cycles(self, steps: list[TaskStep]) -> None:
        """Detect circular dependencies in the step graph."""
        # Build adjacency list
        graph: dict[str, list[str]] = {s.id: [] for s in steps}
        for s in steps:
            for dep in s.depends_on:
                graph[dep].append(s.id)

        # DFS cycle detection
        visited = set()
        rec_stack = set()

        def dfs(node: str) -> bool:
            visited.add(node)
            rec_stack.add(node)
            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    if dfs(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True
            rec_stack.remove(node)
            return False

        for node in graph:
            if node not in visited:
                if dfs(node):
                    raise ValueError("Circular dependency detected in plan")


# ──────────────────────────────────────────────────────────────────────────────
# Executor
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class ExecutionResult:
    """Result of executing a task plan."""
    task_id: str
    success: bool
    completed_steps: int
    total_steps: int
    final_result: Optional[str] = None
    error: Optional[str] = None
    step_results: list[dict] = field(default_factory=list)


class Executor:
    """
    Executes a validated TaskPlan sequentially using ActionRegistry/PluginRegistry.

    - Respects dependency ordering (currently sequential)
    - Validates action/plugin references before execution
    - Stops on required step failure
    - Returns structured execution results
    - Thread-safe (each executor instance handles one task)
    """

    def __init__(
        self,
        action_registry: ActionRegistry,
        plugin_registry: PluginRegistry,
        player: Any = None,
        session_memory: Any = None,
        worker_registry: Optional[WorkerRegistry] = None,
    ):
        self.action_registry = action_registry
        self.plugin_registry = plugin_registry
        self.player = player
        self.session_memory = session_memory
        self._cancelled = False
        # Active worker tracking for cancellation propagation
        self._active_attempt_id: Optional[str] = None
        self._active_step_id: Optional[str] = None
        # Worker registry for resource conflict detection across all executions.
        # If not provided, uses the global singleton registry.
        self._worker_registry = worker_registry

    @property
    def worker_registry(self) -> WorkerRegistry:
        """Get the worker registry, lazily initializing the global one if needed."""
        if self._worker_registry is None:
            self._worker_registry = get_global_registry()
        return self._worker_registry

    def cancel(self) -> None:
        """Signal cancellation (checked between steps and during step execution)."""
        self._cancelled = True
        # Also request cancellation on any active worker for this task
        if self._active_attempt_id and self._active_step_id:
            self.worker_registry.request_step_cancellation(self._active_step_id)

    def cancel_task(self, task_id: str) -> int:
        """
        Request cooperative cancellation for all workers of a task.

        Returns the number of workers that received a cancellation request.
        """
        return self.worker_registry.request_task_cancellation(task_id)

    def execute(self, plan: TaskPlan) -> ExecutionResult:
        """
        Execute all steps in the plan sequentially.

        Returns ExecutionResult with success status and details.
        """
        from core.permission_guard import OPERATION_SPECS
        get_permission_guard().initialize()

        if plan.cancelled:
            return ExecutionResult(
                task_id=plan.task_id,
                success=False,
                completed_steps=0,
                total_steps=len(plan.steps),
                error="Task was cancelled before execution",
            )

        plan.status = TaskState.RUNNING
        step_results = []
        completed = 0

        self._active_thread: Optional[threading.Thread] = None
        self._active_attempt_id: Optional[str] = None

        # Worker lifecycle registry — shared across executions unless explicitly isolated.
        # Uses injected registry or global singleton for cross-Executor conflict detection.
        worker_registry = self.worker_registry

        # Resume from current_step_index if set (for recovery)
        start_index = plan.current_step_index if plan.current_step_index < len(plan.steps) else 0

        for i in range(start_index, len(plan.steps)):
            step = plan.steps[i]
            plan.current_step_index = i

            if self._cancelled:
                plan.status = TaskState.CANCELLED
                return ExecutionResult(
                    task_id=plan.task_id,
                    success=False,
                    completed_steps=completed,
                    total_steps=len(plan.steps),
                    error="Cancelled during execution",
                    step_results=step_results,
                )

            if step.status == StepState.DONE:
                completed += 1
                step_results.append(step.to_dict())
                continue

            if step.status == StepState.FAILED:
                plan.status = TaskState.FAILED
                return ExecutionResult(
                    task_id=plan.task_id,
                    success=False,
                    completed_steps=completed,
                    total_steps=len(plan.steps),
                    error=f"Step {step.id} previously failed: {step.error}",
                    step_results=step_results,
                )

            # Check dependencies (all must be DONE)
            for dep_id in step.depends_on:
                dep_step = next((s for s in plan.steps if s.id == dep_id), None)
                if not dep_step or dep_step.status != StepState.DONE:
                    step.status = StepState.FAILED
                    step.error = f"Dependency {dep_id} not satisfied"
                    plan.status = TaskState.FAILED
                    return ExecutionResult(
                        task_id=plan.task_id,
                        success=False,
                        completed_steps=completed,
                        total_steps=len(plan.steps),
                        error=f"Step {step.id} dependency not met: {dep_id}",
                        step_results=step_results + [step.to_dict()],
                    )

            # Handle confirmation gates (Batch 2)
            if step.requires_confirmation and step.status == StepState.PENDING:
                # First time hitting this step - request confirmation
                step.status = StepState.AWAITING_CONFIRMATION
                plan.status = TaskState.AWAITING_APPROVAL

                # Create confirmation event
                confirm_event = threading.Event()
                confirm_result = {"accepted": False}

                def confirm_callback(accepted: bool):
                    confirm_result["accepted"] = accepted
                    confirm_event.set()

                def on_confirm():
                    confirm_callback(True)
                    return "Confirmation granted"

                # Get confirmation key - use step ID for uniqueness
                confirm_key = f"task_{plan.task_id}_{step.id}"
                step.confirmation_key = confirm_key

                # Build detail message
                detail = (
                    f"Task: {plan.goal}\n"
                    f"Step: {step.description}\n"
                    f"Tool: {step.tool}\n"
                    f"Parameters: {json.dumps(step.parameters, indent=2)}"
                )

                # Request UI confirmation
                confirm_request(
                    key=confirm_key,
                    title=f"Confirm: {step.description}",
                    detail=detail,
                    run=on_confirm
                )

                # Show in player UI
                if self.player:
                    self.player.write_log(f"[TaskAgent] Awaiting confirmation for step: {step.id}")

                # Wait for confirmation with timeout and cancellation/rejection polling
                start_time = time.monotonic()
                while not confirm_event.is_set():
                    if confirm_event.wait(timeout=0.5):
                        break

                    if time.monotonic() - start_time >= CONFIRM_TIMEOUT:
                        break

                    # If the HUD no longer shows our confirmation, the user likely cancelled
                    if not pending_title():
                        time.sleep(0.1)  # Buffer for on_confirm thread
                        if not confirm_event.is_set():
                            break

                if not confirm_event.is_set() or not confirm_result["accepted"]:
                    # Timeout or user rejected
                    is_timeout = not confirm_event.is_set()
                    step.status = StepState.FAILED
                    step.error = f"Confirmation {'timeout' if is_timeout else 'rejected by user'}"
                    step.finished_at = time.time()
                    plan.status = TaskState.FAILED
                    return ExecutionResult(
                        task_id=plan.task_id,
                        success=False,
                        completed_steps=completed,
                        total_steps=len(plan.steps),
                        error=f"Step {step.id} {step.error}",
                        step_results=step_results + [step.to_dict()],
                    )

                # Check if owner authentication is also required
                if self._requires_owner_approval(step.tool, step.parameters):
                    step.status = StepState.AWAITING_AUTH
                    plan.status = TaskState.AWAITING_APPROVAL

                    auth_event = threading.Event()
                    auth_result = {"verified": False}

                    def auth_callback(verified: bool):
                        get_permission_guard().consume_approval(approval_token, verified)
                        auth_result["verified"] = verified
                        auth_event.set()

                    # Create approval token
                    from core.permission_fingerprint import ApprovalToken

                    # Build operation name
                    operation_name = None
                    if step.tool in ("file_controller", "computer_control", "browser_control", "dev_agent"):
                        action = step.parameters.get("action", "").lower().strip()
                        if action:
                            operation_name = f"{step.tool}:{action}"
                    elif step.tool == "send_message":
                        platform = step.parameters.get("platform", "").lower().strip()
                        if platform:
                            operation_name = f"{step.tool}:{platform}"
                    else:
                        action = step.parameters.get("action", "")
                        if action:
                            operation_name = f"{step.tool}:{action.lower().strip()}"
                        else:
                            platform = step.parameters.get("platform", "")
                            if platform:
                                operation_name = f"{step.tool}:{platform.lower().strip()}"

                    spec = OPERATION_SPECS.get(operation_name) if operation_name else None
                    capability = spec.capability if spec else "unknown"
                    template_id = spec.template_id if spec else operation_name or step.tool

                    identity = OperationIdentity.create(
                        capability=capability,
                        project_path=BASE_DIR,
                        template_id=template_id,
                        args=step.parameters,
                        requesting_component="task_agent",
                    )

                    approval_token = ApprovalToken.create(identity)
                    step.approval_token = approval_token

                    # Request owner authentication
                    title = f"Owner Approval: {step.description}"
                    auth_msg = request_auth(
                        token=approval_token,
                        title=title,
                        detail=detail,
                        resolve_cb=auth_callback,
                        task_id=plan.task_id
                    )

                    if self.player:
                        self.player.write_log(f"[TaskAgent] Awaiting owner authentication for step: {step.id}")

                    # Wait for authentication with timeout
                    from core.auth_dialog import AUTH_TIMEOUT_SECONDS
                    if not auth_event.wait(timeout=AUTH_TIMEOUT_SECONDS):
                        step.status = StepState.FAILED
                        step.error = f"Authentication timeout ({AUTH_TIMEOUT_SECONDS}s)"
                        step.finished_at = time.time()
                        plan.status = TaskState.FAILED
                        return ExecutionResult(
                            task_id=plan.task_id,
                            success=False,
                            completed_steps=completed,
                            total_steps=len(plan.steps),
                            error=f"Step {step.id} authentication timed out",
                            step_results=step_results + [step.to_dict()],
                        )

                    if not auth_result["verified"]:
                        step.status = StepState.FAILED
                        step.error = "Owner authentication failed"
                        step.finished_at = time.time()
                        plan.status = TaskState.FAILED
                        return ExecutionResult(
                            task_id=plan.task_id,
                            success=False,
                            completed_steps=completed,
                            total_steps=len(plan.steps),
                            error=f"Step {step.id} owner authentication failed",
                            step_results=step_results + [step.to_dict()],
                        )

            # Execute step
            step.status = StepState.RUNNING
            step.started_at = time.time()

            self._log(f"Executing step {i+1}/{len(plan.steps)}: {step.id} ({step.tool})")

            # Monitoring setup
            from core.task_monitoring import TaskMonitor, TaskRecovery, STEP_TIMEOUT, get_backoff_delay
            from core.permission_guard import OPERATION_SPECS, ResourceScope
            monitor = TaskMonitor(plan, player=self.player)
            if monitor.check_overall_timeout():
                plan.status = TaskState.FAILED
                return ExecutionResult(
                    task_id=plan.task_id,
                    success=False,
                    completed_steps=completed,
                    total_steps=len(plan.steps),
                    error="Overall task timeout exceeded",
                    step_results=step_results,
                )

            # Determine operation metadata for this step
            operation_name = self._get_operation_name(step.tool, step.parameters)
            spec = OPERATION_SPECS.get(operation_name) if operation_name else None
            is_idempotent = spec.idempotent if spec else False
            resource_scope = spec.resource_scope.value if spec and spec.resource_scope else None

            # Retry loop with exponential backoff and timeout
            while True:
                # Create worker record with resource keys for precise conflict detection
                worker = create_worker_record(
                    task_id=plan.task_id,
                    step_id=step.id,
                    tool_name=step.tool,
                    parameters=step.parameters,
                    operation_name=operation_name,
                    resource_scope=resource_scope,
                    is_idempotent=is_idempotent,
                )
                cancel_event = threading.Event()

                # Atomic admission: check conflicts and reserve resources in one operation
                admitted, conflict_reason = worker_registry.admit_worker(worker)
                if not admitted:
                    self._log(f"Step {step.id}: admission blocked by {conflict_reason}, aborting")
                    step.status = StepState.FAILED
                    step.error = f"Resource admission blocked: {conflict_reason}"
                    step.finished_at = time.time()
                    plan.status = TaskState.FAILED
                    step_results.append(step.to_dict())
                    return ExecutionResult(
                        task_id=plan.task_id,
                        success=False,
                        completed_steps=completed,
                        total_steps=len(plan.steps),
                        error=f"Step {step.id} failed: resource admission blocked by {conflict_reason}",
                        step_results=step_results,
                    )

                self._active_attempt_id = worker.attempt_id
                self._active_step_id = step.id

                def run_step():
                    try:
                        # Pre-execution cancellation check: if cancellation was requested before
                        # the handler started, don't execute. This is a safe check without races
                        # because the thread hasn't entered the handler yet.
                        if cancel_event.is_set():
                            if self._active_attempt_id == worker.attempt_id:
                                step_result["error"] = ClassifiedError(
                                    error_class=ErrorClass.INTERRUPTED,
                                    reason="Cancelled before execution started",
                                    exception_type="Cancellation",
                                )
                                step_result["done"] = True
                            return

                        # Execute the step with cancellation support
                        result = self._execute_step(step, cancel_event)
                        # Only accept if this is still the active attempt
                        if self._active_attempt_id == worker.attempt_id:
                            step_result["result"] = result
                            step_result["done"] = True
                    except Exception as e:
                        if self._active_attempt_id == worker.attempt_id:
                            step_result["error"] = str(e)
                            step_result["exception"] = e
                            step_result["done"] = True

                step_result = {"result": None, "error": None, "exception": None, "done": False, "attempt_id": worker.attempt_id}

                thread = threading.Thread(target=run_step, daemon=True)
                try:
                    thread.start()
                except Exception as e:
                    worker.mark_failed(f"thread start failed: {e}")
                    worker.mark_terminated()
                    worker_registry.release_resources(worker.attempt_id)
                    raise
                worker.mark_running(thread, cancel_event)
                thread.join(timeout=STEP_TIMEOUT)

                if thread.is_alive():
                    # Timeout: request cooperative cancellation (advisory — handler may not check it)
                    self._log(f"Step {step.id} timed out after {STEP_TIMEOUT}s, requesting cooperative cancellation")
                    worker.request_cancellation()

                    # Wait for graceful termination (grace period)
                    grace_timeout = 2.0
                    thread.join(timeout=grace_timeout)

                    if thread.is_alive():
                        # Still alive after grace period - mark UNRESOLVED
                        self._log(f"Step {step.id} worker still alive after grace period, marking UNRESOLVED (cancellation was advisory)")
                        worker.mark_unresolved()
                        step_result["error"] = ClassifiedError(
                            error_class=ErrorClass.NON_IDEMPOTENT_TIMEOUT,
                            reason=f"Step timed out after {STEP_TIMEOUT}s (worker unresolved)",
                            exception_type="StepTimeout",
                        )
                        # Do NOT set thread to None - keep tracking the unresolved worker
                    else:
                        # Thread terminated during grace period
                        worker.mark_terminated()
                        worker_registry.release_resources(worker.attempt_id)
                        if step_result["exception"] is not None:
                            # Exception occurred - use it for classification
                            step_result["error"] = step_result["exception"]
                        else:
                            # Successful completion after timeout - classify as timeout
                            step_result["error"] = ClassifiedError(
                                error_class=ErrorClass.NON_IDEMPOTENT_TIMEOUT,
                                reason=f"Step timed out after {STEP_TIMEOUT}s (completed late)",
                                exception_type="StepTimeout",
                            )
                else:
                    # Thread completed within timeout
                    worker.mark_terminated()
                    worker_registry.release_resources(worker.attempt_id)

                # Check for errors and handle retry logic
                if step_result["error"]:
                    # Prefer exception for classification (preserves type info)
                    error_for_classification = step_result["exception"] if step_result["exception"] else step_result["error"]

                    if TaskRecovery.handle_failure(step, error_for_classification, is_idempotent=is_idempotent):
                        # Before retrying: wait for any unresolved workers from previous attempts
                        # This prevents overlapping execution. If a previous worker remains alive after
                        # the bounded wait, abort the retry — do not start another attempt.
                        self._log(f"Step {step.id}: waiting for previous workers to terminate before retry")
                        retry_blocked = False
                        for prev_worker in worker_registry.get_active_for_step(step.id):
                            # Do not skip the current worker — it may still be alive (timed out but handler running)
                            # We must wait for ALL active workers for this step to terminate before retrying.
                            if prev_worker.is_alive():
                                self._log(f"Step {step.id}: previous worker {prev_worker.attempt_id[:8]} still alive, joining...")
                                prev_worker.thread.join(timeout=5.0)
                                if prev_worker.is_alive():
                                    prev_worker.mark_unresolved()
                                    self._log(f"Step {step.id}: previous worker {prev_worker.attempt_id[:8]} still UNRESOLVED — aborting retry")
                                    retry_blocked = True
                                    break
                                else:
                                    prev_worker.mark_terminated()
                                    worker_registry.release_resources(prev_worker.attempt_id)

                        if retry_blocked:
                            step.status = StepState.FAILED
                            step.error = "previous_worker_still_alive"
                            step.finished_at = time.time()
                            plan.status = TaskState.FAILED
                            step_results.append(step.to_dict())
                            return ExecutionResult(
                                task_id=plan.task_id,
                                success=False,
                                completed_steps=completed,
                                total_steps=len(plan.steps),
                                error=f"Step {step.id} failed: previous worker still alive, retry aborted",
                                step_results=step_results,
                            )

                        # Check for resource conflicts with unresolved workers from OTHER steps
                        conflicting = worker_registry.has_conflicting_worker(worker)
                        if conflicting:
                            self._log(f"Step {step.id}: resource conflict with unresolved worker, waiting...")
                            # Wait for conflicting workers to terminate
                            cross_step_blocked = False
                            for w in worker_registry.get_unresolved_workers():
                                if w.conflicts_with(worker) and w.thread and w.thread.is_alive():
                                    w.thread.join(timeout=5.0)
                                    if w.thread.is_alive():
                                        # Still alive - cannot safely retry
                                        self._log(f"Step {step.id}: conflicting worker {w.attempt_id[:8]} remains UNRESOLVED, aborting retry")
                                        cross_step_blocked = True
                                        break
                                    w.mark_terminated()
                                    worker_registry.release_resources(w.attempt_id)

                            if cross_step_blocked:
                                step.status = StepState.FAILED
                                step.error = "cross_step_resource_conflict"
                                step.finished_at = time.time()
                                plan.status = TaskState.FAILED
                                step_results.append(step.to_dict())
                                return ExecutionResult(
                                    task_id=plan.task_id,
                                    success=False,
                                    completed_steps=completed,
                                    total_steps=len(plan.steps),
                                    error=f"Step {step.id} failed: cross-step resource conflict with unresolved worker",
                                    step_results=step_results,
                                )

                        step.retry_count += 1
                        delay = get_backoff_delay(step.retry_count)
                        self._log(f"Retrying step {step.id} (attempt {step.retry_count}) after {delay}s backoff due to: {step_result['error']} (idempotent={is_idempotent})")
                        time.sleep(delay)
                        continue
                    else:
                        step.status = StepState.FAILED
                        step.error = step_result["error"]
                        step.finished_at = time.time()
                        self._log(f"Step {step.id} failed: {step.error} (idempotent={is_idempotent}, retry_eligible=False)")
                        plan.status = TaskState.FAILED
                        step_results.append(step.to_dict())
                        return ExecutionResult(
                            task_id=plan.task_id,
                            success=False,
                            completed_steps=completed,
                            total_steps=len(plan.steps),
                            error=f"Step {step.id} failed: {step.error}",
                            step_results=step_results,
                        )
                else:
                    step.result = step_result["result"]
                    step.status = StepState.DONE
                    step.finished_at = time.time()
                    completed += 1
                    self._log(f"Step {step.id} completed: {step.result[:100]}")

                    # Register undo if available
                    if step.undo_label and step.undo_fn:
                        push_undo(step.undo_label, step.undo_fn)
                    self._active_thread = None
                    self._active_attempt_id = None
                    break

            step_results.append(step.to_dict())
            # Clean up terminated workers for this step
            worker_registry.cleanup_terminated()

        plan.status = TaskState.COMPLETED
        plan.result = f"Completed {completed} steps successfully"

        # Final check: log any remaining unresolved workers
        unresolved = worker_registry.get_unresolved_workers()
        if unresolved:
            self._log(f"Task {plan.task_id} completed with {len(unresolved)} unresolved worker(s)")
            for w in unresolved:
                self._log(f"  Unresolved: step={w.step_id}, tool={w.tool_name}, attempt={w.attempt_id[:8]}")

        return ExecutionResult(
            task_id=plan.task_id,
            success=True,
            completed_steps=completed,
            total_steps=len(plan.steps),
            final_result=plan.result,
            step_results=step_results,
        )

    def _get_operation_name(self, tool_name: str, parameters: dict) -> str | None:
        """Form the operation_name from tool name and parameters (mirrors action_loader).
        Returns None for unknown tools (conservative: no metadata available)."""
        # Check if tool is known in either registry
        if not (self.action_registry.has(tool_name) or self.plugin_registry.has(tool_name)):
            return None

        if tool_name in ("file_controller", "computer_control", "browser_control"):
            action = parameters.get("action", "").lower().strip()
            if action:
                return f"{tool_name}:{action}"
        elif tool_name == "dev_agent":
            mode = parameters.get("mode", "").lower().strip()
            if mode:
                return f"{tool_name}:{mode}"
        elif tool_name == "send_message":
            platform = parameters.get("platform", "").lower().strip()
            if platform:
                return f"{tool_name}:{platform}"
        else:
            # Plugins: try action first, then platform
            action = parameters.get("action", "")
            if action:
                return f"{tool_name}:{action.lower().strip()}"
            platform = parameters.get("platform", "")
            if platform:
                return f"{tool_name}:{platform.lower().strip()}"
        return None

    def _requires_owner_approval(self, tool_name: str, parameters: dict) -> bool:
        """Check if operation requires owner approval (fs.delete, fs.move, proc.exec, etc.)."""
        from core.permission_guard import OPERATION_SPECS
        from core.permission_manager import OWNER_APPROVAL_REQUIRED

        operation_name = self._get_operation_name(tool_name, parameters)
        if not operation_name:
            return False

        spec = OPERATION_SPECS.get(operation_name)
        if not spec:
            return False

        return spec.capability in OWNER_APPROVAL_REQUIRED

    def _execute_step(self, step: TaskStep, cancel_event: Optional[threading.Event] = None) -> str:
        """Execute a single step via ActionRegistry or PluginRegistry."""
        # Determine which registry has the tool
        ctx = {}
        if cancel_event:
            ctx["cancel_event"] = cancel_event
        if self.action_registry.has(step.tool):
            # ActionRegistry.run validates permissions internally
            return self.action_registry.run(step.tool, step.parameters, ctx=ctx)
        elif self.plugin_registry.has(step.tool):
            # PluginRegistry.run validates permissions and passes player/session_memory
            return self.plugin_registry.run(
                step.tool,
                step.parameters,
                player=self.player,
                session_memory=self.session_memory,
                cancel_event=cancel_event,
            )
        else:
            raise ValueError(f"Tool not found in any registry: {step.tool}")

    def _log(self, msg: str) -> None:
        """Log to console and player if available."""
        print(f"[TaskAgent] {msg}")
        if self.player:
            try:
                self.player.write_log(f"[TaskAgent] {msg}")
            except Exception:
                pass


# ──────────────────────────────────────────────────────────────────────────────
# Task Store (In-Memory + Persistence)
# ──────────────────────────────────────────────────────────────────────────────

class TaskStore:
    """Thread-safe in-memory task store with JSON persistence."""

    def __init__(self, storage_path: Optional[Path] = None):
        self._tasks: dict[str, TaskPlan] = {}
        self._lock = threading.RLock()
        self.storage_path = storage_path or (BASE_DIR / "memory" / "tasks.json")
        self._load()

    def _load(self) -> None:
        if self.storage_path.exists():
            try:
                data = json.loads(self.storage_path.read_text(encoding="utf-8"))
                with self._lock:
                    for task_data in data.get("tasks", []):
                        plan = TaskPlan.from_dict(task_data)
                        self._tasks[plan.task_id] = plan
            except Exception as e:
                print(f"[TaskStore] Failed to load tasks: {e}")

    def _save(self) -> None:
        try:
            self.storage_path.parent.mkdir(parents=True, exist_ok=True)
            with self._lock:
                data = {"tasks": [t.to_dict() for t in self._tasks.values()]}
            self.storage_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception as e:
            print(f"[TaskStore] Failed to save tasks: {e}")

    def create(self, plan: TaskPlan) -> TaskPlan:
        with self._lock:
            self._tasks[plan.task_id] = plan
        self._save()
        return plan

    def get(self, task_id: str) -> Optional[TaskPlan]:
        with self._lock:
            return self._tasks.get(task_id)

    def update(self, plan: TaskPlan) -> TaskPlan:
        with self._lock:
            self._tasks[plan.task_id] = plan
        self._save()
        return plan

    def delete(self, task_id: str) -> bool:
        with self._lock:
            if task_id in self._tasks:
                del self._tasks[task_id]
                self._save()
                return True
        return False

    def list_all(self) -> list[TaskPlan]:
        with self._lock:
            return list(self._tasks.values())


# ──────────────────────────────────────────────────────────────────────────────
# Permission Helpers
# ──────────────────────────────────────────────────────────────────────────────

def requires_confirmation_for_tool(tool_name: str, parameters: dict) -> bool:
    """
    Determine if a tool operation requires user confirmation based on OPERATION_SPECS.
    Checks if the operation maps to a capability in OWNER_APPROVAL_REQUIRED.
    """
    from core.permission_guard import OPERATION_SPECS, get_permission_guard
    from core.permission_manager import OWNER_APPROVAL_REQUIRED

    # Form operation name like action_loader/plugin_loader do
    operation_name = None
    if tool_name in ("file_controller", "computer_control", "browser_control"):
        action = parameters.get("action", "").lower().strip()
        if action:
            operation_name = f"{tool_name}:{action}"
    elif tool_name == "dev_agent":
        mode = parameters.get("mode", "").lower().strip()
        if mode:
            operation_name = f"{tool_name}:{mode}"
    elif tool_name == "send_message":
        platform = parameters.get("platform", "").lower().strip()
        if platform:
            operation_name = f"{tool_name}:{platform}"
    else:
        # For plugins, try common parameter keys
        action = parameters.get("action", "")
        if action:
            operation_name = f"{tool_name}:{action.lower().strip()}"
        else:
            platform = parameters.get("platform", "")
            if platform:
                operation_name = f"{tool_name}:{platform.lower().strip()}"

    if not operation_name:
        return False

    spec = OPERATION_SPECS.get(operation_name)
    if not spec:
        return False

    # Check primary capability
    if spec.capability in OWNER_APPROVAL_REQUIRED:
        return True

    # Check additional capabilities
    for cap in spec.additional_caps:
        if cap in OWNER_APPROVAL_REQUIRED:
            return True

    return False