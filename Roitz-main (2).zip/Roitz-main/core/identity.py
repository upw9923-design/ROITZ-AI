"""
Identity module for authenticated caller identity propagation.

This module provides a simple, thread-safe way to establish and propagate
authenticated caller identity from session entry points (voice, dashboard, Telegram)
through the action/plugin dispatch chain to tool handlers.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class CallerIdentity:
    """
    Immutable identity of an authenticated caller.

    Attributes:
        source: Origin of the identity - "voice", "dashboard", "telegram", "api"
        subject: Unique identifier for the caller (user_id, session_id, device_token, etc.)
        display_name: Human-readable name for logging/UI
        metadata: Additional context (e.g., chat_id for Telegram, pairing_key for dashboard)
    """
    source: str
    subject: str
    display_name: str = ""
    metadata: dict = field(default_factory=dict)

    def __str__(self) -> str:
        if self.display_name:
            return f"{self.source}:{self.subject} ({self.display_name})"
        return f"{self.source}:{self.subject}"


# Thread-local storage for the current caller identity
_identity_local = threading.local()


def set_current_identity(identity: Optional[CallerIdentity]) -> None:
    """Set the caller identity for the current thread."""
    _identity_local.identity = identity


def get_current_identity() -> Optional[CallerIdentity]:
    """Get the caller identity for the current thread."""
    return getattr(_identity_local, "identity", None)


def clear_current_identity() -> None:
    """Clear the caller identity for the current thread."""
    if hasattr(_identity_local, "identity"):
        del _identity_local.identity


# Pre-defined identity sources
IDENTITY_SOURCE_VOICE = "voice"
IDENTITY_SOURCE_DASHBOARD = "dashboard"
IDENTITY_SOURCE_TELEGRAM = "telegram"
IDENTITY_SOURCE_API = "api"
IDENTITY_SOURCE_ANONYMOUS = "anonymous"

# Anonymous identity for when no authenticated identity is available
ANONYMOUS_IDENTITY = CallerIdentity(
    source="anonymous",
    subject="anonymous",
    display_name="Anonymous",
)