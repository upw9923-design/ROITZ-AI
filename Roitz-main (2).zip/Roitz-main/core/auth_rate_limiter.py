"""
core/auth_rate_limiter.py — thread-safe rate limiting for owner authentication.

Rate limits by STABLE operation identity (capability|project|template|component),
NOT by nonce. Counts ONLY failed secret verifications — never authentication requests,
cancels, or timeouts.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from collections import defaultdict


@dataclass
class _RateLimitState:
    """Per-identity rate limit state."""
    failed_verifications: int = 0          # ONLY incremented on WRONG secret
    window_start: float = 0.0
    locked_until: float = 0.0


class AuthRateLimiter:
    """Thread-safe rate limiter for owner authentication.

    Identity key: f"{capability}|{project_id}|{template_id}|{requesting_component}"

    Limits:
    - 3 failed VERIFICATIONS per 5-minute window per identity
    - 15-minute lockout after 3rd failed verification
    - Cancel/timeout/request does NOT count as failure
    - Success resets the counter
    """
    MAX_FAILED_VERIFICATIONS = 3
    WINDOW_SECONDS = 300      # 5 minutes
    LOCKOUT_SECONDS = 900     # 15 minutes

    def __init__(self):
        self._lock = threading.Lock()
        self._state: dict[str, _RateLimitState] = defaultdict(_RateLimitState)

    def _make_identity_key(self, capability: str, project_id: str,
                           template_id: str, requesting_component: str) -> str:
        """Stable identity key — NO nonce."""
        return f"{capability}|{project_id}|{template_id}|{requesting_component}"

    def check_lockout(self, capability: str, project_id: str,
                      template_id: str, requesting_component: str) -> tuple[bool, float]:
        """Check if identity is currently locked out.

        Returns: (allowed, lockout_remaining_seconds)
        If not allowed, lockout_remaining > 0.
        """
        key = self._make_identity_key(capability, project_id, template_id, requesting_component)
        now = time.monotonic()

        with self._lock:
            state = self._state[key]

            # Check lockout
            if now < state.locked_until:
                return False, state.locked_until - now

            # Reset window if expired
            if now - state.window_start > self.WINDOW_SECONDS:
                state.failed_verifications = 0
                state.window_start = now

            return True, 0.0

    def record_failed_verification(self, capability: str, project_id: str,
                                    template_id: str, requesting_component: str) -> tuple[bool, float]:
        """Record a FAILED secret verification (wrong secret provided).

        Returns: (allowed, lockout_remaining_seconds)
        If not allowed, lockout_remaining > 0 (15 min lockout).
        """
        key = self._make_identity_key(capability, project_id, template_id, requesting_component)
        now = time.monotonic()

        with self._lock:
            state = self._state[key]

            # Check lockout first
            if now < state.locked_until:
                return False, state.locked_until - now

            # Reset window if expired
            if now - state.window_start > self.WINDOW_SECONDS:
                state.failed_verifications = 0
                state.window_start = now

            # Record failed VERIFICATION (not request)
            state.failed_verifications += 1

            if state.failed_verifications > self.MAX_FAILED_VERIFICATIONS:
                state.locked_until = now + self.LOCKOUT_SECONDS
                return False, self.LOCKOUT_SECONDS

            return True, 0.0

    def record_successful_verification(self, capability: str, project_id: str,
                                        template_id: str, requesting_component: str) -> None:
        """Reset on successful authentication."""
        key = self._make_identity_key(capability, project_id, template_id, requesting_component)
        with self._lock:
            if key in self._state:
                del self._state[key]

    def record_cancel_or_timeout(self, capability: str, project_id: str,
                                  template_id: str, requesting_component: str) -> None:
        """Cancel/timeout does NOT count as failed verification.
        Does NOT reset existing failures — they persist until success or window expiry."""
        # No-op — failures persist until success or window expiry
        pass

    def cleanup_expired(self) -> None:
        """Periodic cleanup of expired entries."""
        now = time.monotonic()
        with self._lock:
            expired = [
                k for k, v in self._state.items()
                if now > v.locked_until and v.failed_verifications == 0
            ]
            for k in expired:
                del self._state[k]


# Global instance
_rate_limiter = AuthRateLimiter()


def get_rate_limiter() -> AuthRateLimiter:
    return _rate_limiter