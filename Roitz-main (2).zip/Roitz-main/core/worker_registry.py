"""
core/worker_registry.py — Centralized, thread-safe Worker Registry.

Manages worker lifecycle, resource conflict detection, and admission control
for concurrent task execution. Extracts and refactors the worker tracking
logic from autonomous_agent.py into a dedicated, reusable module.

Key guarantees:
- Atomic worker admission with resource reservation
- Conflict detection using stable resource keys and conservative scope fallback
- No resource release until verified thread termination
- Thread-safe operations with minimal lock contention
"""

from __future__ import annotations

import threading
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional, Union
from urllib.parse import urlparse


# Browser aliases and default detection (mirrored from actions/browser_control.py
# to avoid circular imports — worker_registry is imported by browser_control)
_BROWSER_ALIASES: dict[str, str] = {
    "google chrome":   "chrome",
    "google-chrome":   "chrome",
    "microsoft edge":  "edge",
    "ms edge":         "edge",
    "msedge":          "edge",
    "mozilla firefox": "firefox",
    "opera gx":        "operagx",
    "opera_gx":        "operagx",
}


def _normalize_url(url: str) -> str:
    """Normalize URL (mirrored from actions/browser_control.py)."""
    url = url.strip()
    if not url:
        return "about:blank"
    if "://" in url:
        return url
    if "." not in url:
        url = url + ".com"
    return "https://" + url


def _detect_default_browser() -> str:
    """Detect default browser (simplified, mirrored from actions/browser_control.py)."""
    import platform
    import subprocess
    import os
    _OS = platform.system()
    try:
        if _OS == "Windows":
            import winreg
            k = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\Shell\Associations"
                r"\UrlAssociations\http\UserChoice",
            )
            prog_id = winreg.QueryValueEx(k, "ProgId")[0].lower()
            winreg.CloseKey(k)
            for kw in ("edge", "firefox", "opera", "brave", "vivaldi", "chrome"):
                if kw in prog_id:
                    return kw
        elif _OS == "Darwin":
            out = subprocess.run(
                ["defaults", "read",
                 "com.apple.LaunchServices/com.apple.launchservices.secure",
                 "LSHandlers"],
                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5,
            ).stdout.lower()
            for kw in ("firefox", "opera", "brave", "vivaldi", "safari", "chrome", "edge"):
                if kw in out:
                    return kw
        elif _OS == "Linux":
            out = subprocess.run(
                ["xdg-settings", "get", "default-web-browser"],
                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5,
            ).stdout.lower()
            for kw in ("firefox", "opera", "brave", "vivaldi", "chrome", "edge"):
                if kw in out:
                    return kw
    except Exception:
        pass
    return "chrome"


class WorkerState(str, Enum):
    """Explicit lifecycle states for execution attempt workers."""
    CREATED = "created"
    RUNNING = "running"
    CANCELLATION_REQUESTED = "cancellation_requested"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMED_OUT = "timed_out"
    UNRESOLVED = "unresolved"
    TERMINATED = "terminated"


@dataclass
class WorkerRecord:
    """
    Tracks a single worker thread's lifecycle from creation to termination.

    Every started worker gets a record that persists until confirmed termination.
    This prevents silent abandonment of live threads and enables conflict detection.
    """
    attempt_id: str
    task_id: str
    step_id: str
    tool_name: str
    operation_name: Optional[str]
    resource_keys: tuple[str, ...] = field(default_factory=tuple)  # Stable resource identifiers
    resource_scope: Optional[str] = None  # Fallback scope (from OPERATION_SPECS)
    state: WorkerState = WorkerState.CREATED
    thread: Optional[threading.Thread] = None
    cancel_event: Optional[threading.Event] = None
    started_at: float = field(default_factory=time.time)
    finished_at: Optional[float] = None
    result: Any = None
    error: Any = None
    exception: Optional[BaseException] = None
    is_idempotent: bool = False

    def mark_running(self, thread: threading.Thread, cancel_event: threading.Event) -> None:
        self.state = WorkerState.RUNNING
        self.thread = thread
        self.cancel_event = cancel_event

    def mark_completed(self, result: Any) -> None:
        self.state = WorkerState.COMPLETED
        self.result = result
        self.finished_at = time.time()

    def mark_failed(self, error: Any, exception: Optional[BaseException] = None) -> None:
        self.state = WorkerState.FAILED
        self.error = error
        self.exception = exception
        self.finished_at = time.time()

    def mark_timed_out(self) -> None:
        self.state = WorkerState.TIMED_OUT
        self.finished_at = time.time()

    def mark_unresolved(self) -> None:
        """Worker still alive after timeout + grace period."""
        self.state = WorkerState.UNRESOLVED
        self.finished_at = time.time()

    def mark_terminated(self) -> None:
        """Confirmed thread termination (joined or confirmed dead)."""
        self.state = WorkerState.TERMINATED
        if self.finished_at is None:
            self.finished_at = time.time()

    def request_cancellation(self) -> None:
        """Request cooperative cancellation."""
        if self.state == WorkerState.RUNNING:
            self.state = WorkerState.CANCELLATION_REQUESTED
            if self.cancel_event:
                self.cancel_event.set()

    def is_alive(self) -> bool:
        """Check if the worker thread is still alive."""
        return self.thread is not None and self.thread.is_alive()

    def conflicts_with(self, other: "WorkerRecord") -> bool:
        """
        Check if this worker conflicts with another based on resource keys or scope.

        Conservative: unknown resource identity conflicts with everything.
        Same resource key = definite conflict.
        Same resource scope = potential conflict (fallback when keys unavailable on either side).
        """
        # Primary: stable resource keys - definite conflict if shared
        if self.resource_keys and other.resource_keys:
            if set(self.resource_keys) & set(other.resource_keys):
                return True
            # Both have keys but no overlap - no conflict (keys are precise)
            return False

        # Fallback: resource scope (conservative) - only when at least one lacks keys
        if self.resource_scope is None or other.resource_scope is None:
            return True  # Conservative: unknown scope = potential conflict

        return self.resource_scope == other.resource_scope


class WorkerRegistry:
    """
    Centralized worker registry for tracking all execution attempt workers.

    Provides:
    - Thread-safe worker registration and lookup
    - Resource-level conflict detection and admission control
    - Unresolved worker tracking and resource reservation
    - Cleanup of terminated workers
    - Diagnostics for monitoring and debugging

    Designed for use across multiple Executor instances or task executions.
    """

    def __init__(self):
        self._workers: dict[str, WorkerRecord] = {}  # attempt_id -> WorkerRecord
        self._task_workers: dict[str, list[str]] = defaultdict(list)  # task_id -> [attempt_ids]
        self._step_workers: dict[str, list[str]] = defaultdict(list)  # step_id -> [attempt_ids]
        self._resource_reservations: dict[str, str] = {}  # resource_key -> attempt_id
        self._scope_reservations: dict[str, set[str]] = defaultdict(set)  # resource_scope -> {attempt_ids}
        self._lock = threading.RLock()

    def register(self, worker: WorkerRecord) -> None:
        """Register a new worker. Must be called before starting the thread."""
        with self._lock:
            self._workers[worker.attempt_id] = worker
            self._task_workers[worker.task_id].append(worker.attempt_id)
            self._step_workers[worker.step_id].append(worker.attempt_id)
            # Reserve resource keys
            for key in worker.resource_keys:
                self._resource_reservations[key] = worker.attempt_id
            # Reserve resource scope (fallback)
            if worker.resource_scope:
                self._scope_reservations[worker.resource_scope].add(worker.attempt_id)

    def unregister(self, attempt_id: str) -> bool:
        """Remove a worker and release its resource reservations. Returns True if removed."""
        with self._lock:
            worker = self._workers.pop(attempt_id, None)
            if worker is None:
                return False

            # Release resource key reservations
            for key in worker.resource_keys:
                if self._resource_reservations.get(key) == attempt_id:
                    self._resource_reservations.pop(key, None)

            # Release scope reservation
            if worker.resource_scope:
                self._scope_reservations[worker.resource_scope].discard(attempt_id)
                if not self._scope_reservations[worker.resource_scope]:
                    self._scope_reservations.pop(worker.resource_scope, None)

            # Clean up task index
            task_list = self._task_workers.get(worker.task_id, [])
            if attempt_id in task_list:
                task_list.remove(attempt_id)
            if not task_list:
                self._task_workers.pop(worker.task_id, None)

            # Clean up step index
            step_list = self._step_workers.get(worker.step_id, [])
            if attempt_id in step_list:
                step_list.remove(attempt_id)
            if not step_list:
                self._step_workers.pop(worker.step_id, None)

            return True

    def get(self, attempt_id: str) -> Optional[WorkerRecord]:
        """Get worker by attempt ID."""
        with self._lock:
            return self._workers.get(attempt_id)

    def get_active_for_task(self, task_id: str) -> list[WorkerRecord]:
        """Get all workers for a task that are not yet terminated."""
        with self._lock:
            attempt_ids = self._task_workers.get(task_id, [])
            return [
                w for aid in attempt_ids
                if (w := self._workers.get(aid)) and w.state != WorkerState.TERMINATED
            ]

    def get_active_for_step(self, step_id: str) -> list[WorkerRecord]:
        """Get all workers for a step that are not yet terminated."""
        with self._lock:
            attempt_ids = self._step_workers.get(step_id, [])
            return [
                w for aid in attempt_ids
                if (w := self._workers.get(aid)) and w.state != WorkerState.TERMINATED
            ]

    def get_unresolved_workers(self) -> list[WorkerRecord]:
        """Get all workers in UNRESOLVED state."""
        with self._lock:
            return [w for w in self._workers.values() if w.state == WorkerState.UNRESOLVED]

    def get_live_workers(self) -> list[WorkerRecord]:
        """Get all workers whose threads are still alive."""
        with self._lock:
            return [w for w in self._workers.values() if w.is_alive()]

    def get_workers_by_resource_key(self, resource_key: str) -> list[WorkerRecord]:
        """Get all workers that have reserved a specific resource key."""
        with self._lock:
            attempt_id = self._resource_reservations.get(resource_key)
            if attempt_id:
                worker = self._workers.get(attempt_id)
                return [worker] if worker else []
            return []

    def get_workers_by_resource_scope(self, resource_scope: str) -> list[WorkerRecord]:
        """Get all workers that have reserved a specific resource scope."""
        with self._lock:
            attempt_ids = self._scope_reservations.get(resource_scope, set())
            return [self._workers[aid] for aid in attempt_ids if aid in self._workers]

    def check_admission(self, worker: WorkerRecord) -> tuple[bool, Optional[str]]:
        """
        Atomically check if a worker can be admitted without resource conflicts.

        Returns (can_admit, reason). If can_admit is False, reason explains the conflict.
        This does NOT register the worker — call register() after successful admission.
        """
        with self._lock:
            # Check resource key conflicts (primary)
            for key in worker.resource_keys:
                if key in self._resource_reservations:
                    conflicting_id = self._resource_reservations[key]
                    conflicting = self._workers.get(conflicting_id)
                    if conflicting and conflicting.is_alive():
                        return False, f"resource_key:{key}"

            # Check resource scope conflicts (fallback)
            if worker.resource_scope:
                for aid in self._scope_reservations.get(worker.resource_scope, set()):
                    conflicting = self._workers.get(aid)
                    if conflicting and conflicting.is_alive() and conflicting.conflicts_with(worker):
                        return False, f"resource_scope:{worker.resource_scope}"

            return True, None

    def has_conflicting_worker(self, worker: WorkerRecord) -> bool:
        """
        Check if there are any alive workers that conflict with the given worker.

        This is used to detect resource conflicts with workers from OTHER steps
        (not the current step being retried).
        """
        with self._lock:
            # Check resource key conflicts (primary)
            for key in worker.resource_keys:
                if key in self._resource_reservations:
                    conflicting_id = self._resource_reservations[key]
                    conflicting = self._workers.get(conflicting_id)
                    if conflicting and conflicting.is_alive() and conflicting.attempt_id != worker.attempt_id:
                        return True

            # Check resource scope conflicts (fallback)
            if worker.resource_scope:
                for aid in self._scope_reservations.get(worker.resource_scope, set()):
                    if aid != worker.attempt_id:
                        conflicting = self._workers.get(aid)
                        if conflicting and conflicting.is_alive() and conflicting.conflicts_with(worker):
                            return True

            return False

    def admit_worker(self, worker: WorkerRecord) -> tuple[bool, Optional[str]]:
        """
        Atomically check admission and register the worker if admitted.

        Critical sequence (atomic under lock):
        1. Inspect active and unresolved workers
        2. Check resource conflicts
        3. Reserve required resources
        4. Register the new worker
        5. Release the registry lock

        Returns (admitted, reason). If not admitted, reason explains the conflict.
        A rejected admission does not start the worker.
        """
        with self._lock:
            # Check resource key conflicts (primary)
            for key in worker.resource_keys:
                if key in self._resource_reservations:
                    conflicting_id = self._resource_reservations[key]
                    conflicting = self._workers.get(conflicting_id)
                    if conflicting and conflicting.is_alive():
                        return False, f"resource_key:{key}"

            # Check resource scope conflicts (fallback)
            if worker.resource_scope:
                # Check workers with same scope
                for aid in self._scope_reservations.get(worker.resource_scope, set()):
                    conflicting = self._workers.get(aid)
                    if conflicting and conflicting.is_alive() and conflicting.conflicts_with(worker):
                        return False, f"resource_scope:{worker.resource_scope}"
                # Conservative: also check workers with no scope (unknown scope = potential conflict)
                # These workers are not in _scope_reservations, so check all workers directly
                for aid, conflicting in self._workers.items():
                    if conflicting.resource_scope is None and conflicting.is_alive():
                        # Worker with no scope is conservative - conflicts with any scoped worker
                        return False, f"resource_scope:{worker.resource_scope}"

            # Admit: reserve resources and register
            for key in worker.resource_keys:
                self._resource_reservations[key] = worker.attempt_id
            if worker.resource_scope:
                self._scope_reservations[worker.resource_scope].add(worker.attempt_id)

            self._workers[worker.attempt_id] = worker
            self._task_workers[worker.task_id].append(worker.attempt_id)
            self._step_workers[worker.step_id].append(worker.attempt_id)

            return True, None

    def release_resources(self, attempt_id: str) -> None:
        """Release resource reservations for a worker (called after verified termination)."""
        with self._lock:
            worker = self._workers.get(attempt_id)
            if worker is None:
                return

            # Release resource key reservations
            for key in worker.resource_keys:
                if self._resource_reservations.get(key) == attempt_id:
                    self._resource_reservations.pop(key, None)

            # Release scope reservation
            if worker.resource_scope:
                self._scope_reservations[worker.resource_scope].discard(attempt_id)
                if not self._scope_reservations[worker.resource_scope]:
                    self._scope_reservations.pop(worker.resource_scope, None)

    def wait_for_worker(self, attempt_id: str, timeout: float) -> bool:
        """Wait for a specific worker to terminate."""
        worker = self.get(attempt_id)
        if worker is None or worker.thread is None:
            return True
        worker.thread.join(timeout=timeout)
        return not worker.thread.is_alive()

    def request_task_cancellation(self, task_id: str) -> int:
        """
        Request cooperative cancellation for all RUNNING workers of a task.

        Returns the number of workers that received a cancellation request.
        Does NOT mark workers as terminated or release resources.
        """
        with self._lock:
            attempt_ids = self._task_workers.get(task_id, [])
            count = 0
            for aid in attempt_ids:
                worker = self._workers.get(aid)
                if worker and worker.state == WorkerState.RUNNING:
                    worker.request_cancellation()
                    count += 1
            return count

    def request_step_cancellation(self, step_id: str) -> int:
        """
        Request cooperative cancellation for all RUNNING workers of a step.

        Returns the number of workers that received a cancellation request.
        """
        with self._lock:
            attempt_ids = self._step_workers.get(step_id, [])
            count = 0
            for aid in attempt_ids:
                worker = self._workers.get(aid)
                if worker and worker.state == WorkerState.RUNNING:
                    worker.request_cancellation()
                    count += 1
            return count

    def get_active_task_workers(self, task_id: str) -> list[WorkerRecord]:
        """Get all RUNNING workers for a task (for diagnostics/cancellation)."""
        with self._lock:
            attempt_ids = self._task_workers.get(task_id, [])
            return [
                w for aid in attempt_ids
                if (w := self._workers.get(aid)) and w.state == WorkerState.RUNNING
            ]

    def cleanup_terminated(self) -> int:
        """Remove terminated workers from tracking. Returns count removed."""
        with self._lock:
            to_remove = [
                aid for aid, w in self._workers.items()
                if w.state == WorkerState.TERMINATED
            ]
            for aid in to_remove:
                w = self._workers.pop(aid)
                # Also clean up indices
                for key in w.resource_keys:
                    if self._resource_reservations.get(key) == aid:
                        self._resource_reservations.pop(key, None)
                if w.resource_scope:
                    self._scope_reservations[w.resource_scope].discard(aid)
                    if not self._scope_reservations[w.resource_scope]:
                        self._scope_reservations.pop(w.resource_scope, None)
                task_list = self._task_workers.get(w.task_id, [])
                if aid in task_list:
                    task_list.remove(aid)
                if not task_list:
                    self._task_workers.pop(w.task_id, None)
                step_list = self._step_workers.get(w.step_id, [])
                if aid in step_list:
                    step_list.remove(aid)
                if not step_list:
                    self._step_workers.pop(w.step_id, None)
            return len(to_remove)

    def get_diagnostics(self) -> dict:
        """Get diagnostic info for debugging."""
        with self._lock:
            return {
                "total": len(self._workers),
                "by_state": {
                    state.value: sum(1 for w in self._workers.values() if w.state == state)
                    for state in WorkerState
                },
                "live_threads": sum(1 for w in self._workers.values() if w.is_alive()),
                "unresolved": sum(1 for w in self._workers.values() if w.state == WorkerState.UNRESOLVED),
                "resource_keys_reserved": len(self._resource_reservations),
                "resource_scopes_reserved": sum(len(s) for s in self._scope_reservations.values()),
            }

    def get_all_workers(self) -> list[WorkerRecord]:
        """Get all workers (for diagnostics)."""
        with self._lock:
            return list(self._workers.values())


# ──────────────────────────────────────────────────────────────────────────────
# Helper functions for creating workers with proper resource identification
# ──────────────────────────────────────────────────────────────────────────────

def extract_resource_keys(tool_name: str, parameters: dict, operation_name: Optional[str]) -> tuple[str, ...]:
    """
    Extract stable resource keys from operation parameters.

    Resource keys are deterministic identifiers for the actual resources
    being accessed (files, network endpoints, etc.). Used for precise
    conflict detection instead of broad scope-based fallback.

    Returns tuple of resource key strings, or empty tuple if unknown.
    """
    keys = []

    if tool_name == "file_controller":
        action = parameters.get("action", "").lower().strip()
        # Single-path operations
        if action in ("read", "write", "create_file", "create_folder", "delete", "rename", "info", "largest", "disk_usage"):
            path = parameters.get("path")
            if path:
                # Normalize to forward slashes for cross-platform consistency
                normalized_path = str(path).replace("\\", "/")
                keys.append(normalized_path)
                # Also reserve project key (parent directory) for cross-module conflict detection
                # with dev_agent which uses "project:{folder}" format
                try:
                    from pathlib import Path as _Path
                    parent = _Path(normalized_path).parent
                    parent_str = str(parent).replace("\\", "/")
                    if parent_str not in (".", "/"):
                        keys.append(f"project:{parent_str}")
                except Exception:
                    pass
        # Multi-path operations - reserve both source and destination
        elif action in ("move", "copy"):
            for p in (parameters.get("path"), parameters.get("destination")):
                if p:
                    keys.append(str(p).replace("\\", "/"))
        # Directory operations
        elif action == "list":
            path = parameters.get("path", ".")
            keys.append(str(path).replace("\\", "/"))
        elif action == "find":
            path = parameters.get("path", ".")
            keys.append(str(path).replace("\\", "/"))
        # Bulk desktop operation - affects desktop directory
        elif action == "organize_desktop":
            try:
                keys.append(str(Path.home() / "Desktop").replace("\\", "/"))
            except Exception:
                keys.append("desktop")

    elif tool_name == "computer_control":
        action = parameters.get("action", "").lower().strip()
        # Input simulation actions - all affect global input stream
        if action in ("click", "left_click", "double_click", "right_click",
                      "type", "smart_type", "hotkey", "press",
                      "move", "drag", "scroll", "paste", "clear_field"):
            keys.append("global:input")
        # Screen capture actions - affect display (read-only for find/screenshot, read+write for click)
        elif action in ("screen_find", "screenshot"):
            keys.append("global:display")
        elif action == "screen_click":
            # Screen click: visual find + click → both display and input
            keys.append("global:display")
            keys.append("global:input")
        # Application management actions
        elif action in ("close_app", "close_application", "quit_app", "focus_window"):
            keys.append("app:manage")
        # Screen recording operations
        elif action in ("record_start", "record_stop"):
            keys.append("global:display")
        elif action == "record_status":
            # record_status is a read-only query - no exclusive resource needed
            pass
        # Read-only utilities - no exclusive resource needed, but track for diagnostics
        elif action in ("wait", "random_data", "user_data"):
            # These are pure computation/wait operations with no external resource access
            # They don't conflict with anything, but we track them for diagnostics
            pass  # No resource keys - they don't reserve exclusive resources
        # Clipboard read - input action (sends hotkey)
        elif action == "copy":
            keys.append("global:input")

    elif tool_name == "browser_control":
        action = parameters.get("action", "").lower().strip()
        browser = parameters.get("browser", "").lower().strip()

        # Resolve browser name through aliases (same logic as _SessionRegistry.get)
        if not browser:
            browser = _detect_default_browser()
        browser = _BROWSER_ALIASES.get(browser, browser)

        session_key = f"browser:session:{browser}"

        # Navigation actions - reserve session + network egress for the URL
        if action in ("go_to", "new_tab", "back", "forward", "reload"):
            keys.append(session_key)
            url = parameters.get("url")
            if url:
                # Extract domain for network egress tracking
                try:
                    parsed = urlparse(_normalize_url(url) if "://" not in url else url)
                    if parsed.netloc:
                        keys.append(f"network:{parsed.netloc}")
                except Exception:
                    pass
        elif action == "search":
            keys.append(session_key)
            # For search, network egress goes to the search engine domain
            engine = parameters.get("engine", "google").lower()
            search_engines = {
                "google": "www.google.com",
                "bing": "www.bing.com",
                "duckduckgo": "duckduckgo.com",
                "yandex": "yandex.com",
            }
            domain = search_engines.get(engine, "www.google.com")
            keys.append(f"network:{domain}")

        # Interactive page actions - reserve the browser session
        elif action in ("click", "type", "scroll", "fill_form", "smart_click",
                        "smart_type", "press", "close_tab", "screenshot",
                        "get_text", "get_url"):
            keys.append(session_key)

        # Session management - reserve session for close/switch, list is read-only
        elif action in ("close", "switch"):
            keys.append(session_key)
        elif action in ("list_browsers", "close_all"):
            # list_browsers is read-only, close_all affects all sessions
            # Use a generic browser registry key for coordination
            keys.append("browser:registry")

        # Unknown action - conservative fallback
        else:
            keys.append(f"op:browser_control:{action}")

    elif tool_name == "dev_agent":
        mode = parameters.get("mode", "").lower().strip()
        folder = parameters.get("folder", ".")
        # Normalize path to forward slashes for cross-platform consistency
        # Don't resolve - use raw path to avoid platform-specific differences
        normalized_folder = folder.replace("\\", "/")
        keys.append(f"project:{normalized_folder}")
        # Underlying resources depend on mode:
        # - status: read-only, only project key
        # - improve: subprocesses (proc:exec), network calls (pip, tests)
        # - build: subprocesses, network, and opens VSCode (app:manage)
        if mode == "improve":
            keys.append("proc:exec")
            keys.append("network:egress")
        elif mode == "build":
            keys.append("proc:exec")
            keys.append("network:egress")
            keys.append("app:manage")
        # status mode: no additional keys (read-only)

    elif tool_name == "send_message":
        platform = parameters.get("platform", "").lower().strip()
        if platform:
            keys.append(f"messaging:{platform}")
            # Underlying resources based on platform implementation
            if platform == "instagram":
                # Browser-based: webbrowser.open to instagram.com + pyautogui
                keys.append("network:www.instagram.com")
                keys.append("global:input")
            elif platform == "messenger":
                # Browser-based: webbrowser.open to messenger.com + pyautogui
                keys.append("network:www.messenger.com")
                keys.append("global:input")
            elif platform == "whatsapp":
                # Primary: verified driver (REMOTE_SERVICE only)
                # Fallback: desktop_send uses pyautogui + app launch
                keys.append("global:input")
                keys.append("app:manage")
            else:
                # Telegram, Signal, Discord: desktop_send (pyautogui + app launch)
                keys.append("global:input")
                keys.append("app:manage")

    elif tool_name == "telegram_bot":
        action = parameters.get("action", "").lower().strip()
        if action in ("send", "command", "poll"):
            keys.append("telegram:bot")
        elif action in ("configure", "pair", "unpair", "start_polling", "stop_polling"):
            keys.append("telegram:config")

    # Inline tools (main.py)
    elif tool_name == "save_memory":
        category = parameters.get("category", "notes")
        key = parameters.get("key", "")
        if key:
            keys.append(f"memory:{category}:{key}")

    elif tool_name == "recall_memory":
        query = parameters.get("query", "")
        if query:
            keys.append(f"memory:query:{query}")

    elif tool_name == "undo":
        # Undo operates on the undo stack
        keys.append("undo:stack")

    elif tool_name == "screen_process":
        angle = parameters.get("angle", "screen").lower()
        keys.append(f"screen:{angle}")

    elif tool_name == "close_camera":
        keys.append("screen:camera")

    elif tool_name == "system_status":
        keys.append("system:status")

    elif tool_name == "manage_monitor":
        action = parameters.get("action", "").lower().strip()
        topic = parameters.get("topic", "")
        if topic:
            keys.append(f"monitor:{topic}")
        else:
            keys.append("monitor:list")

    elif tool_name == "shutdown_jarvis":
        keys.append("system:shutdown")

    # open_app: launches applications
    elif tool_name == "open_app":
        app_name = parameters.get("app_name", "").strip()
        if app_name:
            keys.append(f"app:{app_name}")
        else:
            keys.append("app:unknown")

    # computer_settings: hotkey/window operations via pyautogui
    elif tool_name == "computer_settings":
        action = parameters.get("action", "").lower().strip()
        if action:
            # For precise tracking, use action-specific key
            # System-wide hotkeys affect global input/display
            if action in ("volume_up", "volume_down", "volume_set", "mute",
                          "brightness_up", "brightness_down",
                          "dark_mode", "toggle_wifi", "restart", "shutdown",
                          "sleep_display", "lock_screen"):
                keys.append("global:input")
            elif action in ("screenshot",):
                keys.append("global:display")
            elif action in ("open_settings", "file_explorer", "open_run"):
                keys.append("app:manage")
            else:
                # Window management, browser hotkeys, editing, scrolling, media keys -
                # all send keystrokes to the focused window via pyautogui, sharing the
                # global input stream. Use a single key so they conflict with each other
                # and with computer_control input actions.
                keys.append("global:input")
        else:
            keys.append("computer_settings:unknown")

    # Plugins (generic fallback using operation_name)
    elif operation_name:
        # Use operation_name as a conservative resource key
        keys.append(f"op:{operation_name}")
    else:
        # Truly unknown tool with no operation_name - conservative: conflict with everything
        keys.append("unknown:tool")

    return tuple(keys)


def create_worker_record(
    task_id: str,
    step_id: str,
    tool_name: str,
    parameters: dict,
    operation_name: Optional[str],
    resource_scope: Optional[str],
    is_idempotent: bool,
) -> WorkerRecord:
    """
    Factory function to create a WorkerRecord with all metadata populated.

    Extracts resource keys from parameters for precise conflict detection.
    """
    attempt_id = str(uuid.uuid4())
    resource_keys = extract_resource_keys(tool_name, parameters, operation_name)

    return WorkerRecord(
        attempt_id=attempt_id,
        task_id=task_id,
        step_id=step_id,
        tool_name=tool_name,
        operation_name=operation_name,
        resource_keys=resource_keys,
        resource_scope=resource_scope,
        is_idempotent=is_idempotent,
    )


# ──────────────────────────────────────────────────────────────────────────────
# Global registry instance (for backward compatibility with existing Executor)
# ──────────────────────────────────────────────────────────────────────────────

_global_registry: Optional[WorkerRegistry] = None


def get_global_registry() -> WorkerRegistry:
    """Get the global worker registry instance."""
    global _global_registry
    if _global_registry is None:
        _global_registry = WorkerRegistry()
    return _global_registry


def reset_global_registry() -> None:
    """Reset the global registry (for testing)."""
    global _global_registry
    _global_registry = None