"""
core/permission_store.py — data structures for pending approvals and persistent grants.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional

from core.permission_fingerprint import ApprovalToken, OperationIdentity


@dataclass
class PendingApproval:
    """In-memory only — destroyed on restart. One per unique request."""
    token: ApprovalToken
    created_at: float = field(default_factory=time.monotonic)
    expires_at: float = field(default_factory=lambda: time.monotonic() + 60.0)
    verified: bool = False
    consumed: bool = False
    task_id: Optional[str] = None        # associated task_id for cancellation
    cancelled: bool = False              # set when cancelled by interrupt


@dataclass
class PermissionGrant:
    """Persistent — stored in permissions.json.

    Represents a standing grant for a specific operation identity (no nonce).
    """
    capability: str
    project_id: str
    granted_at: str          # ISO8601
    expires_at: str | None   # ISO8601 or None for no expiry
    approved_by: str         # "owner"
    identity_hash: str       # OperationIdentity.identity_hash() that was approved

    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        try:
            return time.time() > time.mktime(time.strptime(self.expires_at, "%Y-%m-%dT%H:%M:%S"))
        except Exception:
            return True


@dataclass
class PermissionResult:
    """Result of a permission check."""
    allowed: bool
    reason: str
    instruction: str | None = None          # For model when approval required
    identity: OperationIdentity | None = None
    token: ApprovalToken | None = None      # Token to use if approval granted
    requires_approval: bool = False         # Whether approval can be requested