"""
core/command_templates.py — approved command templates for proc.exec capability.

Each template defines an executable, fixed arguments, and validated placeholders.
Templates are resolved at startup (executable paths) and cached.
"""

from __future__ import annotations

import re
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True, slots=True)
class CommandTemplate:
    """An approved command template with validated placeholders."""
    executable: str           # Absolute path (resolved at startup)
    fixed_args: tuple[str, ...]
    placeholder_patterns: dict[str, str]  # name -> regex pattern
    cwd: str                  # "{project_root}" or absolute path
    requires_owner_auth: bool = False


# Template registry — populated at startup with resolved paths
COMMAND_TEMPLATES: dict[str, CommandTemplate] = {}


def _resolve_executable(name: str) -> str:
    """Resolve executable to absolute path, or raise if not found."""
    path = shutil.which(name)
    if not path:
        raise FileNotFoundError(f"Executable not found in PATH: {name}")
    return path


def initialize_templates(project_root: Path) -> None:
    """Resolve all templates with absolute paths. Must be called at startup."""
    global COMMAND_TEMPLATES

    project_root_str = str(project_root.resolve()).replace("\\", "/")

    templates = {
        "git_status": CommandTemplate(
            executable=_resolve_executable("git"),
            fixed_args=("status",),
            placeholder_patterns={},
            cwd=project_root_str,
        ),
        "git_log": CommandTemplate(
            executable=_resolve_executable("git"),
            fixed_args=("log", "--oneline", "-20"),
            placeholder_patterns={},
            cwd=project_root_str,
        ),
        "git_diff": CommandTemplate(
            executable=_resolve_executable("git"),
            fixed_args=("diff",),
            placeholder_patterns={},
            cwd=project_root_str,
        ),
        "git_show": CommandTemplate(
            executable=_resolve_executable("git"),
            fixed_args=("show",),
            placeholder_patterns={"commit_hash": r"^[0-9a-f]{4,40}$"},
            cwd=project_root_str,
        ),
        "git_commit": CommandTemplate(
            executable=_resolve_executable("git"),
            fixed_args=("commit", "-m"),
            placeholder_patterns={"message": r".{1,500}"},
            cwd=project_root_str,
            requires_owner_auth=True,
        ),
        "git_push": CommandTemplate(
            executable=_resolve_executable("git"),
            fixed_args=("push",),
            placeholder_patterns={
                "remote": r"^[a-zA-Z0-9_.-]+$",
                "branch": r"^[a-zA-Z0-9_.-/]+$"
            },
            cwd=project_root_str,
            requires_owner_auth=True,
        ),
        "pytest_project": CommandTemplate(
            executable=_resolve_executable("python"),
            fixed_args=("-I", "-m", "pytest"),
            placeholder_patterns={"test_path": r"^[a-zA-Z0-9_/.-]+$"},
            cwd=project_root_str,
        ),
        "pip_install_approved": CommandTemplate(
            executable=_resolve_executable("python"),
            fixed_args=("-I", "-m", "pip", "install", "--no-index",
                        "--find-links", "file:///internal/wheelhouse",
                        "--require-hashes", "--no-deps"),
            placeholder_patterns={
                "package": r"^[a-zA-Z0-9_.-]+$",
                "version": r"^[0-9.]+$"
            },
            cwd=project_root_str,
            requires_owner_auth=True,
        ),
    }

    COMMAND_TEMPLATES = templates


@dataclass(frozen=True, slots=True)
class ValidationResult:
    allowed: bool
    reason: str
    command: list[str] | None = None
    cwd: str | None = None


def validate_template(template_id: str, args: dict[str, str]) -> ValidationResult:
    """Validate arguments against template and return concrete command."""
    template = COMMAND_TEMPLATES.get(template_id)
    if not template:
        return ValidationResult(False, f"unknown_template:{template_id}")

    # Validate each placeholder
    cmd_args = [template.executable] + list(template.fixed_args)
    for name, pattern in template.placeholder_patterns.items():
        value = args.get(name)
        if not value:
            return ValidationResult(False, f"missing_placeholder:{name}")
        if not re.fullmatch(pattern, value):
            return ValidationResult(False, f"invalid_placeholder:{name}")
        cmd_args.append(value)

    return ValidationResult(True, "valid", command=cmd_args, cwd=template.cwd)


def get_template(template_id: str) -> CommandTemplate | None:
    return COMMAND_TEMPLATES.get(template_id)


def list_templates() -> dict[str, dict[str, Any]]:
    """Return template metadata for UI/debugging."""
    return {
        tid: {
            "executable": t.executable,
            "fixed_args": list(t.fixed_args),
            "placeholders": list(t.placeholder_patterns.keys()),
            "cwd": t.cwd,
            "requires_owner_auth": t.requires_owner_auth,
        }
        for tid, t in COMMAND_TEMPLATES.items()
    }