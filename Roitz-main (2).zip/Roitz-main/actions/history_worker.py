"""
History Worker — Background thread for loading conversation history.

This module provides thread-safe background operations for the HistoryPanel.
All database access runs in worker threads; results are delivered to the
Qt main thread via pyqtSignal through the JarvisUI (player) thread-safe methods.

Usage:
    from actions.history_worker import HistoryWorker
    worker = HistoryWorker(player)
    worker.load_conversation_list(page=0, page_size=20)
    worker.load_conversation_detail(conversation_id, page=0, page_size=50)
    worker.search_messages(query, page=0, page_size=20)
    worker.search_conversations(query, page=0, page_size=20)
"""

import threading
import time
import uuid
from typing import Optional, List, Dict, Any

from memory.conversation_store import (
    ConversationStore,
    get_store,
    ConversationNotFoundError,
    ConversationStoreError,
)
from memory.conversation_models import ConversationSummary, Message


class HistoryWorker:
    """
    Background worker for conversation history operations.

    All methods are safe to call from the Qt main thread. They spawn
    daemon threads that perform database work and emit results via
    the provided player's thread-safe methods.

    Thread Safety:
    - Each operation runs in its own daemon thread
    - ConversationStore uses internal locking for thread-safe DB access
    - Results delivered via player.show_history_* (pyqtSignal → main thread)
    - No Qt widgets created or accessed from worker threads
    - Request ID tracking for stale response detection
    - Lifecycle protected by threading.Lock
    """

    def __init__(self, player):
        """
        Initialize the history worker.

        Args:
            player: JarvisUI instance (provides thread-safe show_history_* methods).
                    Can be None for testing (operations will run but not emit signals).
        """
        self._player = player
        self._store: Optional[ConversationStore] = None
        self._active_threads: List[threading.Thread] = []
        self._shutdown = False
        self._lifecycle_lock = threading.Lock()

    def _get_store(self) -> ConversationStore:
        """Get or create the ConversationStore singleton."""
        if self._store is None:
            self._store = get_store()
        return self._store

    def _run_in_thread(self, target, *args, **kwargs):
        """
        Run a target function in a daemon thread.

        Tracks the thread for lifecycle management. Thread admission and
        shutdown state checking are atomic under _lifecycle_lock.
        """
        thread = None
        with self._lifecycle_lock:
            if self._shutdown:
                return
            def wrapped():
                try:
                    target(*args, **kwargs)
                except Exception as e:
                    # Report unexpected errors through error signal
                    if self._player:
                        try:
                            self._player.show_history_error(f"Worker error: {type(e).__name__}: {e}")
                        except RuntimeError:
                            pass
            thread = threading.Thread(target=wrapped, daemon=True, name=f"HistoryWorker-{target.__name__}")
            self._active_threads.append(thread)
            thread.start()

        # Clean up finished threads periodically (outside the lock)
        self._cleanup_finished_threads()

    def _cleanup_finished_threads(self):
        """Remove finished threads from the active list."""
        with self._lifecycle_lock:
            self._active_threads = [t for t in self._active_threads if t.is_alive()]

    def _generate_request_id(self) -> str:
        """Generate a unique request ID for correlation tracking."""
        return uuid.uuid4().hex[:16]

    # ─── Public API ────────────────────────────────────────────────────────────

    def load_conversation_list(self, page: int = 0, page_size: int = 20) -> str:
        """
        Load a paginated list of conversations.

        Emits via player.show_history_list(conversations, page, total_pages, total_count, request_id)
        or player.show_history_error(error, request_id) on failure.

        Args:
            page: Zero-based page number
            page_size: Number of conversations per page

        Returns:
            Request ID for correlation tracking.
        """
        request_id = self._generate_request_id()

        def work():
            store = None
            try:
                store = self._get_store()
                offset = page * page_size

                # Get paginated conversations
                conversations = store.list_conversations(limit=page_size, offset=offset)
                total_count = store.count_conversations()
                total_pages = max(1, (total_count + page_size - 1) // page_size)

                # Convert ConversationSummary objects to dicts for UI
                conv_dicts = []
                for conv in conversations:
                    conv_dicts.append({
                        "id": conv.id,
                        "title": conv.title,
                        "started_at": conv.started_at,
                        "ended_at": conv.ended_at,
                        "turn_count": conv.turn_count,
                        "summary": conv.summary,
                        "language": conv.language,
                        "engine": conv.engine,
                    })

                if self._player:
                    self._player.show_history_list(conv_dicts, page, total_pages, total_count, request_id)

            except ConversationStoreError as e:
                if self._player:
                    self._player.show_history_error(f"Database error: {e}", request_id)
            except Exception as e:
                if self._player:
                    self._player.show_history_error(f"Failed to load conversations: {type(e).__name__}: {e}", request_id)
            finally:
                # Close thread-local connection to avoid file locking on Windows
                # Note: ConversationStore.close() closes the calling thread's thread-local connection only.
                if store is not None:
                    store.close()

        self._run_in_thread(work)
        return request_id

    def load_conversation_detail(
        self,
        conversation_id: str,
        page: int = 0,
        page_size: int = 50,
    ) -> str:
        """
        Load messages for a specific conversation.

        Emits via player.show_history_detail(conv_id, title, messages, page, total_pages, total_count, request_id)
        or player.show_history_error(error, request_id) on failure.

        Args:
            conversation_id: The conversation to load messages for
            page: Zero-based page number
            page_size: Number of messages per page

        Returns:
            Request ID for correlation tracking.
        """
        request_id = self._generate_request_id()

        def work():
            store = None
            try:
                store = self._get_store()

                # Get conversation metadata (for title)
                try:
                    conv = store.get_conversation(conversation_id)
                    title = conv.title
                except ConversationNotFoundError:
                    if self._player:
                        self._player.show_history_error(f"Conversation not found: {conversation_id}", request_id)
                    return

                offset = page * page_size

                # Get paginated messages (oldest first for detail view)
                messages = store.get_messages(
                    conversation_id,
                    limit=page_size,
                    offset=offset,
                    order_by="sequence",
                    descending=False,
                )
                total_count = store.get_message_count(conversation_id)
                total_pages = max(1, (total_count + page_size - 1) // page_size)

                # Convert Message objects to dicts for UI
                msg_dicts = []
                for msg in messages:
                    msg_dicts.append({
                        "role": msg.role,
                        "content": msg.content,
                        "content_type": msg.content_type,
                        "sequence": msg.sequence,
                        "timestamp_ms": msg.timestamp_ms,
                    })

                if self._player:
                    self._player.show_history_detail(
                        conversation_id, title, msg_dicts, page, total_pages, total_count, request_id
                    )

            except ConversationStoreError as e:
                if self._player:
                    self._player.show_history_error(f"Database error: {e}", request_id)
            except Exception as e:
                if self._player:
                    self._player.show_history_error(f"Failed to load messages: {type(e).__name__}: {e}", request_id)
            finally:
                # Close thread-local connection to avoid file locking on Windows
                # Note: ConversationStore.close() closes the calling thread's thread-local connection only.
                if store is not None:
                    store.close()

        self._run_in_thread(work)
        return request_id

    def search_messages(
        self,
        query: str,
        conversation_id: Optional[str] = None,
        role: Optional[str] = None,
        page: int = 0,
        page_size: int = 20,
    ) -> str:
        """
        Search messages using the store's search API.

        Results are delivered via player.show_history_list (reusing list view for search results)
        or player.show_history_error on failure.

        Note: The store's search_messages returns Message objects, not ConversationSummary.
        This method converts matching messages to a conversation-list-compatible format
        grouped by conversation for display in the list view.

        Args:
            query: Search text
            conversation_id: Optional filter to specific conversation
            role: Optional role filter ('user', 'assistant', 'system')
            page: Zero-based page number
            page_size: Number of results per page

        Returns:
            Request ID for correlation tracking.
        """
        request_id = self._generate_request_id()

        # Early return for empty or whitespace-only queries
        if not query or not query.strip():
            if self._player:
                self._player.show_history_list([], page, 1, 0, request_id)
            return request_id

        def work():
            store = None
            try:
                store = self._get_store()
                offset = page * page_size

                # Perform search
                messages = store.search_messages(
                    query=query,
                    conversation_id=conversation_id,
                    role=role,
                    limit=page_size,
                    offset=offset,
                )

                # Get accurate total count using the same filters
                total_count = store.count_search_messages(
                    query=query,
                    conversation_id=conversation_id,
                    role=role,
                )
                total_pages = max(1, (total_count + page_size - 1) // page_size)

                # For search, we need to group by conversation and show conversation summaries
                # This is a simplified approach: return the matching messages' conversations
                # In a full implementation, we'd want a dedicated search_conversations API
                # For now, convert messages to a list view showing conversation snippets
                results = []
                seen_conv_ids = set()

                for msg in messages:
                    if msg.conversation_id not in seen_conv_ids:
                        seen_conv_ids.add(msg.conversation_id)
                        try:
                            conv = store.get_conversation(msg.conversation_id)
                            results.append({
                                "id": conv.id,
                                "title": conv.title,
                                "started_at": conv.started_at,
                                "ended_at": conv.ended_at,
                                "turn_count": conv.turn_count,
                                "summary": conv.summary,
                                "language": conv.language,
                                "engine": conv.engine,
                            })
                        except ConversationNotFoundError:
                            pass

                if self._player:
                    self._player.show_history_list(results, page, total_pages, total_count, request_id)

            except ConversationStoreError as e:
                if self._player:
                    self._player.show_history_error(f"Database error: {e}", request_id)
            except Exception as e:
                if self._player:
                    self._player.show_history_error(f"Search failed: {type(e).__name__}: {e}", request_id)
            finally:
                # Close thread-local connection to avoid file locking on Windows
                # Note: ConversationStore.close() closes the calling thread's thread-local connection only.
                if store is not None:
                    store.close()

        self._run_in_thread(work)
        return request_id

    def search_conversations(
        self,
        query: str,
        conversation_id: Optional[str] = None,
        role: Optional[str] = None,
        page: int = 0,
        page_size: int = 20,
    ) -> str:
        """
        Search conversations using the store's conversation-level search API.

        Returns ConversationSummary objects directly (no message grouping needed).
        Results are delivered via player.show_history_list or player.show_history_error on failure.

        This is the preferred method for conversation list search — it returns
        accurate conversation-level pagination and deduplication at the database level.

        Args:
            query: Search text
            conversation_id: Optional filter to specific conversation
            role: Optional role filter ('user', 'assistant', 'system') — applies only to message content search
            page: Zero-based page number
            page_size: Number of results per page

        Returns:
            Request ID for correlation tracking.
        """
        request_id = self._generate_request_id()

        # Early return for empty or whitespace-only queries
        if not query or not query.strip():
            if self._player:
                self._player.show_history_list([], page, 1, 0, request_id)
            return request_id

        def work():
            store = None
            try:
                store = self._get_store()
                offset = page * page_size

                # Perform conversation-level search
                conversations = store.search_conversations(
                    query=query,
                    conversation_id=conversation_id,
                    role=role,
                    limit=page_size,
                    offset=offset,
                )

                # Get accurate total count using the same filters
                total_count = store.count_search_conversations(
                    query=query,
                    conversation_id=conversation_id,
                    role=role,
                )
                total_pages = max(1, (total_count + page_size - 1) // page_size)

                # Convert ConversationSummary objects to dicts for UI
                results = []
                for conv in conversations:
                    results.append({
                        "id": conv.id,
                        "title": conv.title,
                        "started_at": conv.started_at,
                        "ended_at": conv.ended_at,
                        "turn_count": conv.turn_count,
                        "summary": conv.summary,
                        "language": conv.language,
                        "engine": conv.engine,
                    })

                if self._player:
                    self._player.show_history_list(results, page, total_pages, total_count, request_id)

            except ConversationStoreError as e:
                if self._player:
                    self._player.show_history_error(f"Database error: {e}", request_id)
            except Exception as e:
                if self._player:
                    self._player.show_history_error(f"Conversation search failed: {type(e).__name__}: {e}", request_id)
            finally:
                # Close thread-local connection to avoid file locking on Windows
                if store is not None:
                    store.close()

        self._run_in_thread(work)
        return request_id

    # ─── Lifecycle ────────────────────────────────────────────────────────────

    def shutdown(self, wait: bool = False, timeout: float = 2.0) -> None:
        """
        Shutdown the worker.

        Args:
            wait: If True, wait for active threads to complete
            timeout: Maximum time to wait per thread (seconds)

        Note:
            join(timeout) does not forcibly terminate threads; it only waits
            up to the timeout. Threads blocked on DB locks may delay shutdown.
        """
        # Take a consistent snapshot of threads to join (atomic with shutdown flag)
        threads_to_join = []
        with self._lifecycle_lock:
            self._shutdown = True
            if wait:
                threads_to_join = list(self._active_threads)

        # Wait for threads OUTSIDE the lock to avoid deadlock
        if wait:
            for thread in threads_to_join:
                thread.join(timeout=timeout)

        # Clear the list (no new threads can be added after _shutdown=True)
        with self._lifecycle_lock:
            self._active_threads.clear()

    def is_busy(self) -> bool:
        """Return True if any worker threads are still running."""
        with self._lifecycle_lock:
            return any(t.is_alive() for t in self._active_threads)