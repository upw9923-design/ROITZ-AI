"""
actions/claude_code_task.py — Tool for executing Claude Code tasks with monitoring.

Provides a tool that:
- Runs `claude -p` with a given prompt
- Captures stdout/stderr via ProcessMonitor
- Associates output with a unique task ID
- Integrates with WorkerRegistry for resource coordination
- Uses outcome system for result reporting
- Supports cancellation and timeout handling
"""

from __future__ import annotations

import json
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Optional

from core.permission_guard import get_permission_guard
from core.worker_registry import get_global_registry, create_worker_record, WorkerState
from core.process_monitor import run_claude_code_task, ProcessResult, ProcessState
from core import outcome
from core import identity as _identity


# Module-level state for tracking active tasks
# Each entry stores: result, cancel_event, worker_record, completed_at, running_thread, owner_identity
_active_tasks: dict[str, dict] = {}
_tasks_lock = threading.Lock()


def _get_owner_identity(identity: Optional[_identity.CallerIdentity]) -> Optional[_identity.CallerIdentity]:
    """Extract owner identity from the provided identity parameter."""
    if identity is None:
        return None
    # Don't use anonymous identity as owner
    if identity.source == _identity.IDENTITY_SOURCE_ANONYMOUS if hasattr(_identity, 'IDENTITY_SOURCE_ANONYMOUS') else identity.source == "anonymous":
        return None
    return identity


def _generate_task_id() -> str:
    """Generate a unique task ID."""
    return f"claude_task_{uuid.uuid4().hex[:12]}"


def _store_task_info(task_id: str, result: ProcessResult, cancel_event: threading.Event,
                     worker_record: Any = None, running_thread: threading.Thread = None,
                     owner_identity: Optional[_identity.CallerIdentity] = None) -> None:
    """Store task info for retrieval and cancellation."""
    with _tasks_lock:
        _active_tasks[task_id] = {
            "result": result,
            "cancel_event": cancel_event,
            "worker_record": worker_record,
            "running_thread": running_thread,
            "completed_at": time.time(),
            "owner_identity": owner_identity,
        }


def _get_task_result(task_id: str) -> Optional[ProcessResult]:
    """Retrieve task result by ID."""
    with _tasks_lock:
        task = _active_tasks.get(task_id)
        if task:
            return task["result"]
    return None


def _get_task_cancel_event(task_id: str) -> Optional[threading.Event]:
    """Retrieve cancellation event for a task."""
    with _tasks_lock:
        task = _active_tasks.get(task_id)
        if task:
            return task.get("cancel_event")
    return None


def _get_task_worker_record(task_id: str) -> Any:
    """Retrieve worker record for a task."""
    with _tasks_lock:
        task = _active_tasks.get(task_id)
        if task:
            return task.get("worker_record")
    return None


def _get_task_owner_identity(task_id: str) -> Optional[_identity.CallerIdentity]:
    """Retrieve owner identity for a task."""
    with _tasks_lock:
        task = _active_tasks.get(task_id)
        if task:
            return task.get("owner_identity")
    return None


def _verify_task_ownership(task_id: str, caller_identity: Optional[_identity.CallerIdentity]) -> bool:
    """
    Verify that the caller owns the task.

    Returns True if:
    - The task has no owner recorded (backward compatibility)
    - The caller identity matches the task owner

    Returns False if:
    - The task has an owner and the caller doesn't match
    """
    owner = _get_task_owner_identity(task_id)
    if owner is None:
        # No owner recorded - allow access (backward compatibility)
        return True
    if caller_identity is None:
        return False
    # Compare source and subject for identity match
    return owner.source == caller_identity.source and owner.subject == caller_identity.subject


def _mark_task_completed(task_id: str, result: ProcessResult) -> None:
    """Mark task as completed with final result."""
    with _tasks_lock:
        if task_id in _active_tasks:
            _active_tasks[task_id]["result"] = result
            _active_tasks[task_id]["completed_at"] = time.time()
            # Clear running references
            _active_tasks[task_id]["running_thread"] = None


def _cleanup_old_tasks(max_age: float = 3600.0) -> None:
    """Remove completed tasks older than max_age seconds."""
    now = time.time()
    with _tasks_lock:
        to_remove = [
            tid for tid, data in _active_tasks.items()
            if now - data["completed_at"] > max_age
        ]
        for tid in to_remove:
            del _active_tasks[tid]


def claude_code_task(
    parameters: dict,
    response=None,
    player=None,
    session_memory=None,
    speak=None,
    identity=None,
) -> str:
    """
    Execute a Claude Code task with full output capture and monitoring.

    Parameters:
        prompt (str): The prompt to send to Claude Code (required)
        task_id (str, optional): Unique task ID (auto-generated if not provided)
        cwd (str, optional): Working directory (defaults to current)
        timeout (int, optional): Timeout in seconds (default: 300)
        additional_args (list, optional): Additional arguments to pass to claude
        wait (bool, optional): If true, wait for completion and return result.
                              If false, return immediately with task_id for polling. (default: true)

    Returns:
        Outcome string (done/unverified/failed/started) with task details.
    """
    p = parameters or {}
    prompt = p.get("prompt", "").strip()
    task_id = p.get("task_id", "").strip() or _generate_task_id()
    cwd = p.get("cwd", "")
    timeout = float(p.get("timeout", 300))
    additional_args = p.get("additional_args", [])
    wait = p.get("wait", True)

    if not prompt:
        return outcome.failed("claude_code_task", "prompt is required", task_id=task_id)

    # Validate additional_args is a list
    if not isinstance(additional_args, list):
        additional_args = []

    # Resolve working directory
    work_dir = Path(cwd).expanduser().resolve() if cwd else Path.cwd()
    if not work_dir.exists():
        return outcome.failed("claude_code_task", f"Working directory does not exist: {work_dir}", task_id=task_id)

    # Permission check
    operation_name = "claude_code_task"
    guard = get_permission_guard()
    params = {
        "prompt": prompt[:100],  # Truncate for logging
        "cwd": str(work_dir),
        "timeout": timeout,
    }
    result = guard.check_operation(operation_name, params)
    if not result.allowed:
        if result.reason == "owner_approval_required":
            return result.instruction
        return outcome.failed(operation_name, result.reason, task_id=task_id)

    # Extract owner identity from the provided identity parameter
    owner_identity = _get_owner_identity(identity)

    # Create cancellation event
    cancel_event = threading.Event()

    # Create worker record for resource coordination
    registry = get_global_registry()
    worker_params = {
        "prompt": prompt,
        "cwd": str(work_dir),
        "timeout": timeout,
        "additional_args": additional_args,
    }
    worker = create_worker_record(
        task_id=task_id,
        step_id=f"claude_code:{task_id}",
        tool_name="claude_code_task",
        parameters=worker_params,
        operation_name=operation_name,
        resource_scope="global",
        is_idempotent=False,
    )

    # Admission check
    admitted, conflict_reason = registry.admit_worker(worker)
    if not admitted:
        return outcome.failed(operation_name, f"Resource admission blocked: {conflict_reason}", task_id=task_id)

    # Mark worker as running
    current_thread = threading.current_thread()
    worker.mark_running(current_thread, cancel_event)

    def run_task(running_thread=None):
        try:
            if player:
                player.write_log(f"[ClaudeCodeTask] Starting task {task_id} in {work_dir}")

            # Store task info with cancel_event, worker, and owner identity
            _store_task_info(task_id, None, cancel_event, worker, running_thread, owner_identity)

            # Run the monitored process
            proc_result = run_claude_code_task(
                task_id=task_id,
                prompt=prompt,
                cwd=work_dir,
                timeout=timeout,
                worker_registry=registry,
                player=player,
                cancel_event=cancel_event,
                additional_args=additional_args,
            )

            # Mark task completed with result
            _mark_task_completed(task_id, proc_result)

            # Convert to outcome
            outcome_str = proc_result.to_outcome(operation_name)

            # Log completion
            if player:
                player.write_log(f"[ClaudeCodeTask] Task {task_id} completed: {proc_result.state.value}")

            # Mark worker completed
            worker.mark_completed("done")
            registry.release_resources(worker.attempt_id)

            # If wait=False, send result via player.request_say
            if not wait and speak:
                speak(f"[CLAUDE_CODE_TASK_DONE] {task_id} | {outcome_str[:500]}")

            return outcome_str

        except Exception as e:
            error_msg = f"Task execution failed: {type(e).__name__}: {str(e)[:200]}"
            if player:
                player.write_log(f"[ClaudeCodeTask] Task {task_id} error: {error_msg}")

            proc_result = ProcessResult(
                task_id=task_id,
                state=ProcessState.FAILED,
                error=error_msg,
                started_at=time.time(),
                finished_at=time.time(),
                duration=0.0,
            )
            _mark_task_completed(task_id, proc_result)

            worker.mark_failed(error_msg)
            registry.release_resources(worker.attempt_id)

            return outcome.failed(operation_name, error_msg, task_id=task_id)

    if wait:
        # Run synchronously (but on worker thread)
        return run_task(running_thread=current_thread)
    else:
        # Run asynchronously
        def async_wrapper():
            run_task()

        thread = threading.Thread(target=async_wrapper, daemon=True, name=f"claude_code-{task_id[:8]}")
        thread.start()

        # Store initial task info for async task with owner identity
        _store_task_info(task_id, None, cancel_event, worker, thread, owner_identity)

        if player:
            player.write_log(f"[ClaudeCodeTask] Started background task {task_id}")

        return outcome.started(operation_name, task_id=task_id, mode="async", project=str(work_dir))


def get_claude_code_result(
    parameters: dict,
    response=None,
    player=None,
    session_memory=None,
    speak=None,
    identity=None,
) -> str:
    """
    Retrieve the result of a previously started Claude Code task.

    Parameters:
        task_id (str): The task ID returned from claude_code_task with wait=false

    Returns:
        Outcome string with the task result.
    """
    p = parameters or {}
    task_id = p.get("task_id", "").strip()

    if not task_id:
        return outcome.failed("get_claude_code_result", "task_id is required")

    # Permission check
    operation_name = "get_claude_code_result"
    guard = get_permission_guard()
    result = guard.check_operation(operation_name, {"task_id": task_id})
    if not result.allowed:
        if result.reason == "owner_approval_required":
            return result.instruction
        return outcome.failed(operation_name, result.reason, task_id=task_id)

    # Ownership verification
    if not _verify_task_ownership(task_id, identity):
        return outcome.failed(operation_name, "Not authorized to access this task", task_id=task_id)

    # Clean up old tasks
    _cleanup_old_tasks()

    # Retrieve result
    proc_result = _get_task_result(task_id)

    if proc_result is None:
        return outcome.unverified(
            "get_claude_code_result",
            reason=f"No result found for task_id: {task_id}. Task may still be running or was cleaned up.",
            task_id=task_id,
        )

    return proc_result.to_outcome("get_claude_code_result")


def cancel_claude_code_task(
    parameters: dict,
    response=None,
    player=None,
    session_memory=None,
    speak=None,
    identity=None,
) -> str:
    """
    Cancel a running Claude Code task.

    Parameters:
        task_id (str): The task ID to cancel

    Returns:
        Outcome string indicating cancellation status.
    """
    p = parameters or {}
    task_id = p.get("task_id", "").strip()

    if not task_id:
        return outcome.failed("cancel_claude_code_task", "task_id is required")

    # Permission check
    operation_name = "cancel_claude_code_task"
    guard = get_permission_guard()
    result = guard.check_operation(operation_name, {"task_id": task_id})
    if not result.allowed:
        if result.reason == "owner_approval_required":
            return result.instruction
        return outcome.failed(operation_name, result.reason, task_id=task_id)

    # Ownership verification
    if not _verify_task_ownership(task_id, identity):
        return outcome.failed(operation_name, "Not authorized to cancel this task", task_id=task_id)

    # Get the cancel event for this task
    cancel_event = _get_task_cancel_event(task_id)
    worker_record = _get_task_worker_record(task_id)
    registry = get_global_registry()

    cancelled_count = 0

    # Trigger cancellation via the cancel_event (this will terminate the process)
    if cancel_event:
        cancel_event.set()
        cancelled_count = 1
        if player:
            player.write_log(f"[ClaudeCodeTask] Cancellation event set for task {task_id}")

    # Also request cancellation via WorkerRegistry (marks worker state)
    registry_cancelled = registry.request_task_cancellation(task_id)
    if registry_cancelled > 0:
        cancelled_count = max(cancelled_count, registry_cancelled)

    # Wait for the worker thread to terminate (with timeout)
    if worker_record and worker_record.thread and worker_record.thread.is_alive():
        worker_record.thread.join(timeout=5.0)
        if player:
            if worker_record.thread.is_alive():
                player.write_log(f"[ClaudeCodeTask] Worker thread for {task_id} did not terminate within timeout")
            else:
                player.write_log(f"[ClaudeCodeTask] Worker thread for {task_id} terminated")

    # Proper cleanup: mark worker as terminated, then release resources
    if worker_record:
        worker_record.mark_terminated()
        registry.release_resources(worker_record.attempt_id)

    # Also clean up from our tracking
    with _tasks_lock:
        if task_id in _active_tasks:
            _active_tasks[task_id]["cancelled"] = True
            # If there's a result, mark it as cancelled
            result = _active_tasks[task_id].get("result")
            if result and hasattr(result, 'state'):
                result.state = ProcessState.CANCELLED

    if player:
        player.write_log(f"[ClaudeCodeTask] Cancellation completed for task {task_id}")

    return outcome.done(
        "cancel_claude_code_task",
        task_id=task_id,
        workers_cancelled=cancelled_count,
    )


def list_claude_code_tasks(
    parameters: dict,
    response=None,
    player=None,
    session_memory=None,
    speak=None,
    identity=None,
) -> str:
    """
    List all active/completed Claude Code tasks.

    Returns:
        JSON string with task information.
    """
    # Permission check
    operation_name = "list_claude_code_tasks"
    guard = get_permission_guard()
    result = guard.check_operation(operation_name, {})
    if not result.allowed:
        if result.reason == "owner_approval_required":
            return result.instruction
        return outcome.failed(operation_name, result.reason)

    _cleanup_old_tasks()

    with _tasks_lock:
        tasks_info = []
        for task_id, data in _active_tasks.items():
            # Filter by ownership
            owner_identity = data.get("owner_identity")
            if owner_identity is not None and identity is not None:
                # Task has an owner, check if caller matches
                if not (owner_identity.source == identity.source and owner_identity.subject == identity.subject):
                    continue
            elif owner_identity is not None and identity is None:
                # Task has an owner but no caller identity - skip
                continue
            # If task has no owner, include it (backward compatibility)
            # If caller has no identity but task has no owner, include it

            result = data["result"]
            tasks_info.append({
                "task_id": task_id,
                "state": result.state.value if hasattr(result.state, 'value') else str(result.state),
                "returncode": result.returncode,
                "duration": result.duration,
                "completed_at": data["completed_at"],
                "has_output": bool(result.stdout or result.stderr),
            })

    import json
    return json.dumps({
        "tasks": tasks_info,
        "count": len(tasks_info),
    }, indent=2)


# Tool declarations for auto-discovery
TOOL_CLAUDE_CODE_TASK = {
    "name": "claude_code_task",
    "description": (
        "Execute a Claude Code task with full output capture and monitoring. "
        "Runs `claude -p <prompt>` in the background, captures stdout/stderr, "
        "and associates output with a unique task ID. Supports both synchronous "
        "(wait for result) and asynchronous (poll for result) modes."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "prompt": {
                "type": "STRING",
                "description": "The prompt to send to Claude Code (required)"
            },
            "task_id": {
                "type": "STRING",
                "description": "Optional unique task ID (auto-generated if not provided)"
            },
            "cwd": {
                "type": "STRING",
                "description": "Working directory (defaults to current directory)"
            },
            "timeout": {
                "type": "NUMBER",
                "description": "Timeout in seconds (default: 300)"
            },
            "additional_args": {
                "type": "ARRAY",
                "items": {"type": "STRING"},
                "description": "Additional arguments to pass to claude command"
            },
            "wait": {
                "type": "BOOLEAN",
                "description": "If true, wait for completion and return result. If false, return immediately with task_id for polling. (default: true)"
            },
        },
        "required": ["prompt"],
    },
}

TOOL_GET_CLAUDE_CODE_RESULT = {
    "name": "get_claude_code_result",
    "description": "Retrieve the result of a previously started Claude Code task (for async mode).",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "task_id": {
                "type": "STRING",
                "description": "The task ID returned from claude_code_task with wait=false"
            },
        },
        "required": ["task_id"],
    },
}

TOOL_CANCEL_CLAUDE_CODE_TASK = {
    "name": "cancel_claude_code_task",
    "description": "Cancel a running Claude Code task.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "task_id": {
                "type": "STRING",
                "description": "The task ID to cancel"
            },
        },
        "required": ["task_id"],
    },
}

TOOL_LIST_CLAUDE_CODE_TASKS = {
    "name": "list_claude_code_tasks",
    "description": "List all active/completed Claude Code tasks.",
    "parameters": {
        "type": "OBJECT",
        "properties": {},
    },
}

# Export all tools
TOOLS = [
    TOOL_CLAUDE_CODE_TASK,
    TOOL_GET_CLAUDE_CODE_RESULT,
    TOOL_CANCEL_CLAUDE_CODE_TASK,
    TOOL_LIST_CLAUDE_CODE_TASKS,
]