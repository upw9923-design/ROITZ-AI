"""
actions/task_agent.py — Autonomous task execution tool.

Provides the `task_agent` action for running multi-step autonomous tasks
with planning, execution, and monitoring. Integrates with existing
ActionRegistry, PluginRegistry, PermissionGuard, and memory systems.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Callable

from core.autonomous_agent import (
    Planner,
    Executor,
    TaskPlan,
    TaskStore,
    TaskState,
    requires_confirmation_for_tool,
)
from core.action_loader import ActionRegistry
from core.plugin_loader import PluginRegistry
from core.gemini import as_json, SMART
from core.undo import push_undo
from memory.config_manager import BASE_DIR


# Global task store and execution lock
_task_store = TaskStore()
_execution_lock = threading.Lock()
_active_executors: dict[str, Executor] = {}
_executors_lock = threading.Lock()
_current_task_id: str | None = None


def _get_registries() -> tuple[ActionRegistry, PluginRegistry]:
    """Get action and plugin registries from main module."""
    import main
    # Access the JarvisLive instance's registries
    # This is a bit of a hack but follows the pattern of how other actions access main
    return main._action_registry, main._plugin_registry


def _plan_task(goal: str, max_steps: int = 10) -> TaskPlan:
    """Generate a task plan from a goal."""
    action_registry, plugin_registry = _get_registries()
    planner = Planner(action_registry, plugin_registry, max_steps=max_steps)
    return planner.create_plan(goal)


def _register_undo_for_step(step: TaskStep) -> None:
    """Register undo function for reversible operations before execution.

    Called during plan preparation so undo is ready if step succeeds.
    """
    tool = step.tool
    params = step.parameters
    action = params.get("action", "").lower().strip()

    # file_controller undo operations
    if tool == "file_controller":
        if action == "write":
            path = params.get("path", "")
            # Can't easily undo write without knowing previous content
            # The action itself handles this if it reads before writing
            pass
        elif action == "create_file":
            path = params.get("path", "")
            def undo_create():
                import os
                try:
                    os.remove(path)
                    return f"Deleted created file {path}"
                except Exception as e:
                    return f"Undo failed: {e}"
            step.undo_label = f"create file {path}"
            step.undo_fn = undo_create
        elif action == "move":
            src = params.get("source", "")
            dst = params.get("destination", "")
            def undo_move():
                import shutil
                try:
                    shutil.move(dst, src)
                    return f"Moved {dst} back to {src}"
                except Exception as e:
                    return f"Undo failed: {e}"
            step.undo_label = f"move {src} → {dst}"
            step.undo_fn = undo_move
        elif action == "copy":
            src = params.get("source", "")
            dst = params.get("destination", "")
            def undo_copy():
                import os
                try:
                    os.remove(dst)
                    return f"Deleted copied file {dst}"
                except Exception as e:
                    return f"Undo failed: {e}"
            step.undo_label = f"copy {src} → {dst}"
            step.undo_fn = undo_copy

    # computer_settings undo operations
    elif tool == "computer_settings":
        if action == "volume_set":
            from actions.computer_settings import volume_get, volume_set
            before = volume_get()
            if before is not None:
                target = int(params.get("value", 50))
                def undo_volume():
                    volume_set(before)
                    return f"Volume restored to {before}%"
                step.undo_label = f"volume {before}% → {target}%"
                step.undo_fn = undo_volume
        elif action in ("volume_up", "volume_down"):
            from actions.computer_settings import volume_get, volume_set
            before = volume_get()
            if before is not None:
                def undo_volume():
                    volume_set(before)
                    return f"Volume restored to {before}%"
                step.undo_label = f"volume ({action})"
                step.undo_fn = undo_volume
        elif action in ("brightness_up", "brightness_down"):
            from actions.computer_settings import brightness_get, brightness_set
            before = brightness_get()
            if before is not None:
                def undo_brightness():
                    brightness_set(before)
                    return f"Brightness restored to {before}%"
                step.undo_label = f"brightness ({action})"
                step.undo_fn = undo_brightness
        elif action == "dark_mode":
            from actions.computer_settings import dark_mode
            def undo_dark():
                dark_mode()
                return "Theme toggled back"
            step.undo_label = "dark mode toggled"
            step.undo_fn = undo_dark

    # computer_control undo operations (some are reversible)
    elif tool == "computer_control":
        if action == "close_window":
            # Can't easily undo closing a window
            pass
        # Most computer_control actions are keystrokes - not easily reversible


def _execute_task(plan: TaskPlan, player=None, session_memory=None) -> str:
    """Execute a task plan and return result summary."""
    global _current_task_id, _active_executors

    action_registry, plugin_registry = _get_registries()
    executor = Executor(action_registry, plugin_registry, player=player, session_memory=session_memory)

    # Register active executor
    with _executors_lock:
        _active_executors[plan.task_id] = executor

    # Check for required confirmations before starting
    # Register undo functions for reversible operations
    for step in plan.steps:
        if requires_confirmation_for_tool(step.tool, step.parameters):
            step.requires_confirmation = True
        _register_undo_for_step(step)

    _current_task_id = plan.task_id
    try:
        result = executor.execute(plan)
    finally:
        _current_task_id = None
        with _executors_lock:
            _active_executors.pop(plan.task_id, None)

    # Update task store
    _task_store.update(plan)

    if result.success:
        return f"Task '{plan.goal}' completed successfully ({result.completed_steps}/{result.total_steps} steps)."
    else:
        return f"Task '{plan.goal}' failed at step {plan.current_step_index + 1}/{result.total_steps}: {result.error}"


def _run_background_task(
    goal: str,
    max_steps: int,
    speak: Any = None,
    player: Any = None,
    session_memory: Any = None,
) -> str:
    """Run task in background thread and return immediately."""
    def worker():
        try:
            plan = _plan_task(goal, max_steps)
            _task_store.create(plan)
            result = _execute_task(plan, player=player, session_memory=session_memory)
            if speak:
                speak(f"[TASK_DONE] {result}")
        except Exception as e:
            error_msg = f"Task failed: {e}"
            if speak:
                speak(f"[TASK_ERROR] {error_msg}")
        finally:
            if _execution_lock.locked():
                try:
                    _execution_lock.release()
                except RuntimeError:
                    pass

    thread = threading.Thread(target=worker, daemon=True, name="task_agent")
    thread.start()
    return f"[STARTED] Task agent is now working on: {goal}. Progress will be reported when complete."


def task_agent(
    parameters: dict,
    response=None,
    player=None,
    session_memory=None,
    speak=None,
) -> str:
    """
    Autonomous task agent tool.

    Modes:
    - "plan" (default): Create and return a plan for the goal
    - "execute": Plan and execute the goal (background)
    - "status": Get status of current or specified task
    - "cancel": Cancel current or specified task
    """
    p = parameters or {}
    goal = p.get("goal", "").strip()
    mode = str(p.get("mode") or "execute").strip().lower()
    task_id = p.get("task_id", "").strip()
    max_steps = int(p.get("max_steps", 10))

    if mode == "status":
        if task_id:
            plan = _task_store.get(task_id)
        else:
            plan = _task_store.get(_current_task_id) if _current_task_id else None

        if not plan:
            return "No active task found."

        steps_done = sum(1 for s in plan.steps if s.status.value == "done")
        steps_total = len(plan.steps)
        current = plan.steps[plan.current_step_index] if plan.current_step_index < len(plan.steps) else None

        status_lines = [
            f"Task: {plan.task_id}",
            f"Goal: {plan.goal}",
            f"Status: {plan.status.value}",
            f"Progress: {steps_done}/{steps_total} steps",
        ]
        if current:
            status_lines.append(f"Current: {current.id} ({current.tool}) - {current.status.value}")
        if plan.error:
            status_lines.append(f"Error: {plan.error}")

        return "\n".join(status_lines)

    if mode == "cancel":
        target_id = task_id or _current_task_id
        if not target_id:
            return "No task to cancel."

        plan = _task_store.get(target_id)
        if not plan:
            return f"Task {target_id} not found."

        if plan.status in (TaskState.COMPLETED, TaskState.FAILED, TaskState.CANCELLED):
            return f"Task already {plan.status.value}."

        plan.cancelled = True
        plan.status = TaskState.CANCELLED
        _task_store.update(plan)

        with _executors_lock:
            executor = _active_executors.get(target_id)
            if executor:
                executor.cancel()

        return f"Task {target_id} cancelled."

    if mode == "plan":
        if not goal:
            return "Goal is required for planning."
        try:
            plan = _plan_task(goal, max_steps)
            _task_store.create(plan)
            steps_summary = "\n".join(
                f"  {i+1}. {s.id}: {s.tool} — {s.description}"
                for i, s in enumerate(plan.steps)
            )
            return f"Plan for: {goal}\n{steps_summary}\n\nTask ID: {plan.task_id} (use mode='execute' with this task_id to run)"
        except Exception as e:
            return f"Planning failed: {e}"

    # mode == "execute"
    if not goal:
        return "Goal is required for execution."

    if not _execution_lock.acquire(blocking=False):
        return "Another task is already running. Use mode='status' to check or mode='cancel' to stop it."

    try:
        return _run_background_task(goal, max_steps, speak=speak, player=player, session_memory=session_memory)
    except Exception:
        if _execution_lock.locked():
            _execution_lock.release()
        raise


# Tool declaration for auto-discovery
TOOL = {
    "name": "task_agent",
    "description": (
        "Autonomous task agent for multi-step goals. "
        "mode='plan' creates a structured plan from a goal. "
        "mode='execute' plans and runs the task in the background. "
        "mode='status' reports progress of current or specified task. "
        "mode='cancel' stops a running task. "
        "All execution respects existing permission system."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "goal": {
                "type": "STRING",
                "description": "What to accomplish in the user's words"
            },
            "mode": {
                "type": "STRING",
                "description": "'plan' to create plan, 'execute' to run, 'status' to check progress, 'cancel' to stop",
                "enum": ["plan", "execute", "status", "cancel"]
            },
            "task_id": {
                "type": "STRING",
                "description": "Task ID for status/cancel (default: current task)"
            },
            "max_steps": {
                "type": "INTEGER",
                "description": "Maximum steps in plan (default: 10, max: 20)"
            }
        },
        "required": ["goal"]
    },
    "handler": task_agent,
    "behavior": "NON_BLOCKING",
    "scheduling": "WHEN_IDLE",
}