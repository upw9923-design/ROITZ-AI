#computer_control.py
import io
import json
import math
import platform
import re
import string
import subprocess
import sys
import time
import random
import threading
import uuid
from dataclasses import dataclass
from pathlib import Path
from threading import Lock
from typing import Optional

if platform.system() == "Windows":
    _WIN_HIDE: dict = {"creationflags": subprocess.CREATE_NO_WINDOW}
else:
    _WIN_HIDE: dict = {}

from core import appidentity, outcome
from core.lazyimport import LazyModule, installed
from core.worker_registry import (
    get_global_registry, create_worker_record
)

# pyautogui and pyperclip are imported on first USE, not at launch — see
# core/lazyimport.py for why and for what stays the same. The flags still mean
# "is it installed?" and still answer without importing anything.
_PYAUTOGUI = installed("pyautogui")
_PYPERCLIP = installed("pyperclip")


def _configure_pyautogui(module) -> None:
    """Settings that used to sit beside the import, run once when it happens."""
    module.FAILSAFE = True
    module.PAUSE = 0.05


pyautogui = LazyModule("pyautogui", _configure_pyautogui)
pyperclip = LazyModule("pyperclip")

# Import unified screen capture API
from core.screen_capture import capture_primary_monitor


# ──────────────────────────────────────────────────────────────────────────────
# Screen Find Result — structured output for visual element detection
# ──────────────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ScreenFindResult:
    """Result of visual element detection with confidence and evidence."""
    x: int
    y: int
    confidence: float           # 0.0 - 1.0
    bounding_box: tuple[int, int, int, int] | None  # (x, y, width, height) if available
    raw_response: str           # Raw AI response for debugging

    def is_valid(self, screen_width: int, screen_height: int) -> bool:
        """Check if coordinates are within screen bounds."""
        return 0 <= self.x < screen_width and 0 <= self.y < screen_height

    def is_high_confidence(self, threshold: float = 0.7) -> bool:
        """Check if confidence meets threshold."""
        return self.confidence >= threshold


# ──────────────────────────────────────────────────────────────────────────────
# Input Validation & Safety Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _validate_coordinates(x, y, action: str) -> str | None:
    """Validate screen coordinates are within bounds. Returns error message or None.

    Accepts only int or float (finite). Rejects str, bool, None, NaN, inf.
    Floats are converted to int by truncation toward zero.
    """
    # Type validation - reject non-numeric types
    if isinstance(x, bool) or isinstance(y, bool):
        return f"{action}: coordinates must be numbers, not boolean"
    if not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
        return f"{action}: coordinates must be int or float, got {type(x).__name__} and {type(y).__name__}"

    # Reject NaN and infinity
    if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
        return f"{action}: x coordinate is not a finite number"
    if isinstance(y, float) and (math.isnan(y) or math.isinf(y)):
        return f"{action}: y coordinate is not a finite number"

    # Convert floats to int (truncate toward zero)
    x_int = int(x)
    y_int = int(y)

    _require_pyautogui()
    try:
        w, h = pyautogui.size()
    except Exception as e:
        return f"{action}: could not get screen size - {e}"

    if x_int < 0 or y_int < 0:
        return f"{action}: coordinates ({x_int}, {y_int}) cannot be negative"
    if x_int >= w or y_int >= h:
        return f"{action}: coordinates ({x_int}, {y_int}) out of screen bounds ({w}x{h})"
    return None


def _validate_text_length(text: str, max_len: int, action: str) -> str | None:
    """Validate text length. Returns error message or None."""
    if len(text) > max_len:
        return f"{action}: text length {len(text)} exceeds maximum {max_len}"
    return None


def _validate_keys(keys: list[str], action: str) -> str | None:
    """Validate key combination. Returns error message or None."""
    if not keys or all(not k.strip() for k in keys):
        return f"{action}: no keys provided"
    valid_modifiers = {"ctrl", "control", "alt", "option", "shift", "command", "cmd", "win", "windows", "super"}
    for k in keys:
        kl = k.lower().strip()
        if not kl:
            continue
        if kl in valid_modifiers:
            continue
        # Single character keys, function keys, arrow keys, etc.
        if len(kl) == 1 and kl.isprintable():
            continue
        if kl.startswith("f") and kl[1:].isdigit() and 1 <= int(kl[1:]) <= 24:
            continue
        if kl in {"enter", "return", "tab", "space", "backspace", "delete", "esc", "escape",
                  "up", "down", "left", "right", "home", "end", "pageup", "pagedown",
                  "insert", "printscreen", "scrolllock", "pause", "capslock", "numlock"}:
            continue
        # Unknown key - warn but allow (PyAutoGUI will handle it)
    return None


def _verify_window_focus(expected_title: str | None = None) -> tuple[bool, str | None]:
    """
    Verify that the expected window has focus (best-effort).
    Returns (has_focus, message_or_None).
    """
    _require_pyautogui()
    try:
        # Get active window title - platform specific
        os_name = _get_os()
        if os_name == "windows":
            import ctypes
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
            if length > 0:
                buf = ctypes.create_unicode_buffer(length + 1)
                ctypes.windll.user32.GetWindowTextW(hwnd, buf, length + 1)
                active_title = buf.value
            else:
                active_title = ""
        elif os_name == "mac":
            # On macOS, we'd need AppKit - skip for now
            return True, None
        else:
            # Linux - would need xdotool/wmctrl - skip for now
            return True, None

        if expected_title and expected_title.lower() not in active_title.lower():
            return False, f"Window focus check: expected '{expected_title}', active is '{active_title}'"
        return True, None
    except Exception:
        # If we can't verify, don't block - just warn
        return True, None


# ──────────────────────────────────────────────────────────────────────────────
# Focus Verification Gate — prevents sensitive input after failed/unverified focus
# ──────────────────────────────────────────────────────────────────────────────

# Module-level state for focus tracking (thread-safe)
_FOCUS_STATE_LOCK = Lock()
# Stores: {"title": str, "hwnd": int | None, "timestamp": float, "verified": bool}
_LAST_VERIFIED_FOCUS: dict | None = None
_FOCUS_VERIFICATION_TTL = 5.0  # seconds - focus verification expires after this


def _update_focus_state(title: str, verified: bool, hwnd: int | None = None) -> None:
    """Update the last verified focus state."""
    with _FOCUS_STATE_LOCK:
        global _LAST_VERIFIED_FOCUS
        if verified:
            _LAST_VERIFIED_FOCUS = {
                "title": title,
                "hwnd": hwnd,
                "timestamp": time.time(),
                "verified": True,
            }
        else:
            # Clear on failed/unverified focus
            _LAST_VERIFIED_FOCUS = None


def _check_focus_verification(expected_title: str) -> tuple[bool, str | None]:
    """
    Check if focus is currently verified for the expected window.
    Returns (is_verified, error_message).
    """
    with _FOCUS_STATE_LOCK:
        global _LAST_VERIFIED_FOCUS

        if _LAST_VERIFIED_FOCUS is None:
            return False, "No verified focus — call focus_window first and wait for verification"

        # Check if verification has expired
        elapsed = time.time() - _LAST_VERIFIED_FOCUS["timestamp"]
        if elapsed > _FOCUS_VERIFICATION_TTL:
            _LAST_VERIFIED_FOCUS = None
            return False, f"Focus verification expired ({elapsed:.1f}s ago) — re-run focus_window"

        # Check if the verified window matches the expected one
        if _LAST_VERIFIED_FOCUS["title"].lower() not in expected_title.lower() and expected_title.lower() not in _LAST_VERIFIED_FOCUS["title"].lower():
            return False, f"Focus mismatch: verified '{_LAST_VERIFIED_FOCUS['title']}' but expected '{expected_title}'"

        return True, None


def _require_focus_verification(action: str, expected_title: str | None = None) -> str | None:
    """
    Check focus verification before sensitive input actions.
    Returns error message if focus not verified, None if OK to proceed.
    If expected_title is provided, verifies it matches the verified focus.
    If not provided, just checks that there's ANY recent verified focus.
    Performs live foreground HWND verification on Windows.
    """
    with _FOCUS_STATE_LOCK:
        global _LAST_VERIFIED_FOCUS

        if _LAST_VERIFIED_FOCUS is None:
            return f"{action}: focus verification required — call focus_window first and wait for verification"

        # Check if verification has expired
        elapsed = time.time() - _LAST_VERIFIED_FOCUS["timestamp"]
        if elapsed > _FOCUS_VERIFICATION_TTL:
            _LAST_VERIFIED_FOCUS = None
            return f"{action}: focus verification expired ({elapsed:.1f}s ago) — re-run focus_window"

        # Live foreground HWND verification on Windows
        os_name = _get_os()
        if os_name == "windows":
            try:
                import ctypes
                current_hwnd = ctypes.windll.user32.GetForegroundWindow()
                if not current_hwnd or current_hwnd == 0:
                    _LAST_VERIFIED_FOCUS = None
                    return f"{action}: no foreground window — focus lost or invalid"

                verified_hwnd = _LAST_VERIFIED_FOCUS.get("hwnd")
                if verified_hwnd is not None and current_hwnd != verified_hwnd:
                    # Mismatch: foreground window is different from verified target
                    _LAST_VERIFIED_FOCUS = None
                    return f"{action}: focus mismatch — foreground window changed (expected HWND {verified_hwnd}, got {current_hwnd})"

                # If we have a verified HWND but no expected_title, still verify HWND matches
                # If expected_title is provided, also do title substring check as fallback
                if expected_title:
                    length = ctypes.windll.user32.GetWindowTextLengthW(current_hwnd)
                    if length > 0:
                        buf = ctypes.create_unicode_buffer(length + 1)
                        ctypes.windll.user32.GetWindowTextW(current_hwnd, buf, length + 1)
                        active_title = buf.value
                        if expected_title.lower() not in active_title.lower():
                            # Title mismatch even if HWND matches (window title changed)
                            _LAST_VERIFIED_FOCUS = None
                            return f"{action}: focus mismatch — active window title '{active_title}' does not match expected '{expected_title}'"
            except Exception as e:
                _LAST_VERIFIED_FOCUS = None
                return f"{action}: focus verification failed — {e}"

        # macOS/Linux: no live HWND verification available, rely on TTL only
        # (focus_window on these platforms returns unverified, so state would be None anyway)

        # If expected_title provided, check it matches the verified focus (title fallback)
        if expected_title:
            verified_title = _LAST_VERIFIED_FOCUS["title"]
            if verified_title.lower() not in expected_title.lower() and expected_title.lower() not in verified_title.lower():
                return f"{action}: focus mismatch — verified '{verified_title}' but expected '{expected_title}'"

        return None


# ──────────────────────────────────────────────────────────────────────────────
# Screen Recording — Persistent Recording Lifecycle (Phase 4 Batch 4)
# ──────────────────────────────────────────────────────────────────────────────

_RECORDING_STATE_LOCK = Lock()
_RECORDING_STATE: dict | None = None  # None = not recording, dict = recording info
# Structure when recording:
# {
#     "session_id": str,
#     "start_time": float,
#     "thread": threading.Thread,
#     "cancel_event": threading.Event,
#     "video_writer": cv2.VideoWriter,
#     "output_path": Path,
#     "fps": int,
#     "duration_limit": float,  # seconds
#     "size_limit": int,  # bytes
#     "monitor_index": int,
#     "region": tuple | None,  # (x, y, width, height) or None for full monitor
# }

# Default recording limits (configurable via parameters)
_DEFAULT_FPS = 15
_MAX_DURATION = 300  # 5 minutes
_MAX_FILE_SIZE = 500 * 1024 * 1024  # 500 MB
_RECORDINGS_DIR = Path.home() / "Videos" / "JarvisRecordings"


def _get_recordings_dir() -> Path:
    """Get the controlled recordings directory, creating it if needed."""
    _RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)
    return _RECORDINGS_DIR


def _generate_recording_filename() -> Path:
    """Generate a unique filename for the recording."""
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    unique_id = uuid.uuid4().hex[:8]
    return _get_recordings_dir() / f"jarvis_recording_{timestamp}_{unique_id}.mp4"


def _is_recording() -> bool:
    """Check if a recording is currently in progress."""
    with _RECORDING_STATE_LOCK:
        return _RECORDING_STATE is not None


def _get_recording_status() -> dict | None:
    """Get current recording status info."""
    with _RECORDING_STATE_LOCK:
        if _RECORDING_STATE is None:
            return None
        state = _RECORDING_STATE.copy()
        # Add computed fields
        state["elapsed_seconds"] = time.time() - state["start_time"]
        state["output_path"] = str(state["output_path"])
        # Remove non-serializable objects
        state.pop("thread", None)
        state.pop("cancel_event", None)
        state.pop("video_writer", None)
        return state


def _stop_recording_internal() -> tuple[bool, str, dict | None]:
    """
    Internal function to stop recording and release resources.
    Returns (success, message, recording_info).
    """
    with _RECORDING_STATE_LOCK:
        global _RECORDING_STATE
        if _RECORDING_STATE is None:
            return False, "No recording in progress", None

        state = _RECORDING_STATE
        cancel_event = state.get("cancel_event")
        video_writer = state.get("video_writer")
        thread = state.get("thread")
        output_path = state.get("output_path")
        start_time = state.get("start_time")
        worker_attempt_id = state.get("worker_attempt_id")

        # Signal the recording thread to stop
        if cancel_event:
            cancel_event.set()

        # Clear the recording state immediately to prevent duplicate stops
        _RECORDING_STATE = None

    # Wait for the recording thread to finish (outside the lock)
    if thread and thread.is_alive():
        thread.join(timeout=10.0)
        if thread.is_alive():
            return False, "Recording thread did not terminate in time", None

    # Unregister worker from WorkerRegistry
    if worker_attempt_id:
        registry = get_global_registry()
        registry.unregister(worker_attempt_id)

    # Release video writer
    if video_writer:
        try:
            video_writer.release()
        except Exception as e:
            return False, f"Failed to release video writer: {e}", None

    # Verify the output file exists and get its size
    file_size = 0
    if output_path and output_path.exists():
        file_size = output_path.stat().st_size

    elapsed = time.time() - start_time if start_time else 0
    recording_info = {
        "output_path": str(output_path) if output_path else None,
        "duration_seconds": elapsed,
        "file_size_bytes": file_size,
        "file_size_mb": round(file_size / (1024 * 1024), 2),
    }

    return True, f"Recording stopped successfully ({recording_info['duration_seconds']:.1f}s, {recording_info['file_size_mb']} MB)", recording_info


def _recording_worker(
    cancel_event: threading.Event,
    output_path: Path,
    fps: int,
    duration_limit: float,
    size_limit: int,
    monitor_index: int,
    region: tuple | None,
):
    """
    Background thread that captures frames and writes them to video.
    """
    try:
        import cv2
        import numpy as np
    except ImportError as e:
        print(f"[ScreenRecording] ❌ OpenCV not available: {e}")
        return

    from core.screen_capture import capture_primary_monitor, capture_monitor, capture_region

    # Get initial frame to determine video dimensions
    try:
        if region:
            x, y, w, h = region
            first_frame_bytes, _ = capture_region(x, y, w, h, monitor_index=monitor_index)
        else:
            if monitor_index == 0:
                first_frame_bytes, _ = capture_primary_monitor()
            else:
                first_frame_bytes, _ = capture_monitor(monitor_index)
    except Exception as e:
        print(f"[ScreenRecording] ❌ Failed to capture initial frame: {e}")
        return

    # Decode frame to get dimensions
    try:
        nparr = np.frombuffer(first_frame_bytes, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if frame is None:
            print("[ScreenRecording] ❌ Failed to decode initial frame")
            return
        height, width = frame.shape[:2]
    except Exception as e:
        print(f"[ScreenRecording] ❌ Failed to process initial frame: {e}")
        return

    # Create video writer
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    video_writer = cv2.VideoWriter(str(output_path), fourcc, fps, (width, height))

    if not video_writer.isOpened():
        print(f"[ScreenRecording] ❌ Failed to open video writer for {output_path}")
        return

    # Write first frame
    video_writer.write(frame)

    # Update state with video writer
    with _RECORDING_STATE_LOCK:
        if _RECORDING_STATE is not None:
            _RECORDING_STATE["video_writer"] = video_writer

    frame_interval = 1.0 / fps
    start_time = time.time()
    last_capture_time = start_time
    frame_count = 1

    while not cancel_event.is_set():
        # Check duration limit
        elapsed = time.time() - start_time
        if elapsed >= duration_limit:
            print(f"[ScreenRecording] ⏱️ Duration limit reached ({duration_limit}s)")
            break

        # Check file size limit
        if output_path.exists():
            current_size = output_path.stat().st_size
            if current_size >= size_limit:
                print(f"[ScreenRecording] 📦 Size limit reached ({size_limit} bytes)")
                break

        # Capture next frame
        try:
            if region:
                x, y, w, h = region
                frame_bytes, _ = capture_region(x, y, w, h, monitor_index=monitor_index)
            else:
                if monitor_index == 0:
                    frame_bytes, _ = capture_primary_monitor()
                else:
                    frame_bytes, _ = capture_monitor(monitor_index)

            nparr = np.frombuffer(frame_bytes, np.uint8)
            frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            if frame is not None:
                # Resize if dimensions changed (shouldn't happen but be safe)
                if frame.shape[:2] != (height, width):
                    frame = cv2.resize(frame, (width, height))
                video_writer.write(frame)
                frame_count += 1
        except Exception as e:
            print(f"[ScreenRecording] ⚠️ Frame capture failed: {e}")
            # Continue trying - don't fail the whole recording for one bad frame
            pass

        # Maintain target FPS
        elapsed_since_last = time.time() - last_capture_time
        sleep_time = frame_interval - elapsed_since_last
        if sleep_time > 0:
            time.sleep(sleep_time)
        last_capture_time = time.time()

    # Final cleanup
    video_writer.release()
    print(f"[ScreenRecording] ✅ Recording thread finished: {frame_count} frames, {time.time() - start_time:.1f}s")


def _require_pyautogui():
    """Refuse early, with the sentence that says what to install."""
    if not _PYAUTOGUI:
        raise RuntimeError("PyAutoGUI not installed. Run: pip install pyautogui")


def _require_pyperclip() -> bool:
    """Is the clipboard usable? Returns a bool rather than raising."""
    return _PYPERCLIP

def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


_BASE         = _base_dir()
_CONFIG_PATH  = _BASE / "config" / "api_keys.json"
_MEMORY_PATH  = _BASE / "memory" / "long_term.json"

def _load_config() -> dict:
    try:
        return json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _platform_os() -> str:
    return {"Windows": "windows", "Darwin": "mac", "Linux": "linux"}.get(
        platform.system(), "linux"
    )

def _get_os() -> str:
    return _load_config().get("os_system", _platform_os()).lower()


def _get_api_key() -> str:
    return _load_config().get("gemini_api_key", "")

_SAFE_SCREENSHOT_ROOTS = (
    Path.home(),
)

def _safe_screenshot_path(requested: str | None) -> Path:
    fallback = Path.home() / "Desktop" / "jarvis_screenshot.png"
    if not requested:
        return fallback
    try:
        p = Path(requested).expanduser().resolve()
        for root in _SAFE_SCREENSHOT_ROOTS:
            if p.is_relative_to(root.resolve()):
                p.parent.mkdir(parents=True, exist_ok=True)
                return p
    except Exception:
        pass
    return fallback

def _require_pyautogui():
    """Refuse early, with the sentence that says what to install.

    The import itself is the module `__getattr__`'s job; this stays exactly
    what it was — the check that turns a missing optional dependency into an
    instruction rather than a traceback.
    """
    if not _PYAUTOGUI:
        raise RuntimeError("PyAutoGUI not installed. Run: pip install pyautogui")


def _require_pyperclip() -> bool:
    """Is the clipboard usable? Returns a bool rather than raising, because
    every caller already has a hotkey fallback written for the case where it
    is not — turning that into an exception would break the path built to
    survive it."""
    return _PYPERCLIP

_FIRST_NAMES = [
    "Alex", "Jordan", "Taylor", "Morgan", "Casey", "Riley", "Drew", "Quinn",
    "Avery", "Blake", "Cameron", "Dakota", "Emerson", "Finley", "Harper",
]
_LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller",
    "Davis", "Wilson", "Moore", "Taylor", "Anderson", "Thomas", "Jackson",
]
_DOMAINS = ["gmail.com", "yahoo.com", "outlook.com", "proton.me", "mail.com"]


def _random_data(data_type: str) -> str:
    dt = data_type.lower().strip()

    if dt == "first_name":
        return random.choice(_FIRST_NAMES)

    if dt == "last_name":
        return random.choice(_LAST_NAMES)

    if dt == "name":
        return f"{random.choice(_FIRST_NAMES)} {random.choice(_LAST_NAMES)}"

    if dt == "email":
        first = random.choice(_FIRST_NAMES).lower()
        last  = random.choice(_LAST_NAMES).lower()
        num   = random.randint(10, 999)
        return f"{first}.{last}{num}@{random.choice(_DOMAINS)}"

    if dt == "username":
        return f"{random.choice(_FIRST_NAMES).lower()}{random.randint(100, 9999)}"

    if dt == "password":
        chars = string.ascii_letters + string.digits + "!@#$%"
        raw   = (
            random.choice(string.ascii_uppercase)
            + random.choice(string.digits)
            + random.choice("!@#$%")
            + "".join(random.choices(chars, k=9))
        )
        return "".join(random.sample(raw, len(raw)))

    if dt == "phone":
        return f"+1{random.randint(200,999)}{random.randint(1_000_000, 9_999_999)}"

    if dt == "birthday":
        y = random.randint(1980, 2000)
        m = random.randint(1, 12)
        d = random.randint(1, 28)
        return f"{m:02d}/{d:02d}/{y}"

    if dt == "address":
        num    = random.randint(100, 9999)
        street = random.choice(["Main St", "Oak Ave", "Park Blvd", "Elm St", "Cedar Ln"])
        return f"{num} {street}"

    if dt == "zip_code":
        return str(random.randint(10000, 99999))

    if dt == "city":
        return random.choice(["New York", "Los Angeles", "Chicago", "Houston", "Phoenix"])

    return f"random_{data_type}_{random.randint(1000, 9999)}"

def _user_profile() -> dict:
    """Read identity fields from long-term memory."""
    try:
        if _MEMORY_PATH.exists():
            data     = json.loads(_MEMORY_PATH.read_text(encoding="utf-8"))
            identity = data.get("identity", {})
            return {k: v.get("value", "") for k, v in identity.items()}
    except Exception:
        pass
    return {}

def _type(text: str, interval: float = 0.03) -> str:
    _require_pyautogui()

    # Input validation
    err = _validate_text_length(text, 5000, "type")
    if err:
        return outcome.failed("type", err)

    time.sleep(0.3)
    pyautogui.typewrite(text, interval=interval)
    # Command sent successfully, but text appearance not verified
    return outcome.unverified("type", "text sent; appearance not verified", text=text[:60] + ("…" if len(text) > 60 else ""))


def _smart_type(text: str, clear_first: bool = True) -> str:
    _require_pyautogui()

    # Input validation
    err = _validate_text_length(text, 5000, "smart_type")
    if err:
        return outcome.failed("smart_type", err)

    if clear_first:
        _clear_field()
        time.sleep(0.1)

    if len(text) > 20 and _require_pyperclip():
        pyperclip.copy(text)
        time.sleep(0.1)
        paste_key = "command" if _get_os() == "mac" else "ctrl"
        pyautogui.hotkey(paste_key, "v")
        return outcome.unverified("smart_type", "text sent via clipboard; appearance not verified", text=text[:60] + ("…" if len(text) > 60 else ""), method="clipboard")

    pyautogui.typewrite(text, interval=0.04)
    return outcome.unverified("smart_type", "text sent via typewrite; appearance not verified", text=text[:60] + ("…" if len(text) > 60 else ""), method="typewrite")


def _click(x=None, y=None, button: str = "left", clicks: int = 1) -> str:
    _require_pyautogui()

    # Validate button
    if button not in ("left", "right", "middle"):
        return outcome.failed("click", f"Invalid button: {button}. Must be 'left', 'right', or 'middle'")

    # Validate clicks
    if clicks not in (1, 2):
        return outcome.failed("click", f"Invalid clicks: {clicks}. Must be 1 or 2")

    if x is not None and y is not None:
        # Input validation
        err = _validate_coordinates(x, y, "click")
        if err:
            return outcome.failed("click", err)
        # Convert validated coordinates to int for pyautogui
        x_int = int(x)
        y_int = int(y)
        pyautogui.click(x_int, y_int, button=button, clicks=clicks)
        return outcome.unverified("click", "click sent at coordinates; target not verified", x=x_int, y=y_int, button=button, clicks=clicks)

    pyautogui.click(button=button, clicks=clicks)
    return outcome.unverified("click", "click sent at current position; target not verified", button=button, clicks=clicks, position="current")


def _hotkey(*keys) -> str:
    _require_pyautogui()

    # Input validation
    err = _validate_keys(list(keys), "hotkey")
    if err:
        return outcome.failed("hotkey", err)

    pyautogui.hotkey(*keys)
    return outcome.unverified("hotkey", "hotkey sent; effect not verified", keys="+".join(keys))


def _press(key: str) -> str:
    _require_pyautogui()

    # Input validation
    err = _validate_keys([key], "press")
    if err:
        return outcome.failed("press", err)

    pyautogui.press(key)
    return outcome.unverified("press", "key press sent; effect not verified", key=key)


def _scroll(direction: str = "down", amount: int = 3) -> str:
    _require_pyautogui()

    # Input validation
    if direction not in ("up", "down", "left", "right"):
        return outcome.failed("scroll", f"Invalid direction: {direction}. Must be 'up', 'down', 'left', or 'right'")
    if amount <= 0:
        return outcome.failed("scroll", f"Amount must be positive, got {amount}")
    if amount > 100:
        return outcome.failed("scroll", f"Amount {amount} exceeds maximum 100")

    vertical   = direction in ("up", "down")
    clicks     = amount if direction in ("up", "right") else -amount
    pyautogui.scroll(clicks) if vertical else pyautogui.hscroll(clicks)
    return outcome.unverified("scroll", "scroll sent; effect not verified", direction=direction, amount=amount)


def _move(x: int, y: int, duration: float = 0.3) -> str:
    _require_pyautogui()

    # Input validation
    err = _validate_coordinates(x, y, "move")
    if err:
        return outcome.failed("move", err)
    if duration < 0:
        return outcome.failed("move", f"Duration cannot be negative: {duration}")
    if duration > 10:
        return outcome.failed("move", f"Duration {duration}s exceeds maximum 10s")

    x_int = int(x)
    y_int = int(y)
    pyautogui.moveTo(x_int, y_int, duration=duration)
    return outcome.unverified("move", "mouse move sent; position not verified", x=x_int, y=y_int, duration=duration)


def _drag(x1: int, y1: int, x2: int, y2: int, duration: float = 0.5) -> str:
    _require_pyautogui()

    # Input validation
    err = _validate_coordinates(x1, y1, "drag")
    if err:
        return outcome.failed("drag", err)
    err = _validate_coordinates(x2, y2, "drag")
    if err:
        return outcome.failed("drag", err)
    if duration < 0:
        return outcome.failed("drag", f"Duration cannot be negative: {duration}")
    if duration > 10:
        return outcome.failed("drag", f"Duration {duration}s exceeds maximum 10s")

    x1_int = int(x1)
    y1_int = int(y1)
    x2_int = int(x2)
    y2_int = int(y2)
    pyautogui.moveTo(x1_int, y1_int, duration=0.2)
    pyautogui.dragTo(x2_int, y2_int, duration=duration, button="left")
    return outcome.unverified("drag", "drag sent; result not verified", x1=x1_int, y1=y1_int, x2=x2_int, y2=y2_int, duration=duration)


def _clipboard_get() -> str:
    if _require_pyperclip():
        text = pyperclip.paste()
        return outcome.done("copy", text=text[:200] + ("…" if len(text) > 200 else ""), verified=True)
    _hotkey("ctrl", "c")
    time.sleep(0.2)
    return outcome.unverified("copy", "pyperclip unavailable — used hotkey fallback", method="hotkey")


def _clipboard_paste(text: str) -> str:
    # Input validation
    err = _validate_text_length(text, 5000, "paste")
    if err:
        return outcome.failed("paste", err)

    if _require_pyperclip():
        pyperclip.copy(text)
        time.sleep(0.1)
        _require_pyautogui()
        paste_key = "command" if _get_os() == "mac" else "ctrl"
        pyautogui.hotkey(paste_key, "v")
        return outcome.unverified("paste", "paste sent via clipboard; appearance not verified", text=text[:60] + ("…" if len(text) > 60 else ""), method="clipboard")
    return outcome.failed("paste", "pyperclip not available")


def _screenshot(save_path: str | None = None) -> str:
    path = _safe_screenshot_path(save_path)
    img_bytes, _ = capture_primary_monitor()
    # Save the compressed image to the requested path
    with open(path, "wb") as f:
        f.write(img_bytes)
    # Verify file was written and can be read
    try:
        written = path.read_bytes()
        if len(written) == len(img_bytes):
            return outcome.done("screenshot", path=str(path), size=len(img_bytes), verified=True)
    except Exception as e:
        pass
    return outcome.unverified("screenshot", "file written but verification failed", path=str(path), size=len(img_bytes))


def _clear_field() -> str:
    _require_pyautogui()
    select_key = "command" if _get_os() == "mac" else "ctrl"
    pyautogui.hotkey(select_key, "a")
    time.sleep(0.1)
    pyautogui.press("delete")
    return outcome.unverified("clear_field", "clear sent; field state not verified")

def _focus_window(title: str) -> str:
    """Focus a window by title. Returns outcome with verification status."""
    os_name = _get_os()
    focus_sent = False
    error_msg = None

    if os_name == "windows":
        try:
            script = f'(New-Object -ComObject WScript.Shell).AppActivate("{title}")'
            subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                capture_output=True, timeout=5, **_WIN_HIDE,
            )
            time.sleep(0.3)
            focus_sent = True
        except Exception as e:
            error_msg = f"focus_window (Windows) failed: {e}"

    elif os_name == "mac":
        script = (
            f'tell application "System Events" to '
            f'set frontmost of (first process whose name contains "{title}") to true'
        )
        try:
            subprocess.run(
                ["osascript", "-e", script],
                capture_output=True, timeout=5,
            )
            time.sleep(0.3)
            focus_sent = True
        except Exception as e:
            error_msg = f"focus_window (macOS) failed: {e}"

    elif os_name == "linux":
        try:
            result = subprocess.run(
                ["wmctrl", "-a", title],
                capture_output=True, timeout=5,
            )
            if result.returncode == 0:
                time.sleep(0.3)
                focus_sent = True
            else:
                error_msg = "wmctrl returned non-zero"
        except FileNotFoundError:
            try:
                result = subprocess.run(
                    ["xdotool", "search", "--name", title, "windowactivate"],
                    capture_output=True, timeout=5,
                )
                time.sleep(0.3)
                focus_sent = True
            except FileNotFoundError:
                return outcome.failed("focus_window", "focus_window (Linux) requires wmctrl or xdotool")
            except Exception as e:
                error_msg = f"focus_window (Linux) failed: {e}"
        except Exception as e:
            error_msg = f"focus_window (Linux) failed: {e}"

    else:
        return outcome.failed("focus_window", f"focus_window: unknown OS '{os_name}'")

    if not focus_sent:
        return outcome.failed("focus_window", error_msg or "focus command failed")

    # Verify focus on Windows; on other platforms verification is unavailable
    if os_name == "windows":
        try:
            import ctypes
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
            if length > 0:
                buf = ctypes.create_unicode_buffer(length + 1)
                ctypes.windll.user32.GetWindowTextW(hwnd, buf, length + 1)
                active_title = buf.value
            else:
                active_title = ""
            if title.lower() in active_title.lower():
                _update_focus_state(title, verified=True, hwnd=hwnd)
                return outcome.done("focus_window", title=title, verified=True)
            else:
                _update_focus_state(title, verified=False)
                return outcome.unverified("focus_window", f"focus sent but active window is '{active_title}'", title=title)
        except Exception:
            _update_focus_state(title, verified=False)
            return outcome.unverified("focus_window", "focus sent; verification unavailable", title=title)
    else:
        # macOS/Linux: focus sent but cannot verify — fail safely (no verification)
        _update_focus_state(title, verified=False)
        return outcome.unverified("focus_window", "focus sent; verification unavailable on this platform", title=title)

def _close_app(app_name: str, confirmed_index: int | None = None) -> str:
    """Close the application the user named — that one, and never this one.

    THE BUG THIS REPLACES
        `computer_settings.close_app` was two lines:

            if _OS == "Darwin": pyautogui.hotkey("command", "q")
            else:               pyautogui.hotkey("alt", "f4")

        No target. It sent Alt+F4 to whatever window had focus, and while
        somebody is talking to the assistant the window with focus is very
        often the assistant — which is why people reported that asking it to
        close an app closed JARVIS itself. It also returned nothing at all, so
        the model announced a success it had no information about.

        The keystroke is not fixable by aiming it better. "The focused window"
        is the wrong idea: the user named an application, so the application is
        what should be found and asked to close.

    HOW THIS ONE BEHAVES
        * The name is matched against what is actually RUNNING — no list of
          applications, so anything on any machine in any country works.
        * The assistant's own process tree is never a candidate. When the only
          thing matching is the assistant, that is said out loud rather than
          obeyed.
        * Two equally good matches is a question, not a coin toss. Closing the
          wrong window loses somebody's unsaved work.
        * It asks politely — WM_CLOSE on Windows, SIGTERM elsewhere — so an
          application with unsaved changes gets to say so, and it NEVER
          escalates to a kill.
        * It then checks whether the process is gone, and answers `done` only
          if it is.
    """
    app_name = (app_name or "").strip()
    if not app_name:
        return outcome.failed("close_app", "no application name was given")

    if not appidentity._PSUTIL:
        return outcome.failed(
            "close_app",
            "psutil is not installed, so running applications cannot be found "
            "- run: pip install psutil",
            app=app_name,
        )

    matches = appidentity.running(app_name)

    if not matches:
        # Nothing, or nothing that is not us. Telling those two apart matters:
        # "it is not running" and "the only thing by that name is me" need
        # completely different sentences.
        including_self = appidentity.running(app_name, include_self=True)
        if any(m.is_self for m in including_self):
            return outcome.failed(
                "close_app",
                "the only thing matching that name is the assistant itself, "
                "and it will not close itself - if the user really wants the "
                "assistant closed they should close its window themselves",
                app=app_name,
            )
        return outcome.failed(
            "close_app",
            "no running application matches that name - it may already be "
            "closed, or be running under a different name",
            app=app_name,
        )

    # Group by process NAME, because twenty `opera.exe` are one application
    # with nineteen helpers, not twenty applications — and closing "Opera"
    # means all of them. `matches` is already best-first, so insertion order
    # here ranks the groups.
    by_name: dict[str, list] = {}
    for match in matches:
        by_name.setdefault(match.label, []).append(match)

    ranked = list(by_name.items())          # [(name, [matches...]), ...]
    target_name, group = ranked[0]

    # Two DIFFERENT applications that answer equally well is a question, not a
    # coin toss. Only when they tie: "discord" beating "discordcanary" on an
    # exact match is a clear winner and interrupting the user to confirm it
    # would be the assistant refusing to do an unambiguous thing.
    if len(ranked) > 1 and not confirmed_index:
        best_score = group[0].score
        tied = [name for name, ms in ranked if ms[0].score == best_score]
        if len(tied) > 1:
            return outcome.ask(
                "close_app",
                f"more than one application matches '{app_name}' equally well: "
                f"{', '.join(tied[:4])} - which one should be closed?",
                app=app_name, candidates=len(tied),
            )
        print(f"[ComputerControl] close_app: '{app_name}' -> {target_name} "
              f"(also matched: {', '.join(n for n, _ in ranked[1:5])})")

    closed, still_open, reason = 0, 0, ""
    for match in group:
        gone, detail = appidentity.request_close(match)
        if gone:
            closed += 1
        else:
            still_open += 1
            reason = reason or detail

    if closed and not still_open:
        return outcome.done(
            "close_app", app=app_name, closed=target_name,
            processes=closed, verified=True,
        )

    if closed and still_open:
        # Partly gone. Common and benign for multi-process applications: the
        # window is shut and a background helper is taking its time. Said as
        # `unverified` because that is exactly what it is.
        return outcome.unverified(
            "close_app",
            f"{closed} of {closed + still_open} processes closed; the rest are "
            f"still running - {reason}",
            app=app_name, closed=target_name,
        )

    return outcome.failed(
        "close_app", reason or "the application did not close",
        app=app_name, matched=target_name,
    )


def _screen_find(description: str, capture_bytes: bytes | None = None) -> ScreenFindResult | None:
    """Find a UI element on screen by description.

    Returns ScreenFindResult with coordinates, confidence, and bounding box,
    or None if element not found or detection failed.

    Args:
        description: Natural language description of the UI element.
        capture_bytes: Optional pre-captured screen image bytes. If None, captures fresh.
    """
    # Input validation
    if not description or not description.strip():
        print("[ComputerControl] ⚠️ screen_find: empty description")
        return None

    api_key = _get_api_key()
    if not api_key:
        print("[ComputerControl] ⚠️ No API key for screen_find")
        return None

    try:
        from google import genai
        from google.genai import types as gtypes

        # Use unified capture API instead of pyautogui.screenshot()
        if capture_bytes is None:
            capture_bytes, mime_type = capture_primary_monitor()
        else:
            # If caller provided bytes, we still need mime type
            # Assume JPEG since that's what capture_primary_monitor returns after compression
            mime_type = "image/jpeg"

        # Get screen dimensions for the prompt
        _require_pyautogui()
        w, h = pyautogui.size()

        # Enhanced prompt requesting structured output with confidence
        prompt = (
            f"This is a screenshot of a {w}×{h} pixel screen. "
            f"Locate the UI element described as: '{description}'. "
            f"Reply with ONLY a JSON object in this format:\n"
            f'{{"x": <int>, "y": <int>, "confidence": <float 0-1>, "bbox": [<x>, <y>, <w>, <h>]}}\n'
            f"Where bbox is the bounding box of the element (optional). "
            f"If the element is not visible, reply: NOT_FOUND"
        )

        from core import gemini
        response = gemini.call(
            [gtypes.Part.from_bytes(data=capture_bytes, mime_type=mime_type), prompt],
            tier=gemini.FAST, timeout_ms=20_000,
        )
        if response is None:
            return None

        text = (response.text or "").strip()
        if "NOT_FOUND" in text.upper():
            return None

        # Parse JSON response
        import json
        try:
            data = json.loads(text)
            x = int(data.get("x", 0))
            y = int(data.get("y", 0))
            confidence = float(data.get("confidence", 0.5))
            bbox = data.get("bbox")
            bounding_box = tuple(bbox) if bbox and len(bbox) == 4 else None
        except (json.JSONDecodeError, ValueError, TypeError):
            # Fallback: try to parse simple x,y format
            match = re.search(r"(\d+)\s*,\s*(\d+)", text)
            if match:
                x = int(match.group(1))
                y = int(match.group(2))
                confidence = 0.5  # Default confidence for legacy format
                bounding_box = None
            else:
                print(f"[ComputerControl] ⚠️ screen_find: could not parse response: {text}")
                return None

        # Validate coordinates against screen bounds
        if not (0 <= x < w and 0 <= y < h):
            print(f"[ComputerControl] ⚠️ screen_find: coordinates ({x}, {y}) out of bounds ({w}x{h})")
            return None

        # Clamp confidence to valid range
        confidence = max(0.0, min(1.0, confidence))

        return ScreenFindResult(
            x=x,
            y=y,
            confidence=confidence,
            bounding_box=bounding_box,
            raw_response=text,
        )

    except Exception as e:
        print(f"[ComputerControl] ⚠️ screen_find failed: {e}")

    return None


def _compare_screen_region(
    original_bytes: bytes,
    fresh_bytes: bytes,
    x: int,
    y: int,
    width: int = 64,
    height: int = 64,
    threshold: float = 0.85,
) -> tuple[bool, str]:
    """
    Compare a region of two screen captures to detect content changes.

    Args:
        original_bytes: Original screen capture (PNG/JPEG bytes).
        fresh_bytes: Fresh screen capture (PNG/JPEG bytes).
        x, y: Center coordinates of region to compare.
        width, height: Size of region to compare (default 64x64 around center).
        threshold: Similarity threshold (0-1). Below = changed.

    Returns:
        (is_similar, message): True if region is similar enough, False if changed.
    """
    try:
        from PIL import Image
        import io

        # Load both images
        orig_img = Image.open(io.BytesIO(original_bytes)).convert("RGB")
        fresh_img = Image.open(io.BytesIO(fresh_bytes)).convert("RGB")

        # Ensure same size
        if orig_img.size != fresh_img.size:
            return False, f"Screen size changed: {orig_img.size} vs {fresh_img.size}"

        # Define region to compare (centered on x,y, clamped to image bounds)
        img_w, img_h = orig_img.size
        left = max(0, x - width // 2)
        top = max(0, y - height // 2)
        right = min(img_w, left + width)
        bottom = min(img_h, top + height)

        # Adjust if clamped
        actual_w = right - left
        actual_h = bottom - top
        if actual_w < 10 or actual_h < 10:
            return False, f"Region too small after clamping: {actual_w}x{actual_h}"

        # Crop regions
        orig_region = orig_img.crop((left, top, right, bottom))
        fresh_region = fresh_img.crop((left, top, right, bottom))

        # Simple pixel difference comparison (MSE-based similarity)
        orig_pixels = list(orig_region.getdata())
        fresh_pixels = list(fresh_region.getdata())

        if len(orig_pixels) != len(fresh_pixels):
            return False, "Region pixel count mismatch"

        # Calculate mean squared error
        mse = sum(
            (r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2
            for (r1, g1, b1), (r2, g2, b2) in zip(orig_pixels, fresh_pixels)
        ) / (len(orig_pixels) * 3)

        # Convert MSE to similarity (max MSE per channel is 255^2 = 65025, for 3 channels 195075)
        max_mse = 255.0 ** 2
        similarity = 1.0 - min(mse / max_mse, 1.0)

        if similarity >= threshold:
            return True, f"Region similar (similarity={similarity:.3f} >= {threshold})"
        else:
            return False, f"Region changed (similarity={similarity:.3f} < {threshold})"

    except Exception as e:
        return False, f"Comparison failed: {e}"


def _record_start(params: dict, player) -> str:
    """
    Start a persistent screen recording session.

    Parameters:
        fps: Target frames per second (default: 15, max: 30)
        duration_limit: Maximum recording duration in seconds (default: 300, max: 3600)
        size_limit: Maximum file size in bytes (default: 500MB, max: 2GB)
        monitor_index: Monitor to record (0=all, 1=primary, etc.) (default: 1)
        region: Optional tuple (x, y, width, height) for partial screen recording

    Returns structured outcome with session info.
    """
    from core import outcome
    from core.permission_guard import get_permission_guard

    # Permission check
    guard = get_permission_guard()
    result = guard.check_operation("computer_control:record_start", params)
    if not result.allowed:
        if result.reason == "approval_required":
            return result.instruction
        return outcome.failed("record_start", result.reason)

    # Check if already recording
    if _is_recording():
        status = _get_recording_status()
        return outcome.failed("record_start", "Recording already in progress", session=status)

    # Validate and clamp parameters
    fps = int(params.get("fps", _DEFAULT_FPS))
    fps = max(1, min(fps, 30))

    duration_limit = float(params.get("duration_limit", _MAX_DURATION))
    duration_limit = max(1, min(duration_limit, 3600))  # Max 1 hour

    size_limit = int(params.get("size_limit", _MAX_FILE_SIZE))
    size_limit = max(1024 * 1024, min(size_limit, 2 * 1024 * 1024 * 1024))  # 1MB to 2GB

    monitor_index = int(params.get("monitor_index", 1))

    # Optional region
    region = params.get("region")
    if region:
        if not isinstance(region, (list, tuple)) or len(region) != 4:
            return outcome.failed("record_start", "region must be a tuple/list of (x, y, width, height)")
        try:
            region = tuple(int(v) for v in region)
            x, y, w, h = region
            if w <= 0 or h <= 0 or x < 0 or y < 0:
                return outcome.failed("record_start", "region values must be positive (width, height) and non-negative (x, y)")
        except (ValueError, TypeError):
            return outcome.failed("record_start", "region values must be integers")

    # Validate monitor index
    try:
        from core.screen_capture import validate_monitor_index
        validate_monitor_index(monitor_index)
    except Exception as e:
        return outcome.failed("record_start", f"Invalid monitor index: {e}")

    # Generate output path
    output_path = _generate_recording_filename()

    # Create cancel event and recording thread
    cancel_event = threading.Event()
    session_id = str(uuid.uuid4())

    # Prepare recording state
    recording_state = {
        "session_id": session_id,
        "start_time": time.time(),
        "thread": None,  # Will be set after thread creation
        "cancel_event": cancel_event,
        "video_writer": None,  # Will be set by worker thread
        "output_path": output_path,
        "fps": fps,
        "duration_limit": duration_limit,
        "size_limit": size_limit,
        "monitor_index": monitor_index,
        "region": region,
    }

    # Start recording thread
    def worker():
        _recording_worker(
            cancel_event=cancel_event,
            output_path=output_path,
            fps=fps,
            duration_limit=duration_limit,
            size_limit=size_limit,
            monitor_index=monitor_index,
            region=region,
        )

    thread = threading.Thread(target=worker, daemon=True, name=f"ScreenRecording-{session_id[:8]}")

    # Register with WorkerRegistry for resource coordination
    registry = get_global_registry()
    from core.worker_registry import create_worker_record
    worker_record = create_worker_record(
        task_id="screen_recording",
        step_id=session_id,
        tool_name="computer_control",
        parameters={"action": "record_start", "monitor_index": monitor_index},
        operation_name="computer_control:record_start",
        resource_scope="LOCAL_SYSTEM",
        is_idempotent=False,
    )
    admitted, reason = registry.admit_worker(worker_record)
    if not admitted:
        return outcome.failed("record_start", f"Resource conflict: {reason}")

    # Update state with thread and worker attempt_id, mark as recording
    recording_state["thread"] = thread
    recording_state["worker_attempt_id"] = worker_record.attempt_id
    with _RECORDING_STATE_LOCK:
        global _RECORDING_STATE
        _RECORDING_STATE = recording_state

    thread.start()

    # Mark worker as running with thread reference
    worker_record.mark_running(thread, cancel_event)

    # Notify UI if player available
    if player:
        try:
            player.write_log(f"JARVIS: Screen recording started (session: {session_id[:8]})")
            player.set_state("RECORDING")
        except Exception:
            pass

    return outcome.done(
        "record_start",
        session_id=session_id,
        output_path=str(output_path),
        fps=fps,
        duration_limit=duration_limit,
        size_limit=size_limit,
        monitor_index=monitor_index,
        region=region,
        verified=True,
    )


def _record_stop(params: dict, player) -> str:
    """
    Stop the current screen recording session.

    Returns structured outcome with recording info.
    """
    from core import outcome
    from core.permission_guard import get_permission_guard

    # Permission check
    guard = get_permission_guard()
    result = guard.check_operation("computer_control:record_stop", params)
    if not result.allowed:
        if result.reason == "approval_required":
            return result.instruction
        return outcome.failed("record_stop", result.reason)

    if not _is_recording():
        return outcome.failed("record_stop", "No recording in progress")

    success, message, recording_info = _stop_recording_internal()

    # Notify UI
    if player:
        try:
            player.write_log(f"JARVIS: Screen recording stopped")
            player.set_state("IDLE")
        except Exception:
            pass

    if success:
        return outcome.done("record_stop", reason=message, **(recording_info or {}), verified=True)
    else:
        return outcome.failed("record_stop", message)


def _record_status(params: dict, player) -> str:
    """
    Get the current recording status.

    Returns structured outcome with status info.
    """
    from core import outcome
    from core.permission_guard import get_permission_guard

    # Permission check
    guard = get_permission_guard()
    result = guard.check_operation("computer_control:record_status", params)
    if not result.allowed:
        if result.reason == "approval_required":
            return result.instruction
        return outcome.failed("record_status", result.reason)

    status = _get_recording_status()
    if status is None:
        return outcome.done("record_status", reason="No recording in progress", recording=False, verified=True)

    return outcome.done(
        "record_status",
        reason="Recording in progress",
        recording=True,
        session_id=status.get("session_id"),
        elapsed_seconds=status.get("elapsed_seconds"),
        output_path=status.get("output_path"),
        fps=status.get("fps"),
        duration_limit=status.get("duration_limit"),
        size_limit=status.get("size_limit"),
        monitor_index=status.get("monitor_index"),
        region=status.get("region"),
        verified=True,
    )


def computer_control(
    parameters: dict,
    response=None,
    player=None,
    session_memory=None,
) -> str:
    """
    Dispatch table for all computer control actions.

    parameters keys (all optional unless noted):
      action        : (required) one of the actions listed below
      text          : text to type or paste
      x, y          : screen coordinates
      button        : 'left' | 'right' (default: left)
      keys          : hotkey string, e.g. 'ctrl+c'
      key           : single key name, e.g. 'enter'
      direction     : 'up' | 'down' | 'left' | 'right'
      amount        : scroll amount (default: 3)
      seconds       : wait duration
      title         : window title fragment for focus_window
      description   : natural-language element description for screen_find/click
      type          : data type for random_data
      field         : memory field name for user_data
      clear_first   : bool, clear field before typing (default: true)
      path          : save path for screenshot (must be inside home dir)

    Actions:
      type          — type text at cursor
      smart_type    — clear field + type (clipboard-backed)
      click         — left click
      double_click  — double left click
      right_click   — right click
      move          — move mouse
      drag          — click-drag between two points
      hotkey        — key combination
      press         — single key
      scroll        — scroll the wheel
      copy          — read clipboard
      paste         — write + paste clipboard
      screenshot    — capture screen (safe path only)
      wait          — sleep N seconds
      clear_field   — select-all + delete
      focus_window  — bring window to foreground
      screen_find   — AI element finder (returns x,y)
      screen_click  — AI element finder + click
      random_data   — generate fake form data
      user_data     — pull real data from memory
    """
    params = parameters or {}
    action = params.get("action", "").lower().strip()

    if not action:
        return "No action specified for computer_control."

    if player:
        # Terminal, not the HUD: the activity log is for the conversation and
        # for problems, not a receipt for every keystroke. See
        # core/outcome.is_problem().
        print(f"[ComputerControl] {action}")

    print(f"[ComputerControl] ▶ {action}  {params}")

    try:

        if action == "type":
            err = _require_focus_verification("type", expected_title=params.get("title"))
            if err:
                return outcome.failed("type", err)
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:type",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:type",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("type", f"resource conflict: {reason}")
            try:
                result = _type(params.get("text", ""))
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "smart_type":
            err = _require_focus_verification("smart_type", expected_title=params.get("title"))
            if err:
                return outcome.failed("smart_type", err)
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:smart_type",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:smart_type",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("smart_type", f"resource conflict: {reason}")
            try:
                result = _smart_type(
                    params.get("text", ""),
                    clear_first=params.get("clear_first", True),
                )
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action in ("click", "left_click"):
            err = _require_focus_verification("click", expected_title=params.get("title"))
            if err:
                return outcome.failed("click", err)
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:click",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:click",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("click", f"resource conflict: {reason}")
            try:
                result = _click(
                    params.get("x"),
                    params.get("y"),
                    button=params.get("button", "left"),
                    clicks=params.get("clicks", 1),
                )
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "double_click":
            err = _require_focus_verification("double_click", expected_title=params.get("title"))
            if err:
                return outcome.failed("double_click", err)
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:double_click",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:double_click",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("double_click", f"resource conflict: {reason}")
            try:
                result = _click(
                    params.get("x"),
                    params.get("y"),
                    button=params.get("button", "left"),
                    clicks=2,
                )
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "right_click":
            err = _require_focus_verification("right_click", expected_title=params.get("title"))
            if err:
                return outcome.failed("right_click", err)
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:right_click",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:right_click",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("right_click", f"resource conflict: {reason}")
            try:
                result = _click(
                    params.get("x"),
                    params.get("y"),
                    button=params.get("button", "right"),
                    clicks=1,
                )
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "move":
            err = _require_focus_verification("move", expected_title=params.get("title"))
            if err:
                return outcome.failed("move", err)
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:move",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:move",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("move", f"resource conflict: {reason}")
            try:
                result = _move(
                    params.get("x", 0),
                    params.get("y", 0),
                    duration=params.get("duration", 0.3),
                )
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "drag":
            err = _require_focus_verification("drag", expected_title=params.get("title"))
            if err:
                return outcome.failed("drag", err)
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:drag",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:drag",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("drag", f"resource conflict: {reason}")
            try:
                result = _drag(
                    params.get("x1", 0),
                    params.get("y1", 0),
                    params.get("x2", 0),
                    params.get("y2", 0),
                    duration=params.get("duration", 0.5),
                )
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "hotkey":
            err = _require_focus_verification("hotkey", expected_title=params.get("title"))
            if err:
                return outcome.failed("hotkey", err)
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:hotkey",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:hotkey",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("hotkey", f"resource conflict: {reason}")
            raw  = params.get("keys", "")
            keys = [k.strip() for k in raw.split("+")] if isinstance(raw, str) else raw
            try:
                result = _hotkey(*keys)
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "press":
            err = _require_focus_verification("press", expected_title=params.get("title"))
            if err:
                return outcome.failed("press", err)
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:press",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:press",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("press", f"resource conflict: {reason}")
            try:
                result = _press(params.get("key", "enter"))
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "scroll":
            # WorkerRegistry admission (scroll doesn't need focus verification)
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:scroll",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:scroll",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("scroll", f"resource conflict: {reason}")
            try:
                result = _scroll(
                    direction=params.get("direction", "down"),
                    amount=int(params.get("amount", 3)),
                )
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "copy":
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:copy",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:copy",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=True,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("copy", f"resource conflict: {reason}")
            try:
                result = _clipboard_get()
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "paste":
            err = _require_focus_verification("paste", expected_title=params.get("title"))
            if err:
                return outcome.failed("paste", err)
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:paste",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:paste",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("paste", f"resource conflict: {reason}")
            try:
                result = _clipboard_paste(params.get("text", ""))
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "screenshot":
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:screenshot",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:screenshot",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=True,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("screenshot", f"resource conflict: {reason}")
            try:
                result = _screenshot(params.get("path"))
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "screen_find":
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:screen_find",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:screen_find",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=True,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("screen_find", f"resource conflict: {reason}")
            desc = params.get("description", "")
            if not desc or not desc.strip():
                worker.mark_failed("description is required")
                registry.release_resources(worker.attempt_id)
                return outcome.failed("screen_find", "description is required")
            try:
                result = _screen_find(desc)
                if result is None:
                    worker.mark_failed("Element not found on screen")
                    registry.release_resources(worker.attempt_id)
                    return outcome.failed("screen_find", "Element not found on screen", description=desc)

                # Get screen dimensions for validation
                _require_pyautogui()
                w, h = pyautogui.size()

                # Validate coordinates against current screen
                if not result.is_valid(w, h):
                    worker.mark_failed(f"Detected coordinates ({result.x}, {result.y}) out of screen bounds ({w}x{h})")
                    registry.release_resources(worker.attempt_id)
                    return outcome.failed("screen_find", f"Detected coordinates ({result.x}, {result.y}) out of screen bounds ({w}x{h})", description=desc)

                # Check confidence threshold
                confidence_threshold = 0.5  # Minimum acceptable confidence
                if not result.is_high_confidence(confidence_threshold):
                    worker.mark_failed(f"Low confidence detection ({result.confidence:.2f} < {confidence_threshold})")
                    registry.release_resources(worker.attempt_id)
                    return outcome.failed("screen_find", f"Low confidence detection ({result.confidence:.2f} < {confidence_threshold})", description=desc, confidence=result.confidence)

                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return outcome.done(
                    "screen_find",
                    description=desc,
                    x=result.x,
                    y=result.y,
                    confidence=result.confidence,
                    bounding_box=result.bounding_box,
                    verified=True  # Coordinates validated against screen bounds
                )
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "screen_click":
            # WorkerRegistry admission (uses both global:display and global:input)
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:screen_click",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:screen_click",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("screen_click", f"resource conflict: {reason}")

            # Validate description first (before focus check)
            desc = params.get("description", "")
            if not desc or not desc.strip():
                worker.mark_failed("description is required")
                registry.release_resources(worker.attempt_id)
                return outcome.failed("screen_click", "description is required")

            err = _require_focus_verification("screen_click", expected_title=params.get("title"))
            if err:
                worker.mark_failed(err)
                registry.release_resources(worker.attempt_id)
                return outcome.failed("screen_click", err)

            # Step 1: Find element with fresh screen capture
            # Capture original image for stale detection comparison
            try:
                original_img_bytes, original_mime = capture_primary_monitor()
                find_result = _screen_find(desc, capture_bytes=original_img_bytes)
                if find_result is None:
                    worker.mark_failed("Element not found on screen")
                    registry.release_resources(worker.attempt_id)
                    return outcome.failed("screen_click", "Element not found on screen", description=desc)

                # Step 2: Validate coordinates against screen bounds
                _require_pyautogui()
                w, h = pyautogui.size()
                if not find_result.is_valid(w, h):
                    worker.mark_failed(f"Detected coordinates ({find_result.x}, {find_result.y}) out of screen bounds ({w}x{h})")
                    registry.release_resources(worker.attempt_id)
                    return outcome.failed("screen_click", f"Detected coordinates ({find_result.x}, {find_result.y}) out of screen bounds ({w}x{h})", description=desc)

                # Step 3: Check confidence threshold
                confidence_threshold = 0.5
                if not find_result.is_high_confidence(confidence_threshold):
                    worker.mark_failed(f"Low confidence detection ({find_result.confidence:.2f} < {confidence_threshold})")
                    registry.release_resources(worker.attempt_id)
                    return outcome.failed("screen_click", f"Low confidence detection ({find_result.confidence:.2f} < {confidence_threshold}) - refusing to click blindly", description=desc, confidence=find_result.confidence)

                # Step 4: Re-capture screen and verify element still at coordinates (stale capture check)
                # This ensures the UI hasn't changed between find and click
                try:
                    # Capture fresh screen for comparison
                    fresh_img_bytes, _ = capture_primary_monitor()
                    _require_pyautogui()
                    w2, h2 = pyautogui.size()

                    # Check if screen dimensions changed between find and click
                    if w2 != w or h2 != h:
                        worker.mark_failed("Screen dimensions changed between find and click")
                        registry.release_resources(worker.attempt_id)
                        return outcome.failed("screen_click", "Screen dimensions changed between find and click", description=desc)
                    if not (0 <= find_result.x < w2 and 0 <= find_result.y < h2):
                        worker.mark_failed("Coordinates out of bounds on fresh capture")
                        registry.release_resources(worker.attempt_id)
                        return outcome.failed("screen_click", "Coordinates out of bounds on fresh capture", description=desc)

                    # Content-based stale detection: compare region around detected element
                    # Use bounding box if available, otherwise default 64x64 region around (x,y)
                    if find_result.bounding_box:
                        bx, by, bw, bh = find_result.bounding_box
                        # Compare a slightly larger region around the bounding box
                        compare_x = bx + bw // 2
                        compare_y = by + bh // 2
                        compare_w = max(bw + 20, 64)
                        compare_h = max(bh + 20, 64)
                    else:
                        compare_x = find_result.x
                        compare_y = find_result.y
                        compare_w = 64
                        compare_h = 64

                    is_similar, compare_msg = _compare_screen_region(
                        original_img_bytes,
                        fresh_img_bytes,
                        compare_x,
                        compare_y,
                        width=compare_w,
                        height=compare_h,
                        threshold=0.85,
                    )
                    if not is_similar:
                        worker.mark_failed(f"Stale capture detected: {compare_msg}")
                        registry.release_resources(worker.attempt_id)
                        return outcome.failed("screen_click", f"Stale capture detected: {compare_msg}", description=desc)
                except Exception as e:
                    print(f"[ComputerControl] ⚠️ screen_click: pre-click verification failed: {e}")
                    # If comparison fails, return explicit failed rather than silently clicking
                    worker.mark_failed(f"Pre-click verification failed: {e}")
                    registry.release_resources(worker.attempt_id)
                    return outcome.failed("screen_click", f"Pre-click verification failed: {e}", description=desc)

                # Step 5: Execute click
                time.sleep(0.2)
                click_result = _click(x=find_result.x, y=find_result.y)

                # Step 6: Return appropriate outcome
                # Since we can't reliably verify post-click state for generic UI elements,
                # we return unverified with the evidence we have
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return outcome.unverified(
                    "screen_click",
                    "AI find + click sent; target activation not verified",
                    x=find_result.x,
                    y=find_result.y,
                    description=desc,
                    confidence=find_result.confidence,
                    bounding_box=find_result.bounding_box,
                )
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "wait":
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:wait",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:wait",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=True,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("wait", f"resource conflict: {reason}")
            try:
                secs = float(params.get("seconds", 1.0))
                secs = min(secs, 30.0)
                time.sleep(secs)
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return outcome.done("wait", seconds=secs, verified=True)
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "record_start":
            # record_start already has WorkerRegistry integration internally
            return _record_start(params, player)

        if action == "record_stop":
            # record_stop needs to release resources from the recording worker
            from core.permission_guard import get_permission_guard

            # Permission check
            guard = get_permission_guard()
            result = guard.check_operation("computer_control:record_stop", params)
            if not result.allowed:
                if result.reason == "approval_required":
                    return result.instruction
                return outcome.failed("record_stop", result.reason)

            if not _is_recording():
                return outcome.failed("record_stop", "No recording in progress")

            success, message, recording_info = _stop_recording_internal()

            # Notify UI
            if player:
                try:
                    player.write_log(f"JARVIS: Screen recording stopped")
                    player.set_state("IDLE")
                except Exception:
                    pass

            if success:
                return outcome.done("record_stop", reason=message, **(recording_info or {}), verified=True)
            else:
                return outcome.failed("record_stop", message)

        if action == "record_status":
            # record_status - read-only query, no WorkerRegistry admission needed
            # (doesn't reserve exclusive resources, should work during active recording)
            from core.permission_guard import get_permission_guard

            # Permission check
            guard = get_permission_guard()
            result = guard.check_operation("computer_control:record_status", params)
            if not result.allowed:
                if result.reason == "approval_required":
                    return result.instruction
                return outcome.failed("record_status", result.reason)

            status = _get_recording_status()
            if status is None:
                return outcome.done("record_status", reason="No recording in progress", recording=False, verified=True)

            return outcome.done(
                "record_status",
                reason="Recording in progress",
                recording=True,
                session_id=status.get("session_id"),
                elapsed_seconds=status.get("elapsed_seconds"),
                output_path=status.get("output_path"),
                fps=status.get("fps"),
                duration_limit=status.get("duration_limit"),
                size_limit=status.get("size_limit"),
                monitor_index=status.get("monitor_index"),
                region=status.get("region"),
                verified=True,
            )

        if action == "clear_field":
            err = _require_focus_verification("clear_field", expected_title=params.get("title"))
            if err:
                return outcome.failed("clear_field", err)
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:clear_field",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:clear_field",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("clear_field", f"resource conflict: {reason}")
            try:
                result = _clear_field()
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "focus_window":
            title = params.get("title", "")
            if not title:
                return outcome.failed("focus_window", "title is required")
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:focus_window",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:focus_window",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("focus_window", f"resource conflict: {reason}")
            try:
                result = _focus_window(title)
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action in ("close_app", "close_application", "quit_app"):
            # WorkerRegistry admission
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:close_app",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:close_app",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=False,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("close_app", f"resource conflict: {reason}")
            try:
                result = _close_app(
                    params.get("app_name") or params.get("text") or "",
                    confirmed_index=params.get("confirmed"),
                )
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return result
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "random_data":
            # WorkerRegistry admission (read-only, no resource conflict expected)
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:random_data",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:random_data",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=True,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("random_data", f"resource conflict: {reason}")
            try:
                dt     = params.get("type", "name")
                result = _random_data(dt)
                print(f"[ComputerControl] 🎲 random {dt} → {result}")
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return outcome.done("random_data", type=dt, value=result, verified=True)
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        if action == "user_data":
            # WorkerRegistry admission (read-only, no resource conflict expected)
            registry = get_global_registry()
            worker = create_worker_record(
                task_id="inline",
                step_id="computer_control:user_data",
                tool_name="computer_control",
                parameters=parameters or {},
                operation_name="computer_control:user_data",
                resource_scope="LOCAL_SYSTEM",
                is_idempotent=True,
            )
            admitted, reason = registry.admit_worker(worker)
            if not admitted:
                return outcome.failed("user_data", f"resource conflict: {reason}")
            try:
                field   = params.get("field", "name")
                profile = _user_profile()
                value   = profile.get(field, "")
                if not value:
                    value = _random_data(field)
                    print(f"[ComputerControl] ⚠️ No '{field}' in memory, using random: {value}")
                worker.mark_completed("done")
                registry.release_resources(worker.attempt_id)
                return outcome.done("user_data", field=field, value=value, source="memory" if profile.get(field) else "random", verified=True)
            except Exception as e:
                worker.mark_failed(str(e))
                registry.release_resources(worker.attempt_id)
                raise

        return outcome.failed("computer_control", f"Unknown action: '{action}'", action=action)

    except Exception as e:
        print(f"[ComputerControl] ❌ {action}: {e}")
        return f"computer_control '{action}' failed: {e}"


# ── Tool declaration (auto-discovered by core/action_loader.py) ──────────────
TOOL = {
    "name": "computer_control",
    "description": (
        "Direct computer control: type, click, hotkeys, scroll, move mouse, "
        "screenshots, find elements on screen, and CLOSE an application. "
        "Use action='close_app' with 'app_name' whenever the user asks to "
        "close, quit or exit a program - 'close Spotify', 'quit Chrome'. "
        "Always name the application in 'app_name'; there is no action that "
        "closes 'whatever is in front', because that is usually the assistant. "
        "To OPEN an application use the open_app tool instead. "
        "Read the status the tool returns: 'done' means it was confirmed, "
        "'unverified' means it was requested and could NOT be confirmed - say "
        "so rather than claiming success - and 'ask' means nothing was done "
        "and the question must go to the user first."
    ),
    # Used in place of `description` only when a small model is on a tool
    # budget - Gemini still gets the full text. See providers/schema.py.
    "brief": (
        "Controls the computer: type, click, hotkeys, scroll, screenshots, and close_app to close a named application (put its name in 'app_name'). Use open_app to open one."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "type | smart_type | click | double_click | right_click | hotkey | press | scroll | move | copy | paste | screenshot | wait | clear_field | focus_window | close_app | screen_find | screen_click | random_data | user_data | record_start | record_stop | record_status"
            },
            "app_name": {
                "type": "STRING",
                "description": (
                    "For close_app: the application to close, named as the "
                    "user said it. Any application running on the machine "
                    "works - there is no fixed list. Never leave this empty."
                )
            },
            "confirmed": {
                "type": "BOOLEAN",
                "description": (
                    "For close_app: set true only after the tool asked which "
                    "application was meant AND the user answered. Pass their "
                    "answer in 'app_name'."
                )
            },
            "text": {
                "type": "STRING",
                "description": "Text to type or paste"
            },
            "x": {
                "type": "INTEGER",
                "description": "X coordinate"
            },
            "y": {
                "type": "INTEGER",
                "description": "Y coordinate"
            },
            "keys": {
                "type": "STRING",
                "description": "Key combination e.g. 'ctrl+c'"
            },
            "key": {
                "type": "STRING",
                "description": "Single key e.g. 'enter'"
            },
            "direction": {
                "type": "STRING",
                "description": "up | down | left | right"
            },
            "amount": {
                "type": "INTEGER",
                "description": "Scroll amount (default: 3)"
            },
            "seconds": {
                "type": "NUMBER",
                "description": "Seconds to wait"
            },
            "title": {
                "type": "STRING",
                "description": "Window title for focus_window"
            },
            "description": {
                "type": "STRING",
                "description": "Element description for screen_find/screen_click"
            },
            "type": {
                "type": "STRING",
                "description": "Data type for random_data"
            },
            "field": {
                "type": "STRING",
                "description": "Field for user_data: name|email|city"
            },
            "clear_first": {
                "type": "BOOLEAN",
                "description": "Clear field before typing (default: true)"
            },
            "path": {
                "type": "STRING",
                "description": "Save path for screenshot"
            },
            "fps": {
                "type": "INTEGER",
                "description": "Target FPS for recording (default: 15, max: 30)"
            },
            "duration_limit": {
                "type": "NUMBER",
                "description": "Maximum recording duration in seconds (default: 300, max: 3600)"
            },
            "size_limit": {
                "type": "INTEGER",
                "description": "Maximum file size in bytes (default: 500MB, max: 2GB)"
            },
            "monitor_index": {
                "type": "INTEGER",
                "description": "Monitor to record (0=all, 1=primary, etc.) (default: 1)"
            },
            "region": {
                "type": "ARRAY",
                "description": "Optional region (x, y, width, height) for partial screen recording",
                "items": {"type": "INTEGER"},
                "minItems": 4,
                "maxItems": 4
            }
        },
        "required": [
            "action"
        ]
    },
    "handler": computer_control,
}
