"""
Data models for conversation history storage.

These dataclasses represent the core entities in the conversation storage system.
They are designed to be simple, serializable, and independent of the storage backend.
"""
from dataclasses import dataclass, field
from typing import Optional
import time
import uuid


@dataclass
class Conversation:
    """
    Represents a single conversation session.

    Attributes:
        id: Stable UUID v4 identifier (auto-generated if not provided).
        title: User-editable or auto-generated title.
        started_at: Unix timestamp in milliseconds when the conversation began.
        ended_at: Unix timestamp in milliseconds when the conversation ended (None if active).
        turn_count: Number of complete turns (user + assistant pairs) in this conversation.
        summary: Optional 1-2 sentence summary of the conversation.
        language: Dominant language detected in the conversation.
        engine: The conversation engine used (e.g., 'gemini_live', 'pipeline').
        meta_json: Extensible JSON string for additional metadata (tags, source, etc.).
        created_at: Unix timestamp in milliseconds when this record was created.
        updated_at: Unix timestamp in milliseconds when this record was last modified.
    """
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    title: str = ""
    started_at: int = 0
    ended_at: Optional[int] = None
    turn_count: int = 0
    summary: Optional[str] = None
    language: Optional[str] = None
    engine: str = "gemini_live"
    meta_json: str = "{}"
    created_at: int = field(default_factory=lambda: int(time.time() * 1000))
    updated_at: int = field(default_factory=lambda: int(time.time() * 1000))

    def __post_init__(self):
        now_ms = int(time.time() * 1000)
        if self.started_at == 0:
            self.started_at = now_ms
        if self.created_at == 0:
            self.created_at = now_ms
        if self.updated_at == 0:
            self.updated_at = now_ms

    @property
    def resume_handle(self) -> str | None:
        """Extract and return the decrypted resumption handle from meta_json.

        Returns None if not present or decryption fails. Decryption is done
        lazily via config_manager.decrypt_conversation_handle.
        """
        if not self.meta_json:
            return None
        try:
            import json
            meta = json.loads(self.meta_json)
        except Exception:
            return None
        encrypted = meta.get("resume_handle")
        if not encrypted:
            return None
        # Lazy import to avoid circular dependency
        from memory.config_manager import decrypt_conversation_handle
        return decrypt_conversation_handle(encrypted)


@dataclass
class Message:
    """
    Represents a single message/turn within a conversation.

    Attributes:
        id: Stable UUID v4 identifier (auto-generated if not provided).
        conversation_id: Foreign key to the parent conversation.
        role: One of 'user', 'assistant', 'system'.
        content: The message content (transcription or response text).
        content_type: Type of content ('text', 'tool_call', 'tool_result', 'vision').
        sequence: 1-based sequence number within the conversation (enforced unique per conversation).
        timestamp_ms: Unix timestamp in milliseconds when the message was received.
        meta_json: Extensible JSON string for additional metadata (tool name, confidence, etc.).
        created_at: Unix timestamp in milliseconds when this record was created.
    """
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    conversation_id: str = ""
    role: str = ""
    content: str = ""
    content_type: str = "text"
    sequence: int = 0
    timestamp_ms: int = field(default_factory=lambda: int(time.time() * 1000))
    meta_json: str = "{}"
    created_at: int = field(default_factory=lambda: int(time.time() * 1000))

    def __post_init__(self):
        if self.timestamp_ms == 0:
            self.timestamp_ms = int(time.time() * 1000)
        if self.created_at == 0:
            self.created_at = int(time.time() * 1000)


@dataclass
class ConversationSummary:
    """
    Lightweight summary for listing conversations.

    Used for pagination and UI display without loading full message history.
    """
    id: str
    title: str
    started_at: int
    ended_at: Optional[int]
    turn_count: int
    summary: Optional[str]
    language: Optional[str]
    engine: str

    @classmethod
    def from_conversation(cls, conv: Conversation) -> "ConversationSummary":
        return cls(
            id=conv.id,
            title=conv.title,
            started_at=conv.started_at,
            ended_at=conv.ended_at,
            turn_count=conv.turn_count,
            summary=conv.summary,
            language=conv.language,
            engine=conv.engine,
        )