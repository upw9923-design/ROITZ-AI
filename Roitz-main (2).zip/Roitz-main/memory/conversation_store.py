"""
SQLite-backed conversation storage for JARVIS.

This module provides a thread-safe, crash-resistant conversation history store
using Python's standard-library sqlite3 with WAL mode.

Key design decisions:
- WAL mode for concurrent readers/writers without blocking
- Foreign keys enforced on every connection
- Parameterized queries everywhere (no SQL injection)
- UTC Unix timestamps in milliseconds
- Explicit transactions for related updates
- Context-managed connections (no connection pooling needed for SQLite)
- Schema versioning via PRAGMA user_version

No external dependencies. No encryption. No modification of long_term.json.
"""
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Optional, List, Iterator, Tuple

from .conversation_models import Conversation, Message, ConversationSummary
from .migrations import migrate

# Import encryption helpers lazily to avoid circular imports
def _get_encrypt_handle():
    from memory.config_manager import encrypt_conversation_handle
    return encrypt_conversation_handle


def _get_decrypt_handle():
    from memory.config_manager import decrypt_conversation_handle
    return decrypt_conversation_handle


# ─── Configuration ────────────────────────────────────────────────────────────

# Database file location (alongside long_term.json)
def _get_db_path() -> Path:
    """Get the database file path, creating the directory if needed."""
    base_dir = Path(__file__).resolve().parent.parent
    db_dir = base_dir / "memory"
    db_dir.mkdir(parents=True, exist_ok=True)
    return db_dir / "conversations.sqlite3"


# Connection settings
PRAGMA_SETTINGS = """
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA foreign_keys = ON;
PRAGMA busy_timeout = 5000;
PRAGMA page_size = 4096;
"""


# ─── Exceptions ───────────────────────────────────────────────────────────────

class ConversationStoreError(Exception):
    """Base exception for conversation store errors."""
    pass


class ConversationNotFoundError(ConversationStoreError):
    """Raised when a conversation ID does not exist."""
    pass


class MessageNotFoundError(ConversationStoreError):
    """Raised when a message ID does not exist."""
    pass


class SequenceConflictError(ConversationStoreError):
    """Raised when a sequence number collision occurs."""
    pass


class ValidationError(ConversationStoreError):
    """Raised when input validation fails."""
    pass


# ─── Core Store Class ─────────────────────────────────────────────────────────

class ConversationStore:
    """
    Thread-safe SQLite conversation store.

    All public methods are safe for concurrent use from multiple threads.
    Uses a single lock for connection management; SQLite WAL handles
    concurrent readers/writers at the database level.
    """

    _lock = threading.Lock()

    def __init__(self, db_path: Optional[Path] = None):
        """
        Initialize the store.

        Args:
            db_path: Optional custom database path. If None, uses default location.
        """
        self.db_path = db_path or _get_db_path()
        self._local = threading.local()
        self._ensure_schema()

    # ─── Connection Management ────────────────────────────────────────────────

    def _get_connection(self) -> sqlite3.Connection:
        """
        Get a thread-local database connection.

        Each thread gets its own connection. Connections are reused within
        the same thread. The connection has WAL mode and foreign keys enabled.
        """
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(
                self.db_path,
                check_same_thread=False,  # We manage thread safety via _lock
                timeout=5.0,              # Respects busy_timeout
            )
            conn.row_factory = sqlite3.Row
            # Apply PRAGMA settings
            conn.executescript(PRAGMA_SETTINGS)
            self._local.conn = conn
        return self._local.conn

    @contextmanager
    def _transaction(self) -> Iterator[sqlite3.Connection]:
        """
        Context manager for a database transaction.

        Commits on success, rolls back on exception. The lock ensures
        only one transaction runs at a time per store instance.
        """
        with self._lock:
            conn = self._get_connection()
            try:
                yield conn
                conn.commit()
            except Exception:
                conn.rollback()
                raise

    def close(self) -> None:
        """Close the thread-local connection if open."""
        if hasattr(self._local, "conn") and self._local.conn is not None:
            conn = self._local.conn
            # Run WAL checkpoint to ensure WAL files are truncated
            # This prevents file locking issues on Windows
            try:
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
            except Exception:
                pass
            conn.close()
            self._local.conn = None

    # ─── Schema Management ────────────────────────────────────────────────────

    def _ensure_schema(self) -> None:
        """Create tables and run migrations if needed."""
        with self._transaction() as conn:
            migrate.run_migrations(conn)

    # ─── Conversation CRUD ────────────────────────────────────────────────────

    def create_conversation(self, conv: Conversation) -> Conversation:
        """
        Create a new conversation record.

        Args:
            conv: Conversation object (id will be generated if empty).

        Returns:
            The created Conversation with all fields populated.

        Raises:
            ValidationError: If required fields are missing or invalid.
        """
        if not conv.id:
            conv.id = uuid.uuid4().hex
        if not conv.title:
            conv.title = f"Conversation {conv.started_at}"

        now_ms = int(time.time() * 1000)
        if conv.created_at == 0:
            conv.created_at = now_ms
        if conv.updated_at == 0:
            conv.updated_at = now_ms

        with self._transaction() as conn:
            conn.execute(
                """
                INSERT INTO conversations
                (id, title, started_at, ended_at, turn_count, summary,
                 language, engine, meta_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    conv.id,
                    conv.title,
                    conv.started_at,
                    conv.ended_at,
                    conv.turn_count,
                    conv.summary,
                    conv.language,
                    conv.engine,
                    conv.meta_json,
                    conv.created_at,
                    conv.updated_at,
                ),
            )
        return conv

    def get_conversation(self, conversation_id: str) -> Conversation:
        """
        Retrieve a conversation by ID.

        Args:
            conversation_id: The conversation UUID.

        Returns:
            Conversation object.

        Raises:
            ConversationNotFoundError: If no conversation with that ID exists.
        """
        with self._lock:
            conn = self._get_connection()
            row = conn.execute(
                "SELECT * FROM conversations WHERE id = ?",
                (conversation_id,),
            ).fetchone()

        if not row:
            raise ConversationNotFoundError(f"Conversation not found: {conversation_id}")

        return self._row_to_conversation(row)

    def update_conversation(self, conv: Conversation) -> Conversation:
        """
        Update an existing conversation.

        Only updates title, ended_at, turn_count, summary, language, meta_json.
        updated_at is set to current time automatically.

        Args:
            conv: Conversation object with updated fields (id must exist).

        Returns:
            The updated Conversation.

        Raises:
            ConversationNotFoundError: If the conversation does not exist.
        """
        now_ms = int(time.time() * 1000)
        conv.updated_at = now_ms

        with self._transaction() as conn:
            cursor = conn.execute(
                """
                UPDATE conversations
                SET title = ?, ended_at = ?, turn_count = ?, summary = ?,
                    language = ?, meta_json = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    conv.title,
                    conv.ended_at,
                    conv.turn_count,
                    conv.summary,
                    conv.language,
                    conv.meta_json,
                    conv.updated_at,
                    conv.id,
                ),
            )
            if cursor.rowcount == 0:
                raise ConversationNotFoundError(f"Conversation not found: {conv.id}")

        return conv

    def finalize_conversation(
        self,
        conversation_id: str,
        summary: Optional[str] = None,
        turn_count: Optional[int] = None,
        title: Optional[str] = None,
    ) -> Conversation:
        """
        Mark a conversation as ended and update its metadata.

        This is the primary way to close a session. It sets ended_at,
        optionally updates summary, turn_count, and title, and bumps updated_at.

        Args:
            conversation_id: The conversation to finalize.
            summary: Optional summary to set.
            turn_count: Optional turn count to set.
            title: Optional title to set (max 60 chars). If not provided, existing title is preserved.

        Returns:
            The updated Conversation.

        Raises:
            ConversationNotFoundError: If the conversation does not exist.
        """
        now_ms = int(time.time() * 1000)

        with self._transaction() as conn:
            # Build dynamic update based on provided fields
            updates = ["ended_at = ?", "updated_at = ?"]
            params = [now_ms, now_ms]

            if summary is not None:
                updates.append("summary = ?")
                params.append(summary)
            if turn_count is not None:
                updates.append("turn_count = ?")
                params.append(turn_count)
            if title is not None:
                updates.append("title = ?")
                params.append(title)

            params.append(conversation_id)

            cursor = conn.execute(
                f"UPDATE conversations SET {', '.join(updates)} WHERE id = ?",
                params,
            )
            if cursor.rowcount == 0:
                raise ConversationNotFoundError(f"Conversation not found: {conversation_id}")

        return self.get_conversation(conversation_id)

    def delete_conversation(self, conversation_id: str) -> None:
        """
        Delete a conversation and all its messages (cascade).

        Args:
            conversation_id: The conversation to delete.

        Raises:
            ConversationNotFoundError: If the conversation does not exist.
        """
        with self._transaction() as conn:
            cursor = conn.execute(
                "DELETE FROM conversations WHERE id = ?",
                (conversation_id,),
            )
            if cursor.rowcount == 0:
                raise ConversationNotFoundError(f"Conversation not found: {conversation_id}")

    def set_resume_handle(self, conversation_id: str, handle: str) -> None:
        """
        Store an encrypted resumption handle for a conversation.

        The handle is encrypted at rest using AES-256-GCM with a per-install
        key derived via PBKDF2. Stored in the conversation's meta_json column.

        Args:
            conversation_id: The conversation to update.
            handle: The plaintext resumption handle from Gemini Live.

        Raises:
            ConversationNotFoundError: If the conversation does not exist.
        """
        if not handle:
            return
        encrypt_handle = _get_encrypt_handle()
        encrypted = encrypt_handle(handle)

        with self._transaction() as conn:
            # Read current meta_json
            row = conn.execute(
                "SELECT meta_json FROM conversations WHERE id = ?",
                (conversation_id,),
            ).fetchone()
            if not row:
                raise ConversationNotFoundError(f"Conversation not found: {conversation_id}")

            # Update meta_json with resume_handle
            import json
            try:
                meta = json.loads(row["meta_json"]) if row["meta_json"] else {}
            except Exception:
                meta = {}
            meta["resume_handle"] = encrypted

            cursor = conn.execute(
                "UPDATE conversations SET meta_json = ?, updated_at = ? WHERE id = ?",
                (json.dumps(meta), int(time.time() * 1000), conversation_id),
            )
            if cursor.rowcount == 0:
                raise ConversationNotFoundError(f"Conversation not found: {conversation_id}")

    def get_resume_handle(self, conversation_id: str) -> str | None:
        """
        Retrieve and decrypt the resumption handle for a conversation.

        Args:
            conversation_id: The conversation to query.

        Returns:
            The decrypted handle, or None if not set or decryption fails.
            Never raises — returns None on any error.
        """
        with self._lock:
            conn = self._get_connection()
            row = conn.execute(
                "SELECT meta_json FROM conversations WHERE id = ?",
                (conversation_id,),
            ).fetchone()
        if not row:
            return None

        try:
            import json
            meta = json.loads(row["meta_json"]) if row["meta_json"] else {}
        except Exception:
            return None

        encrypted = meta.get("resume_handle")
        if not encrypted:
            return None

        decrypt_handle = _get_decrypt_handle()
        return decrypt_handle(encrypted)

    def clear_resume_handle(self, conversation_id: str) -> None:
        """
        Remove the stored resumption handle from a conversation's meta_json.

        This is used when a voice change (keep_context=False) or server rejection
        requires a fresh session — the stale handle must not be reloaded on
        the next session start (Integration Point A).

        Args:
            conversation_id: The conversation to update.

        Raises:
            ConversationNotFoundError: If the conversation does not exist.
        """
        with self._transaction() as conn:
            # Read current meta_json
            row = conn.execute(
                "SELECT meta_json FROM conversations WHERE id = ?",
                (conversation_id,),
            ).fetchone()
            if not row:
                raise ConversationNotFoundError(f"Conversation not found: {conversation_id}")

            # Update meta_json: remove resume_handle if present
            import json
            try:
                meta = json.loads(row["meta_json"]) if row["meta_json"] else {}
            except Exception:
                meta = {}

            if "resume_handle" in meta:
                del meta["resume_handle"]
                cursor = conn.execute(
                    "UPDATE conversations SET meta_json = ?, updated_at = ? WHERE id = ?",
                    (json.dumps(meta), int(time.time() * 1000), conversation_id),
                )
                if cursor.rowcount == 0:
                    raise ConversationNotFoundError(f"Conversation not found: {conversation_id}")

    # ─── Conversation Listing ─────────────────────────────────────────────────

    def list_conversations(
        self,
        limit: int = 50,
        offset: int = 0,
        order_by: str = "started_at",
        descending: bool = True,
    ) -> List[ConversationSummary]:
        """
        List conversations with pagination.

        Args:
            limit: Maximum number of results.
            offset: Number of results to skip.
            order_by: Column to order by ('started_at' or 'updated_at').
            descending: If True, newest first.

        Returns:
            List of ConversationSummary objects.
        """
        if order_by not in ("started_at", "updated_at"):
            order_by = "started_at"
        order_dir = "DESC" if descending else "ASC"

        with self._lock:
            conn = self._get_connection()
            rows = conn.execute(
                f"""
                SELECT id, title, started_at, ended_at, turn_count, summary, language, engine
                FROM conversations
                ORDER BY {order_by} {order_dir}
                LIMIT ? OFFSET ?
                """,
                (limit, offset),
            ).fetchall()

        return [self._row_to_summary(row) for row in rows]

    def count_conversations(self) -> int:
        """Return total number of conversations."""
        with self._lock:
            conn = self._get_connection()
            row = conn.execute("SELECT COUNT(*) FROM conversations").fetchone()
        return row[0] if row else 0

    # ─── Message CRUD ─────────────────────────────────────────────────────────

    def append_message(self, msg: Message) -> Message:
        """
        Append a message to a conversation.

        The message sequence number is auto-assigned as the next available
        integer for that conversation (1-based). This is done atomically
        within a transaction to prevent race conditions.

        Args:
            msg: Message object (id generated if empty, sequence ignored).

        Returns:
            The created Message with assigned sequence and ID.

        Raises:
            ConversationNotFoundError: If the conversation does not exist.
            ValidationError: If role or content_type is invalid.
            SequenceConflictError: If a sequence collision occurs (should not happen).
        """
        # Validate role
        if msg.role not in ("user", "assistant", "system"):
            raise ValidationError(f"Invalid role: {msg.role}")

        # Validate content_type
        if msg.content_type not in ("text", "tool_call", "tool_result", "vision"):
            raise ValidationError(f"Invalid content_type: {msg.content_type}")

        if not msg.id:
            msg.id = uuid.uuid4().hex
        if msg.created_at == 0:
            msg.created_at = int(time.time() * 1000)
        if msg.timestamp_ms == 0:
            msg.timestamp_ms = int(time.time() * 1000)

        with self._transaction() as conn:
            # Verify conversation exists
            conv_exists = conn.execute(
                "SELECT 1 FROM conversations WHERE id = ?",
                (msg.conversation_id,),
            ).fetchone()
            if not conv_exists:
                raise ConversationNotFoundError(
                    f"Conversation not found: {msg.conversation_id}"
                )

            # Atomically get next sequence number and insert
            # Using a subquery for max sequence + 1
            cursor = conn.execute(
                """
                INSERT INTO messages
                (id, conversation_id, role, content, content_type, sequence,
                 timestamp_ms, meta_json, created_at)
                VALUES (?, ?, ?, ?, ?,
                        COALESCE((SELECT MAX(sequence) FROM messages WHERE conversation_id = ?), 0) + 1,
                        ?, ?, ?)
                """,
                (
                    msg.id,
                    msg.conversation_id,
                    msg.role,
                    msg.content,
                    msg.content_type,
                    msg.conversation_id,
                    msg.timestamp_ms,
                    msg.meta_json,
                    msg.created_at,
                ),
            )

            # Get the assigned sequence number
            msg.sequence = cursor.lastrowid
            if msg.sequence is None:
                # Fallback: query for it
                row = conn.execute(
                    "SELECT sequence FROM messages WHERE id = ?",
                    (msg.id,),
                ).fetchone()
                if row:
                    msg.sequence = row[0]
                else:
                    raise SequenceConflictError("Failed to determine assigned sequence")

        return msg

    def get_message(self, message_id: str) -> Message:
        """
        Retrieve a single message by ID.

        Args:
            message_id: The message UUID.

        Returns:
            Message object.

        Raises:
            MessageNotFoundError: If no message with that ID exists.
        """
        with self._lock:
            conn = self._get_connection()
            row = conn.execute(
                "SELECT * FROM messages WHERE id = ?",
                (message_id,),
            ).fetchone()

        if not row:
            raise MessageNotFoundError(f"Message not found: {message_id}")

        return self._row_to_message(row)

    def get_messages(
        self,
        conversation_id: str,
        limit: Optional[int] = None,
        offset: int = 0,
        order_by: str = "sequence",
        descending: bool = False,
    ) -> List[Message]:
        """
        Retrieve messages for a conversation with pagination.

        Args:
            conversation_id: The parent conversation.
            limit: Maximum number of results (None = all).
            offset: Number of results to skip.
            order_by: Column to order by ('sequence' or 'timestamp_ms').
            descending: If True, newest first.

        Returns:
            List of Message objects.
        """
        if order_by not in ("sequence", "timestamp_ms"):
            order_by = "sequence"
        order_dir = "DESC" if descending else "ASC"

        # SQLite requires LIMIT when using OFFSET. Use a very large limit
        # when limit is None to effectively mean "no limit".
        if limit is not None:
            limit_clause = "LIMIT ?"
            params = [conversation_id, limit, offset]
        else:
            limit_clause = "LIMIT -1"  # SQLite: -1 means no limit
            params = [conversation_id, offset]

        with self._lock:
            conn = self._get_connection()
            rows = conn.execute(
                f"""
                SELECT * FROM messages
                WHERE conversation_id = ?
                ORDER BY {order_by} {order_dir}
                {limit_clause} OFFSET ?
                """,
                params,
            ).fetchall()

        return [self._row_to_message(row) for row in rows]

    def get_message_count(self, conversation_id: str) -> int:
        """Return number of messages in a conversation."""
        with self._lock:
            conn = self._get_connection()
            row = conn.execute(
                "SELECT COUNT(*) FROM messages WHERE conversation_id = ?",
                (conversation_id,),
            ).fetchone()
        return row[0] if row else 0

    def delete_message(self, message_id: str) -> None:
        """
        Delete a single message.

        Note: This may create gaps in sequence numbers. Consider
        whether you need to renumber subsequent messages.

        Args:
            message_id: The message to delete.

        Raises:
            MessageNotFoundError: If the message does not exist.
        """
        with self._transaction() as conn:
            cursor = conn.execute(
                "DELETE FROM messages WHERE id = ?",
                (message_id,),
            )
            if cursor.rowcount == 0:
                raise MessageNotFoundError(f"Message not found: {message_id}")

    # ─── Search ───────────────────────────────────────────────────────────────

    def _build_search_conditions(
        self,
        query: str,
        conversation_id: Optional[str] = None,
        role: Optional[str] = None,
    ) -> tuple[str, list]:
        """
        Build WHERE conditions and parameters for search queries.

        Used by both search_messages and count_search_messages to ensure
        identical filtering logic.

        Args:
            query: Search text (wrapped in % wildcards, wildcards escaped for literal matching).
            conversation_id: Optional filter to specific conversation.
            role: Optional role filter ('user', 'assistant', 'system').

        Returns:
            Tuple of (where_clause, params_list) where where_clause includes
            the WHERE keyword and conditions joined by AND.
        """
        if not query or not query.strip():
            return "", []

        # Escape wildcards for literal matching, then wrap in % for substring search
        escaped_query = self._escape_like_pattern(query.strip())
        like_pattern = f"%{escaped_query}%"
        conditions = ["content LIKE ? ESCAPE '\\'"]
        params = [like_pattern]

        if conversation_id:
            conditions.append("conversation_id = ?")
            params.append(conversation_id)
        if role:
            if role not in ("user", "assistant", "system"):
                raise ValidationError(f"Invalid role filter: {role}")
            conditions.append("role = ?")
            params.append(role)

        where_clause = "WHERE " + " AND ".join(conditions)
        return where_clause, params

    def search_messages(
        self,
        query: str,
        conversation_id: Optional[str] = None,
        role: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[Message]:
        """
        Search messages using a parameterized LIKE query.

        This is a simple text search. For production use with large datasets,
        consider adding FTS5 virtual table (out of scope for this batch).

        Args:
            query: Search text (wrapped in % wildcards).
            conversation_id: Optional filter to specific conversation.
            role: Optional role filter ('user', 'assistant', 'system').
            limit: Maximum results.
            offset: Results to skip.

        Returns:
            List of matching Message objects, ordered by timestamp descending.
        """
        where_clause, params = self._build_search_conditions(query, conversation_id, role)
        if not where_clause:
            return []

        params.extend([limit, offset])

        with self._lock:
            conn = self._get_connection()
            rows = conn.execute(
                f"""
                SELECT * FROM messages
                {where_clause}
                ORDER BY timestamp_ms DESC
                LIMIT ? OFFSET ?
                """,
                params,
            ).fetchall()

        return [self._row_to_message(row) for row in rows]

    def count_search_messages(
        self,
        query: str,
        conversation_id: Optional[str] = None,
        role: Optional[str] = None,
    ) -> int:
        """
        Count messages matching a search query with the same filters as search_messages.

        Args:
            query: Search text (wrapped in % wildcards).
            conversation_id: Optional filter to specific conversation.
            role: Optional role filter ('user', 'assistant', 'system').

        Returns:
            Total number of matching messages across all pages.
        """
        where_clause, params = self._build_search_conditions(query, conversation_id, role)
        if not where_clause:
            return 0

        with self._lock:
            conn = self._get_connection()
            row = conn.execute(
                f"SELECT COUNT(*) FROM messages {where_clause}",
                params,
            ).fetchone()

        return row[0] if row else 0

    # ─── Conversation Search ──────────────────────────────────────────────────────

    def _escape_like_pattern(self, pattern: str) -> str:
        """
        Escape SQL LIKE wildcards in a pattern string.

        Args:
            pattern: Input string that may contain % or _ wildcards.

        Returns:
            Pattern with % and _ escaped for literal matching.
        """
        return pattern.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    def _build_conversation_search_conditions(
        self,
        query: str,
        conversation_id: Optional[str] = None,
        role: Optional[str] = None,
    ) -> tuple[str, list]:
        """
        Build WHERE conditions for conversation-level search queries.

        Searches both conversation metadata (title, summary) and message content.
        A conversation matches if its metadata matches OR any of its messages match.

        Args:
            query: Search text (wrapped in % wildcards, wildcards escaped for literal matching).
            conversation_id: Optional filter to specific conversation.
            role: Optional role filter for messages ('user', 'assistant', 'system').

        Returns:
            Tuple of (where_clause, params_list) where where_clause includes
            the WHERE keyword and conditions joined by AND.
        """
        if not query or not query.strip():
            return "", []

        # Escape wildcards for literal matching, then wrap in % for substring search
        escaped_query = self._escape_like_pattern(query.strip())
        like_pattern = f"%{escaped_query}%"
        conditions = []
        params = []

        # Search conversation metadata: title or summary
        meta_conditions = ["title LIKE ? ESCAPE '\\'", "summary LIKE ? ESCAPE '\\'"]
        meta_params = [like_pattern, like_pattern]

        # Search message content (with optional role filter)
        msg_conditions = ["content LIKE ? ESCAPE '\\'"]
        msg_params = [like_pattern]

        if role:
            if role not in ("user", "assistant", "system"):
                raise ValidationError(f"Invalid role filter: {role}")
            msg_conditions.append("role = ?")
            msg_params.append(role)

        # Combine: conversation matches if metadata matches OR messages match
        # Use EXISTS subquery for message search
        conditions.append(f"({ ' OR '.join(meta_conditions) } OR EXISTS (SELECT 1 FROM messages WHERE conversation_id = conversations.id AND { ' AND '.join(msg_conditions) }))")
        params.extend(meta_params)
        params.extend(msg_params)

        if conversation_id:
            conditions.append("conversations.id = ?")
            params.append(conversation_id)

        where_clause = "WHERE " + " AND ".join(conditions)
        return where_clause, params

    def search_conversations(
        self,
        query: str,
        conversation_id: Optional[str] = None,
        role: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[ConversationSummary]:
        """
        Search conversations using a parameterized LIKE query.

        A conversation matches if its title/summary matches the query,
        OR any of its messages match the query (with optional role filter).

        Each matching conversation appears only once, even if multiple messages match.

        This is a simple text search. For production use with large datasets,
        consider adding FTS5 virtual table (out of scope for this batch).

        Args:
            query: Search text (wrapped in % wildcards).
            conversation_id: Optional filter to specific conversation.
            role: Optional role filter for messages ('user', 'assistant', 'system').
            limit: Maximum results.
            offset: Results to skip.

        Returns:
            List of matching ConversationSummary objects, ordered by most recent
            matching message timestamp descending (fallback: conversation started_at DESC).
        """
        where_clause, params = self._build_conversation_search_conditions(query, conversation_id, role)
        if not where_clause:
            return []

        params.extend([limit, offset])

        with self._lock:
            conn = self._get_connection()
            rows = conn.execute(
                f"""
                SELECT DISTINCT
                    conversations.id,
                    conversations.title,
                    conversations.started_at,
                    conversations.ended_at,
                    conversations.turn_count,
                    conversations.summary,
                    conversations.language,
                    conversations.engine,
                    MAX(messages.timestamp_ms) as last_match_time
                FROM conversations
                LEFT JOIN messages ON messages.conversation_id = conversations.id
                {where_clause}
                GROUP BY conversations.id
                ORDER BY last_match_time DESC NULLS LAST, conversations.started_at DESC
                LIMIT ? OFFSET ?
                """,
                params,
            ).fetchall()

        return [self._row_to_summary(row) for row in rows]

    def count_search_conversations(
        self,
        query: str,
        conversation_id: Optional[str] = None,
        role: Optional[str] = None,
    ) -> int:
        """
        Count conversations matching a search query with the same filters as search_conversations.

        Args:
            query: Search text (wrapped in % wildcards).
            conversation_id: Optional filter to specific conversation.
            role: Optional role filter for messages ('user', 'assistant', 'system').

        Returns:
            Total number of matching conversations across all pages.
        """
        where_clause, params = self._build_conversation_search_conditions(query, conversation_id, role)
        if not where_clause:
            return 0

        with self._lock:
            conn = self._get_connection()
            row = conn.execute(
                f"""
                SELECT COUNT(DISTINCT conversations.id)
                FROM conversations
                LEFT JOIN messages ON messages.conversation_id = conversations.id
                {where_clause}
                """,
                params,
            ).fetchone()

        return row[0] if row else 0

    # ─── Utility / Maintenance ────────────────────────────────────────────────

    def integrity_check(self) -> Tuple[bool, List[str]]:
        """
        Run SQLite integrity check.

        Returns:
            Tuple of (is_healthy, list_of_issues).
        """
        with self._lock:
            conn = self._get_connection()
            rows = conn.execute("PRAGMA integrity_check").fetchall()

        issues = [row[0] for row in rows if row[0] != "ok"]
        return (len(issues) == 0, issues)

    def wal_checkpoint(self, mode: str = "PASSIVE") -> int:
        """
        Trigger a WAL checkpoint.

        Args:
            mode: One of 'PASSIVE', 'FULL', 'RESTART', 'TRUNCATE'.

        Returns:
            Number of frames checkpointed (0 on error or if not in WAL mode).
        """
        valid_modes = {"PASSIVE", "FULL", "RESTART", "TRUNCATE"}
        if mode not in valid_modes:
            raise ValidationError(f"Invalid checkpoint mode: {mode}")

        with self._lock:
            conn = self._get_connection()
            row = conn.execute(f"PRAGMA wal_checkpoint({mode})").fetchone()
        return row[0] if row else 0

    def vacuum(self) -> None:
        """Rebuild the database file, reclaiming space and defragmenting."""
        with self._lock:
            conn = self._get_connection()
            conn.execute("VACUUM")

    def get_schema_version(self) -> int:
        """Get the current schema version."""
        with self._lock:
            conn = self._get_connection()
            row = conn.execute("PRAGMA user_version").fetchone()
        return row[0] if row else 0

    def backup(self, dest_path: Path) -> None:
        """
        Create a hot backup of the database.

        Uses SQLite's online backup API - safe to call while other
        connections are reading/writing.

        Args:
            dest_path: Destination file path for the backup.
        """
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        with self._lock:
            src = self._get_connection()
            with sqlite3.connect(dest_path) as dst:
                src.backup(dst)

    # ─── Internal Helpers ─────────────────────────────────────────────────────

    def _row_to_conversation(self, row: sqlite3.Row) -> Conversation:
        return Conversation(
            id=row["id"],
            title=row["title"],
            started_at=row["started_at"],
            ended_at=row["ended_at"],
            turn_count=row["turn_count"],
            summary=row["summary"],
            language=row["language"],
            engine=row["engine"],
            meta_json=row["meta_json"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def _row_to_summary(self, row: sqlite3.Row) -> ConversationSummary:
        return ConversationSummary(
            id=row["id"],
            title=row["title"],
            started_at=row["started_at"],
            ended_at=row["ended_at"],
            turn_count=row["turn_count"],
            summary=row["summary"],
            language=row["language"],
            engine=row["engine"],
        )

    def _row_to_message(self, row: sqlite3.Row) -> Message:
        return Message(
            id=row["id"],
            conversation_id=row["conversation_id"],
            role=row["role"],
            content=row["content"],
            content_type=row["content_type"],
            sequence=row["sequence"],
            timestamp_ms=row["timestamp_ms"],
            meta_json=row["meta_json"],
            created_at=row["created_at"],
        )


# ─── Migration Runner ─────────────────────────────────────────────────────────

class MigrationRunner:
    """
    Runs schema migrations in order.

    Each migration is a module with:
    - SCHEMA_VERSION: int
    - upgrade(conn): applies the migration
    """

    def __init__(self):
        self.migrations = [
            (1, "v001_initial_schema"),
        ]

    def run_migrations(self, conn: sqlite3.Connection) -> None:
        """Apply all pending migrations."""
        current = conn.execute("PRAGMA user_version").fetchone()[0]

        for version, module_name in self.migrations:
            if version <= current:
                continue

            # Import and run the migration
            module = __import__(
                f"memory.migrations.{module_name}",
                fromlist=["upgrade"],
            )
            module.upgrade(conn)

            # Version is set by the migration's PRAGMA user_version


# Global migration runner instance
migrate = MigrationRunner()


# ─── Convenience Functions ────────────────────────────────────────────────────

_default_store: Optional[ConversationStore] = None
_store_lock = threading.Lock()


def get_store() -> ConversationStore:
    """Get the default singleton store instance."""
    global _default_store
    with _store_lock:
        if _default_store is None:
            _default_store = ConversationStore()
        return _default_store


def reset_store() -> None:
    """Reset the default store (mainly for testing)."""
    global _default_store
    with _store_lock:
        if _default_store is not None:
            _default_store.close()
            _default_store = None