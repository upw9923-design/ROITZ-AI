"""
Migrations package for conversation storage schema.
"""
from .v001_initial_schema import upgrade, get_version, needs_migration, SCHEMA_VERSION


class MigrationRunner:
    """
    Runs schema migrations in order.

    Each migration is a module with:
    - SCHEMA_VERSION: int
    - upgrade(conn): applies the migration
    """

    def __init__(self):
        self.migrations = [
            (1, "v001_initial_schema"),
        ]

    def run_migrations(self, conn) -> None:
        """Apply all pending migrations."""
        current = conn.execute("PRAGMA user_version").fetchone()[0]

        for version, module_name in self.migrations:
            if version <= current:
                continue

            # Import and run the migration
            module = __import__(
                f"memory.migrations.{module_name}",
                fromlist=["upgrade"],
            )
            module.upgrade(conn)

            # Version is set by the migration's PRAGMA user_version


# Global migration runner instance
migrate = MigrationRunner()


__all__ = [
    "migrate",
    "upgrade",
    "get_version",
    "needs_migration",
    "SCHEMA_VERSION",
    "MigrationRunner",
]