"""
Initial schema migration for conversation storage.

This module creates the conversations and messages tables with all required
constraints, indexes, and schema versioning.

Schema version: 1
"""
import sqlite3


SCHEMA_VERSION = 1


SCHEMA_SQL = """
-- Enable foreign key constraints (must be set per-connection)
PRAGMA foreign_keys = ON;

-- Conversations table: one row per session
CREATE TABLE IF NOT EXISTS conversations (
    id              TEXT PRIMARY KEY,           -- UUID v4 (stable)
    title           TEXT NOT NULL DEFAULT '',   -- User-editable or auto-generated
    started_at      INTEGER NOT NULL,           -- Unix ms (monotonic or wall-clock)
    ended_at        INTEGER,                    -- Null = active
    turn_count      INTEGER NOT NULL DEFAULT 0,
    summary         TEXT,                       -- 1-2 sentence summary
    language        TEXT,                       -- Dominant language
    engine          TEXT NOT NULL DEFAULT 'gemini_live',
    meta_json       TEXT NOT NULL DEFAULT '{}', -- Extensible: tags, source, etc.
    created_at      INTEGER NOT NULL,           -- Row creation time
    updated_at      INTEGER NOT NULL            -- Last modification
);

-- Messages table: one row per turn (user or assistant)
CREATE TABLE IF NOT EXISTS messages (
    id              TEXT PRIMARY KEY,           -- UUID v4 (stable)
    conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role            TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    content         TEXT NOT NULL,              -- Plain text (transcription)
    content_type    TEXT NOT NULL DEFAULT 'text', -- 'text', 'tool_call', 'tool_result', 'vision'
    sequence        INTEGER NOT NULL,           -- 1-based order within conversation
    timestamp_ms    INTEGER NOT NULL,           -- Unix ms when received
    meta_json       TEXT NOT NULL DEFAULT '{}', -- Extensible: tool name, confidence, etc.
    created_at      INTEGER NOT NULL
);

-- Unique constraint: sequence numbers are unique per conversation
CREATE UNIQUE INDEX IF NOT EXISTS idx_messages_conv_seq_unique
    ON messages(conversation_id, sequence);

-- Index for fetching messages in order
CREATE INDEX IF NOT EXISTS idx_messages_conv_seq
    ON messages(conversation_id, sequence);

-- Index for time-based queries
CREATE INDEX IF NOT EXISTS idx_messages_conv_time
    ON messages(conversation_id, timestamp_ms);

-- Index for conversation ordering (newest first)
CREATE INDEX IF NOT EXISTS idx_conversations_started
    ON conversations(started_at DESC);

-- Index for conversation ordering by update time
CREATE INDEX IF NOT EXISTS idx_conversations_updated
    ON conversations(updated_at DESC);

-- Schema version tracking
PRAGMA user_version = """ + str(SCHEMA_VERSION) + """;
"""


def upgrade(conn: sqlite3.Connection) -> None:
    """
    Apply the initial schema migration.

    This function is idempotent - it can be called multiple times safely.
    It uses CREATE TABLE IF NOT EXISTS and CREATE INDEX IF NOT EXISTS.

    Args:
        conn: SQLite connection with foreign_keys enabled.
    """
    # Execute all statements in a single transaction
    conn.executescript(SCHEMA_SQL)


def get_version(conn: sqlite3.Connection) -> int:
    """
    Get the current schema version from the database.

    Args:
        conn: SQLite connection.

    Returns:
        Current user_version (0 if not set).
    """
    cursor = conn.execute("PRAGMA user_version")
    row = cursor.fetchone()
    return row[0] if row else 0


def needs_migration(conn: sqlite3.Connection) -> bool:
    """
    Check if the database needs migration.

    Args:
        conn: SQLite connection.

    Returns:
        True if current version < SCHEMA_VERSION.
    """
    return get_version(conn) < SCHEMA_VERSION