"""
Unit tests for the permission manager and authentication foundation.

Run with: python -m unittest tests/unit/test_permission_manager.py -v
"""

import time
import threading
import unittest
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock


class TestAuthRateLimiter(unittest.TestCase):
    """Tests for AuthRateLimiter."""

    def setUp(self):
        from core.auth_rate_limiter import AuthRateLimiter
        self.limiter = AuthRateLimiter()

    def test_stable_identity_not_nonce(self):
        """Rate limiter uses stable identity, not nonce."""
        id1 = ("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "delete_tpl", "file_controller")
        id2 = ("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "delete_tpl", "file_controller")

        # check_lockout doesn't increment counter - only record_failed_verification does
        for _ in range(3):
            allowed, _ = self.limiter.check_lockout(*id1)
            self.assertTrue(allowed)
        # Now record 3 failed verifications
        for _ in range(3):
            allowed, _ = self.limiter.record_failed_verification(*id1)
            self.assertTrue(allowed)
        # 4th should lock
        allowed, lockout = self.limiter.record_failed_verification(*id1)
        self.assertFalse(allowed)
        self.assertEqual(lockout, 900)

        # id2 should also be locked (same identity)
        allowed, _ = self.limiter.check_lockout(*id2)
        self.assertFalse(allowed)

    def test_different_identities_independent(self):
        """Different template_id = different rate limit bucket."""
        for _ in range(3):
            self.limiter.record_failed_verification("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")

        allowed, _ = self.limiter.check_lockout("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "other_tpl", "comp")
        self.assertTrue(allowed)

    def test_lockout_expires(self):
        """Lockout expires after 15 minutes."""
        from core.auth_rate_limiter import _RateLimitState
        for _ in range(3):
            self.limiter.record_failed_verification("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")

        with self.limiter._lock:
            state = self.limiter._state["fs.delete|D:/M MONSTER PROJECT/Roitz-main|tpl|comp"]
            state.locked_until = time.monotonic() - 1

        allowed, _ = self.limiter.check_lockout("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")
        self.assertTrue(allowed)

    def test_cancel_does_not_reset(self):
        """Cancel/timeout does not reset failure counter."""
        self.limiter.record_failed_verification("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")
        self.limiter.record_failed_verification("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")

        self.limiter.record_cancel_or_timeout("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")

        # 3rd failure is still allowed (MAX=3 means 3 allowed, 4th locks)
        allowed, _ = self.limiter.record_failed_verification("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")
        self.assertTrue(allowed)
        # 4th should lock
        allowed, lockout = self.limiter.record_failed_verification("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")
        self.assertFalse(allowed)
        self.assertEqual(lockout, 900)

    def test_success_resets(self):
        """Successful verification resets counter."""
        for _ in range(2):
            self.limiter.record_failed_verification("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")

        self.limiter.record_successful_verification("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")

        # Should have 3 attempts again
        for _ in range(3):
            allowed, _ = self.limiter.record_failed_verification("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")
            self.assertTrue(allowed)

    def test_request_not_counted(self):
        """Authentication REQUEST does not count toward limit."""
        # check_lockout (simulating requests) doesn't increment counter
        for _ in range(100):
            allowed, _ = self.limiter.check_lockout("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")
            self.assertTrue(allowed)

        # Still have 3 attempts for actual failed verifications
        for _ in range(3):
            allowed, _ = self.limiter.record_failed_verification("fs.delete", "D:/M MONSTER PROJECT/Roitz-main", "tpl", "comp")
            self.assertTrue(allowed)


class TestOperationIdentity(unittest.TestCase):
    """Tests for OperationIdentity and ApprovalToken."""

    def test_canonical_serialization(self):
        """Canonical serialization is deterministic and type-preserving."""
        from core.permission_fingerprint import OperationIdentity
        id1 = OperationIdentity.create(
            "proc.exec", Path("D:/M MONSTER PROJECT/Roitz-main"),
            "git_push", {"remote": "origin", "branch": "main"}, "file_controller"
        )
        id2 = OperationIdentity.create(
            "proc.exec", Path("D:/M MONSTER PROJECT/Roitz-main"),
            "git_push", {"branch": "main", "remote": "origin"}, "file_controller"
        )
        self.assertEqual(id1.canonical_bytes(), id2.canonical_bytes())
        self.assertEqual(id1.identity_hash(), id2.identity_hash())

    def test_type_preservation(self):
        """Types preserved in canonical_bytes."""
        from core.permission_fingerprint import OperationIdentity
        id1 = OperationIdentity.create(
            "proc.exec", Path("D:/M MONSTER PROJECT/Roitz-main"), "tpl",
            {"count": 5, "flag": True, "name": "test", "ratio": 1.5, "items": [1,2], "nested": {"a": 1}}, "comp"
        )
        canon = id1.canonical_bytes()
        self.assertIn(b"i:5", canon)
        self.assertIn(b"b:1", canon)
        self.assertIn(b's:"test"', canon)
        self.assertIn(b"f:1.5", canon)
        self.assertIn(b"l:i:1i:2", canon)
        # Dict serialization includes braces, key-value separators, and comma
        self.assertIn(b"d:{a,:,i:1}", canon)

    def test_rejects_unsupported_types(self):
        """Unsupported types raise TypeError."""
        from core.permission_fingerprint import OperationIdentity
        with self.assertRaises(TypeError):
            OperationIdentity.create("cap", Path("D:/M MONSTER PROJECT/Roitz-main"), "tpl", {"bad": set()}, "comp")
        with self.assertRaises(TypeError):
            OperationIdentity.create("cap", Path("D:/M MONSTER PROJECT/Roitz-main"), "tpl", {"bad": object()}, "comp")

    def test_rejects_outside_project(self):
        """Project outside BASE_DIR is rejected."""
        from core.permission_fingerprint import OperationIdentity
        from memory.config_manager import BASE_DIR
        outside = BASE_DIR.parent / "other_project"
        with self.assertRaises(ValueError):
            OperationIdentity.create("fs.read", outside, "tpl", {}, "comp")


class TestApprovalToken(unittest.TestCase):
    """Tests for ApprovalToken."""

    def test_unique_per_request(self):
        """Each request gets unique token_hash due to nonce."""
        from core.permission_fingerprint import OperationIdentity, ApprovalToken
        identity = OperationIdentity.create("cap", Path("D:/M MONSTER PROJECT/Roitz-main"), "tpl", {}, "comp")

        token1 = ApprovalToken.create(identity)
        token2 = ApprovalToken.create(identity)

        self.assertNotEqual(token1.token_hash(), token2.token_hash())
        self.assertEqual(token1.identity.identity_hash(), token2.identity.identity_hash())

    def test_exact_match_required(self):
        """Token bound to exact identity; mutation changes token_hash."""
        from core.permission_fingerprint import OperationIdentity, ApprovalToken
        identity = OperationIdentity.create("cap", Path("D:/M MONSTER PROJECT/Roitz-main"), "tpl", {"arg": "v1"}, "comp")
        token = ApprovalToken.create(identity)

        identity2 = OperationIdentity.create("cap", Path("D:/M MONSTER PROJECT/Roitz-main"), "tpl", {"arg": "v2"}, "comp")
        token2 = ApprovalToken(identity=identity2, nonce=token.nonce)

        self.assertNotEqual(token.token_hash(), token2.token_hash())
        self.assertNotEqual(token.identity.canonical_bytes(), token2.identity.canonical_bytes())


class TestWindowsACL(unittest.TestCase):
    """Tests for Windows ACL verification."""

    @patch('core.windows_acl.platform.system', return_value='Windows')
    @patch('core.windows_acl.win32security')
    @patch('core.windows_acl.ntsecuritycon')
    def test_verify_checks_sids_masks_inheritance(self, mock_nc, mock_ws, mock_platform):
        """verify_restrictive_acl checks SIDs, masks, inheritance, protected DACL."""
        from core.windows_acl import verify_restrictive_acl

        mock_user_sid = Mock()
        mock_system_sid = Mock()
        mock_ws.GetTokenInformation.return_value = [mock_user_sid]
        mock_ws.CreateWellKnownSid.return_value = mock_system_sid
        mock_ws.ACCESS_ALLOWED_ACE_TYPE = 0
        mock_nc.FILE_ALL_ACCESS = 0x1F01FF

        mock_dacl = Mock()
        mock_dacl.GetAceCount.return_value = 2
        # Real ACE structure: ((type, flags), mask, sid)
        mock_dacl.GetAce.side_effect = [
            ((0, 0), 0x1F01FF, mock_user_sid),
            ((0, 0), 0x1F01FF, mock_system_sid),
        ]

        mock_sd = Mock()
        mock_sd.GetSecurityDescriptorDacl.return_value = mock_dacl
        mock_sd.GetSecurityDescriptorControl.return_value = (0x1000, 0)
        mock_ws.GetFileSecurity.return_value = mock_sd

        self.assertTrue(verify_restrictive_acl(Path("test")))

        # Test inheritance flag rejection
        mock_dacl.GetAce.side_effect = [
            ((0, 1), 0x1F01FF, mock_user_sid),
            ((0, 0), 0x1F01FF, mock_system_sid),
        ]
        self.assertFalse(verify_restrictive_acl(Path("test")))

    def test_secure_create_directory_windows_import(self):
        """secure_create_directory imports win32file on Windows."""
        # This test verifies the import structure without mocking internal function imports
        from core.windows_acl import secure_create_directory
        import platform
        if platform.system() == "Windows":
            # On Windows, verify the function doesn't crash on import
            try:
                import win32file
                self.assertTrue(True)
            except ImportError:
                self.skipTest("pywin32 not installed")
        else:
            # On non-Windows, just verify function exists
            self.assertTrue(callable(secure_create_directory))


class TestPermissionGuard(unittest.TestCase):
    """Tests for PermissionGuard."""

    def test_validates_exact_operation(self):
        """PermissionGuard validates exact operation with parameters."""
        from core.permission_guard import PermissionGuard, OPERATION_SPECS
        pm = Mock()
        pm.check.return_value = Mock(allowed=False, requires_approval=True)
        pm.check.return_value.instruction = "[AUTH_REQUIRED] ..."

        guard = PermissionGuard(pm)
        guard.initialize()

        spec = OPERATION_SPECS["file_controller:delete"]
        self.assertEqual(spec.capability, "fs.delete")

        spec = OPERATION_SPECS["dev_agent:build"]
        self.assertEqual(spec.capability, "proc.exec")
        self.assertEqual(spec.template_id, "pytest_project")

        spec = OPERATION_SPECS["computer_control:screen_click"]
        self.assertEqual(spec.capability, "screen.capture")
        self.assertEqual(spec.additional_caps, ("input.simulate",))

    def test_fail_closed_uninitialized(self):
        """Uninitialized guard denies all operations."""
        from core.permission_guard import PermissionGuard
        pm = Mock()
        guard = PermissionGuard(pm)

        result = guard.check_operation("file_controller:delete", {})
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "guard_uninitialized")

    def test_unknown_operation_denied(self):
        """Unknown operations are denied by default."""
        from core.permission_guard import PermissionGuard
        pm = Mock()
        guard = PermissionGuard(pm)
        guard.initialize()

        result = guard.check_operation("unknown:operation", {})
        self.assertFalse(result.allowed)
        self.assertIn("unknown_operation", result.reason)


class TestCommandTemplates(unittest.TestCase):
    """Tests for command template validation."""

    def setUp(self):
        from core.command_templates import initialize_templates
        from memory.config_manager import BASE_DIR
        initialize_templates(BASE_DIR)

    def test_placeholder_validation(self):
        """Template validates placeholders against regex patterns."""
        from core.command_templates import validate_template
        result = validate_template("git_push", {"remote": "origin", "branch": "main"})
        self.assertTrue(result.allowed)
        # Command includes resolved executable path + fixed_args + placeholders
        self.assertEqual(len(result.command), 4)
        self.assertTrue(result.command[0].endswith("git.EXE") or result.command[0].endswith("git.exe") or result.command[0].endswith("git"))
        self.assertEqual(result.command[1:], ["push", "origin", "main"])

        result = validate_template("git_push", {"remote": "origin", "branch": "feature branch"})
        self.assertFalse(result.allowed)
        self.assertIn("invalid_placeholder", result.reason)

        result = validate_template("git_push", {"remote": "origin"})
        self.assertFalse(result.allowed)
        self.assertIn("missing_placeholder", result.reason)

    def test_injection_blocked(self):
        """Shell metacharacters in arguments are blocked by regex."""
        from core.command_templates import validate_template
        result = validate_template("git_push", {"remote": "origin", "branch": "main; rm -rf /"})
        self.assertFalse(result.allowed)

    def test_requires_owner_auth(self):
        """git_commit and git_push require owner auth."""
        from core.command_templates import get_template
        t = get_template("git_commit")
        self.assertTrue(t.requires_owner_auth)

        t = get_template("git_push")
        self.assertTrue(t.requires_owner_auth)

        t = get_template("git_status")
        self.assertFalse(t.requires_owner_auth)


class TestPermissionManager(unittest.TestCase):
    """Tests for PermissionManager."""

    def test_denies_if_ui_not_bound(self):
        """Permission manager denies sensitive ops if UI not bound."""
        from core.permission_manager import PermissionManager
        pm = PermissionManager()
        pm._ui_bound = False

        result = pm.check("fs.delete", Path("D:/M MONSTER PROJECT/Roitz-main"))
        self.assertFalse(result.allowed)

    @patch('core.permission_manager.initialize_config_acl', return_value=(False, "owner_secret not configured"))
    def test_denies_sensitive_if_no_owner_secret(self, mock_acl):
        """Sensitive operations denied if owner_secret missing."""
        from core.permission_manager import PermissionManager
        pm = PermissionManager()
        pm._config_acl_ok = False

        result = pm.check("fs.delete", Path("D:/M MONSTER PROJECT/Roitz-main"))
        self.assertFalse(result.allowed)


class TestConcurrentAuth(unittest.TestCase):
    """Tests for concurrent authentication requests."""

    def test_concurrent_auth_requests(self):
        """Multiple concurrent auth requests tracked independently by token_hash."""
        from core.auth_dialog import _pending_auth, _auth_lock, request_auth, resolve_auth
        from core.permission_fingerprint import OperationIdentity, ApprovalToken
        import core.auth_dialog as auth_dialog

        with _auth_lock:
            _pending_auth.clear()

        identity = OperationIdentity.create("fs.delete", Path("D:/M MONSTER PROJECT/Roitz-main"), "delete", {}, "comp")
        token1 = ApprovalToken.create(identity)
        token2 = ApprovalToken.create(identity)

        results = []
        def cb1(v): results.append(("cb1", v))
        def cb2(v): results.append(("cb2", v))

        auth_dialog._show_cb = lambda h, t, d: None
        auth_dialog._hide_cb = lambda: None
        auth_dialog._log_cb = lambda m: None

        r1 = request_auth(token1, "Title 1", "Detail 1", cb1)
        r2 = request_auth(token2, "Title 2", "Detail 2", cb2)

        self.assertIn("[AUTH_REQUIRED]", r1)
        self.assertIn("[AUTH_REQUIRED]", r2)

        with _auth_lock:
            self.assertEqual(len(_pending_auth), 2)

        resolve_auth(token1.token_hash(), True, b"secret")
        resolve_auth(token2.token_hash(), False, b"")

        with _auth_lock:
            self.assertEqual(len(_pending_auth), 0)


class TestAuditLog(unittest.TestCase):
    """Tests for audit logging."""

    def test_audit_log_written(self):
        """Permission checks write to audit log."""
        from core.permission_manager import _audit_log

        log_file = Path("d:/M MONSTER PROJECT/Roitz-main/config/permissions_audit.jsonl")
        if log_file.exists():
            log_file.unlink()

        _audit_log({"event": "test", "capability": "fs.read"})

        self.assertTrue(log_file.exists())
        content = log_file.read_text()
        self.assertIn("test", content)
        self.assertIn("fs.read", content)


if __name__ == "__main__":
    unittest.main()