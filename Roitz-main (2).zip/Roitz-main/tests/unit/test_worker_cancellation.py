"""
Unit tests for Batch 2: Worker Cancellation Architecture.

Run with: py -m pytest tests/unit/test_worker_cancellation.py -v
"""
import sys
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.worker_registry import (
    WorkerRegistry,
    WorkerRecord,
    WorkerState,
    create_worker_record,
    extract_resource_keys,
    get_global_registry,
    reset_global_registry,
)
from core.autonomous_agent import (
    Executor,
    TaskPlan,
    TaskStep,
    TaskState,
    StepState,
    ActionRegistry,
    PluginRegistry,
)


class TestWorkerRegistryCancellation(unittest.TestCase):
    """Tests for WorkerRegistry cancellation methods."""

    def setUp(self):
        reset_global_registry()
        self.registry = WorkerRegistry()

    def tearDown(self):
        reset_global_registry()

    def _create_worker(self, task_id="task_1", step_id="step_1", tool="file_controller", state=WorkerState.RUNNING):
        worker = create_worker_record(
            task_id=task_id,
            step_id=step_id,
            tool_name=tool,
            parameters={"action": "read", "path": "/tmp/test.txt"},
            operation_name="file_controller:read",
            resource_scope=None,
            is_idempotent=True,
        )
        cancel_event = threading.Event()
        worker.mark_running(threading.current_thread(), cancel_event)
        # Set state AFTER mark_running (which sets it to RUNNING)
        worker.state = state
        self.registry.register(worker)
        return worker

    def test_request_task_cancellation_single_worker(self):
        """Request cancellation for a task with one worker."""
        worker = self._create_worker()
        self.assertEqual(worker.state, WorkerState.RUNNING)

        count = self.registry.request_task_cancellation("task_1")

        self.assertEqual(count, 1)
        self.assertEqual(worker.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertTrue(worker.cancel_event.is_set())

    def test_request_task_cancellation_multiple_workers_same_task(self):
        """Request cancellation for a task with multiple workers."""
        worker1 = self._create_worker(step_id="step_1")
        worker2 = self._create_worker(step_id="step_2")

        count = self.registry.request_task_cancellation("task_1")

        self.assertEqual(count, 2)
        self.assertEqual(worker1.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertEqual(worker2.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertTrue(worker1.cancel_event.is_set())
        self.assertTrue(worker2.cancel_event.is_set())

    def test_request_task_cancellation_no_effect_on_other_tasks(self):
        """Cancelling task_1 does not affect task_2."""
        worker1 = self._create_worker(task_id="task_1")
        worker2 = self._create_worker(task_id="task_2")

        count = self.registry.request_task_cancellation("task_1")

        self.assertEqual(count, 1)
        self.assertEqual(worker1.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertEqual(worker2.state, WorkerState.RUNNING)
        self.assertFalse(worker2.cancel_event.is_set())

    def test_request_task_cancellation_only_running_workers(self):
        """Only RUNNING workers receive cancellation."""
        running_worker = self._create_worker(state=WorkerState.RUNNING)
        completed_worker = self._create_worker(step_id="step_2", state=WorkerState.COMPLETED)
        failed_worker = self._create_worker(step_id="step_3", state=WorkerState.FAILED)

        count = self.registry.request_task_cancellation("task_1")

        self.assertEqual(count, 1)
        self.assertEqual(running_worker.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertEqual(completed_worker.state, WorkerState.COMPLETED)
        self.assertEqual(failed_worker.state, WorkerState.FAILED)

    def test_request_step_cancellation(self):
        """Request cancellation for a specific step."""
        worker1 = self._create_worker(step_id="step_1")
        worker2 = self._create_worker(step_id="step_2")

        count = self.registry.request_step_cancellation("step_1")

        self.assertEqual(count, 1)
        self.assertEqual(worker1.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertEqual(worker2.state, WorkerState.RUNNING)

    def test_cancellation_idempotent(self):
        """Repeated cancellation requests are safe."""
        worker = self._create_worker()

        self.registry.request_task_cancellation("task_1")
        self.registry.request_task_cancellation("task_1")
        self.registry.request_task_cancellation("task_1")

        self.assertEqual(worker.state, WorkerState.CANCELLATION_REQUESTED)

    def test_cancellation_concurrent_requests(self):
        """Concurrent cancellation requests from multiple threads are safe."""
        worker = self._create_worker()
        results = []

        def request_cancel():
            count = self.registry.request_task_cancellation("task_1")
            results.append(count)

        threads = [threading.Thread(target=request_cancel) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(worker.state, WorkerState.CANCELLATION_REQUESTED)
        # First call returns 1, subsequent return 0 (idempotent)
        self.assertEqual(sum(results), 1)
        self.assertTrue(all(r >= 0 for r in results))

    def test_get_active_task_workers(self):
        """Get active workers for a task."""
        worker1 = self._create_worker(step_id="step_1")
        worker2 = self._create_worker(step_id="step_2")
        completed = self._create_worker(step_id="step_3", state=WorkerState.COMPLETED)

        active = self.registry.get_active_task_workers("task_1")

        self.assertEqual(len(active), 2)
        self.assertIn(worker1, active)
        self.assertIn(worker2, active)
        self.assertNotIn(completed, active)


class TestExecutorCancellation(unittest.TestCase):
    """Tests for Executor cancellation propagation."""

    def setUp(self):
        reset_global_registry()
        self.action_registry = Mock(spec=ActionRegistry)
        self.plugin_registry = Mock(spec=PluginRegistry)
        self.executor = Executor(
            action_registry=self.action_registry,
            plugin_registry=self.plugin_registry,
            worker_registry=get_global_registry(),
        )

    def tearDown(self):
        reset_global_registry()

    def test_cancel_sets_flag(self):
        """Executor.cancel() sets the _cancelled flag."""
        self.assertFalse(self.executor._cancelled)
        self.executor.cancel()
        self.assertTrue(self.executor._cancelled)

    def test_cancel_requests_worker_cancellation(self):
        """Executor.cancel() requests cancellation on active worker."""
        # Simulate an active worker
        worker = create_worker_record(
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            parameters={"action": "read", "path": "/tmp/test.txt"},
            operation_name="file_controller:read",
            resource_scope=None,
            is_idempotent=True,
        )
        cancel_event = threading.Event()
        worker.mark_running(threading.current_thread(), cancel_event)
        self.executor.worker_registry.register(worker)
        self.executor._active_attempt_id = worker.attempt_id
        self.executor._active_step_id = "step_1"

        self.executor.cancel()

        self.assertEqual(worker.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertTrue(cancel_event.is_set())

    def test_cancel_task_requests_all_workers(self):
        """Executor.cancel_task() requests cancellation for all task workers."""
        worker1 = create_worker_record("task_1", "step_1", "file_controller", {"action": "read"}, "file_controller:read", None, True)
        worker2 = create_worker_record("task_1", "step_2", "file_controller", {"action": "write"}, "file_controller:write", None, True)
        for w in [worker1, worker2]:
            w.mark_running(threading.current_thread(), threading.Event())
            self.executor.worker_registry.register(w)

        count = self.executor.cancel_task("task_1")

        self.assertEqual(count, 2)
        self.assertEqual(worker1.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertEqual(worker2.state, WorkerState.CANCELLATION_REQUESTED)


class TestWorkerRecordCancellation(unittest.TestCase):
    """Tests for WorkerRecord cancellation behavior."""

    def test_request_cancellation_sets_state_and_event(self):
        """request_cancellation() sets state and signals event."""
        cancel_event = threading.Event()
        worker = WorkerRecord(
            attempt_id="test_1",
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            operation_name="file_controller:read",
        )
        worker.mark_running(threading.current_thread(), cancel_event)

        self.assertEqual(worker.state, WorkerState.RUNNING)
        self.assertFalse(cancel_event.is_set())

        worker.request_cancellation()

        self.assertEqual(worker.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertTrue(cancel_event.is_set())

    def test_request_cancellation_only_from_running(self):
        """request_cancellation() only works from RUNNING state."""
        worker = WorkerRecord(
            attempt_id="test_1",
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            operation_name="file_controller:read",
        )
        worker.state = WorkerState.COMPLETED

        worker.request_cancellation()

        self.assertEqual(worker.state, WorkerState.COMPLETED)


class TestVoiceInterruptPropagation(unittest.TestCase):
    """Tests for voice interrupt -> task cancellation propagation."""

    def test_interrupt_cancels_active_task(self):
        """Voice interrupt propagates cancellation to active executors."""
        from actions import task_agent as ta
        from core.autonomous_agent import Executor

        reset_global_registry()
        registry = get_global_registry()

        # Create mock registries
        mock_action_reg = Mock()
        mock_plugin_reg = Mock()

        # Create a mock executor with active workers
        executor = Executor(
            action_registry=mock_action_reg,
            plugin_registry=mock_plugin_reg,
            worker_registry=registry,
        )

        # Add active workers
        worker1 = create_worker_record("task_1", "step_1", "file_controller", {"action": "read"}, "file_controller:read", None, True)
        worker2 = create_worker_record("task_1", "step_2", "computer_control", {"action": "click"}, "computer_control:click", None, True)
        for w in [worker1, worker2]:
            w.mark_running(threading.current_thread(), threading.Event())
            registry.register(w)

        # Register executor
        with ta._executors_lock:
            ta._active_executors["task_1"] = executor

        # Simulate interrupt by calling the cancellation logic directly
        # (We can't easily instantiate full JARVIS, so test the propagation logic)
        with ta._executors_lock:
            for task_id, exec_ in ta._active_executors.items():
                exec_.cancel_task(task_id)
                exec_.cancel()

        # Verify workers received cancellation
        self.assertEqual(worker1.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertEqual(worker2.state, WorkerState.CANCELLATION_REQUESTED)

        # Cleanup
        with ta._executors_lock:
            ta._active_executors.clear()
        reset_global_registry()


class TestResourceReservationDuringCancellation(unittest.TestCase):
    """Tests that resources remain reserved during cancellation."""

    def setUp(self):
        reset_global_registry()
        self.registry = WorkerRegistry()

    def tearDown(self):
        reset_global_registry()

    def test_resources_held_during_cancellation(self):
        """Resource keys remain reserved while worker is alive after cancellation."""
        worker = create_worker_record(
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/tmp/test.txt"},
            operation_name="file_controller:write",
            resource_scope=None,
            is_idempotent=False,
        )
        cancel_event = threading.Event()
        worker.mark_running(threading.current_thread(), cancel_event)
        self.registry.register(worker)

        # Verify resource is reserved
        self.assertIn("/tmp/test.txt", self.registry._resource_reservations)

        # Request cancellation
        self.registry.request_task_cancellation("task_1")

        # Resource should still be reserved (worker still alive)
        self.assertIn("/tmp/test.txt", self.registry._resource_reservations)

    def test_resources_released_after_termination(self):
        """Resources released only after confirmed termination."""
        worker = create_worker_record(
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/tmp/test.txt"},
            operation_name="file_controller:write",
            resource_scope=None,
            is_idempotent=False,
        )
        cancel_event = threading.Event()
        worker.mark_running(threading.current_thread(), cancel_event)
        self.registry.register(worker)

        # Cancel and mark terminated
        self.registry.request_task_cancellation("task_1")
        worker.mark_terminated()
        self.registry.release_resources(worker.attempt_id)

        # Resource should be released
        self.assertNotIn("/tmp/test.txt", self.registry._resource_reservations)

    def test_unresolved_worker_holds_resources(self):
        """UNRESOLVED workers continue to hold resource reservations."""
        worker = create_worker_record(
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/tmp/test.txt"},
            operation_name="file_controller:write",
            resource_scope=None,
            is_idempotent=False,
        )
        cancel_event = threading.Event()
        worker.mark_running(threading.current_thread(), cancel_event)
        self.registry.register(worker)

        # Simulate timeout -> UNRESOLVED
        self.registry.request_task_cancellation("task_1")
        worker.mark_unresolved()

        # Resource should still be reserved
        self.assertIn("/tmp/test.txt", self.registry._resource_reservations)

        # Other task should be blocked by unresolved worker
        worker2 = create_worker_record(
            task_id="task_2",
            step_id="step_1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/tmp/test.txt"},
            operation_name="file_controller:write",
            resource_scope=None,
            is_idempotent=False,
        )
        admitted, reason = self.registry.admit_worker(worker2)
        self.assertFalse(admitted)
        self.assertIn("resource_key:/tmp/test.txt", reason)


class TestIntraStepCancellationChecking(unittest.TestCase):
    """Tests that handlers can check cancel_event during execution."""

    @classmethod
    def setUpClass(cls):
        """Initialize permission manager and guard for testing."""
        from core.permission_manager import initialize_permission_manager_for_test
        from core.permission_guard import get_permission_guard
        initialize_permission_manager_for_test()
        guard = get_permission_guard()
        guard.initialize()

    def test_cancel_event_passed_to_action_registry(self):
        """ActionRegistry.run receives cancel_event in context."""
        from core.action_loader import ActionRegistry, _call_handler
        from core.permission_guard import get_permission_guard
        import inspect

        cancel_event = threading.Event()

        def dummy_logger(msg):
            pass

        def handler_with_cancel(parameters, cancel_event=None):
            if cancel_event and cancel_event.is_set():
                return "CANCELLED"
            return "DONE"

        # Register a dummy action with a valid tool name (file_controller)
        # which has operation specs for "read" action
        registry = ActionRegistry(
            actions={
                "file_controller": Mock(
                    valid=True,
                    handler=handler_with_cancel,
                    name="file_controller",
                    description="Test",
                    parameters={"type": "OBJECT", "properties": {}},
                )
            },
            logger=dummy_logger,
        )

        # Mock permission guard - use the real one (already initialized in setUpClass)
        with patch("core.action_loader.get_permission_guard") as mock_guard:
            mock_guard.return_value = get_permission_guard()

            # Call with cancel_event in context and valid parameters
            result = registry.run("file_controller", {"action": "read"}, ctx={"cancel_event": cancel_event})

        self.assertEqual(result, "DONE")

        # Now test with cancelled
        cancel_event.set()
        result = registry.run("file_controller", {"action": "read"}, ctx={"cancel_event": cancel_event})
        self.assertEqual(result, "CANCELLED")

    def test_cancel_event_passed_to_plugin_registry(self):
        """PluginRegistry.run receives cancel_event."""
        from core.plugin_loader import PluginRegistry, _call_run
        from core.permission_manager import PermissionResult
        from core.permission_guard import get_permission_guard

        cancel_event = threading.Event()

        def dummy_logger(msg):
            pass

        def dummy_notify(msg):
            pass

        def plugin_run(parameters, cancel_event=None):
            if cancel_event and cancel_event.is_set():
                return "CANCELLED"
            return "DONE"

        # Use a valid plugin name
        registry = PluginRegistry(
            plugins={
                "test_plugin": Mock(
                    valid=True,
                    run=plugin_run,
                    name="test_plugin",
                    description="Test",
                    parameters={"type": "OBJECT", "properties": {}},
                )
            },
            logger=dummy_logger,
            notify=dummy_notify,
        )

        # Mock permission guard to allow the operation
        guard = get_permission_guard()
        with patch.object(guard, 'check_operation', return_value=PermissionResult(True, "allowed")):
            with patch("core.plugin_loader.get_plugin_enabled", return_value=True):

                result = registry.run("test_plugin", {"action": "test"}, cancel_event=cancel_event)

        self.assertEqual(result, "DONE")

        cancel_event.set()
        with patch.object(guard, 'check_operation', return_value=PermissionResult(True, "allowed")):
            with patch("core.plugin_loader.get_plugin_enabled", return_value=True):
                result = registry.run("test_plugin", {"action": "test"}, cancel_event=cancel_event)
        self.assertEqual(result, "CANCELLED")


class TestWorkerIgnoringCancellation(unittest.TestCase):
    """Tests for workers that ignore cancellation."""

    def setUp(self):
        reset_global_registry()
        self.registry = WorkerRegistry()

    def tearDown(self):
        reset_global_registry()

    def test_ignoring_cancellation_remains_unresolved(self):
        """Worker that ignores cancellation stays alive and becomes UNRESOLVED."""
        worker = create_worker_record(
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/tmp/test.txt"},
            operation_name="file_controller:write",
            resource_scope=None,
            is_idempotent=False,
        )
        cancel_event = threading.Event()
        worker.mark_running(threading.current_thread(), cancel_event)
        self.registry.register(worker)

        # Request cancellation
        self.registry.request_task_cancellation("task_1")

        # Worker ignores it (doesn't check cancel_event)
        # Simulate timeout handling
        worker.mark_unresolved()

        self.assertEqual(worker.state, WorkerState.UNRESOLVED)
        self.assertTrue(worker.is_alive())  # Thread still alive

        # Resource still held
        self.assertIn("/tmp/test.txt", self.registry._resource_reservations)

    def test_never_mark_terminated_while_alive(self):
        """mark_terminated() should not be called while thread is alive."""
        worker = create_worker_record(
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/tmp/test.txt"},
            operation_name="file_controller:write",
            resource_scope=None,
            is_idempotent=False,
        )
        cancel_event = threading.Event()
        worker.mark_running(threading.current_thread(), cancel_event)
        self.registry.register(worker)

        # This would be incorrect - don't do it
        # worker.mark_terminated()  # WRONG: thread still alive

        # Correct flow: wait for thread, then mark terminated
        self.assertTrue(worker.is_alive())


class TestExecutorIntegration(unittest.TestCase):
    """Integration tests for Executor with cancellation."""

    def setUp(self):
        reset_global_registry()
        self.action_registry = Mock(spec=ActionRegistry)
        self.plugin_registry = Mock(spec=PluginRegistry)
        self.executor = Executor(
            action_registry=self.action_registry,
            plugin_registry=self.plugin_registry,
            worker_registry=get_global_registry(),
        )

    def tearDown(self):
        reset_global_registry()

    def test_cancel_between_steps(self):
        """Executor respects cancellation between steps."""
        plan = TaskPlan(
            task_id="task_1",
            goal="Test",
            steps=[
                TaskStep(id="step_1", description="Step 1", tool="file_controller"),
                TaskStep(id="step_2", description="Step 2", tool="file_controller"),
            ],
        )

        # Mock first step to succeed
        self.action_registry.has.return_value = True
        self.action_registry.run.return_value = "Done"

        # Cancel before second step
        original_execute = self.executor._execute_step
        def execute_with_cancel(step, cancel_event=None):
            if step.id == "step_1":
                self.executor.cancel()  # Cancel after first step
            return original_execute(step, cancel_event)
        self.executor._execute_step = execute_with_cancel

        result = self.executor.execute(plan)

        # Should complete step_1, then cancel before step_2
        self.assertFalse(result.success)
        self.assertIn("Cancelled", result.error)
        self.assertEqual(result.completed_steps, 1)


if __name__ == "__main__":
    unittest.main()