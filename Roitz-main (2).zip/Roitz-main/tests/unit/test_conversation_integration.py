"""
End-to-End Integration Tests for ConversationStore Lifecycle.

These tests verify the integration points A-F as implemented in main.py:
- Test 1: End-to-End Reconnect Resume (criterion 5)
- Test 2: End-to-End Session Finalization (criterion 6)

Run with: py -m pytest tests/unit/test_conversation_integration.py -v
"""
import sys
import time
import json
import unittest
import gc
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from memory.conversation_store import ConversationStore
from memory.conversation_models import Conversation, Message


class TestEndToEndReconnectResume(unittest.TestCase):
    """
    Test criterion 5: Reconnect resumes same conversation.

    This simulates the Integration Point A logic from main.py:
    - First session: creates new conversation, stores messages
    - Reconnect: reuses existing conversation ID, verifies ended_at is None
    - Continues storing messages in same conversation
    """

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"

    def tearDown(self):
        # Windows file locking fix: allow time for handles to release
        time.sleep(0.2)
        gc.collect()
        self.temp_dir.cleanup()

    def test_reconnect_resumes_active_conversation(self):
        """
        Simulates: Session 1 creates conversation, adds messages.
        Reconnect (Session 2) resumes same conversation, adds more messages.
        """
        # ═══════════════════════════════════════════════════════════════════
        # SESSION 1: First connection - creates new conversation
        # ═══════════════════════════════════════════════════════════════════
        store1 = ConversationStore(self.db_path)

        # Integration Point A: Create new conversation (first session)
        conv = Conversation(
            title="",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
            meta_json=json.dumps({"resumed": "none"}),
        )
        created = store1.create_conversation(conv)
        conversation_id = created.id
        self.assertIsNotNone(conversation_id)

        # Integration Point B: Store user message
        msg1 = Message(
            conversation_id=conversation_id,
            role="user",
            content="Hello, how are you?",
            content_type="text",
            timestamp_ms=int(time.time() * 1000),
            meta_json=json.dumps({"source": "microphone"}),
        )
        store1.append_message(msg1)

        # Integration Point C: Store assistant message + update turn_count
        msg2 = Message(
            conversation_id=conversation_id,
            role="assistant",
            content="I'm doing well, thank you!",
            content_type="text",
            timestamp_ms=int(time.time() * 1000),
            meta_json=json.dumps({"source": "gemini_live"}),
        )
        store1.append_message(msg2)
        # Calculate turn_count: number of assistant messages
        messages = store1.get_messages(conversation_id)
        turn_count = sum(1 for m in messages if m.role == "assistant")
        # Update conversation with turn_count
        conv = store1.get_conversation(conversation_id)
        conv.turn_count = turn_count
        store1.update_conversation(conv)

        # Simulate session ending (but conversation NOT ended in DB)
        store1.close()

        # ═══════════════════════════════════════════════════════════════════
        # SESSION 2: Reconnect - should resume same conversation
        # ═══════════════════════════════════════════════════════════════════
        store2 = ConversationStore(self.db_path)

        # Integration Point A (reconnect path): Verify conversation exists and ended_at is None
        conv = store2.get_conversation(conversation_id)
        self.assertIsNotNone(conv, "Conversation should exist after reconnect")
        self.assertIsNone(conv.ended_at, "Conversation should not be ended")

        # Resume existing conversation - update engine/meta (as main.py does)
        conv.engine = "gemini_live"
        store2.update_conversation(conv)
        conv.meta_json = json.dumps({"resumed": "session_reconnect"})
        store2.update_conversation(conv)

        # Continue conversation - add more messages
        msg3 = Message(
            conversation_id=conversation_id,
            role="user",
            content="What's the weather like?",
            content_type="text",
            timestamp_ms=int(time.time() * 1000),
            meta_json=json.dumps({"source": "microphone"}),
        )
        store2.append_message(msg3)

        msg4 = Message(
            conversation_id=conversation_id,
            role="assistant",
            content="I don't have access to weather data.",
            content_type="text",
            timestamp_ms=int(time.time() * 1000),
            meta_json=json.dumps({"source": "gemini_live"}),
        )
        store2.append_message(msg4)
        # Calculate turn_count: number of assistant messages
        messages = store2.get_messages(conversation_id)
        turn_count = sum(1 for m in messages if m.role == "assistant")
        conv = store2.get_conversation(conversation_id)
        conv.turn_count = turn_count
        store2.update_conversation(conv)

        store2.close()

        # ═══════════════════════════════════════════════════════════════════
        # VERIFICATION: All messages in single conversation, correct sequence
        # ═══════════════════════════════════════════════════════════════════
        store3 = ConversationStore(self.db_path)

        # Verify single conversation row
        conv = store3.get_conversation(conversation_id)
        self.assertEqual(conv.id, conversation_id)
        self.assertIsNone(conv.ended_at)
        self.assertEqual(conv.turn_count, 2)  # 2 assistant messages = 2 turns

        # Verify all 4 messages in correct sequence
        messages = store3.get_messages(conversation_id)
        self.assertEqual(len(messages), 4)

        expected_content = [
            "Hello, how are you?",
            "I'm doing well, thank you!",
            "What's the weather like?",
            "I don't have access to weather data.",
        ]
        for i, (msg, expected) in enumerate(zip(messages, expected_content)):
            self.assertEqual(msg.sequence, i + 1)
            self.assertEqual(msg.content, expected)
            self.assertEqual(msg.conversation_id, conversation_id)

        # Verify roles alternate correctly
        self.assertEqual(messages[0].role, "user")
        self.assertEqual(messages[1].role, "assistant")
        self.assertEqual(messages[2].role, "user")
        self.assertEqual(messages[3].role, "assistant")

        store3.close()

    def test_reconnect_after_ended_conversation_creates_new(self):
        """
        Simulates: Session 1 creates conversation, ends it properly.
        Reconnect (Session 2) should create NEW conversation (not resume ended one).
        """
        # ═══════════════════════════════════════════════════════════════════
        # SESSION 1: Normal session that ends properly
        # ═══════════════════════════════════════════════════════════════════
        store1 = ConversationStore(self.db_path)

        conv = Conversation(
            title="",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
            meta_json=json.dumps({"resumed": "none"}),
        )
        created = store1.create_conversation(conv)
        conversation_id = created.id

        # Add 3 turns (>=3 so it would be finalized)
        for i in range(3):
            store1.append_message(Message(
                conversation_id=conversation_id,
                role="user",
                content=f"User message {i}",
                content_type="text",
                timestamp_ms=int(time.time() * 1000),
            ))
            store1.append_message(Message(
                conversation_id=conversation_id,
                role="assistant",
                content=f"Assistant reply {i}",
                content_type="text",
                timestamp_ms=int(time.time() * 1000),
            ))

        # Integration Point E: Finalize conversation (end_conversation)
        store1.finalize_conversation(
            conversation_id,
            summary="Test conversation ended",
            turn_count=3,
        )

        store1.close()

        # ═══════════════════════════════════════════════════════════════════
        # SESSION 2: Reconnect - should detect ended conversation and create NEW
        # ═══════════════════════════════════════════════════════════════════
        store2 = ConversationStore(self.db_path)

        # Integration Point A (reconnect path): Check ended_at
        conv = store2.get_conversation(conversation_id)
        self.assertIsNotNone(conv)
        self.assertIsNotNone(conv.ended_at, "Conversation should be ended")

        # main.py logic: if ended_at is not None, clear ID and create new
        # This simulates main.py lines 3009-3012
        self.assertIsNotNone(conv.ended_at)
        # In main.py: self._current_conversation_id = None; self._conv_store = None

        # Create NEW conversation (simulating main.py lines 3014-3025)
        new_conv = Conversation(
            title="",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
            meta_json=json.dumps({"resumed": "session_reconnect"}),
        )
        created = store2.create_conversation(new_conv)
        new_conversation_id = created.id

        # Verify it's a different conversation
        self.assertNotEqual(new_conversation_id, conversation_id)

        # Add message to new conversation
        store2.append_message(Message(
            conversation_id=new_conversation_id,
            role="user",
            content="New session message",
            content_type="text",
            timestamp_ms=int(time.time() * 1000),
        ))

        store2.close()

        # ═══════════════════════════════════════════════════════════════════
        # VERIFICATION: Two separate conversations
        # ═══════════════════════════════════════════════════════════════════
        store3 = ConversationStore(self.db_path)

        # Original conversation still exists and is ended
        old_conv = store3.get_conversation(conversation_id)
        self.assertIsNotNone(old_conv.ended_at)
        self.assertEqual(store3.get_message_count(conversation_id), 6)  # 3 turns = 6 messages

        # New conversation exists and is active
        new_conv = store3.get_conversation(new_conversation_id)
        self.assertIsNone(new_conv.ended_at)
        self.assertEqual(store3.get_message_count(new_conversation_id), 1)

        store3.close()


class TestEndToEndSessionFinalization(unittest.TestCase):
    """
    Test criterion 6: Session end calls end_conversation + save_session_summary.

    This simulates the Integration Point E logic from main.py:
    - Session with >= 3 turns ends
    - Conversation is finalized with summary
    - save_session_summary is called for backward compatibility
    - Turn count < 3: conversation persists but no summary (ended_at stays NULL)
    """

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        # Use a separate memory file for testing save_session_summary
        self.memory_dir = Path(self.temp_dir.name) / "memory"
        self.memory_dir.mkdir()
        self.memory_path = self.memory_dir / "long_term.json"

    def tearDown(self):
        # Windows file locking fix: allow time for handles to release
        time.sleep(0.2)
        gc.collect()
        self.temp_dir.cleanup()

    def _save_session_summary_for_test(self, summary: str, language: str = "") -> None:
        """Test version of save_session_summary that uses our temp memory file."""
        import json
        from datetime import datetime
        summary = (summary or "").strip()
        if not summary:
            return
        # Load existing memory
        if self.memory_path.exists():
            with open(self.memory_path, 'r', encoding='utf-8') as f:
                memory = json.load(f)
        else:
            memory = {
                "identity": {}, "preferences": {}, "projects": {},
                "relationships": {}, "wishes": {}, "notes": {}, "sessions": []
            }
        sessions = memory.get("sessions", [])
        if not isinstance(sessions, list):
            sessions = []
        entry = {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "summary": summary[:280],
        }
        if language:
            entry["language"] = language
        sessions.append(entry)
        memory["sessions"] = sessions[-3:]  # _SESSION_MAX = 3
        with open(self.memory_path, 'w', encoding='utf-8') as f:
            json.dump(memory, f, indent=2, ensure_ascii=False)

    def test_session_finalization_with_3_or_more_turns(self):
        """
        Session with >= 3 turns:
        - end_conversation called with summary and turn_count
        - save_session_summary called with summary and language
        - Conversation row gets ended_at and summary
        """
        store = ConversationStore(self.db_path)

        # Create conversation
        conv = Conversation(
            title="",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
            meta_json=json.dumps({"resumed": "none"}),
        )
        created = store.create_conversation(conv)
        conversation_id = created.id

        # Simulate 3 turns (6 messages: user + assistant x 3)
        test_messages = [
            ("user", "What time is it?"),
            ("assistant", "It's 3 PM."),
            ("user", "Thanks"),
            ("assistant", "You're welcome!"),
            ("user", "One more question"),
            ("assistant", "Sure, go ahead."),
        ]
        for role, content in test_messages:
            store.append_message(Message(
                conversation_id=conversation_id,
                role=role,
                content=content,
                content_type="text",
                timestamp_ms=int(time.time() * 1000),
            ))

        # Get turn count (should be 3)
        messages = store.get_messages(conversation_id)
        turn_count = sum(1 for m in messages if m.role == "assistant")
        self.assertEqual(turn_count, 3)

        # ═══════════════════════════════════════════════════════════════════
        # Integration Point E: Session End Finalization (simulated)
        # ═══════════════════════════════════════════════════════════════════
        # Generate summary from stored messages (as main.py does)
        messages = store.get_messages(conversation_id, limit=40)
        convo_text = "\n".join(f"{m.role}: {m.content}" for m in messages)

        # Simulate summary generation (normally done by gemini)
        summary = "User asked about time, said thanks, and had one more question."
        language = "English"

        # Call end_conversation (Integration Point E)
        finalized = store.finalize_conversation(
            conversation_id,
            summary=summary,
            turn_count=turn_count,
        )

        # Call save_session_summary for backward compatibility (Integration Point E)
        self._save_session_summary_for_test(summary, language)

        # ═══════════════════════════════════════════════════════════════════
        # VERIFICATION
        # ═══════════════════════════════════════════════════════════════════
        # Verify conversation finalized in SQLite
        conv = store.get_conversation(conversation_id)
        self.assertIsNotNone(conv.ended_at, "ended_at should be set")
        self.assertEqual(conv.summary, summary)
        self.assertEqual(conv.turn_count, 3)

        # Verify messages still accessible
        messages = store.get_messages(conversation_id)
        self.assertEqual(len(messages), 6)

        # Verify save_session_summary wrote to long_term.json
        self.assertTrue(self.memory_path.exists())
        with open(self.memory_path, 'r', encoding='utf-8') as f:
            memory = json.load(f)
        sessions = memory.get("sessions", [])
        self.assertEqual(len(sessions), 1)
        self.assertEqual(sessions[0]["summary"], summary)
        self.assertEqual(sessions[0]["language"], language)
        self.assertEqual(sessions[0]["date"], time.strftime("%Y-%m-%d"))

        store.close()

    def test_session_finalization_less_than_3_turns_no_summary(self):
        """
        Session with < 3 turns:
        - end_conversation NOT called
        - Conversation row persists with ended_at=NULL (no summary)
        - save_session_summary NOT called
        """
        store = ConversationStore(self.db_path)

        # Create conversation
        conv = Conversation(
            title="",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
            meta_json=json.dumps({"resumed": "none"}),
        )
        created = store.create_conversation(conv)
        conversation_id = created.id

        # Simulate only 2 turns (4 messages)
        test_messages = [
            ("user", "Hi"),
            ("assistant", "Hello!"),
            ("user", "Bye"),
            ("assistant", "Goodbye!"),
        ]
        for role, content in test_messages:
            store.append_message(Message(
                conversation_id=conversation_id,
                role=role,
                content=content,
                content_type="text",
                timestamp_ms=int(time.time() * 1000),
            ))

        messages = store.get_messages(conversation_id)
        turn_count = sum(1 for m in messages if m.role == "assistant")
        self.assertEqual(turn_count, 2)  # Less than 3

        # Update conversation turn_count (as main.py does in Integration Point C)
        conv = store.get_conversation(conversation_id)
        conv.turn_count = turn_count
        store.update_conversation(conv)

        # ═══════════════════════════════════════════════════════════════════
        # Integration Point E: Session End - but turn_count < 3
        # Per main.py:3216-3217: if turn_count >= 3:
        # ═══════════════════════════════════════════════════════════════════
        # Do NOT call end_conversation
        # Do NOT call save_session_summary
        # Just reset _current_conversation_id and _conv_store

        # ═══════════════════════════════════════════════════════════════════
        # VERIFICATION
        # ═══════════════════════════════════════════════════════════════════
        # Conversation should persist but NOT be ended
        conv = store.get_conversation(conversation_id)
        self.assertIsNone(conv.ended_at, "ended_at should be NULL for < 3 turns")
        self.assertIsNone(conv.summary, "summary should be NULL for < 3 turns")
        self.assertEqual(conv.turn_count, 2)

        # Messages still there
        messages = store.get_messages(conversation_id)
        self.assertEqual(len(messages), 4)

        # long_term.json should NOT have new session entry
        self.assertFalse(self.memory_path.exists(), "long_term.json should not be created")

        store.close()

    def test_session_finalization_generates_summary_from_stored_messages(self):
        """
        Verify summary is generated from SQLite messages, not _session_log.
        This tests the specific behavior in main.py:3219-3225.
        """
        store = ConversationStore(self.db_path)

        conv = Conversation(
            title="",
            started_at=int(time.time() * 1000),
            engine="pipeline",  # Different engine
            meta_json=json.dumps({"resumed": "none"}),
        )
        created = store.create_conversation(conv)
        conversation_id = created.id

        # Add messages with specific content that would appear in summary
        store.append_message(Message(
            conversation_id=conversation_id,
            role="user",
            content="I want to learn Python programming",
            content_type="text",
            timestamp_ms=int(time.time() * 1000),
        ))
        store.append_message(Message(
            conversation_id=conversation_id,
            role="assistant",
            content="Great! Python is a versatile language. Start with basics.",
            content_type="text",
            timestamp_ms=int(time.time() * 1000),
        ))
        store.append_message(Message(
            conversation_id=conversation_id,
            role="user",
            content="What are variables?",
            content_type="text",
            timestamp_ms=int(time.time() * 1000),
        ))
        store.append_message(Message(
            conversation_id=conversation_id,
            role="assistant",
            content="Variables store data. In Python: x = 5",
            content_type="text",
            timestamp_ms=int(time.time() * 1000),
        ))

        messages = store.get_messages(conversation_id)
        turn_count = sum(1 for m in messages if m.role == "assistant")
        self.assertEqual(turn_count, 2)

        # Get messages for summary generation (as main.py does)
        messages = store.get_messages(conversation_id, limit=40)
        convo_text = "\n".join(f"{m.role}: {m.content}" for m in messages)

        # Verify the conversation text contains all messages in order
        self.assertIn("I want to learn Python programming", convo_text)
        self.assertIn("Variables store data", convo_text)
        self.assertIn("user: I want to learn Python programming", convo_text)
        self.assertIn("assistant: Variables store data", convo_text)

        # Simulate summary generation and finalization
        summary = "User learned Python basics including variables."
        language = "English"

        store.finalize_conversation(conversation_id, summary=summary, turn_count=turn_count)
        self._save_session_summary_for_test(summary, language)

        # Verify
        conv = store.get_conversation(conversation_id)
        self.assertEqual(conv.summary, summary)
        self.assertEqual(conv.engine, "pipeline")
        self.assertIsNotNone(conv.ended_at)

        store.close()


class TestIntegrationErrorHandling(unittest.TestCase):
    """
    Test that integration handles database failures gracefully (degraded mode).
    Per main.py: errors caught and logged, session continues in-memory.
    """

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"

    def tearDown(self):
        # Windows file locking fix: allow time for handles to release
        time.sleep(0.2)
        gc.collect()
        self.temp_dir.cleanup()

    def test_store_failure_during_message_add_continues_in_memory(self):
        """
        If ConversationStore.add_message fails, session should continue.
        This simulates the try/except in main.py:2178-2191 and 2212-2232.
        """
        store = ConversationStore(self.db_path)

        conv = Conversation(
            title="",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
        )
        created = store.create_conversation(conv)
        conversation_id = created.id

        # Normal message add works
        msg1 = Message(
            conversation_id=conversation_id,
            role="user",
            content="Test message",
            content_type="text",
            timestamp_ms=int(time.time() * 1000),
        )
        store.append_message(msg1)
        self.assertEqual(store.get_message_count(conversation_id), 1)

        # Simulate store failure by closing it
        store.close()

        # In main.py, the try/except catches the error and continues
        # Here we verify that a new store can be created and works
        store2 = ConversationStore(self.db_path)
        msg2 = Message(
            conversation_id=conversation_id,
            role="assistant",
            content="Test reply",
            content_type="text",
            timestamp_ms=int(time.time() * 1000),
        )
        store2.append_message(msg2)
        self.assertEqual(store2.get_message_count(conversation_id), 2)

        store2.close()


if __name__ == "__main__":
    unittest.main()