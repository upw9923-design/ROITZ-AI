"""
Unit tests for Phase 2: Operation Metadata (idempotent, read_only, resource_scope).
Tests the new fields on OperationSpec and their integration with TaskRecovery.
"""
import sys
import threading
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.permission_guard import (
    OperationSpec,
    OPERATION_SPECS,
    ResourceScope,
    get_permission_guard,
)
from core.task_monitoring import TaskRecovery, MAX_RETRIES
from core.autonomous_agent import TaskStep, TaskPlan, StepState, Executor
from core.error_classification import ErrorClass, ClassifiedError, classify_error
from unittest.mock import Mock, patch


class TestOperationMetadataDefaults(unittest.TestCase):
    """Test that OperationSpec has correct default values for new fields."""

    def test_operation_spec_defaults(self):
        """New fields should have sensible defaults when not explicitly set."""
        spec = OperationSpec("fs.read")
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_FILE)

    def test_operation_spec_explicit_values(self):
        """Explicit values should be preserved."""
        spec = OperationSpec(
            "fs.write",
            idempotent=True,
            read_only=False,
            resource_scope=ResourceScope.USER_PROFILE,
        )
        self.assertTrue(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.USER_PROFILE)


class TestVerifiedOperationsMetadata(unittest.TestCase):
    """Test that all 56 operations have correct metadata populated."""

    def test_all_operations_have_metadata(self):
        """Every entry in OPERATION_SPECS should have all three new fields set."""
        for op_name, spec in OPERATION_SPECS.items():
            with self.subTest(operation=op_name):
                # idempotent must be explicitly set (not default)
                self.assertIn(type(spec.idempotent), (bool,))
                # read_only must be explicitly set
                self.assertIn(type(spec.read_only), (bool,))
                # resource_scope must be explicitly set (not default LOCAL_FILE)
                self.assertIsInstance(spec.resource_scope, ResourceScope)

    def test_file_controller_metadata(self):
        """file_controller operations should have correct classifications."""
        # Read operations: idempotent, read_only, LOCAL_FILE
        for op in ["file_controller:list", "file_controller:read", "file_controller:find"]:
            spec = OPERATION_SPECS[op]
            self.assertTrue(spec.idempotent, f"{op} should be idempotent")
            self.assertTrue(spec.read_only, f"{op} should be read_only")
            self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_FILE)

        # Write operations: NOT idempotent (create/overwrite has side effects), not read_only, LOCAL_FILE
        for op in ["file_controller:create_file", "file_controller:write", "file_controller:copy"]:
            spec = OPERATION_SPECS[op]
            self.assertFalse(spec.idempotent, f"{op} should not be idempotent")
            self.assertFalse(spec.read_only, f"{op} should not be read_only")
            self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_FILE)

        # Mutating operations: not idempotent, not read_only, LOCAL_FILE
        for op in ["file_controller:delete", "file_controller:move", "file_controller:rename", "file_controller:organize_desktop"]:
            spec = OPERATION_SPECS[op]
            self.assertFalse(spec.idempotent, f"{op} should not be idempotent")
            self.assertFalse(spec.read_only, f"{op} should not be read_only")
            self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_FILE)

    def test_computer_control_metadata(self):
        """computer_control operations should have correct classifications."""
        # Input simulation: not idempotent, not read_only, LOCAL_SYSTEM
        for op in ["computer_control:type", "computer_control:click", "computer_control:hotkey"]:
            spec = OPERATION_SPECS[op]
            self.assertFalse(spec.idempotent, f"{op} should not be idempotent")
            self.assertFalse(spec.read_only, f"{op} should not be read_only")
            self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)

        # Screen capture (read): idempotent, read_only, LOCAL_SYSTEM
        spec = OPERATION_SPECS["computer_control:screen_find"]
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)

        # Screen click: not idempotent (clicks), not read_only, LOCAL_SYSTEM
        spec = OPERATION_SPECS["computer_control:screen_click"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)

        # Screenshot: idempotent, read_only, LOCAL_SYSTEM
        spec = OPERATION_SPECS["computer_control:screenshot"]
        self.assertTrue(spec.idempotent, "computer_control:screenshot should be idempotent")
        self.assertTrue(spec.read_only, "computer_control:screenshot should be read_only")
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        self.assertEqual(spec.capability, "screen.capture")

        # Close app: not idempotent, not read_only, LOCAL_SYSTEM, requires app.manage capability
        spec = OPERATION_SPECS["computer_control:close_app"]
        self.assertFalse(spec.idempotent, "computer_control:close_app should not be idempotent")
        self.assertFalse(spec.read_only, "computer_control:close_app should not be read_only")
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        self.assertEqual(spec.capability, "app.manage")

        # Focus window: not idempotent, not read_only, LOCAL_SYSTEM, requires app.manage capability
        spec = OPERATION_SPECS["computer_control:focus_window"]
        self.assertFalse(spec.idempotent, "computer_control:focus_window should not be idempotent")
        self.assertFalse(spec.read_only, "computer_control:focus_window should not be read_only")
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        self.assertEqual(spec.capability, "app.manage")

    def test_browser_control_metadata(self):
        """browser_control operations should have correct classifications."""
        # Navigation actions: NOT idempotent (can trigger server-side effects), not read_only, NETWORK_EGRESS
        for action in ("go_to", "search", "new_tab", "back", "forward", "reload"):
            spec = OPERATION_SPECS[f"browser_control:{action}"]
            self.assertFalse(spec.idempotent, f"browser_control:{action} should not be idempotent")
            self.assertFalse(spec.read_only, f"browser_control:{action} should not be read_only")
            self.assertEqual(spec.resource_scope, ResourceScope.NETWORK_EGRESS, f"browser_control:{action} should be NETWORK_EGRESS")
            self.assertEqual(spec.capability, "browser.navigate", f"browser_control:{action} should have browser.navigate capability")

        # Interactive page actions: not idempotent, not read_only, LOCAL_SYSTEM
        for action in ("click", "type", "scroll", "fill_form", "smart_click", "smart_type", "press", "close_tab"):
            spec = OPERATION_SPECS[f"browser_control:{action}"]
            self.assertFalse(spec.idempotent, f"browser_control:{action} should not be idempotent")
            self.assertFalse(spec.read_only, f"browser_control:{action} should not be read_only")
            self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM, f"browser_control:{action} should be LOCAL_SYSTEM")
            self.assertEqual(spec.capability, "browser.interact", f"browser_control:{action} should have browser.interact capability")

        # Read-only page actions
        spec = OPERATION_SPECS["browser_control:screenshot"]
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        self.assertEqual(spec.capability, "screen.capture")

        spec = OPERATION_SPECS["browser_control:get_text"]
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        self.assertEqual(spec.capability, "browser.read")

        spec = OPERATION_SPECS["browser_control:get_url"]
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        self.assertEqual(spec.capability, "browser.read")

        # Session management
        for action in ("switch", "close", "close_all"):
            spec = OPERATION_SPECS[f"browser_control:{action}"]
            self.assertFalse(spec.idempotent, f"browser_control:{action} should not be idempotent")
            self.assertFalse(spec.read_only, f"browser_control:{action} should not be read_only")
            self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
            self.assertEqual(spec.capability, "browser.manage")

        spec = OPERATION_SPECS["browser_control:list_browsers"]
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        self.assertEqual(spec.capability, "browser.read")

    def test_dev_agent_metadata(self):
        """dev_agent operations should have correct classifications."""
        # improve: modifies existing folder (writes files, runs tests, subprocesses) - not idempotent, not read_only, LOCAL_SYSTEM
        # Uses subprocesses for pip install, running tests, etc. -> needs proc.exec + net.egress
        spec = OPERATION_SPECS["dev_agent:improve"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        self.assertIn("proc.exec", spec.additional_caps)
        self.assertIn("net.egress", spec.additional_caps)

        # build: creates new project (writes files, runs commands, installs packages, opens VSCode)
        # Uses subprocesses + app.manage (opens VSCode) -> needs proc.exec + net.egress + app.manage
        spec = OPERATION_SPECS["dev_agent:build"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        # build also needs proc.exec, net.egress, and app.manage capabilities
        self.assertIn("proc.exec", spec.additional_caps)
        self.assertIn("net.egress", spec.additional_caps)
        self.assertIn("app.manage", spec.additional_caps)

        # status: reads job state - idempotent, read_only, LOCAL_FILE
        spec = OPERATION_SPECS["dev_agent:status"]
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_FILE)

    def test_send_message_metadata(self):
        """send_message operations should have correct classifications."""
        # WhatsApp: verified driver path (REMOTE_SERVICE)
        spec = OPERATION_SPECS["send_message:whatsapp"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.REMOTE_SERVICE)
        self.assertEqual(spec.capability, "messaging.send")

        # Telegram: desktop_send (pyautogui + app launch) -> LOCAL_SYSTEM
        spec = OPERATION_SPECS["send_message:telegram"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        self.assertEqual(spec.capability, "messaging.send")
        self.assertIn("input.simulate", spec.additional_caps)
        self.assertIn("app.manage", spec.additional_caps)

        # Instagram: browser + pyautogui -> REMOTE_SERVICE with net.egress + input.simulate
        spec = OPERATION_SPECS["send_message:instagram"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.REMOTE_SERVICE)
        self.assertEqual(spec.capability, "messaging.send")
        self.assertIn("net.egress", spec.additional_caps)
        self.assertIn("input.simulate", spec.additional_caps)

        # Signal: desktop_send -> LOCAL_SYSTEM
        spec = OPERATION_SPECS["send_message:signal"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        self.assertEqual(spec.capability, "messaging.send")
        self.assertIn("input.simulate", spec.additional_caps)
        self.assertIn("app.manage", spec.additional_caps)

        # Discord: desktop_send -> LOCAL_SYSTEM
        spec = OPERATION_SPECS["send_message:discord"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)
        self.assertEqual(spec.capability, "messaging.send")
        self.assertIn("input.simulate", spec.additional_caps)
        self.assertIn("app.manage", spec.additional_caps)

        # Messenger: browser + pyautogui -> REMOTE_SERVICE
        spec = OPERATION_SPECS["send_message:messenger"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.REMOTE_SERVICE)
        self.assertEqual(spec.capability, "messaging.send")
        self.assertIn("net.egress", spec.additional_caps)
        self.assertIn("input.simulate", spec.additional_caps)

    def test_screen_processor_metadata(self):
        """screen_processor operations should be read-only captures."""
        for op in ["screen_process:screen", "screen_process:camera"]:
            spec = OPERATION_SPECS[op]
            self.assertTrue(spec.idempotent, f"{op} should be idempotent")
            self.assertTrue(spec.read_only, f"{op} should be read_only")
            self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_SYSTEM)

    def test_telegram_bot_metadata(self):
        """telegram_bot operations should have correct classifications."""
        # Command execution: not idempotent, not read_only, REMOTE_SERVICE
        spec = OPERATION_SPECS["telegram_bot:command"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.REMOTE_SERVICE)

        # Polling: idempotent (GET), read_only, NETWORK_EGRESS
        spec = OPERATION_SPECS["telegram_bot:poll"]
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.NETWORK_EGRESS)

        # Send: not idempotent, not read_only, REMOTE_SERVICE
        spec = OPERATION_SPECS["telegram_bot:send"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.REMOTE_SERVICE)

        # Management actions
        spec = OPERATION_SPECS["telegram_bot:configure"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.USER_PROFILE)

        spec = OPERATION_SPECS["telegram_bot:pair"]
        self.assertTrue(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.USER_PROFILE)

        spec = OPERATION_SPECS["telegram_bot:unpair"]
        self.assertTrue(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.USER_PROFILE)

        spec = OPERATION_SPECS["telegram_bot:status"]
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.USER_PROFILE)

        spec = OPERATION_SPECS["telegram_bot:start_polling"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.NETWORK_EGRESS)

        spec = OPERATION_SPECS["telegram_bot:stop_polling"]
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.NETWORK_EGRESS)


class TestUnknownOperationBehavior(unittest.TestCase):
    """Test behavior when operation is not in OPERATION_SPECS."""

    def test_unknown_operation_defaults_to_non_idempotent(self):
        """Unknown operations should be treated as non-idempotent (conservative)."""
        # This is tested via TaskRecovery.handle_failure receiving no spec
        step = TaskStep(id="s1", description="test", tool="unknown_tool")
        step.retry_count = 0

        # When no spec is found, is_idempotent defaults to False in Executor
        # Verify the logic in _get_operation_name returns None for unknown tools
        from core.autonomous_agent import Executor
        from core.action_loader import ActionRegistry
        from core.plugin_loader import PluginRegistry

        executor = Executor(ActionRegistry({}, lambda _: None), PluginRegistry({}, lambda _: None))
        op_name = executor._get_operation_name("unknown_tool", {"action": "foo"})
        self.assertIsNone(op_name)

        # TaskRecovery.handle_failure with is_idempotent=False should not retry NON_IDEMPOTENT_TIMEOUT
        classified = ClassifiedError(
            error_class=ErrorClass.NON_IDEMPOTENT_TIMEOUT,
            reason="test",
        )
        self.assertFalse(TaskRecovery.handle_failure(step, classified, is_idempotent=False))
        self.assertTrue(TaskRecovery.handle_failure(step, classified, is_idempotent=True))


class TestIdempotentVsNonIdempotentRetry(unittest.TestCase):
    """Test that idempotent flag correctly controls retry eligibility for NON_IDEMPOTENT_TIMEOUT."""

    def test_non_idempotent_timeout_not_retried_when_false(self):
        """NON_IDEMPOTENT_TIMEOUT should not retry when is_idempotent=False."""
        step = TaskStep(id="s1", description="test", tool="file_controller")
        step.retry_count = 0

        classified = ClassifiedError(
            error_class=ErrorClass.NON_IDEMPOTENT_TIMEOUT,
            reason="timeout on non-idempotent operation",
        )

        # is_idempotent=False (default for unknown/conservative)
        self.assertFalse(TaskRecovery.handle_failure(step, classified, is_idempotent=False))

    def test_non_idempotent_timeout_retried_when_true(self):
        """NON_IDEMPOTENT_TIMEOUT should retry when is_idempotent=True."""
        step = TaskStep(id="s1", description="test", tool="file_controller")
        step.retry_count = 0

        classified = ClassifiedError(
            error_class=ErrorClass.NON_IDEMPOTENT_TIMEOUT,
            reason="timeout on idempotent operation",
        )

        # is_idempotent=True (e.g., file_controller:write)
        self.assertTrue(TaskRecovery.handle_failure(step, classified, is_idempotent=True))

    def test_recoverable_errors_retry_regardless_of_idempotent(self):
        """RECOVERABLE errors should retry regardless of idempotent flag."""
        step = TaskStep(id="s1", description="test", tool="file_controller")
        step.retry_count = 0

        classified = ClassifiedError(
            error_class=ErrorClass.RECOVERABLE,
            reason="connection reset",
        )

        self.assertTrue(TaskRecovery.handle_failure(step, classified, is_idempotent=False))
        self.assertTrue(TaskRecovery.handle_failure(step, classified, is_idempotent=True))

    def test_fatal_errors_never_retry(self):
        """FATAL errors should never retry regardless of idempotent flag."""
        step = TaskStep(id="s1", description="test", tool="file_controller")
        step.retry_count = 0

        classified = ClassifiedError(
            error_class=ErrorClass.FATAL,
            reason="permission denied",
        )

        self.assertFalse(TaskRecovery.handle_failure(step, classified, is_idempotent=False))
        self.assertFalse(TaskRecovery.handle_failure(step, classified, is_idempotent=True))


class TestReadOnlyOperations(unittest.TestCase):
    """Test read_only metadata classification."""

    def test_read_only_operations_identified(self):
        """Operations marked read_only should be correctly identified."""
        read_only_ops = [
            "file_controller:list",
            "file_controller:read",
            "file_controller:find",
            "computer_control:screen_find",
            "browser_control:screenshot",
            "screen_process:screen",
            "screen_process:camera",
            "telegram_bot:poll",
            "telegram_bot:status",
        ]

        for op in read_only_ops:
            spec = OPERATION_SPECS[op]
            self.assertTrue(spec.read_only, f"{op} should be read_only")

    def test_write_operations_not_read_only(self):
        """Operations that mutate state should not be read_only."""
        write_ops = [
            "file_controller:create_file",
            "file_controller:write",
            "file_controller:delete",
            "file_controller:move",
            "file_controller:copy",
            "file_controller:rename",
            "computer_control:type",
            "computer_control:click",
            "send_message:whatsapp",
            "telegram_bot:command",
        ]

        for op in write_ops:
            spec = OPERATION_SPECS[op]
            self.assertFalse(spec.read_only, f"{op} should not be read_only")


class TestMultipleResourceScopes(unittest.TestCase):
    """Test that all 5 resource scopes are represented."""

    def test_all_resource_scopes_used(self):
        """All 5 ResourceScope values should be used in OPERATION_SPECS."""
        scopes_found = set()
        for spec in OPERATION_SPECS.values():
            scopes_found.add(spec.resource_scope)

        expected_scopes = {
            ResourceScope.LOCAL_FILE,
            ResourceScope.LOCAL_SYSTEM,
            ResourceScope.NETWORK_EGRESS,
            ResourceScope.USER_PROFILE,
            ResourceScope.REMOTE_SERVICE,
        }

        self.assertEqual(scopes_found, expected_scopes)

    def test_scope_distribution(self):
        """Verify reasonable distribution of operations across scopes."""
        scope_counts = {}
        for spec in OPERATION_SPECS.values():
            scope_counts[spec.resource_scope] = scope_counts.get(spec.resource_scope, 0) + 1

        # Each scope should have at least 2 operations
        for scope, count in scope_counts.items():
            self.assertGreaterEqual(count, 2, f"Scope {scope} should have at least 2 operations")

    def test_app_manage_capability_exists(self):
        """app.manage capability should exist in CAPABILITIES."""
        from core.permission_manager import CAPABILITIES
        self.assertIn("app.manage", CAPABILITIES)
        self.assertEqual(CAPABILITIES["app.manage"]["risk"], "high")

    def test_app_manage_in_owner_approval_required(self):
        """app.manage should be in OWNER_APPROVAL_REQUIRED."""
        from core.permission_manager import OWNER_APPROVAL_REQUIRED
        self.assertIn("app.manage", OWNER_APPROVAL_REQUIRED)

    def test_app_manage_not_in_auto_allow(self):
        """app.manage should NOT be in AUTO_ALLOW."""
        from core.permission_manager import AUTO_ALLOW
        self.assertNotIn("app.manage", AUTO_ALLOW)


class TestBackwardCompatibility(unittest.TestCase):
    """Test that existing code without metadata continues to work."""

    def test_existing_permission_guard_check_works(self):
        """PermissionGuard.check_operation should work unchanged."""
        guard = get_permission_guard()
        guard.initialize()

        # Test a known operation
        result = guard.check_operation("file_controller:read", {"path": "desktop"})
        # Should not crash - may be allowed or require approval depending on config
        self.assertIsNotNone(result)

    def test_existing_requires_confirmation_helper_works(self):
        """requires_confirmation_for_tool should work unchanged."""
        from core.autonomous_agent import requires_confirmation_for_tool

        # fs.delete requires confirmation
        self.assertTrue(requires_confirmation_for_tool("file_controller", {"action": "delete"}))
        # fs.read does not
        self.assertFalse(requires_confirmation_for_tool("file_controller", {"action": "list"}))

    def test_operation_spec_creation_without_new_fields(self):
        """Creating OperationSpec without new fields should use defaults."""
        spec = OperationSpec("fs.read", template_id="test_template")
        self.assertEqual(spec.template_id, "test_template")
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope, ResourceScope.LOCAL_FILE)


class TestExecutorIntegration(unittest.TestCase):
    """Test that Executor correctly uses metadata for retry decisions."""

    @patch("core.autonomous_agent.get_permission_guard")
    def test_idempotent_operation_retries_on_timeout(self, mock_get_guard):
        """Idempotent operations should retry on timeout (NON_IDEMPOTENT_TIMEOUT)."""
        mock_guard = Mock()
        mock_guard.initialize.return_value = None
        mock_guard.check_operation.return_value = Mock(allowed=True)
        mock_get_guard.return_value = mock_guard

        from core.autonomous_agent import ActionRegistry, PluginRegistry
        from core.task_monitoring import STEP_TIMEOUT

        # Create a slow action that times out first, then succeeds
        calls = {"count": 0}

        class SlowActionRegistry:
            def has(self, name): return True

            def run(self, name, params, ctx):
                calls["count"] += 1
                if calls["count"] == 1:
                    # First call - simulate timeout by raising
                    raise TimeoutError("Simulated timeout")
                return "Success on retry"

        executor = Executor(SlowActionRegistry(), PluginRegistry({}, lambda _: None))
        plan = TaskPlan(
            task_id="t1",
            goal="Test idempotent retry",
            steps=[TaskStep(id="s1", description="Read file", tool="file_controller", parameters={"action": "read"})]
        )

        result = executor.execute(plan)
        # Should have retried (file_controller:read is idempotent=True)
        self.assertTrue(result.success)
        self.assertEqual(calls["count"], 2)
        self.assertEqual(plan.steps[0].retry_count, 1)

    @patch("core.autonomous_agent.get_permission_guard")
    def test_non_idempotent_operation_does_not_retry_on_timeout(self, mock_get_guard):
        """Non-idempotent operations should NOT retry on timeout."""
        mock_guard = Mock()
        mock_guard.initialize.return_value = None
        mock_guard.check_operation.return_value = Mock(allowed=True)
        mock_get_guard.return_value = mock_guard

        from core.autonomous_agent import ActionRegistry, PluginRegistry

        # Create a slow action that times out
        class SlowActionRegistry:
            def has(self, name): return True

            def run(self, name, params, ctx):
                raise TimeoutError("Simulated timeout")

        executor = Executor(SlowActionRegistry(), PluginRegistry({}, lambda _: None))
        plan = TaskPlan(
            task_id="t2",
            goal="Test non-idempotent no retry",
            steps=[TaskStep(id="s1", description="Delete file", tool="file_controller", parameters={"action": "delete"})]
        )

        result = executor.execute(plan)
        # Should NOT have retried (file_controller:delete is idempotent=False)
        self.assertFalse(result.success)
        self.assertEqual(plan.steps[0].retry_count, 0)
        self.assertIn("timeout", result.error.lower())


if __name__ == "__main__":
    unittest.main()