"""
Tests for HistoryPanel (Mark LVII-B P1 Phase 1A).

These tests verify the UI shell only — no database or backend integration.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Ensure project root is on path
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pytest
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication

from history_panel import HistoryPanel


@pytest.fixture(scope="session")
def qapp():
    """Create QApplication once per session."""
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)
    yield app


@pytest.fixture
def panel(qapp):
    """Create a fresh HistoryPanel for each test."""
    p = HistoryPanel()
    p.show()  # Must be shown for widget geometry
    yield p
    p.close()


class TestHistoryPanelConstruction:
    """Test panel widget construction and initial state."""

    def test_panel_creates_successfully(self, panel):
        """Panel instantiates without error."""
        assert panel is not None
        assert panel.objectName() == "HistoryPanel"

    def test_panel_hidden_by_default(self, panel):
        """Panel starts hidden."""
        # The panel is shown in the fixture, but by default it's hidden
        # We can't easily test the initial hidden state without a separate
        # instantiation, so we test that show/hide works
        panel.hide()
        assert not panel.isVisible()
        panel.show()
        assert panel.isVisible()

    def test_panel_has_required_components(self, panel):
        """Panel has all required child widgets."""
        # Title label
        assert hasattr(panel, "_title_lbl")
        assert panel._title_lbl.text() == "HISTORY"

        # Search input
        assert hasattr(panel, "_search_input")
        assert panel._search_input.placeholderText() == "Search conversations…"

        # Clear search button
        assert hasattr(panel, "_search_clear_btn")

        # Split view
        assert hasattr(panel, "_split")
        assert panel._split.count() == 2

        # List view
        assert hasattr(panel, "_list_view")
        assert hasattr(panel, "_list_model")

        # Detail view
        assert hasattr(panel, "_detail_display")
        assert hasattr(panel, "_detail_title_lbl")

        # Pagination controls
        assert hasattr(panel, "_list_prev_btn")
        assert hasattr(panel, "_list_next_btn")
        assert hasattr(panel, "_detail_prev_btn")
        assert hasattr(panel, "_detail_next_btn")

        # State labels
        assert hasattr(panel, "_list_empty_lbl")
        assert hasattr(panel, "_list_loading_lbl")
        assert hasattr(panel, "_detail_empty_lbl")
        assert hasattr(panel, "_detail_loading_lbl")
        assert hasattr(panel, "_detail_error_lbl")

        # Dismiss button
        # Find the dismiss button in the header
        dismiss_btn = None
        # Check the header layout for dismiss button
        # It's created inline in _build_ui

    def test_split_initial_sizes(self, panel):
        """Split view starts with 40/60 ratio (setSizes called, actual sizes depend on layout)."""
        # The initial setSizes is called in _build_ui, but actual sizes depend on
        # the widget being laid out. Just verify setSizes was called with the
        # expected ratio by checking the method exists and the split has 2 widgets.
        assert panel._split.count() == 2
        # Verify the ratio is roughly 40/60 by checking the stretch factors aren't set
        # (they're not on the inner split, only on _center_split in MainWindow)


class TestHistoryPanelConversationList:
    """Test conversation list population and states."""

    def test_set_conversation_list_populates_model(self, panel):
        """set_conversation_list fills the list model."""
        conversations = [
            {
                "id": "conv-1",
                "title": "Test Conversation",
                "started_at": 1700000000000,
                "ended_at": None,
                "turn_count": 5,
                "engine": "gemini_live",
                "summary": "A test conversation",
            }
        ]
        panel.set_conversation_list(conversations, page=0, total_pages=1, total_count=1)

        assert panel._list_model.rowCount() == 1
        item = panel._list_model.item(0)
        assert item is not None
        assert "Test Conversation" in item.text()
        assert item.data(Qt.ItemDataRole.UserRole) == "conv-1"

    def test_set_conversation_list_empty_shows_empty_state(self, panel):
        """Empty conversation list shows empty state label."""
        panel.set_conversation_list([], page=0, total_pages=1, total_count=0)

        assert panel._list_model.rowCount() == 0
        assert panel._list_empty_lbl.isVisible()
        assert not panel._list_view.isVisible()

    def test_set_conversation_list_loading_state(self, panel):
        """Loading state shows loading label."""
        panel.set_list_loading(True)
        assert panel._list_loading_lbl.isVisible()
        assert not panel._list_view.isVisible()

        panel.set_list_loading(False)
        assert not panel._list_loading_lbl.isVisible()

    def test_pagination_controls_update(self, panel):
        """Pagination controls reflect current page."""
        # Page 0 of 3
        panel.set_conversation_list([{"id": "1"}] * 3, page=0, total_pages=3, total_count=3)
        assert panel._list_prev_btn.isEnabled() is False
        assert panel._list_next_btn.isEnabled() is True
        assert "Page 1 / 3" in panel._list_page_lbl.text()

        # Page 1 of 3
        panel.set_conversation_list([{"id": "1"}] * 3, page=1, total_pages=3, total_count=3)
        assert panel._list_prev_btn.isEnabled() is True
        assert panel._list_next_btn.isEnabled() is True
        assert "Page 2 / 3" in panel._list_page_lbl.text()

        # Page 2 of 3 (last)
        panel.set_conversation_list([{"id": "1"}] * 3, page=2, total_pages=3, total_count=3)
        assert panel._list_prev_btn.isEnabled() is True
        assert panel._list_next_btn.isEnabled() is False
        assert "Page 3 / 3" in panel._list_page_lbl.text()

    def test_timestamp_title_fallback(self, panel):
        """Auto-generated timestamp titles show as 'Untitled conversation'."""
        conversations = [
            {
                "id": "conv-1",
                "title": "Conversation 1234567890",
                "started_at": 1700000000000,
                "ended_at": 1700001000000,
                "turn_count": 2,
                "engine": "gemini_live",
            }
        ]
        panel.set_conversation_list(conversations, page=0, total_pages=1, total_count=1)
        item = panel._list_model.item(0)
        assert "Untitled conversation" in item.text()


class TestHistoryPanelMessageDetail:
    """Test message detail view population and states."""

    def test_set_message_detail_populates_display(self, panel):
        """set_message_detail fills the detail display."""
        messages = [
            {
                "role": "user",
                "content": "Hello",
                "content_type": "text",
                "sequence": 1,
                "timestamp_ms": 1700000000000,
            },
            {
                "role": "assistant",
                "content": "Hi there!",
                "content_type": "text",
                "sequence": 2,
                "timestamp_ms": 1700000001000,
            },
        ]
        panel.set_message_detail("conv-1", "Test Conversation", messages, page=0, total_pages=1, total_count=2)

        html = panel._detail_display.toHtml()
        assert "Hello" in html
        assert "Hi there!" in html
        assert "YOU" in html  # user role label
        assert "JARVIS" in html  # assistant role label

    def test_set_message_detail_empty_shows_empty_state(self, panel):
        """Empty message list shows empty state."""
        panel.set_message_detail("conv-1", "Test", [], page=0, total_pages=1, total_count=0)

        assert panel._detail_empty_lbl.isVisible()
        assert not panel._detail_display.isVisible()

    def test_set_message_detail_loading_state(self, panel):
        """Detail loading state works."""
        panel.set_detail_loading(True)
        assert panel._detail_loading_lbl.isVisible()
        assert not panel._detail_display.isVisible()

        panel.set_detail_loading(False)
        assert not panel._detail_loading_lbl.isVisible()

    def test_set_message_detail_error_state(self, panel):
        """Detail error state shows error message."""
        panel.set_detail_error("Database connection failed")
        assert panel._detail_error_lbl.isVisible()
        assert "Database connection failed" in panel._detail_error_lbl.text()
        assert not panel._detail_display.isVisible()
        assert not panel._detail_empty_lbl.isVisible()

    def test_detail_pagination_controls_update(self, panel):
        """Detail pagination controls reflect current page."""
        messages = [{"role": "user", "content": f"msg {i}"} for i in range(5)]
        panel.set_message_detail("conv-1", "Test", messages, page=0, total_pages=2, total_count=5)

        assert panel._detail_prev_btn.isEnabled() is False
        assert panel._detail_next_btn.isEnabled() is True
        assert "Page 1 / 2" in panel._detail_page_lbl.text()

    def test_role_colors_render(self, panel):
        """Different roles render with correct color labels."""
        messages = [
            {"role": "user", "content": "User msg", "timestamp_ms": 1700000000000},
            {"role": "assistant", "content": "Assistant msg", "timestamp_ms": 1700000001000},
            {"role": "system", "content": "System msg", "timestamp_ms": 1700000002000},
            {"role": "tool", "content": "Tool msg", "timestamp_ms": 1700000003000},
        ]
        panel.set_message_detail("conv-1", "Test", messages, page=0, total_pages=1, total_count=4)

        html = panel._detail_display.toHtml()
        assert "YOU" in html
        assert "JARVIS" in html
        assert "SYS" in html
        assert "TOOL" in html


class TestHistoryPanelSelection:
    """Test conversation selection and clearing."""

    def test_clear_selection_resets_detail(self, panel):
        """clear_selection resets detail view to empty state."""
        # First populate with a conversation
        panel.set_conversation_list(
            [{"id": "conv-1", "title": "Test", "started_at": 1700000000000, "turn_count": 1, "engine": "gemini_live"}],
            page=0, total_pages=1, total_count=1
        )
        panel.set_message_detail("conv-1", "Test", [{"role": "user", "content": "Hi"}], page=0, total_pages=1, total_count=1)

        # Now clear
        panel.clear_selection()

        assert panel._detail_empty_lbl.isVisible()
        assert not panel._detail_display.isVisible()
        assert panel._selected_conversation_id is None


class TestHistoryPanelSignals:
    """Test signal emissions."""

    def test_conversation_selected_signal_emitted(self, panel, qapp):
        """Clicking a conversation emits conversation_selected signal."""
        received = []

        def on_selected(conv_id):
            received.append(conv_id)

        panel.conversation_selected.connect(on_selected)

        # Populate and simulate click
        panel.set_conversation_list(
            [{"id": "conv-1", "title": "Test", "started_at": 1700000000000, "turn_count": 1, "engine": "gemini_live"}],
            page=0, total_pages=1, total_count=1
        )

        index = panel._list_model.index(0, 0)
        panel._list_view.clicked.emit(index)
        qapp.processEvents()

        assert received == ["conv-1"]

    def test_page_requested_signal_on_list_pagination(self, panel, qapp):
        """Clicking list pagination emits list_page_requested."""
        received = []

        def on_page(page):
            received.append(page)

        panel.list_page_requested.connect(on_page)

        # Populate with 3 pages
        conversations = [{"id": str(idx)} for idx in range(3)]
        panel.set_conversation_list(conversations, page=0, total_pages=3, total_count=3)

        # Click next
        panel._list_next_btn.click()
        qapp.processEvents()

        assert 1 in received  # Should request page 1

    def test_page_requested_signal_on_detail_pagination(self, panel, qapp):
        """Clicking detail pagination emits detail_page_requested."""
        received = []

        def on_page(page):
            received.append(page)

        panel.detail_page_requested.connect(on_page)

        panel.set_message_detail(
            "conv-1", "Test",
            [{"role": "user", "content": f"m{i}"} for i in range(5)],
            page=0, total_pages=2, total_count=5
        )

        panel._detail_next_btn.click()
        qapp.processEvents()

        assert 1 in received

    def test_search_requested_signal_debounced(self, panel, qapp):
        """Search input emits search_requested after debounce."""
        received = []

        def on_search(query):
            received.append(query)

        panel.search_requested.connect(on_search)

        panel._search_input.setText("test query")
        qapp.processEvents()

        # Should not emit immediately (debounced)
        assert len(received) == 0

        # Wait for debounce timer (300ms)
        import time
        time.sleep(0.35)
        qapp.processEvents()

        assert received == ["test query"]


class TestHistoryPanelRegression:
    """Regression tests to ensure existing UI patterns still work."""

    def test_panel_stylesheet_uses_c_palette(self, panel):
        """Panel stylesheet references C palette colors."""
        style = panel.styleSheet()
        assert "C.PANEL" not in style  # Should be interpolated
        assert "background:" in style.lower()

    def test_no_qt_widgets_created_in_worker_thread(self, panel):
        """Panel doesn't create Qt widgets in constructor that would
        violate threading rules (it's created on main thread in tests,
        but the class itself should be safe to instantiate)."""
        # This is a smoke test - if we can create it here without
        # "Cannot set parent, new parent is in a different thread"
        # errors, the pattern is correct.
        new_panel = HistoryPanel()
        new_panel.close()

    def test_content_panel_unaffected(self, panel):
        """Verify we didn't break anything - just a sanity check that
        the panel has all expected methods."""
        # These are the public API methods that external code will call
        assert hasattr(panel, "set_conversation_list")
        assert hasattr(panel, "set_message_detail")
        assert hasattr(panel, "set_detail_loading")
        assert hasattr(panel, "set_detail_error")
        assert hasattr(panel, "set_list_loading")
        assert hasattr(panel, "clear_selection")


class TestHistoryPanelKeyboardNavigation:
    """Test keyboard navigation (Task 5B)."""

    def test_tab_order_configured(self, panel):
        """Verify explicit tab order is set on all interactive controls."""
        # Tab order: dismiss_btn -> search_input -> list_view -> detail_display
        # -> list_prev_btn -> list_next_btn -> detail_prev_btn -> detail_next_btn -> dismiss_btn
        # We verify by checking the tab order chain works
        # (PyQt doesn't expose a direct query, so we test focus traversal)

        # Start with dismiss button focused
        panel._dismiss_btn.setFocus()
        assert panel._dismiss_btn.hasFocus()

        # Tab moves to search input
        panel._dismiss_btn.setFocus()
        panel._dismiss_btn.nextInFocusChain()  # This tests the chain is connected

    def test_escape_dismisses_panel_when_search_not_focused(self, panel):
        """Escape key dismisses panel when search input doesn't have focus."""
        panel.show()
        assert panel.isVisible()

        # Send Escape key event to panel (not search input)
        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Escape, Qt.KeyboardModifier.NoModifier)
        panel.keyPressEvent(event)

        assert not panel.isVisible()

    def test_escape_clears_search_when_search_focused(self, panel):
        """Escape key clears search input when it has focus."""
        panel._search_input.setText("test query")
        panel._search_input.setFocus()
        assert panel._search_input.text() == "test query"

        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Escape, Qt.KeyboardModifier.NoModifier)
        panel.keyPressEvent(event)

        # Panel should NOT dismiss, search should clear
        assert panel.isVisible()
        assert panel._search_input.text() == ""

    def test_enter_activates_selected_conversation(self, panel, qapp):
        """Enter key on list view activates selected conversation."""
        received = []

        def on_selected(conv_id):
            received.append(conv_id)

        panel.conversation_selected.connect(on_selected)

        # Populate list
        panel.set_conversation_list(
            [{"id": "conv-1", "title": "Test", "started_at": 1700000000000, "turn_count": 1, "engine": "gemini_live"}],
            page=0, total_pages=1, total_count=1
        )

        # Select first item and press Enter
        index = panel._list_model.index(0, 0)
        panel._list_view.setCurrentIndex(index)

        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Return, Qt.KeyboardModifier.NoModifier)
        panel.eventFilter(panel._list_view, event)
        qapp.processEvents()

        assert received == ["conv-1"]

    def test_left_right_arrows_navigate_list_pagination(self, panel, qapp):
        """Left/Right arrows navigate list pagination when list focused."""
        received = []

        def on_page(page):
            received.append(page)

        panel.list_page_requested.connect(on_page)

        # Populate with 3 pages
        conversations = [{"id": str(i)} for i in range(15)]  # 3 pages of 5
        panel.set_conversation_list(conversations, page=1, total_pages=3, total_count=15)

        # Right arrow -> next page
        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Right, Qt.KeyboardModifier.NoModifier)
        panel.eventFilter(panel._list_view, event)
        qapp.processEvents()

        assert 2 in received  # page 2 (0-based)

        # Left arrow -> prev page
        received.clear()
        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Left, Qt.KeyboardModifier.NoModifier)
        panel.eventFilter(panel._list_view, event)
        qapp.processEvents()

        assert 1 in received  # back to page 1

    def test_ctrl_left_right_arrows_navigate_detail_pagination(self, panel, qapp):
        """Ctrl+Left/Right arrows navigate detail pagination when detail focused."""
        received = []

        def on_page(page):
            received.append(page)

        panel.detail_page_requested.connect(on_page)

        # Populate detail with 3 pages
        messages = [{"role": "user", "content": f"m{i}"} for i in range(15)]
        panel.set_message_detail("conv-1", "Test", messages, page=1, total_pages=3, total_count=15)

        # Ctrl+Right -> next page
        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        event = QKeyEvent(
            QKeyEvent.Type.KeyPress,
            Qt.Key.Key_Right,
            Qt.KeyboardModifier.ControlModifier
        )
        panel.eventFilter(panel._detail_display, event)
        qapp.processEvents()

        assert 2 in received

        # Ctrl+Left -> prev page
        received.clear()
        event = QKeyEvent(
            QKeyEvent.Type.KeyPress,
            Qt.Key.Key_Left,
            Qt.KeyboardModifier.ControlModifier
        )
        panel.eventFilter(panel._detail_display, event)
        qapp.processEvents()

        assert 1 in received

    def test_page_up_down_jumps_5_pages_list(self, panel, qapp):
        """Page Up/Down jumps 5 pages in list pagination."""
        received = []

        def on_page(page):
            received.append(page)

        panel.list_page_requested.connect(on_page)

        # 10 pages total, start at page 5
        conversations = [{"id": str(i)} for i in range(50)]
        panel.set_conversation_list(conversations, page=5, total_pages=10, total_count=50)

        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        # Page Up -> jump back 5 pages (to page 0)
        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_PageUp, Qt.KeyboardModifier.NoModifier)
        panel.eventFilter(panel._list_view, event)
        qapp.processEvents()

        assert 0 in received

        # Page Down -> jump forward 5 pages (to page 10, clamped to 9)
        received.clear()
        panel.set_conversation_list(conversations, page=0, total_pages=10, total_count=50)
        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_PageDown, Qt.KeyboardModifier.NoModifier)
        panel.eventFilter(panel._list_view, event)
        qapp.processEvents()

        assert 5 in received  # min(9, 0+5) = 5

    def test_page_up_down_jumps_5_pages_detail(self, panel, qapp):
        """Page Up/Down jumps 5 pages in detail pagination."""
        received = []

        def on_page(page):
            received.append(page)

        panel.detail_page_requested.connect(on_page)

        # 10 pages total, start at page 5
        messages = [{"role": "user", "content": f"m{i}"} for i in range(50)]
        panel.set_message_detail("conv-1", "Test", messages, page=5, total_pages=10, total_count=50)

        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        # Page Up -> jump back 5 pages
        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_PageUp, Qt.KeyboardModifier.NoModifier)
        panel.eventFilter(panel._detail_display, event)
        qapp.processEvents()

        assert 0 in received

        # Page Down -> jump forward 5 pages
        received.clear()
        panel.set_message_detail("conv-1", "Test", messages, page=0, total_pages=10, total_count=50)
        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_PageDown, Qt.KeyboardModifier.NoModifier)
        panel.eventFilter(panel._detail_display, event)
        qapp.processEvents()

        assert 5 in received

    def test_up_down_arrows_use_native_list_navigation(self, panel, qapp):
        """Up/Down arrows use native QListView navigation (not intercepted)."""
        panel.set_conversation_list(
            [{"id": f"conv-{i}", "title": f"Test {i}", "started_at": 1700000000000, "turn_count": 1, "engine": "gemini_live"} for i in range(5)],
            page=0, total_pages=1, total_count=5
        )

        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        # Up arrow - should NOT be handled by our filter (return False)
        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Up, Qt.KeyboardModifier.NoModifier)
        result = panel.eventFilter(panel._list_view, event)
        # Our filter returns False for Up/Down, letting QListView handle it natively
        assert result is False

        # Down arrow - same
        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Down, Qt.KeyboardModifier.NoModifier)
        result = panel.eventFilter(panel._list_view, event)
        assert result is False


class TestHistoryPanelUXPolish:
    """Test UX polish improvements (Task 5C)."""

    def test_clear_search_button_initially_hidden(self, panel):
        """Clear search button is hidden when search is empty."""
        assert not panel._search_clear_btn.isVisible()

    def test_clear_search_button_shows_when_typing(self, panel):
        """Clear search button appears when search has text."""
        panel._search_input.setText("test")
        assert panel._search_clear_btn.isVisible()

    def test_clear_search_button_hides_when_cleared(self, panel):
        """Clear search button hides when search is cleared."""
        panel._search_input.setText("test")
        assert panel._search_clear_btn.isVisible()

        panel._search_input.clear()
        assert not panel._search_clear_btn.isVisible()

    def test_clear_search_button_clears_input(self, panel, qapp):
        """Clicking clear button clears search input and emits empty search."""
        received = []

        def on_search(query):
            received.append(query)

        panel.search_requested.connect(on_search)

        panel._search_input.setText("test query")
        panel._search_clear_btn.click()
        qapp.processEvents()

        assert panel._search_input.text() == ""
        assert not panel._search_clear_btn.isVisible()
        assert "" in received  # Empty search emitted

    def test_clear_search_button_accessible_properties(self, panel):
        """Clear search button has accessible name and description."""
        assert panel._search_clear_btn.accessibleName() == "Clear search"
        assert panel._search_clear_btn.accessibleDescription() == "Clear the search query"

    def test_empty_state_shows_no_conversations_when_not_searching(self, panel):
        """Empty state shows 'No conversations yet' when not searching."""
        panel.set_conversation_list([], page=0, total_pages=1, total_count=0)

        assert panel._list_empty_lbl.isVisible()
        assert panel._list_empty_lbl.text() == "No conversations yet."
        assert panel._list_empty_lbl.accessibleName() == "Empty conversation list"

    def test_empty_state_shows_no_results_when_searching(self, panel):
        """Empty state shows 'No results for query' when searching."""
        # Simulate a search that returned no results
        panel._current_search_query = "nonexistent"
        panel.set_conversation_list([], page=0, total_pages=1, total_count=0)

        assert panel._list_empty_lbl.isVisible()
        assert 'No results for "nonexistent"' in panel._list_empty_lbl.text()
        assert panel._list_empty_lbl.accessibleName() == "No search results"

    def test_loading_shows_searching_text_when_searching(self, panel):
        """Loading label shows search-specific text when searching."""
        panel._current_search_query = "test query"
        panel.set_list_loading(True)

        assert panel._list_loading_lbl.isVisible()
        assert 'Searching for "test query"' in panel._list_loading_lbl.text()
        assert panel._list_loading_lbl.accessibleName() == "Searching conversations"

    def test_loading_shows_default_text_when_not_searching(self, panel):
        """Loading label shows default text when not searching."""
        panel._current_search_query = ""
        panel.set_list_loading(True)

        assert panel._list_loading_lbl.isVisible()
        assert panel._list_loading_lbl.text() == "Loading conversations…"
        assert panel._list_loading_lbl.accessibleName() == "Loading conversations"

    def test_tab_order_includes_clear_search_button(self, panel):
        """Tab order includes clear search button between search input and list view."""
        # Tab order: dismiss -> search -> clear -> list -> detail -> ...
        panel._search_input.setFocus()
        assert panel._search_input.hasFocus()

        # Next in chain should be clear button
        next_widget = panel._search_input.nextInFocusChain()
        assert next_widget == panel._search_clear_btn

        # Next after clear should be list view
        next_widget = panel._search_clear_btn.nextInFocusChain()
        assert next_widget == panel._list_view

    def test_clear_search_via_escape_key(self, panel, qapp):
        """Escape key in search input clears search (not dismiss panel)."""
        received = []

        def on_search(query):
            received.append(query)

        panel.search_requested.connect(on_search)

        panel._search_input.setText("test query")
        panel._search_input.setFocus()

        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Escape, Qt.KeyboardModifier.NoModifier)
        panel.keyPressEvent(event)
        qapp.processEvents()

        assert panel._search_input.text() == ""
        assert not panel._search_clear_btn.isVisible()
        assert panel.isVisible()  # Panel not dismissed
        assert "" in received  # Empty search emitted

    def test_search_clear_button_focus_indicator(self, panel):
        """Clear search button has focus indicator stylesheet."""
        style = panel._search_clear_btn.styleSheet()
        assert ":focus" in style
        assert "border-color:" in style
        assert "outline:" in style


class TestHistoryPanelAccessibility:
    """Test accessibility features (Task 5B)."""

    def test_dismiss_button_accessible_properties(self, panel):
        """Dismiss button has accessible name and description."""
        assert panel._dismiss_btn.accessibleName() == "Dismiss history panel"
        assert panel._dismiss_btn.accessibleDescription() == "Closes the history panel"

    def test_search_input_accessible_properties(self, panel):
        """Search input has accessible name and description."""
        assert panel._search_input.accessibleName() == "Search conversations"
        assert panel._search_input.accessibleDescription() == "Type to search conversation history by title, summary, or message content"

    def test_list_view_accessible_properties(self, panel):
        """List view has accessible name and description."""
        assert panel._list_view.accessibleName() == "Conversation list"
        assert panel._list_view.accessibleDescription() == "List of conversations. Use Up/Down arrows to navigate, Enter to open, Left/Right arrows to change pages"

    def test_detail_display_accessible_properties(self, panel):
        """Detail display has accessible name and description."""
        assert panel._detail_display.accessibleName() == "Message history"
        assert panel._detail_display.accessibleDescription() == "Conversation messages. Use Ctrl+Left/Right arrows or Page Up/Down to navigate pages"

    def test_list_empty_label_accessible_name(self, panel):
        """Empty list label has accessible name."""
        assert panel._list_empty_lbl.accessibleName() == "Empty conversation list"

    def test_list_loading_label_accessible_name(self, panel):
        """Loading list label has accessible name."""
        assert panel._list_loading_lbl.accessibleName() == "Loading conversations"

    def test_detail_empty_label_accessible_name(self, panel):
        """Empty detail label has accessible name."""
        assert panel._detail_empty_lbl.accessibleName() == "Empty message detail"

    def test_detail_loading_label_accessible_name(self, panel):
        """Loading detail label has accessible name."""
        assert panel._detail_loading_lbl.accessibleName() == "Loading messages"

    def test_detail_error_label_accessible_name(self, panel):
        """Error detail label has accessible name."""
        assert panel._detail_error_lbl.accessibleName() == "Error loading messages"

    def test_detail_title_label_accessible_name(self, panel):
        """Detail title label has accessible name."""
        assert panel._detail_title_lbl.accessibleName() == "Conversation title"

    def test_list_pagination_buttons_accessible_properties(self, panel):
        """List pagination buttons have accessible names and descriptions."""
        assert panel._list_prev_btn.accessibleName() == "Previous page"
        assert panel._list_prev_btn.accessibleDescription() == "Go to previous page of conversations (Left arrow)"
        assert panel._list_next_btn.accessibleName() == "Next page"
        assert panel._list_next_btn.accessibleDescription() == "Go to next page of conversations (Right arrow)"
        assert panel._list_page_lbl.accessibleName() == "Conversation list page indicator"

    def test_detail_pagination_buttons_accessible_properties(self, panel):
        """Detail pagination buttons have accessible names and descriptions."""
        assert panel._detail_prev_btn.accessibleName() == "Previous message page"
        assert panel._detail_prev_btn.accessibleDescription() == "Go to previous page of messages (Ctrl+Left arrow)"
        assert panel._detail_next_btn.accessibleName() == "Next message page"
        assert panel._detail_next_btn.accessibleDescription() == "Go to next page of messages (Ctrl+Right arrow)"
        assert panel._detail_page_lbl.accessibleName() == "Message detail page indicator"

    def test_focus_indicator_styles_list_view(self, panel):
        """List view has focus indicator stylesheet."""
        style = panel._list_view.styleSheet()
        assert ":focus" in style
        assert "border-color:" in style
        assert "outline:" in style
        assert "C.PRI" not in style  # Should be interpolated

    def test_focus_indicator_styles_detail_display(self, panel):
        """Detail display has focus indicator stylesheet."""
        style = panel._detail_display.styleSheet()
        assert ":focus" in style
        assert "border-color:" in style
        assert "outline:" in style

    def test_focus_indicator_styles_search_input(self, panel):
        """Search input has focus indicator stylesheet."""
        style = panel._search_input.styleSheet()
        assert ":focus" in style
        assert "border-color:" in style
        assert "outline:" in style

    def test_focus_indicator_styles_dismiss_button(self, panel):
        """Dismiss button has focus indicator stylesheet."""
        style = panel._dismiss_btn.styleSheet()
        assert ":focus" in style
        assert "border-color:" in style
        assert "outline:" in style

    def test_focus_indicator_styles_pagination_buttons(self, panel):
        """Pagination buttons have focus indicator stylesheet."""
        for btn in [panel._list_prev_btn, panel._list_next_btn, panel._detail_prev_btn, panel._detail_next_btn]:
            style = btn.styleSheet()
            assert ":focus" in style
            assert "border-color:" in style
            assert "outline:" in style


class TestHistoryPanelLayoutCoordination:
    """Test layout coordination features (Task 5D)."""

    def test_minimum_height_enforced(self, panel):
        """History panel has minimum height to prevent collapse."""
        assert panel.minimumHeight() == 200

    def test_dismissed_signal_exists(self, panel):
        """HistoryPanel has dismissed signal."""
        assert hasattr(panel, "dismissed")
        from PyQt6.QtCore import pyqtSignal
        assert isinstance(getattr(HistoryPanel, "dismissed"), pyqtSignal)

    def test_dismiss_button_emits_signal(self, panel, qapp):
        """Clicking dismiss button emits dismissed signal."""
        received = []
        panel.dismissed.connect(lambda: received.append(True))

        panel._dismiss_btn.click()
        qapp.processEvents()

        assert len(received) == 1
        assert not panel.isVisible()

    def test_escape_key_emits_dismissed_signal(self, panel, qapp):
        """Escape key (when search not focused) emits dismissed signal."""
        received = []
        panel.dismissed.connect(lambda: received.append(True))

        # Ensure search input doesn't have focus
        panel._list_view.setFocus()
        assert not panel._search_input.hasFocus()

        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Escape, Qt.KeyboardModifier.NoModifier)
        panel.keyPressEvent(event)
        qapp.processEvents()

        assert len(received) == 1
        assert not panel.isVisible()

    def test_escape_in_search_clears_not_dismisses(self, panel, qapp):
        """Escape in search input clears search, doesn't emit dismissed."""
        dismissed = []
        searched = []
        panel.dismissed.connect(lambda: dismissed.append(True))
        panel.search_requested.connect(lambda q: searched.append(q))

        panel._search_input.setText("test")
        panel._search_input.setFocus()

        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Escape, Qt.KeyboardModifier.NoModifier)
        panel.keyPressEvent(event)
        qapp.processEvents()

        assert len(dismissed) == 0
        assert panel.isVisible()
        assert panel._search_input.text() == ""
        assert "" in searched

    def test_on_dismiss_method_exists(self, panel):
        """_on_dismiss method exists and hides panel."""
        assert hasattr(panel, "_on_dismiss")
        assert callable(panel._on_dismiss)

    # ---- Regression tests for the four confirmed defects ----

    def test_history_then_quiz_then_dismiss_quiz_restores_history(self, panel, qapp):
        """
        Defect 1/5: History -> Quiz -> dismiss Quiz -> History restored.
        Simulate the panel state transitions and verify correct restoration.
        """
        # We can't easily test the full MainWindow splitter here, but we can
        # verify the HistoryPanel's signal emission behavior is correct.
        # The MainWindow coordination is tested separately in integration.
        # This test ensures the signal chain works.

        # Simulate: History visible -> Quiz shown (hides history) -> Quiz dismissed -> History shown
        # We track the dismissed signal to verify it's emitted correctly

        dismissed_count = []
        panel.dismissed.connect(lambda: dismissed_count.append(1))

        # Dismiss history
        panel._on_dismiss()
        qapp.processEvents()

        assert len(dismissed_count) == 1
        assert not panel.isVisible()

        # Re-show panel (simulating history being restored)
        panel.show()
        qapp.processEvents()

        # Dismiss again
        panel._on_dismiss()
        qapp.processEvents()

        assert len(dismissed_count) == 2

    def test_content_show_does_not_overwrite_saved_sizes(self, panel):
        """
        Defect 2/6: Content show should not overwrite saved sizes when temp panel visible.
        This is a MainWindow-level test but we verify the signal is available.
        """
        # Content panel doesn't emit signals to HistoryPanel, so this is
        # verified at the MainWindow level. We ensure the HistoryPanel
        # doesn't have any conflicting state.
        assert hasattr(panel, "dismissed")

    def test_history_reshow_updates_saved_sizes(self, panel, qapp):
        """
        Defect 3: History re-show should update or reuse correct layout snapshot.
        Verify that showing an already-visible panel doesn't cause issues.
        """
        # Show history (simulate first show)
        panel.show()
        qapp.processEvents()
        assert panel.isVisible()

        # Show again (simulate re-show)
        panel.show()
        qapp.processEvents()
        assert panel.isVisible()

        # Dismiss
        dismissed = []
        panel.dismissed.connect(lambda: dismissed.append(True))
        panel._on_dismiss()
        qapp.processEvents()

        assert len(dismissed) == 1
        assert not panel.isVisible()

    def test_quiz_then_history_then_dismiss_history_restores_quiz(self, panel, qapp):
        """
        Defect 4/C: Quiz -> History -> dismiss History -> Quiz restored.
        Verify signal chain works for this transition.
        """
        # Show panel (simulating Quiz)
        panel.show()
        qapp.processEvents()
        assert panel.isVisible()

        # Dismiss (simulating History dismiss which should restore Quiz)
        dismissed = []
        panel.dismissed.connect(lambda: dismissed.append(True))
        panel._on_dismiss()
        qapp.processEvents()

        assert len(dismissed) == 1
        assert not panel.isVisible()

        # Panel can be shown again (simulating Quiz restored)
        panel.show()
        qapp.processEvents()
        assert panel.isVisible()

    def test_repeated_transitions_no_drift(self, panel, qapp):
        """
        Defect E: Repeated History/Quiz/Content transitions -> no splitter-size drift.
        Verify multiple show/dismiss cycles don't accumulate issues.
        """
        for _ in range(10):
            panel.show()
            qapp.processEvents()
            assert panel.isVisible()

            dismissed = []
            panel.dismissed.connect(lambda: dismissed.append(True))
            panel._on_dismiss()
            qapp.processEvents()

            assert len(dismissed) == 1
            assert not panel.isVisible()

    def test_rapid_transitions_no_stale_overwrite(self, panel, qapp):
        """
        Defect F: Rapid consecutive transitions -> no stale snapshot overwrites.
        Verify rapid show/dismiss doesn't cause signal issues.
        """
        for _ in range(20):
            panel.show()
            qapp.processEvents()
            panel._on_dismiss()
            qapp.processEvents()

        # Final state should be hidden
        assert not panel.isVisible()

    def test_dismiss_button_and_escape_equivalent_restoration(self, panel, qapp):
        """
        Defect G: Dismiss button and Escape -> equivalent layout restoration.
        Both paths should emit dismissed signal exactly once.
        """
        # Test button
        panel.show()
        qapp.processEvents()

        btn_dismissed = []
        panel.dismissed.connect(lambda: btn_dismissed.append(True))
        panel._dismiss_btn.click()
        qapp.processEvents()

        assert len(btn_dismissed) == 1
        assert not panel.isVisible()

        # Test Escape
        panel.show()
        qapp.processEvents()

        esc_dismissed = []
        panel.dismissed.connect(lambda: esc_dismissed.append(True))

        from PyQt6.QtGui import QKeyEvent
        from PyQt6.QtCore import Qt

        panel._list_view.setFocus()
        event = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Escape, Qt.KeyboardModifier.NoModifier)
        panel.keyPressEvent(event)
        qapp.processEvents()

        assert len(esc_dismissed) == 1
        assert not panel.isVisible()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])