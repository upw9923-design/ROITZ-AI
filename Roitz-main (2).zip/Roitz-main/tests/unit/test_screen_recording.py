"""
Regression tests for Phase 4 Batch 4: Persistent Screen Recording.

Tests the recording lifecycle (start/stop/status), privacy/permission enforcement,
WorkerRegistry resource coordination, and structured outcomes.
"""
import sys
import time
import threading
import base64
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from actions.computer_control import (
    computer_control,
    _is_recording,
    _get_recording_status,
    _stop_recording_internal,
    _RECORDING_STATE_LOCK,
    _RECORDING_STATE,
    _recording_worker,
)
from core.permission_guard import initialize_global_guard


def _wait_for_recording_stop(timeout=5.0):
    """Wait for recording thread to fully terminate."""
    start = time.time()
    while _is_recording() and (time.time() - start) < timeout:
        time.sleep(0.1)
    # Additional wait for thread join
    time.sleep(0.2)


def _reset_recording_state():
    """Force reset recording state for test isolation."""
    with _RECORDING_STATE_LOCK:
        global _RECORDING_STATE
        _RECORDING_STATE = None


def _setup_test_env():
    """Common test setup: reset state and initialize permission guard and manager."""
    _reset_recording_state()
    from core.worker_registry import reset_global_registry
    reset_global_registry()
    initialize_global_guard()
    from core.permission_manager import initialize_permission_manager_for_test
    initialize_permission_manager_for_test()


def _mock_recording_worker(cancel_event, *args, **kwargs):
    """Mock recording worker that stays alive until cancel_event is set."""
    while not cancel_event.is_set():
        time.sleep(0.1)


class TestScreenRecordingLifecycle:
    """Test the recording start/stop/status lifecycle."""

    def setup_method(self):
        """Ensure clean state before each test."""
        _setup_test_env()

    def teardown_method(self):
        """Clean up after each test."""
        if _is_recording():
            _stop_recording_internal()
        _wait_for_recording_stop()
        _reset_recording_state()
        from core.worker_registry import reset_global_registry
        reset_global_registry()

    def test_record_start_creates_session(self):
        """record_start should create a recording session with session_id."""
        params = {"action": "record_start"}
        result = computer_control(params)

        assert "status=done" in result
        assert "action=record_start" in result
        assert "session_id=" in result
        assert "verified=true" in result
        assert "output_path=" in result

    def test_record_start_returns_done_with_details(self):
        """record_start should return structured outcome with recording parameters."""
        params = {"action": "record_start", "fps": 20, "duration_limit": 60, "monitor_index": 0}
        result = computer_control(params)

        assert "status=done" in result
        assert "fps=20" in result
        assert "duration_limit=60" in result
        assert "monitor_index=0" in result
        assert "verified=true" in result

        # Clean up
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_record_start_prevents_duplicate(self):
        """record_start should fail if recording already in progress."""
        # Start first recording
        computer_control({"action": "record_start"})
        _wait_for_recording_stop()  # Wait for thread to start

        # Try to start second recording
        params = {"action": "record_start"}
        result = computer_control(params)

        assert "status=failed" in result
        assert "action=record_start" in result
        assert "Recording already in progress" in result

        # Clean up
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_record_stop_returns_done_with_info(self):
        """record_stop should stop recording and return file info."""
        # Start recording
        computer_control({"action": "record_start"})
        _wait_for_recording_stop()  # Let it capture at least one frame

        # Stop recording
        params = {"action": "record_stop"}
        result = computer_control(params)

        assert "status=done" in result
        assert "action=record_stop" in result
        assert "output_path=" in result
        assert "duration_seconds=" in result
        assert "file_size_bytes=" in result
        assert "verified=true" in result

    def test_record_stop_fails_when_not_recording(self):
        """record_stop should fail if no recording in progress."""
        params = {"action": "record_stop"}
        result = computer_control(params)

        assert "status=failed" in result
        assert "action=record_stop" in result
        assert "No recording in progress" in result

    def test_record_status_returns_recording_info(self):
        """record_status should return current recording status."""
        computer_control({"action": "record_start"})
        _wait_for_recording_stop()

        params = {"action": "record_status"}
        result = computer_control(params)

        assert "status=done" in result
        assert "action=record_status" in result
        assert "recording=true" in result
        assert "session_id=" in result
        assert "elapsed_seconds=" in result
        assert "verified=true" in result

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_record_status_returns_not_recording(self):
        """record_status should indicate when not recording."""
        params = {"action": "record_status"}
        result = computer_control(params)

        assert "status=done" in result
        assert "action=record_status" in result
        assert "recording=false" in result
        assert "verified=true" in result

    def test_record_start_stop_status_full_cycle(self):
        """Test complete recording lifecycle: start -> status -> stop -> status."""
        # Start
        result = computer_control({"action": "record_start"})
        assert "status=done" in result
        assert "session_id=" in result

        # Extract session_id from result
        session_id = result.split("session_id=")[1].split(" ")[0]

        # Status during recording
        _wait_for_recording_stop()
        result = computer_control({"action": "record_status"})
        assert "recording=true" in result
        assert session_id in result

        # Stop
        result = computer_control({"action": "record_stop"})
        assert "status=done" in result

        # Status after stop
        _wait_for_recording_stop()
        result = computer_control({"action": "record_status"})
        assert "recording=false" in result


class TestScreenRecordingParameterValidation:
    """Test parameter validation and clamping."""

    def setup_method(self):
        _setup_test_env()

    def teardown_method(self):
        if _is_recording():
            _stop_recording_internal()
        _wait_for_recording_stop()
        _reset_recording_state()
        from core.worker_registry import reset_global_registry
        reset_global_registry()

    def test_fps_clamped_to_range(self):
        """FPS should be clamped to 1-30 range."""
        # Test low FPS clamped to 1
        params = {"action": "record_start", "fps": 0}
        result = computer_control(params)
        assert "fps=1" in result
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

        # Test high FPS clamped to 30
        params = {"action": "record_start", "fps": 100}
        result = computer_control(params)
        assert "fps=30" in result
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_duration_limit_clamped(self):
        """Duration limit should be clamped to 1-3600 seconds."""
        params = {"action": "record_start", "duration_limit": 0}
        result = computer_control(params)
        assert "duration_limit=1" in result
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

        params = {"action": "record_start", "duration_limit": 10000}
        result = computer_control(params)
        assert "duration_limit=3600" in result
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_size_limit_clamped(self):
        """Size limit should be clamped to 1MB-2GB."""
        params = {"action": "record_start", "size_limit": 100}
        result = computer_control(params)
        assert "size_limit=1048576" in result  # 1MB minimum
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

        params = {"action": "record_start", "size_limit": 10_000_000_000}
        result = computer_control(params)
        assert "size_limit=2147483648" in result  # 2GB maximum
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_invalid_region_fails(self):
        """Invalid region parameter should fail."""
        params = {"action": "record_start", "region": "not a tuple"}
        result = computer_control(params)
        assert "status=failed" in result
        assert "region must be a tuple" in result

        params = {"action": "record_start", "region": [1, 2, 3]}  # wrong length
        result = computer_control(params)
        assert "status=failed" in result
        assert "region must be a tuple" in result

        params = {"action": "record_start", "region": [1, 2, -3, 4]}  # negative
        result = computer_control(params)
        assert "status=failed" in result
        assert "positive" in result.lower()

    def test_valid_region_accepted(self):
        """Valid region should be accepted."""
        params = {"action": "record_start", "region": [100, 100, 800, 600]}
        result = computer_control(params)
        assert "status=done" in result
        # Region tuple gets quoted in outcome format: region="(100, 100, 800, 600)"
        assert 'region="(100, 100, 800, 600)"' in result
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_invalid_monitor_index_fails(self):
        """Invalid monitor index should fail gracefully."""
        params = {"action": "record_start", "monitor_index": 999}
        result = computer_control(params)
        assert "status=failed" in result
        assert "Invalid monitor index" in result


class TestScreenRecordingPermissionEnforcement:
    """Test permission checks for recording operations."""

    def setup_method(self):
        _setup_test_env()

    def teardown_method(self):
        if _is_recording():
            _stop_recording_internal()
        _wait_for_recording_stop()
        _reset_recording_state()
        from core.worker_registry import reset_global_registry
        reset_global_registry()

    @patch("core.permission_guard.get_permission_guard")
    def test_record_start_requires_screen_capture_permission(self, mock_guard):
        """record_start should check screen.capture permission."""
        mock_guard_instance = MagicMock()
        mock_guard.return_value = mock_guard_instance
        mock_guard_instance.check_operation.return_value = MagicMock(
            allowed=False,
            reason="approval_required",
            instruction="Please approve screen capture"
        )

        params = {"action": "record_start"}
        result = computer_control(params)

        # Should return approval instruction
        assert "approval_required" in result or "Please approve" in result

    @patch("core.permission_guard.get_permission_guard")
    def test_record_stop_requires_screen_capture_permission(self, mock_guard):
        """record_stop should check screen.capture permission."""
        mock_guard_instance = MagicMock()
        mock_guard.return_value = mock_guard_instance
        mock_guard_instance.check_operation.return_value = MagicMock(
            allowed=False,
            reason="approval_required",
            instruction="Please approve screen capture"
        )

        params = {"action": "record_stop"}
        result = computer_control(params)

        assert "approval_required" in result or "Please approve" in result

    @patch("core.permission_guard.get_permission_guard")
    def test_record_status_requires_screen_capture_permission(self, mock_guard):
        """record_status should check screen.capture permission."""
        mock_guard_instance = MagicMock()
        mock_guard.return_value = mock_guard_instance
        mock_guard_instance.check_operation.return_value = MagicMock(
            allowed=False,
            reason="approval_required",
            instruction="Please approve screen capture"
        )

        params = {"action": "record_status"}
        result = computer_control(params)

        assert "approval_required" in result or "Please approve" in result


class TestScreenRecordingResourceCoordination:
    """Test WorkerRegistry resource coordination for recordings."""

    def setup_method(self):
        _setup_test_env()

    def teardown_method(self):
        if _is_recording():
            _stop_recording_internal()
        _wait_for_recording_stop()
        _reset_recording_state()
        from core.worker_registry import reset_global_registry
        reset_global_registry()

    def test_record_start_reserves_global_display(self):
        """record_start should reserve global:display resource."""
        from core.worker_registry import get_global_registry
        registry = get_global_registry()

        params = {"action": "record_start"}
        result = computer_control(params)

        assert "status=done" in result

        # Check resource reservation
        workers = registry.get_workers_by_resource_key("global:display")
        assert len(workers) >= 1
        assert any(w.operation_name == "computer_control:record_start" for w in workers)

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_record_stop_releases_global_display(self):
        """record_stop should release global:display resource."""
        from core.worker_registry import get_global_registry
        registry = get_global_registry()

        computer_control({"action": "record_start"})
        _wait_for_recording_stop()

        # Verify reserved
        workers = registry.get_workers_by_resource_key("global:display")
        assert len(workers) >= 1

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

        # Verify released
        workers = registry.get_workers_by_resource_key("global:display")
        # After stop and cleanup, should be released
        active = [w for w in workers if w.is_alive()]
        assert len(active) == 0

    @patch("actions.computer_control._recording_worker", side_effect=_mock_recording_worker)
    def test_record_conflicts_with_screen_find(self, mock_worker):
        """Recording should conflict with screen_find (both use global:display)."""
        from core.worker_registry import get_global_registry, create_worker_record
        registry = get_global_registry()

        # Start recording with mocked worker that stays alive
        computer_control({"action": "record_start"})
        time.sleep(0.3)  # Give time for thread to start and register

        # Verify worker is registered and alive
        workers = registry.get_workers_by_resource_key("global:display")
        assert len(workers) >= 1, f"Expected recording worker in registry, got {len(workers)}"
        recording_worker = next((w for w in workers if w.operation_name == "computer_control:record_start"), None)
        assert recording_worker is not None, "Recording worker not found"
        assert recording_worker.is_alive(), "Recording worker should be alive"

        # Try to admit a screen_find worker (simulating concurrent operation)
        worker = create_worker_record(
            task_id="test_task",
            step_id="step1",
            tool_name="computer_control",
            parameters={"action": "screen_find", "description": "button"},
            operation_name="computer_control:screen_find",
            resource_scope="LOCAL_SYSTEM",
            is_idempotent=True,
        )

        admitted, reason = registry.admit_worker(worker)
        assert not admitted, f"Expected conflict but worker was admitted: {reason}"
        assert "resource_key:global:display" in reason

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    @patch("actions.computer_control._recording_worker", side_effect=_mock_recording_worker)
    def test_record_conflicts_with_screenshot(self, mock_worker):
        """Recording should conflict with screenshot (both use global:display)."""
        from core.worker_registry import get_global_registry, create_worker_record
        registry = get_global_registry()

        computer_control({"action": "record_start"})
        time.sleep(0.3)

        # Verify worker is registered and alive
        workers = registry.get_workers_by_resource_key("global:display")
        assert len(workers) >= 1, f"Expected recording worker in registry, got {len(workers)}"
        recording_worker = next((w for w in workers if w.operation_name == "computer_control:record_start"), None)
        assert recording_worker is not None, "Recording worker not found"
        assert recording_worker.is_alive(), "Recording worker should be alive"

        worker = create_worker_record(
            task_id="test_task",
            step_id="step1",
            tool_name="computer_control",
            parameters={"action": "screenshot"},
            operation_name="computer_control:screenshot",
            resource_scope="LOCAL_SYSTEM",
            is_idempotent=True,
        )

        admitted, reason = registry.admit_worker(worker)
        assert not admitted, f"Expected conflict but worker was admitted: {reason}"
        assert "resource_key:global:display" in reason

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    @patch("actions.computer_control._recording_worker", side_effect=_mock_recording_worker)
    def test_record_conflicts_with_screen_click(self, mock_worker):
        """Recording should conflict with screen_click (both use global:display)."""
        from core.worker_registry import get_global_registry, create_worker_record
        registry = get_global_registry()

        computer_control({"action": "record_start"})
        time.sleep(0.3)

        # Verify worker is registered and alive
        workers = registry.get_workers_by_resource_key("global:display")
        assert len(workers) >= 1, f"Expected recording worker in registry, got {len(workers)}"
        recording_worker = next((w for w in workers if w.operation_name == "computer_control:record_start"), None)
        assert recording_worker is not None, "Recording worker not found"
        assert recording_worker.is_alive(), "Recording worker should be alive"

        worker = create_worker_record(
            task_id="test_task",
            step_id="step1",
            tool_name="computer_control",
            parameters={"action": "screen_click", "description": "button"},
            operation_name="computer_control:screen_click",
            resource_scope="LOCAL_SYSTEM",
            is_idempotent=False,
        )

        admitted, reason = registry.admit_worker(worker)
        assert not admitted
        assert "resource_key:global:display" in reason

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_multiple_record_sessions_blocked(self):
        """Only one recording session should be allowed at a time."""
        # First recording
        result1 = computer_control({"action": "record_start"})
        assert "status=done" in result1
        _wait_for_recording_stop()

        # Second recording should fail
        result2 = computer_control({"action": "record_start"})
        assert "status=failed" in result2
        assert "Recording already in progress" in result2

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()


class TestScreenRecordingErrorHandling:
    """Test error handling and cleanup."""

    def setup_method(self):
        _setup_test_env()

    def teardown_method(self):
        if _is_recording():
            _stop_recording_internal()
        _wait_for_recording_stop()
        _reset_recording_state()
        from core.worker_registry import reset_global_registry
        reset_global_registry()

    def test_record_stop_cleans_up_state(self):
        """record_stop should clean up internal state."""
        computer_control({"action": "record_start"})
        _wait_for_recording_stop()
        assert _is_recording() is True

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()
        assert _is_recording() is False

    def test_record_stop_releases_worker_registry(self):
        """record_stop should release WorkerRegistry resources."""
        from core.worker_registry import get_global_registry
        registry = get_global_registry()

        computer_control({"action": "record_start"})
        _wait_for_recording_stop()

        # Verify worker registered
        workers = registry.get_active_for_task("screen_recording")
        assert len(workers) >= 1

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

        # Verify worker cleaned up
        workers = registry.get_active_for_task("screen_recording")
        assert len(workers) == 0

    def test_record_status_after_stop_shows_not_recording(self):
        """record_status should correctly report not recording after stop."""
        computer_control({"action": "record_start"})
        _wait_for_recording_stop()
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

        result = computer_control({"action": "record_status"})
        assert "recording=false" in result


class TestScreenRecordingNoCameraActivation:
    """Test that recording never accidentally activates camera."""

    def setup_method(self):
        _setup_test_env()

    def teardown_method(self):
        if _is_recording():
            _stop_recording_internal()
        _wait_for_recording_stop()
        _reset_recording_state()
        from core.worker_registry import reset_global_registry
        reset_global_registry()

    @patch("core.screen_capture.capture_primary_monitor")
    def test_record_uses_screen_capture_not_camera(self, mock_capture):
        """Recording should use screen capture, not camera capture."""
        # Minimal valid 1x1 red pixel PNG that OpenCV can decode
        png_data = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg==")
        mock_capture.return_value = (png_data, "image/png")

        # Use monitor_index=0 to trigger capture_primary_monitor
        computer_control({"action": "record_start", "monitor_index": 0})
        time.sleep(0.2)  # Let recording thread capture a frame
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

        # Verify screen capture was called, not camera capture
        assert mock_capture.called

    @patch("core.screen_capture.capture_region")
    def test_record_region_uses_capture_region(self, mock_capture_region):
        """Region recording should use capture_region function."""
        # Minimal valid 1x1 red pixel PNG that OpenCV can decode
        png_data = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg==")
        mock_capture_region.return_value = (png_data, "image/png")

        computer_control({"action": "record_start", "region": [0, 0, 800, 600]})
        time.sleep(0.2)
        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

        # Verify capture_region was called with region params
        assert mock_capture_region.called


class TestScreenRecordingStructuredOutcomes:
    """Test that outcomes follow the structured format."""

    def setup_method(self):
        _setup_test_env()

    def teardown_method(self):
        if _is_recording():
            _stop_recording_internal()
        _wait_for_recording_stop()
        _reset_recording_state()
        from core.worker_registry import reset_global_registry
        reset_global_registry()

    def test_record_start_outcome_format(self):
        """record_start outcome should follow done format."""
        result = computer_control({"action": "record_start"})

        # Check status=done format
        assert result.startswith("status=done action=record_start")
        assert "verified=true" in result
        assert "session_id=" in result
        assert "output_path=" in result

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_record_stop_outcome_format(self):
        """record_stop outcome should follow done format."""
        computer_control({"action": "record_start"})
        _wait_for_recording_stop()
        result = computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

        assert result.startswith("status=done action=record_stop")
        assert "verified=true" in result
        assert "output_path=" in result
        assert "duration_seconds=" in result
        assert "file_size_bytes=" in result

    def test_record_status_outcome_format(self):
        """record_status outcome should follow done format."""
        computer_control({"action": "record_start"})
        _wait_for_recording_stop()
        result = computer_control({"action": "record_status"})

        assert result.startswith("status=done action=record_status")
        assert "verified=true" in result
        assert "recording=true" in result
        assert "elapsed_seconds=" in result

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_failed_outcome_format(self):
        """Failed outcomes should follow failed format."""
        # Duplicate start should fail
        computer_control({"action": "record_start"})
        _wait_for_recording_stop()
        result = computer_control({"action": "record_start"})

        assert result.startswith("status=failed action=record_start")
        assert "reason=" in result

        computer_control({"action": "record_stop"})
        _wait_for_recording_stop()

    def test_stop_when_not_recording_outcome(self):
        """Stop when not recording should return failed."""
        result = computer_control({"action": "record_stop"})

        assert result.startswith("status=failed action=record_stop")
        assert "reason=" in result


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])