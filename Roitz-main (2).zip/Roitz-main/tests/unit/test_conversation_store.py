"""
Unit tests for ConversationStore (Batch 1: SQLite Conversation Storage Foundation).

Run with: py -m pytest tests/unit/test_conversation_store.py -v
"""
import sys
import threading
import time
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from memory.conversation_store import (
    ConversationStore,
    ConversationNotFoundError,
    MessageNotFoundError,
    SequenceConflictError,
    ValidationError,
    get_store,
    reset_store,
)
from memory.conversation_models import Conversation, Message, ConversationSummary


class TestConversationStoreBasics(unittest.TestCase):
    """Basic CRUD operations for conversations and messages."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.store = ConversationStore(self.db_path)

    def tearDown(self):
        self.store.close()
        self.temp_dir.cleanup()

    def test_create_and_get_conversation(self):
        """Create a conversation and retrieve it by ID."""
        conv = Conversation(
            id="test-conv-1",
            title="Test Conversation",
            started_at=int(time.time() * 1000),
        )
        created = self.store.create_conversation(conv)

        self.assertEqual(created.id, "test-conv-1")
        self.assertEqual(created.title, "Test Conversation")
        self.assertEqual(created.turn_count, 0)
        self.assertEqual(created.engine, "gemini_live")

        retrieved = self.store.get_conversation("test-conv-1")
        self.assertEqual(retrieved.id, created.id)
        self.assertEqual(retrieved.title, created.title)

    def test_create_conversation_auto_id(self):
        """Conversation ID is auto-generated if not provided."""
        conv = Conversation(title="Auto ID Test", started_at=int(time.time() * 1000))
        created = self.store.create_conversation(conv)

        self.assertIsNotNone(created.id)
        self.assertEqual(len(created.id), 32)  # UUID hex

    def test_update_conversation(self):
        """Update conversation metadata."""
        conv = Conversation(id="update-test", title="Original", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)

        retrieved = self.store.get_conversation("update-test")
        retrieved.title = "Updated Title"
        retrieved.turn_count = 5
        retrieved.summary = "A test conversation"
        updated = self.store.update_conversation(retrieved)

        self.assertEqual(updated.title, "Updated Title")
        self.assertEqual(updated.turn_count, 5)
        self.assertEqual(updated.summary, "A test conversation")
        # updated_at may be equal if update happens within same millisecond
        self.assertGreaterEqual(updated.updated_at, retrieved.updated_at)

    def test_update_nonexistent_conversation_raises(self):
        """Updating a non-existent conversation raises ConversationNotFoundError."""
        conv = Conversation(id="nonexistent", title="Ghost", started_at=int(time.time() * 1000))
        with self.assertRaises(ConversationNotFoundError):
            self.store.update_conversation(conv)

    def test_count_conversations(self):
        """Conversation count is accurate."""
        self.assertEqual(self.store.count_conversations(), 0)

        for i in range(3):
            conv = Conversation(id=f"count-{i}", title=f"Count {i}", started_at=int(time.time() * 1000))
            self.store.create_conversation(conv)

        self.assertEqual(self.store.count_conversations(), 3)

    def test_finalize_conversation(self):
        """Finalize a conversation (mark as ended)."""
        conv = Conversation(id="finalize-test", title="To Finalize", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)

        finalized = self.store.finalize_conversation(
            "finalize-test",
            summary="Final summary",
            turn_count=10,
        )

        self.assertIsNotNone(finalized.ended_at)
        self.assertEqual(finalized.summary, "Final summary")
        self.assertEqual(finalized.turn_count, 10)

    def test_delete_conversation(self):
        """Delete a conversation."""
        conv = Conversation(id="delete-test", title="To Delete", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)

        self.store.delete_conversation("delete-test")

        with self.assertRaises(ConversationNotFoundError):
            self.store.get_conversation("delete-test")

    def test_delete_nonexistent_conversation_raises(self):
        """Deleting a non-existent conversation raises ConversationNotFoundError."""
        with self.assertRaises(ConversationNotFoundError):
            self.store.delete_conversation("ghost")


class TestMessageCRUD(unittest.TestCase):
    """Message insertion, retrieval, and sequence management."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.store = ConversationStore(self.db_path)

        # Create a conversation for message tests
        self.conv = Conversation(id="msg-test-conv", title="Message Test", started_at=int(time.time() * 1000))
        self.store.create_conversation(self.conv)

    def tearDown(self):
        self.store.close()
        self.temp_dir.cleanup()

    def test_append_message_auto_sequence(self):
        """Messages get auto-assigned sequential numbers."""
        msg1 = Message(conversation_id="msg-test-conv", role="user", content="Hello")
        msg2 = Message(conversation_id="msg-test-conv", role="assistant", content="Hi there")
        msg3 = Message(conversation_id="msg-test-conv", role="user", content="How are you?")

        self.store.append_message(msg1)
        self.store.append_message(msg2)
        self.store.append_message(msg3)

        self.assertEqual(msg1.sequence, 1)
        self.assertEqual(msg2.sequence, 2)
        self.assertEqual(msg3.sequence, 3)

    def test_append_message_returns_assigned_sequence(self):
        """Append returns the message with assigned sequence."""
        msg = Message(conversation_id="msg-test-conv", role="user", content="Test")
        returned = self.store.append_message(msg)

        self.assertEqual(returned.sequence, 1)
        self.assertIsNotNone(returned.id)

    def test_get_messages_in_order(self):
        """Messages retrieved in sequence order."""
        for i in range(5):
            role = "user" if i % 2 == 0 else "assistant"
            self.store.append_message(Message(
                conversation_id="msg-test-conv",
                role=role,
                content=f"Message {i}",
            ))

        messages = self.store.get_messages("msg-test-conv")
        self.assertEqual(len(messages), 5)
        for i, msg in enumerate(messages):
            self.assertEqual(msg.sequence, i + 1)
            self.assertEqual(msg.content, f"Message {i}")

    def test_get_messages_pagination(self):
        """Pagination works correctly."""
        for i in range(10):
            self.store.append_message(Message(
                conversation_id="msg-test-conv",
                role="user",
                content=f"Msg {i}",
            ))

        page1 = self.store.get_messages("msg-test-conv", limit=3, offset=0)
        page2 = self.store.get_messages("msg-test-conv", limit=3, offset=3)

        self.assertEqual(len(page1), 3)
        self.assertEqual(len(page2), 3)
        self.assertEqual(page1[0].sequence, 1)
        self.assertEqual(page2[0].sequence, 4)

    def test_get_messages_descending(self):
        """Descending order returns newest first."""
        for i in range(3):
            self.store.append_message(Message(
                conversation_id="msg-test-conv",
                role="user",
                content=f"Msg {i}",
            ))

        messages = self.store.get_messages("msg-test-conv", descending=True)
        self.assertEqual(messages[0].sequence, 3)
        self.assertEqual(messages[1].sequence, 2)
        self.assertEqual(messages[2].sequence, 1)

    def test_append_message_invalid_role_raises(self):
        """Invalid role raises ValidationError."""
        msg = Message(conversation_id="msg-test-conv", role="invalid", content="Test")
        with self.assertRaises(ValidationError):
            self.store.append_message(msg)

    def test_append_message_invalid_content_type_raises(self):
        """Invalid content_type raises ValidationError."""
        msg = Message(
            conversation_id="msg-test-conv",
            role="user",
            content="Test",
            content_type="invalid_type",
        )
        with self.assertRaises(ValidationError):
            self.store.append_message(msg)

    def test_append_message_nonexistent_conversation_raises(self):
        """Appending to non-existent conversation raises ConversationNotFoundError."""
        msg = Message(conversation_id="ghost-conv", role="user", content="Test")
        with self.assertRaises(ConversationNotFoundError):
            self.store.append_message(msg)

    def test_get_message_by_id(self):
        """Retrieve a single message by its ID."""
        msg = self.store.append_message(Message(
            conversation_id="msg-test-conv",
            role="user",
            content="Find me",
        ))

        retrieved = self.store.get_message(msg.id)
        self.assertEqual(retrieved.id, msg.id)
        self.assertEqual(retrieved.content, "Find me")

    def test_get_nonexistent_message_raises(self):
        """Getting non-existent message raises MessageNotFoundError."""
        with self.assertRaises(MessageNotFoundError):
            self.store.get_message("ghost-msg-id")

    def test_delete_message(self):
        """Delete a single message."""
        msg = self.store.append_message(Message(
            conversation_id="msg-test-conv",
            role="user",
            content="To delete",
        ))

        self.store.delete_message(msg.id)

        with self.assertRaises(MessageNotFoundError):
            self.store.get_message(msg.id)

    def test_message_count(self):
        """get_message_count returns correct count."""
        self.assertEqual(self.store.get_message_count("msg-test-conv"), 0)

        for i in range(5):
            self.store.append_message(Message(
                conversation_id="msg-test-conv",
                role="user",
                content=f"Msg {i}",
            ))

        self.assertEqual(self.store.get_message_count("msg-test-conv"), 5)


class TestSequenceUniqueness(unittest.TestCase):
    """Sequence numbers are unique per conversation."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.store = ConversationStore(self.db_path)

        self.conv = Conversation(id="seq-test", title="Sequence Test", started_at=int(time.time() * 1000))
        self.store.create_conversation(self.conv)

    def tearDown(self):
        self.store.close()
        self.temp_dir.cleanup()

    def test_unique_sequence_per_conversation(self):
        """Each conversation has independent sequence numbering."""
        conv2 = Conversation(id="seq-test-2", title="Another", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv2)

        # Add messages to both conversations
        for i in range(3):
            self.store.append_message(Message(conversation_id="seq-test", role="user", content=f"A{i}"))
            self.store.append_message(Message(conversation_id="seq-test-2", role="user", content=f"B{i}"))

        msgs_a = self.store.get_messages("seq-test")
        msgs_b = self.store.get_messages("seq-test-2")

        self.assertEqual([m.sequence for m in msgs_a], [1, 2, 3])
        self.assertEqual([m.sequence for m in msgs_b], [1, 2, 3])

    def test_sequence_gap_after_delete(self):
        """Deleting a message creates a gap (sequence not reused)."""
        msg1 = self.store.append_message(Message(conversation_id="seq-test", role="user", content="1"))
        msg2 = self.store.append_message(Message(conversation_id="seq-test", role="user", content="2"))
        msg3 = self.store.append_message(Message(conversation_id="seq-test", role="user", content="3"))

        self.store.delete_message(msg2.id)

        messages = self.store.get_messages("seq-test")
        sequences = [m.sequence for m in messages]
        self.assertEqual(sequences, [1, 3])  # Gap at 2


class TestConcurrentInsertion(unittest.TestCase):
    """Concurrent message insertion behavior."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        # Create initial store to set up the conversation
        store = ConversationStore(self.db_path)
        self.conv = Conversation(id="concurrent-test", title="Concurrent", started_at=int(time.time() * 1000))
        store.create_conversation(self.conv)
        store.close()

        self.errors = []

    def tearDown(self):
        self.temp_dir.cleanup()

    def _worker(self, thread_id: int, count: int, db_path: Path):
        """Worker function that appends messages using its own store instance."""
        try:
            store = ConversationStore(db_path)
            for i in range(count):
                store.append_message(Message(
                    conversation_id="concurrent-test",
                    role="user",
                    content=f"Thread {thread_id} msg {i}",
                ))
                time.sleep(0.001)  # Small delay to encourage interleaving
            store.close()
        except Exception as e:
            self.errors.append(e)

    def test_concurrent_appends_maintain_sequence_integrity(self):
        """Multiple threads appending concurrently don't corrupt sequences."""
        threads = []
        msgs_per_thread = 20
        num_threads = 5

        for t in range(num_threads):
            th = threading.Thread(target=self._worker, args=(t, msgs_per_thread, self.db_path))
            threads.append(th)
            th.start()

        for th in threads:
            th.join()

        self.assertEqual(len(self.errors), 0, f"Thread errors: {self.errors}")

        # Verify results using a fresh store instance
        store = ConversationStore(self.db_path)
        messages = store.get_messages("concurrent-test")
        store.close()

        self.assertEqual(len(messages), num_threads * msgs_per_thread)

        # Verify all sequences 1..N present exactly once
        sequences = sorted(m.sequence for m in messages)
        expected = list(range(1, num_threads * msgs_per_thread + 1))
        self.assertEqual(sequences, expected)


class TestForeignKeyEnforcement(unittest.TestCase):
    """Foreign key constraints are enforced."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.store = ConversationStore(self.db_path)

    def tearDown(self):
        self.store.close()
        self.temp_dir.cleanup()

    def test_message_requires_existing_conversation(self):
        """Cannot insert message for non-existent conversation."""
        msg = Message(conversation_id="nonexistent", role="user", content="Test")
        with self.assertRaises(ConversationNotFoundError):
            self.store.append_message(msg)

    def test_cascade_delete_messages(self):
        """Deleting conversation cascades to messages."""
        conv = Conversation(id="cascade-test", title="Cascade", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)

        for i in range(5):
            self.store.append_message(Message(
                conversation_id="cascade-test",
                role="user",
                content=f"Msg {i}",
            ))

        self.assertEqual(self.store.get_message_count("cascade-test"), 5)

        self.store.delete_conversation("cascade-test")

        # Messages should be gone
        messages = self.store.get_messages("cascade-test")
        self.assertEqual(len(messages), 0)


class TestSearchAndPagination(unittest.TestCase):
    """Search and pagination functionality."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.store = ConversationStore(self.db_path)

        self.conv = Conversation(id="search-test", title="Search Test", started_at=int(time.time() * 1000))
        self.store.create_conversation(self.conv)

    def tearDown(self):
        self.store.close()
        self.temp_dir.cleanup()

    def test_search_messages_basic(self):
        """Basic text search works."""
        self.store.append_message(Message(conversation_id="search-test", role="user", content="Hello world"))
        self.store.append_message(Message(conversation_id="search-test", role="assistant", content="Hi there"))
        self.store.append_message(Message(conversation_id="search-test", role="user", content="Goodbye world"))

        results = self.store.search_messages("world", conversation_id="search-test")
        self.assertEqual(len(results), 2)
        for msg in results:
            self.assertIn("world", msg.content.lower())

    def test_search_messages_with_role_filter(self):
        """Search with role filter."""
        self.store.append_message(Message(conversation_id="search-test", role="user", content="Hello"))
        self.store.append_message(Message(conversation_id="search-test", role="assistant", content="Hello"))
        self.store.append_message(Message(conversation_id="search-test", role="user", content="Hi"))

        results = self.store.search_messages("hello", conversation_id="search-test", role="user")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].role, "user")

    def test_search_messages_pagination(self):
        """Search results paginate correctly."""
        for i in range(10):
            self.store.append_message(Message(
                conversation_id="search-test",
                role="user",
                content=f"Test message {i}",
            ))

        page1 = self.store.search_messages("test", conversation_id="search-test", limit=3, offset=0)
        page2 = self.store.search_messages("test", conversation_id="search-test", limit=3, offset=3)

        self.assertEqual(len(page1), 3)
        self.assertEqual(len(page2), 3)

    def test_search_empty_query_returns_empty(self):
        """Empty search query returns empty list."""
        results = self.store.search_messages("", conversation_id="search-test")
        self.assertEqual(results, [])

        results = self.store.search_messages("   ", conversation_id="search-test")
        self.assertEqual(results, [])

    def test_list_conversations_pagination(self):
        """Conversation listing with pagination."""
        for i in range(5):
            conv = Conversation(id=f"list-{i}", title=f"Conv {i}", started_at=int(time.time() * 1000) + i)
            self.store.create_conversation(conv)

        page1 = self.store.list_conversations(limit=2, offset=0)
        page2 = self.store.list_conversations(limit=2, offset=2)

        self.assertEqual(len(page1), 2)
        self.assertEqual(len(page2), 2)
        self.assertEqual(page1[0].id, "list-4")  # Newest first (started_at DESC)
        self.assertEqual(page2[0].id, "list-2")


class TestConversationSearch(unittest.TestCase):
    """Conversation-level search functionality."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.store = ConversationStore(self.db_path)

        # Create test conversations with messages
        base_time = int(time.time() * 1000)
        self.conv1 = Conversation(id="conv-1", title="Python Project", started_at=base_time, summary="A Python project")
        self.conv2 = Conversation(id="conv-2", title="JavaScript App", started_at=base_time + 1000, summary="A JS application")
        self.conv3 = Conversation(id="conv-3", title="Rust Library", started_at=base_time + 2000, summary="Systems programming")
        self.conv4 = Conversation(id="conv-4", title="No Match Here", started_at=base_time + 3000, summary="Nothing relevant")

        for conv in [self.conv1, self.conv2, self.conv3, self.conv4]:
            self.store.create_conversation(conv)

        # Add messages to conv-1 (Python Project)
        self.store.append_message(Message(conversation_id="conv-1", role="user", content="How do I use Python async?"))
        self.store.append_message(Message(conversation_id="conv-1", role="assistant", content="Use asyncio for async Python code"))
        self.store.append_message(Message(conversation_id="conv-1", role="user", content="What about threading?"))

        # Add messages to conv-2 (JavaScript App)
        self.store.append_message(Message(conversation_id="conv-2", role="user", content="JavaScript async patterns"))
        self.store.append_message(Message(conversation_id="conv-2", role="assistant", content="Use Promises or async/await in JavaScript"))

        # Add messages to conv-3 (Rust Library)
        self.store.append_message(Message(conversation_id="conv-3", role="user", content="Rust ownership model"))
        self.store.append_message(Message(conversation_id="conv-3", role="assistant", content="Rust uses ownership and borrowing"))

        # Add messages to conv-4 (No Match Here)
        self.store.append_message(Message(conversation_id="conv-4", role="user", content="Unrelated content"))
        self.store.append_message(Message(conversation_id="conv-4", role="assistant", content="Completely different topic"))

    def tearDown(self):
        self.store.close()
        self.temp_dir.cleanup()

    def test_search_conversations_by_title(self):
        """Search matches conversation title."""
        results = self.store.search_conversations("Python")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].id, "conv-1")
        self.assertEqual(results[0].title, "Python Project")

    def test_search_conversations_by_summary(self):
        """Search matches conversation summary."""
        results = self.store.search_conversations("Systems programming")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].id, "conv-3")

    def test_search_conversations_by_message_content(self):
        """Search matches message content."""
        results = self.store.search_conversations("asyncio")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].id, "conv-1")

    def test_search_conversations_multiple_matches_one_result(self):
        """Multiple matching messages in one conversation produce one result."""
        # conv-1 has two messages with "Python"
        results = self.store.search_conversations("Python")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].id, "conv-1")

    def test_search_conversations_returns_conversation_summary(self):
        """Results are ConversationSummary objects with correct fields."""
        results = self.store.search_conversations("JavaScript")
        self.assertEqual(len(results), 1)
        result = results[0]
        self.assertIsInstance(result, ConversationSummary)
        self.assertEqual(result.id, "conv-2")
        self.assertEqual(result.title, "JavaScript App")
        self.assertIsNotNone(result.started_at)
        self.assertIsNone(result.ended_at)
        self.assertEqual(result.turn_count, 0)
        self.assertEqual(result.engine, "gemini_live")

    def test_search_conversations_ordering_by_last_match_time(self):
        """Results ordered by most recent matching message timestamp descending."""
        # Search for "async" - matches conv-1 (Python asyncio) and conv-2 (JavaScript async)
        # conv-2's message was added later, so it should appear first
        results = self.store.search_conversations("async")
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0].id, "conv-2")  # More recent message
        self.assertEqual(results[1].id, "conv-1")

    def test_search_conversations_pagination(self):
        """Conversation search paginates correctly."""
        # Search for "a" - should match multiple conversations
        # We'll use a more specific test with multiple conversations
        results_page1 = self.store.search_conversations("a", limit=2, offset=0)
        results_page2 = self.store.search_conversations("a", limit=2, offset=2)

        # Verify no overlap
        page1_ids = {r.id for r in results_page1}
        page2_ids = {r.id for r in results_page2}
        self.assertEqual(len(page1_ids & page2_ids), 0)

        # Total should be correct
        total_count = self.store.count_search_conversations("a")
        self.assertEqual(total_count, len(results_page1) + len(results_page2))

    def test_search_conversations_empty_query_returns_empty(self):
        """Empty or whitespace-only query returns empty list."""
        results = self.store.search_conversations("")
        self.assertEqual(results, [])

        results = self.store.search_conversations("   ")
        self.assertEqual(results, [])

    def test_search_conversations_wildcard_characters(self):
        """SQL wildcard characters are treated as literals."""
        # Add a conversation with literal % and _ in title
        conv = Conversation(id="wildcard-test", title="100% Complete_test", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)

        # Search for literal "%" should find it
        results = self.store.search_conversations("%")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].id, "wildcard-test")

        # Search for literal "_" should find it
        results = self.store.search_conversations("_")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].id, "wildcard-test")

    def test_search_conversations_no_matches(self):
        """Query with no matches returns empty list."""
        results = self.store.search_conversations("XYZ_NOMATCH_123")
        self.assertEqual(results, [])

        count = self.store.count_search_conversations("XYZ_NOMATCH_123")
        self.assertEqual(count, 0)

    def test_search_conversations_conversation_with_no_messages(self):
        """Conversation with no messages can still match via title/summary."""
        conv = Conversation(id="no-msgs", title="Empty Conversation", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)

        results = self.store.search_conversations("Empty")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].id, "no-msgs")

    def test_search_conversations_conversation_id_filter(self):
        """Filter by conversation_id restricts search to that conversation."""
        results = self.store.search_conversations("Python", conversation_id="conv-1")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].id, "conv-1")

        # Same query filtered to different conversation returns nothing
        results = self.store.search_conversations("Python", conversation_id="conv-2")
        self.assertEqual(results, [])

    def test_search_conversations_role_filter(self):
        """Role filter restricts message search to specific role."""
        # Search for "async" in user messages only
        results = self.store.search_conversations("async", role="user")
        # Should match conv-1 (user asked about async) and conv-2 (user asked about async)
        self.assertEqual(len(results), 2)

        # Search for "async" in assistant messages only
        results = self.store.search_conversations("async", role="assistant")
        # Should match conv-1 (assistant mentioned asyncio) and conv-2 (assistant mentioned async/await)
        self.assertEqual(len(results), 2)

    def test_count_search_conversations_matches_search(self):
        """count_search_conversations returns same count as search with no limit."""
        query = "async"
        count = self.store.count_search_conversations(query)
        results = self.store.search_conversations(query, limit=100)
        self.assertEqual(count, len(results))

    def test_count_search_conversations_with_filters(self):
        """count respects conversation_id and role filters."""
        # With conversation filter
        count = self.store.count_search_conversations("Python", conversation_id="conv-1")
        self.assertEqual(count, 1)

        count = self.store.count_search_conversations("Python", conversation_id="conv-2")
        self.assertEqual(count, 0)

        # With role filter
        count = self.store.count_search_conversations("async", role="user")
        results = self.store.search_conversations("async", role="user", limit=100)
        self.assertEqual(count, len(results))

    def test_search_conversations_stable_ordering(self):
        """Ordering is stable across repeated calls."""
        results1 = self.store.search_conversations("a")
        results2 = self.store.search_conversations("a")
        self.assertEqual([r.id for r in results1], [r.id for r in results2])

    def test_search_conversations_excludes_meta_json(self):
        """ConversationSummary does not include meta_json."""
        results = self.store.search_conversations("Python")
        self.assertEqual(len(results), 1)
        result = results[0]
        # ConversationSummary has no meta_json field
        self.assertFalse(hasattr(result, 'meta_json'))


class TestTransactionRollback(unittest.TestCase):
    """Failed operations roll back cleanly."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.store = ConversationStore(self.db_path)

    def tearDown(self):
        self.store.close()
        self.temp_dir.cleanup()

    def test_failed_message_insert_does_not_corrupt_sequence(self):
        """If a message insert fails mid-transaction, sequence is not consumed."""
        conv = Conversation(id="tx-test", title="Transaction Test", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)

        # Insert a valid message first
        msg1 = self.store.append_message(Message(conversation_id="tx-test", role="user", content="Valid 1"))
        self.assertEqual(msg1.sequence, 1)

        # Try to insert a message with invalid role (should fail)
        try:
            self.store.append_message(Message(conversation_id="tx-test", role="invalid", content="Invalid"))
        except ValidationError:
            pass

        # Next valid message should get sequence 2 (not 3)
        msg2 = self.store.append_message(Message(conversation_id="tx-test", role="user", content="Valid 2"))
        self.assertEqual(msg2.sequence, 2)

    def test_failed_conversation_update_rolls_back(self):
        """Failed update rolls back changes."""
        conv = Conversation(id="rollback-test", title="Original", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)

        # This should work
        conv.title = "Updated"
        self.store.update_conversation(conv)

        retrieved = self.store.get_conversation("rollback-test")
        self.assertEqual(retrieved.title, "Updated")


class TestSchemaVersioning(unittest.TestCase):
    """Schema version initialization and migration idempotency."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_schema_version_initialized(self):
        """New database gets correct schema version."""
        store = ConversationStore(self.db_path)
        version = store.get_schema_version()
        store.close()
        self.assertEqual(version, 1)

    def test_migration_idempotent(self):
        """Running migrations twice doesn't error."""
        store = ConversationStore(self.db_path)
        store.close()

        # Reopen and verify schema still works
        store2 = ConversationStore(self.db_path)
        version = store2.get_schema_version()
        store2.close()
        self.assertEqual(version, 1)

    def test_existing_database_reopened(self):
        """Database can be reopened and used normally."""
        store1 = ConversationStore(self.db_path)
        conv = Conversation(id="reopen-test", title="Reopen", started_at=int(time.time() * 1000))
        store1.create_conversation(conv)
        store1.close()

        store2 = ConversationStore(self.db_path)
        retrieved = store2.get_conversation("reopen-test")
        store2.close()

        self.assertEqual(retrieved.id, "reopen-test")
        self.assertEqual(retrieved.title, "Reopen")


class TestIntegrityCheck(unittest.TestCase):
    """Database integrity verification."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.store = ConversationStore(self.db_path)

    def tearDown(self):
        self.store.close()
        self.temp_dir.cleanup()

    def test_integrity_check_healthy(self):
        """Fresh database passes integrity check."""
        healthy, issues = self.store.integrity_check()
        self.assertTrue(healthy)
        self.assertEqual(issues, [])

    def test_integrity_check_after_operations(self):
        """Database passes integrity check after normal operations."""
        conv = Conversation(id="integrity-test", title="Integrity", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)

        for i in range(10):
            self.store.append_message(Message(
                conversation_id="integrity-test",
                role="user" if i % 2 == 0 else "assistant",
                content=f"Message {i}",
            ))

        healthy, issues = self.store.integrity_check()
        self.assertTrue(healthy)
        self.assertEqual(issues, [])


class TestBackup(unittest.TestCase):
    """Backup functionality (basic verification)."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.backup_path = Path(self.temp_dir.name) / "backup.sqlite3"
        self.store = ConversationStore(self.db_path)
        self._backup_store = None

    def tearDown(self):
        self.store.close()
        if self._backup_store is not None:
            self._backup_store.close()
        # Longer delay to allow Windows to release file handles
        time.sleep(0.2)
        import gc
        gc.collect()
        self.temp_dir.cleanup()

    def test_backup_creates_file(self):
        """Backup creates a valid database file."""
        conv = Conversation(id="backup-test", title="Backup Test", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)

        self.store.append_message(Message(conversation_id="backup-test", role="user", content="Test"))

        self.store.backup(self.backup_path)

        self.assertTrue(self.backup_path.exists())
        self.assertGreater(self.backup_path.stat().st_size, 0)

    def test_backup_restorable(self):
        """Backup can be opened as a valid database."""
        conv = Conversation(id="backup-test", title="Backup Test", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)
        self.store.append_message(Message(conversation_id="backup-test", role="user", content="Test"))

        self.store.backup(self.backup_path)

        # Open backup as a new store
        self._backup_store = ConversationStore(self.backup_path)
        retrieved = self._backup_store.get_conversation("backup-test")
        self._backup_store.close()
        self._backup_store = None

        self.assertEqual(retrieved.id, "backup-test")
        # Reopen to verify message count (since we closed the store)
        backup_store2 = ConversationStore(self.backup_path)
        self.assertEqual(backup_store2.get_message_count("backup-test"), 1)
        backup_store2.close()


class TestPersistenceAcrossInstances(unittest.TestCase):
    """Data persists across store instances."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_data_persists_after_close_reopen(self):
        """Data written by one store instance is visible to another."""
        store1 = ConversationStore(self.db_path)
        conv = Conversation(id="persist-test", title="Persist", started_at=int(time.time() * 1000))
        store1.create_conversation(conv)
        store1.append_message(Message(conversation_id="persist-test", role="user", content="Hello"))
        store1.close()

        store2 = ConversationStore(self.db_path)
        retrieved_conv = store2.get_conversation("persist-test")
        messages = store2.get_messages("persist-test")
        store2.close()

        self.assertEqual(retrieved_conv.title, "Persist")
        self.assertEqual(len(messages), 1)
        self.assertEqual(messages[0].content, "Hello")


if __name__ == "__main__":
    unittest.main()