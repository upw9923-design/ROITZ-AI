"""
Regression tests for the Focus Verification Gate (Phase 4 Batch 2 Safety Correction).

Tests the enforcement mechanism that prevents sensitive input after failed/unverified focus_window.
"""
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from actions import computer_control as cc_module
from actions.computer_control import computer_control
import ctypes


def _set_verified_focus(title: str = "Test Window", hwnd: int = 12345):
    """Helper to set verified focus state for tests."""
    with cc_module._FOCUS_STATE_LOCK:
        cc_module._LAST_VERIFIED_FOCUS = {
            "title": title,
            "hwnd": hwnd,
            "timestamp": time.time(),
            "verified": True,
        }


def _clear_focus_state():
    """Helper to clear focus state for tests."""
    with cc_module._FOCUS_STATE_LOCK:
        cc_module._LAST_VERIFIED_FOCUS = None


def _set_expired_focus(title: str = "Test Window", hwnd: int = 12345):
    """Helper to set an expired focus state (older than TTL)."""
    with cc_module._FOCUS_STATE_LOCK:
        cc_module._LAST_VERIFIED_FOCUS = {
            "title": title,
            "hwnd": hwnd,
            "timestamp": time.time() - cc_module._FOCUS_VERIFICATION_TTL - 1.0,
            "verified": True,
        }


def _set_mismatched_focus(title: str = "Other Window", hwnd: int = 54321):
    """Helper to set a verified focus for a different window."""
    with cc_module._FOCUS_STATE_LOCK:
        cc_module._LAST_VERIFIED_FOCUS = {
            "title": title,
            "hwnd": hwnd,
            "timestamp": time.time(),
            "verified": True,
        }


class TestFocusVerificationGate(unittest.TestCase):
    """Test the focus verification gate enforcement."""

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_focus_verified_allows_type(self, mock_get_fg, mock_pyautogui, mock_require):
        """Verified focus should allow type action."""
        _set_verified_focus("Notepad")
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=unverified", result)
        self.assertIn("text sent; appearance not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_focus_verified_allows_click(self, mock_get_fg, mock_pyautogui, mock_require):
        """Verified focus should allow click action."""
        _set_verified_focus("Notepad")
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "click", "x": 100, "y": 200})
        self.assertIn("status=unverified", result)
        self.assertIn("click sent at coordinates; target not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_focus_verified_allows_hotkey(self, mock_get_fg, mock_pyautogui, mock_require):
        """Verified focus should allow hotkey action."""
        _set_verified_focus("Notepad")
        result = computer_control({"action": "hotkey", "keys": "ctrl+c"})
        self.assertIn("status=unverified", result)
        self.assertIn("hotkey sent; effect not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_focus_verified_allows_press(self, mock_get_fg, mock_pyautogui, mock_require):
        """Verified focus should allow press action."""
        _set_verified_focus("Notepad")
        result = computer_control({"action": "press", "key": "enter"})
        self.assertIn("status=unverified", result)
        self.assertIn("key press sent; effect not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_focus_verified_allows_paste(self, mock_get_fg, mock_pyautogui, mock_require):
        """Verified focus should allow paste action."""
        _set_verified_focus("Notepad")
        result = computer_control({"action": "paste", "text": "hello"})
        self.assertIn("status=unverified", result)
        self.assertIn("paste sent via clipboard; appearance not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_focus_verified_allows_clear_field(self, mock_get_fg, mock_pyautogui, mock_require):
        """Verified focus should allow clear_field action."""
        _set_verified_focus("Notepad")
        result = computer_control({"action": "clear_field"})
        self.assertIn("status=unverified", result)
        self.assertIn("clear sent; field state not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_focus_verified_allows_move(self, mock_get_fg, mock_pyautogui, mock_require):
        """Verified focus should allow move action."""
        _set_verified_focus("Notepad")
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "move", "x": 100, "y": 200})
        self.assertIn("status=unverified", result)
        self.assertIn("mouse move sent; position not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_focus_verified_allows_drag(self, mock_get_fg, mock_pyautogui, mock_require):
        """Verified focus should allow drag action."""
        _set_verified_focus("Notepad")
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "drag", "x1": 100, "y1": 100, "x2": 200, "y2": 200})
        self.assertIn("status=unverified", result)
        self.assertIn("drag sent; result not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control._click")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_focus_verified_allows_screen_click(self, mock_get_fg, mock_click, mock_find, mock_require):
        """Verified focus should allow screen_click action."""
        from actions.computer_control import ScreenFindResult
        _set_verified_focus("Notepad")
        mock_find.return_value = ScreenFindResult(
            x=100, y=200, confidence=0.8,
            bounding_box=None, raw_response='{"x":100,"y":200,"confidence":0.8}'
        )
        mock_click.return_value = "status=unverified action=click x=100 y=200 button=left clicks=1 reason=\"click sent at coordinates; target not verified\""
        result = computer_control({"action": "screen_click", "description": "button"})
        self.assertIn("status=unverified", result)
        self.assertIn("AI find + click sent; target activation not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_focus_verified_allows_smart_type(self, mock_get_fg, mock_pyautogui, mock_require):
        """Verified focus should allow smart_type action."""
        _set_verified_focus("Notepad")
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "smart_type", "text": "hello world"})
        self.assertIn("status=unverified", result)
        self.assertIn("text sent via typewrite; appearance not verified", result)


class TestFocusVerificationGateBlocks(unittest.TestCase):
    """Test that the gate blocks sensitive input when focus not verified."""

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_no_focus_blocks_type(self, mock_pyautogui, mock_require):
        """No focus should block type action."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=failed", result)
        self.assertIn("focus verification required", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_no_focus_blocks_click(self, mock_pyautogui, mock_require):
        """No focus should block click action."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "click", "x": 100, "y": 200})
        self.assertIn("status=failed", result)
        self.assertIn("focus verification required", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_no_focus_blocks_hotkey(self, mock_pyautogui, mock_require):
        """No focus should block hotkey action."""
        result = computer_control({"action": "hotkey", "keys": "ctrl+c"})
        self.assertIn("status=failed", result)
        self.assertIn("focus verification required", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_expired_focus_blocks_type(self, mock_pyautogui, mock_require):
        """Expired focus should block type action."""
        _set_expired_focus("Notepad")
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=failed", result)
        self.assertIn("focus verification expired", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_expired_focus_clears_state(self, mock_pyautogui, mock_require):
        """Expired focus should clear the internal state."""
        _set_expired_focus("Notepad")
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=failed", result)
        # Second call should also fail (state cleared)
        result2 = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=failed", result2)
        self.assertIn("focus verification required", result2)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=54321)
    def test_mismatched_focus_allows_type(self, mock_get_fg, mock_pyautogui, mock_require):
        """Mismatched focus should still allow type (no title to match against)."""
        # Current design: actions don't have a target title, so any verified focus allows them
        _set_mismatched_focus("Other Window")
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=unverified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=54321)
    def test_mismatched_focus_allows_click(self, mock_get_fg, mock_pyautogui, mock_require):
        """Mismatched focus should still allow click (no title to match against)."""
        _set_mismatched_focus("Other Window")
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "click", "x": 100, "y": 200})
        self.assertIn("status=unverified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_partial_title_match_allowed(self, mock_get_fg, mock_pyautogui, mock_require):
        """Partial title match should be allowed (substring matching)."""
        _set_verified_focus("Notepad - test.txt")
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=unverified", result)


class TestFocusWindowUpdatesState(unittest.TestCase):
    """Test that focus_window updates the verification state correctly."""

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._get_os", return_value="windows")
    @patch("actions.computer_control.subprocess.run")
    def test_focus_window_failed_clears_state(self, mock_run, mock_get_os):
        """focus_window that fails should clear focus state."""
        mock_run.side_effect = Exception("PowerShell failed")
        result = computer_control({"action": "focus_window", "title": "Notepad"})
        self.assertIn("status=failed", result)
        # Check internal state was cleared
        with cc_module._FOCUS_STATE_LOCK:
            self.assertIsNone(cc_module._LAST_VERIFIED_FOCUS)

    def test_focus_window_macos_unverified(self):
        """focus_window on macOS should return unverified (cannot verify)."""
        # This test documents the behavior - macOS/Linux focus_window returns unverified
        # because verification is not implemented
        import actions.computer_control as cc
        original_os = cc._get_os
        cc._get_os = lambda: "mac"
        try:
            with patch("actions.computer_control.subprocess.run") as mock_run:
                mock_run.return_value = Mock(returncode=0)
                result = computer_control({"action": "focus_window", "title": "Notepad"})
                self.assertIn("status=unverified", result)
                self.assertIn("verification unavailable on this platform", result)
                # State should be cleared (unverified)
                with cc_module._FOCUS_STATE_LOCK:
                    self.assertIsNone(cc_module._LAST_VERIFIED_FOCUS)
        finally:
            cc._get_os = original_os

    def test_focus_window_linux_unverified(self):
        """focus_window on Linux should return unverified (cannot verify)."""
        import actions.computer_control as cc
        original_os = cc._get_os
        cc._get_os = lambda: "linux"
        try:
            with patch("actions.computer_control.subprocess.run") as mock_run:
                mock_run.return_value = Mock(returncode=0)
                result = computer_control({"action": "focus_window", "title": "Notepad"})
                self.assertIn("status=unverified", result)
                self.assertIn("verification unavailable on this platform", result)
                # State should be cleared (unverified)
                with cc_module._FOCUS_STATE_LOCK:
                    self.assertIsNone(cc_module._LAST_VERIFIED_FOCUS)
        finally:
            cc._get_os = original_os


class TestNonSensitiveActionsNotBlocked(unittest.TestCase):
    """Test that non-sensitive actions are not blocked by the gate."""

    def tearDown(self):
        _clear_focus_state()

    def test_scroll_not_blocked(self):
        """Scroll should work without focus verification."""
        result = computer_control({"action": "scroll", "direction": "down", "amount": 3})
        self.assertIn("status=unverified", result)

    def test_copy_not_blocked(self):
        """Copy should work without focus verification."""
        with patch("actions.computer_control._require_pyperclip", return_value=True):
            with patch("actions.computer_control.pyperclip") as mock_pyperclip:
                mock_pyperclip.paste.return_value = "clipboard content"
                result = computer_control({"action": "copy"})
                self.assertIn("status=done", result)

    def test_screenshot_not_blocked(self):
        """Screenshot should work without focus verification."""
        with patch("actions.computer_control.capture_primary_monitor") as mock_capture:
            with patch("pathlib.Path.read_bytes") as mock_read:
                mock_capture.return_value = (b"fake_image_data", "image/jpeg")
                mock_read.return_value = b"fake_image_data"
                with patch("builtins.open", unittest.mock.mock_open()):
                    result = computer_control({"action": "screenshot"})
                    self.assertIn("status=done", result)

    def test_wait_not_blocked(self):
        """Wait should work without focus verification."""
        result = computer_control({"action": "wait", "seconds": 1.0})
        self.assertIn("status=done", result)

    def test_screen_find_not_blocked(self):
        """Screen find should work without focus verification."""
        from actions.computer_control import ScreenFindResult
        with patch("actions.computer_control._screen_find") as mock_find:
            mock_find.return_value = ScreenFindResult(
                x=100, y=200, confidence=0.8,
                bounding_box=None, raw_response='{"x":100,"y":200,"confidence":0.8}'
            )
            result = computer_control({"action": "screen_find", "description": "button"})
            self.assertIn("status=done", result)
            self.assertIn("verified=true", result)

    def test_focus_window_not_blocked(self):
        """focus_window itself should not be blocked."""
        with patch("actions.computer_control.subprocess.run") as mock_run:
            mock_run.return_value = Mock(returncode=0)
            result = computer_control({"action": "focus_window", "title": "Notepad"})
            # Will be unverified on macOS/Linux or failed if verification fails
            self.assertIn("status=", result)

    def test_close_app_not_blocked(self):
        """close_app should work without focus verification."""
        with patch("actions.computer_control.appidentity.running", return_value=[]):
            result = computer_control({"action": "close_app", "app_name": "Notepad"})
            self.assertIn("status=failed", result)
            self.assertIn("no running application matches", result)

    def test_random_data_not_blocked(self):
        """random_data should work without focus verification."""
        result = computer_control({"action": "random_data", "type": "email"})
        self.assertIn("status=done", result)

    def test_user_data_not_blocked(self):
        """user_data should work without focus verification."""
        with patch("actions.computer_control._user_profile", return_value={}):
            result = computer_control({"action": "user_data", "field": "email"})
            self.assertIn("status=done", result)


class TestFocusVerificationTTL(unittest.TestCase):
    """Test the TTL (time-to-live) for focus verification."""

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow", return_value=12345)
    def test_focus_verification_expires_after_ttl(self, mock_get_fg, mock_pyautogui, mock_require):
        """Focus verification should expire after TTL seconds."""
        _set_verified_focus("Notepad")
        mock_pyautogui.size.return_value = (1920, 1080)

        # Immediately after setting - should work
        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=unverified", result)

        # Manually expire the focus
        with cc_module._FOCUS_STATE_LOCK:
            cc_module._LAST_VERIFIED_FOCUS["timestamp"] = time.time() - cc_module._FOCUS_VERIFICATION_TTL - 0.1

        # Should now fail
        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=failed", result)
        self.assertIn("focus verification expired", result)


class TestLiveForegroundVerification(unittest.TestCase):
    """Test live foreground window HWND verification (Windows)."""

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._get_os", return_value="windows")
    @patch("ctypes.windll.user32.GetForegroundWindow")
    def test_correct_hwnd_allows_type(self, mock_get_fg, mock_get_os, mock_pyautogui, mock_require):
        """Correct target HWND remains active: input allowed."""
        _set_verified_focus("Notepad", hwnd=12345)
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_get_fg.return_value = 12345  # Same HWND as verified

        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=unverified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._get_os", return_value="windows")
    @patch("ctypes.windll.user32.GetForegroundWindow")
    def test_different_hwnd_blocks_type(self, mock_get_fg, mock_get_os, mock_pyautogui, mock_require):
        """Different foreground HWND within TTL: input blocked."""
        _set_verified_focus("Notepad", hwnd=12345)
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_get_fg.return_value = 99999  # Different HWND

        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=failed", result)
        self.assertIn("focus mismatch", result)
        self.assertIn("foreground window changed", result)
        # State should be cleared after mismatch
        with cc_module._FOCUS_STATE_LOCK:
            self.assertIsNone(cc_module._LAST_VERIFIED_FOCUS)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._get_os", return_value="windows")
    @patch("ctypes.windll.user32.GetForegroundWindow")
    def test_zero_hwnd_blocks_type(self, mock_get_fg, mock_get_os, mock_pyautogui, mock_require):
        """Zero/invalid HWND (no foreground window): input blocked."""
        _set_verified_focus("Notepad", hwnd=12345)
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_get_fg.return_value = 0  # No foreground window

        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=failed", result)
        self.assertIn("no foreground window", result)
        # State should be cleared
        with cc_module._FOCUS_STATE_LOCK:
            self.assertIsNone(cc_module._LAST_VERIFIED_FOCUS)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._get_os", return_value="windows")
    @patch("ctypes.windll.user32.GetForegroundWindow")
    def test_getforegroundwindow_exception_blocks_type(self, mock_get_fg, mock_get_os, mock_pyautogui, mock_require):
        """GetForegroundWindow raises exception: input blocked."""
        _set_verified_focus("Notepad", hwnd=12345)
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_get_fg.side_effect = Exception("API failure")

        result = computer_control({"action": "type", "text": "hello"})
        self.assertIn("status=failed", result)
        self.assertIn("focus verification failed", result)
        # State should be cleared
        with cc_module._FOCUS_STATE_LOCK:
            self.assertIsNone(cc_module._LAST_VERIFIED_FOCUS)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._get_os", return_value="windows")
    @patch("ctypes.windll.user32.GetForegroundWindow")
    @patch("ctypes.windll.user32.GetWindowTextLengthW")
    @patch("ctypes.windll.user32.GetWindowTextW")
    def test_title_mismatch_blocks_type(self, mock_get_text, mock_get_len, mock_get_fg, mock_get_os, mock_pyautogui, mock_require):
        """Title mismatch despite matching HWND: input blocked."""
        _set_verified_focus("Notepad", hwnd=12345)
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_get_fg.return_value = 12345
        # Return a different title
        mock_get_len.return_value = len("Other Window")
        # GetWindowTextW writes to the buffer; simulate this with side_effect
        def fill_buffer(hwnd, buf, max_len):
            buf.value = "Other Window"
            return len("Other Window")
        mock_get_text.side_effect = fill_buffer

        result = computer_control({"action": "type", "text": "hello", "title": "Notepad"})
        self.assertIn("status=failed", result)
        self.assertIn("focus mismatch", result)
        # State should be cleared
        with cc_module._FOCUS_STATE_LOCK:
            self.assertIsNone(cc_module._LAST_VERIFIED_FOCUS)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._get_os", return_value="windows")
    @patch("ctypes.windll.user32.GetForegroundWindow")
    def test_screen_click_mismatched_hwnd_blocked(self, mock_get_fg, mock_get_os, mock_pyautogui, mock_require):
        """screen_click with mismatched foreground HWND: click blocked."""
        _set_verified_focus("Notepad", hwnd=12345)
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_get_fg.return_value = 99999  # Different HWND

        result = computer_control({"action": "screen_click", "description": "button"})
        self.assertIn("status=failed", result)
        self.assertIn("focus mismatch", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._get_os", return_value="windows")
    @patch("ctypes.windll.user32.GetForegroundWindow")
    def test_all_protected_actions_use_live_verification(self, mock_get_fg, mock_get_os, mock_pyautogui, mock_require):
        """Every protected action uses live HWND verification."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_get_fg.return_value = 99999  # Different HWND

        protected_actions = [
            {"action": "type", "text": "hello"},
            {"action": "smart_type", "text": "hello"},
            {"action": "click", "x": 100, "y": 200},
            {"action": "double_click", "x": 100, "y": 200},
            {"action": "right_click", "x": 100, "y": 200},
            {"action": "move", "x": 100, "y": 200},
            {"action": "drag", "x1": 100, "y1": 100, "x2": 200, "y2": 200},
            {"action": "hotkey", "keys": "ctrl+c"},
            {"action": "press", "key": "enter"},
            {"action": "paste", "text": "hello"},
            {"action": "clear_field"},
        ]

        for params in protected_actions:
            with self.subTest(action=params["action"]):
                _set_verified_focus("Notepad", hwnd=12345)
                result = computer_control(params)
                self.assertIn("status=failed", result, f"Action {params['action']} should be blocked")
                self.assertIn("focus mismatch", result, f"Action {params['action']} should report focus mismatch")
                with cc_module._FOCUS_STATE_LOCK:
                    self.assertIsNone(cc_module._LAST_VERIFIED_FOCUS, f"State should be cleared after {params['action']}")


class TestFocusWindowEstablishesHWND(unittest.TestCase):
    """Test that focus_window captures and stores HWND on Windows."""

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._get_os", return_value="windows")
    @patch("actions.computer_control.subprocess.run")
    @patch("ctypes.windll.user32.GetForegroundWindow")
    @patch("ctypes.windll.user32.GetWindowTextLengthW")
    @patch("ctypes.windll.user32.GetWindowTextW")
    def test_focus_window_stores_hwnd(self, mock_get_text, mock_get_len, mock_get_fg, mock_run, mock_get_os):
        """focus_window should capture and store HWND after successful focus."""
        mock_run.return_value = Mock(returncode=0)
        mock_get_fg.return_value = 12345
        mock_get_len.return_value = len("Notepad - test.txt")
        # GetWindowTextW writes to the buffer; simulate this with side_effect
        def fill_buffer(hwnd, buf, max_len):
            buf.value = "Notepad - test.txt"
            return len("Notepad - test.txt")
        mock_get_text.side_effect = fill_buffer

        result = computer_control({"action": "focus_window", "title": "Notepad"})

        self.assertIn("status=done", result)
        with cc_module._FOCUS_STATE_LOCK:
            state = cc_module._LAST_VERIFIED_FOCUS
            self.assertIsNotNone(state)
            self.assertEqual(state["hwnd"], 12345)
            self.assertEqual(state["title"], "Notepad")
            self.assertTrue(state["verified"])

    @patch("actions.computer_control._get_os", return_value="windows")
    @patch("actions.computer_control.subprocess.run")
    @patch("ctypes.windll.user32.GetForegroundWindow")
    @patch("ctypes.windll.user32.GetWindowTextLengthW")
    @patch("ctypes.windll.user32.GetWindowTextW")
    def test_focus_window_failed_verification_clears_state(self, mock_get_text, mock_get_len, mock_get_fg, mock_run, mock_get_os):
        """focus_window with failed verification should not store HWND."""
        mock_run.return_value = Mock(returncode=0)
        mock_get_fg.return_value = 12345
        mock_get_len.return_value = len("Other Window")
        def fill_buffer(hwnd, buf, max_len):
            buf.value = "Other Window"
            return len("Other Window")
        mock_get_text.side_effect = fill_buffer

        result = computer_control({"action": "focus_window", "title": "Notepad"})

        # Should be unverified because title doesn't match
        self.assertIn("status=unverified", result)
        with cc_module._FOCUS_STATE_LOCK:
            self.assertIsNone(cc_module._LAST_VERIFIED_FOCUS)

    @patch("actions.computer_control._get_os", return_value="mac")
    @patch("actions.computer_control.subprocess.run")
    def test_focus_window_macos_no_hwnd_stored(self, mock_run, mock_get_os):
        """focus_window on macOS should not store HWND (verification unavailable)."""
        mock_run.return_value = Mock(returncode=0)

        result = computer_control({"action": "focus_window", "title": "Notepad"})

        self.assertIn("status=unverified", result)
        with cc_module._FOCUS_STATE_LOCK:
            self.assertIsNone(cc_module._LAST_VERIFIED_FOCUS)


if __name__ == "__main__":
    unittest.main()