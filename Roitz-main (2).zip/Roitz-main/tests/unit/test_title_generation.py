"""
Regression tests for Milestone 2: Conversation Title Generation.

Tests that titles are correctly derived from summaries and persisted.
"""
import sys
import time
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from memory.conversation_store import ConversationStore
from memory.conversation_models import Conversation


class TestTitleGeneration(unittest.TestCase):
    """Tests for title generation and persistence."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.store = ConversationStore(self.db_path)

    def tearDown(self):
        self.store.close()
        self.temp_dir.cleanup()

    def _create_conversation(self, title: str = "") -> str:
        """Helper: create a conversation and return its ID."""
        conv = Conversation(
            title=title,
            started_at=int(time.time() * 1000),
            engine="gemini_live",
        )
        created = self.store.create_conversation(conv)
        return created.id

    def test_valid_summary_produces_title(self):
        """Valid summary should produce and persist a title."""
        conv_id = self._create_conversation("Original Title")

        # Finalize with a summary - should derive title from it
        summary = "User asked about Python basics. Assistant explained variables and loops."
        self.store.finalize_conversation(conv_id, summary=summary, turn_count=3, title="User asked about Python basics.")

        # Verify title was persisted
        conv = self.store.get_conversation(conv_id)
        self.assertEqual(conv.title, "User asked about Python basics.")

    def test_store_accepts_title_without_truncation(self):
        """Store accepts whatever title is passed; truncation happens in main.py."""
        conv_id = self._create_conversation("Original Title")

        # Very long title (over 60 chars) - store doesn't truncate
        long_title = "A" * 70
        self.store.finalize_conversation(conv_id, summary="test", turn_count=3, title=long_title)

        # Store persists exactly what was passed
        conv = self.store.get_conversation(conv_id)
        self.assertEqual(len(conv.title), 70)
        self.assertEqual(conv.title, "A" * 70)

    def test_empty_summary_does_not_corrupt_existing_title(self):
        """Empty or missing title should not overwrite existing title."""
        conv_id = self._create_conversation("Existing Title")

        # Finalize without providing a title
        self.store.finalize_conversation(conv_id, summary="Some summary", turn_count=3)

        # Original title should be preserved
        conv = self.store.get_conversation(conv_id)
        self.assertEqual(conv.title, "Existing Title")

    def test_none_title_does_not_overwrite(self):
        """Passing None for title should not overwrite existing title."""
        conv_id = self._create_conversation("Existing Title")

        # Explicitly pass None for title
        self.store.finalize_conversation(conv_id, summary="Some summary", turn_count=3, title=None)

        # Original title should be preserved
        conv = self.store.get_conversation(conv_id)
        self.assertEqual(conv.title, "Existing Title")

    def test_existing_callers_without_title_remain_compatible(self):
        """Existing callers that don't pass title should continue working."""
        conv_id = self._create_conversation("Test Conversation")

        # Call without title parameter (old API)
        self.store.finalize_conversation(conv_id, summary="Test summary", turn_count=5)

        # Should not raise, conversation should be finalized
        conv = self.store.get_conversation(conv_id)
        self.assertIsNotNone(conv.ended_at)
        self.assertEqual(conv.summary, "Test summary")
        self.assertEqual(conv.turn_count, 5)
        # Title should remain unchanged (default from creation)
        self.assertEqual(conv.title, "Test Conversation")

    def test_title_extraction_first_sentence(self):
        """Title should be first sentence of summary."""
        conv_id = self._create_conversation("")

        # Simulate main.py title extraction: first sentence
        summary = "User asked about Python. Assistant explained variables. User said thanks."
        # First sentence ends at first period
        title = summary.strip()
        for i, ch in enumerate(title):
            if ch in ".!?":
                title = title[:i + 1]
                break

        self.store.finalize_conversation(conv_id, summary=summary, turn_count=3, title=title)

        conv = self.store.get_conversation(conv_id)
        self.assertEqual(conv.title, "User asked about Python.")

    def test_title_extraction_no_punctuation_falls_back_to_60_chars(self):
        """Summary without sentence punctuation gets first 60 chars (with ellipsis if truncated)."""
        conv_id = self._create_conversation("")

        summary = "User asked about Python basics and got a detailed explanation"
        title = summary.strip()
        for i, ch in enumerate(title):
            if ch in ".!?":
                title = title[:i + 1]
                break
        if len(title) > 60:
            title = title[:57] + "..."

        self.store.finalize_conversation(conv_id, summary=summary, turn_count=3, title=title)

        conv = self.store.get_conversation(conv_id)
        # Title is truncated to 60 chars with ellipsis
        self.assertEqual(len(conv.title), 60)
        self.assertTrue(conv.title.endswith("..."))

    def test_title_truncation_with_ellipsis(self):
        """Title over 60 chars should be truncated with ellipsis."""
        conv_id = self._create_conversation("")

        summary = "A" * 70
        title = summary.strip()
        for i, ch in enumerate(title):
            if ch in ".!?":
                title = title[:i + 1]
                break
        if len(title) > 60:
            title = title[:57] + "..."

        self.store.finalize_conversation(conv_id, summary=summary, turn_count=3, title=title)

        conv = self.store.get_conversation(conv_id)
        self.assertEqual(len(conv.title), 60)
        self.assertTrue(conv.title.endswith("..."))


class TestTitleGenerationIntegration(unittest.TestCase):
    """Integration tests for title generation with session finalization."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"

    def tearDown(self):
        # Windows file locking fix
        time.sleep(0.2)
        self.temp_dir.cleanup()

    def test_session_finalization_generates_and_persists_title(self):
        """End-to-end: session with summary gets title derived and stored."""
        store = ConversationStore(self.db_path)

        # Create conversation
        conv = Conversation(
            title="",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
        )
        created = store.create_conversation(conv)
        conv_id = created.id

        # Add some messages (3 turns = 6 messages)
        for i in range(3):
            store.append_message(type("Message", (), {
                "id": f"user-{i}",
                "conversation_id": conv_id,
                "role": "user",
                "content": f"User message {i}",
                "content_type": "text",
                "sequence": 0,
                "timestamp_ms": int(time.time() * 1000),
                "meta_json": "{}",
                "created_at": int(time.time() * 1000),
            })())
            store.append_message(type("Message", (), {
                "id": f"assistant-{i}",
                "conversation_id": conv_id,
                "role": "assistant",
                "content": f"Assistant reply {i}",
                "content_type": "text",
                "sequence": 0,
                "timestamp_ms": int(time.time() * 1000),
                "meta_json": "{}",
                "created_at": int(time.time() * 1000),
            })())

        # Simulate summary generation and finalization with title
        summary = "User learned Python basics including variables and loops."
        title = summary.strip()
        for i, ch in enumerate(title):
            if ch in ".!?":
                title = title[:i + 1]
                break
        if len(title) > 60:
            title = title[:57] + "..."

        finalized = store.finalize_conversation(conv_id, summary=summary, turn_count=3, title=title)

        # Verify title persisted
        self.assertEqual(finalized.title, "User learned Python basics including variables and loops.")

        store.close()


if __name__ == "__main__":
    unittest.main()