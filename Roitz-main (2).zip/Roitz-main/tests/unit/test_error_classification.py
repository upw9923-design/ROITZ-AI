"""
Unit tests for core/error_classification.py
"""

import sys
import errno
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.error_classification import (
    ErrorClass,
    ClassifiedError,
    classify_error,
    classify_error_string,
    is_retry_eligible,
    _FATAL_EXCEPTION_TYPES,
    _RECOVERABLE_EXCEPTION_TYPES,
    _ERRNO_CLASSIFICATION,
)


class TestErrorClassification(unittest.TestCase):

    # ──────────────────────────────────────────────────────────────────────────
    # Fatal exceptions
    # ──────────────────────────────────────────────────────────────────────────

    def test_value_error_is_fatal(self):
        exc = ValueError("invalid value")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)
        self.assertEqual(result.exception_type, "ValueError")
        self.assertIs(result.original, exc)

    def test_type_error_is_fatal(self):
        exc = TypeError("unsupported operand")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_key_error_is_fatal(self):
        exc = KeyError("missing_key")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_index_error_is_fatal(self):
        exc = IndexError("list index out of range")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_attribute_error_is_fatal(self):
        exc = AttributeError("'NoneType' object has no attribute 'foo'")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_import_error_is_fatal(self):
        exc = ImportError("No module named 'foo'")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_module_not_found_error_is_fatal(self):
        exc = ModuleNotFoundError("No module named 'bar'")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_syntax_error_is_fatal(self):
        exc = SyntaxError("invalid syntax")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_memory_error_is_fatal(self):
        exc = MemoryError("out of memory")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_recursion_error_is_fatal(self):
        exc = RecursionError("maximum recursion depth exceeded")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_not_implemented_error_is_fatal(self):
        exc = NotImplementedError("not implemented")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_assertion_error_is_fatal(self):
        exc = AssertionError("assertion failed")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_all_fatal_types_covered(self):
        """Verify our fatal set covers common programming errors."""
        for exc_type in _FATAL_EXCEPTION_TYPES:
            if exc_type is AssertionError:
                # AssertionError might be optimized away in some contexts
                continue
            try:
                exc = exc_type("test")
                result = classify_error(exc)
                self.assertEqual(result.error_class, ErrorClass.FATAL, f"{exc_type.__name__} should be FATAL")
            except Exception:
                pass  # Some exception types can't be instantiated simply

    # ──────────────────────────────────────────────────────────────────────────
    # Recoverable exceptions
    # ──────────────────────────────────────────────────────────────────────────

    def test_connection_error_is_recoverable(self):
        exc = ConnectionError("connection failed")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_connection_refused_error_is_recoverable(self):
        exc = ConnectionRefusedError("connection refused")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_connection_reset_error_is_recoverable(self):
        exc = ConnectionResetError("connection reset")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_connection_aborted_error_is_recoverable(self):
        exc = ConnectionAbortedError("connection aborted")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_timeout_error_is_non_idempotent_timeout(self):
        """TimeoutError without errno is NON_IDEMPOTENT_TIMEOUT (operation completion unknown)."""
        exc = TimeoutError("operation timed out")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.NON_IDEMPOTENT_TIMEOUT)

    def test_blocking_io_error_is_recoverable(self):
        exc = BlockingIOError("operation would block")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_interrupted_error_is_recoverable(self):
        exc = InterruptedError("system call interrupted")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_child_process_error_is_recoverable(self):
        exc = ChildProcessError("no child process")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_broken_pipe_error_is_recoverable(self):
        exc = BrokenPipeError("broken pipe")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_all_recoverable_types_covered(self):
        for exc_type in _RECOVERABLE_EXCEPTION_TYPES:
            try:
                exc = exc_type("test")
                result = classify_error(exc)
                self.assertEqual(result.error_class, ErrorClass.RECOVERABLE, f"{exc_type.__name__} should be RECOVERABLE")
            except Exception:
                pass

    # ──────────────────────────────────────────────────────────────────────────
    # KeyboardInterrupt and SystemExit
    # ──────────────────────────────────────────────────────────────────────────

    def test_keyboard_interrupt_is_interrupted(self):
        exc = KeyboardInterrupt("user interrupt")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.INTERRUPTED)
        self.assertEqual(result.exception_type, "KeyboardInterrupt")

    def test_system_exit_is_interrupted(self):
        exc = SystemExit(1)
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.INTERRUPTED)
        self.assertEqual(result.exception_type, "SystemExit")

    def test_generator_exit_is_interrupted(self):
        exc = GeneratorExit("generator exit")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.INTERRUPTED)
        self.assertEqual(result.exception_type, "GeneratorExit")

    # ──────────────────────────────────────────────────────────────────────────
    # Unknown custom exception
    # ──────────────────────────────────────────────────────────────────────────

    def test_unknown_custom_exception_is_unknown(self):
        class CustomError(Exception):
            pass

        exc = CustomError("something went wrong")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.UNKNOWN)
        self.assertEqual(result.exception_type, "CustomError")

    def test_runtime_error_is_unknown(self):
        exc = RuntimeError("runtime error")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.UNKNOWN)

    def test_exception_base_class_is_unknown(self):
        exc = Exception("generic exception")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.UNKNOWN)

    # ──────────────────────────────────────────────────────────────────────────
    # POSIX errno classification
    # ──────────────────────────────────────────────────────────────────────────

    def test_oserror_eacces_is_fatal(self):
        exc = OSError(errno.EACCES, "Permission denied")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)
        self.assertEqual(result.errno, errno.EACCES)

    def test_oserror_eperm_is_fatal(self):
        exc = OSError(errno.EPERM, "Operation not permitted")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_oserror_enoent_is_fatal(self):
        exc = OSError(errno.ENOENT, "No such file or directory")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_oserror_eexist_is_fatal(self):
        exc = OSError(errno.EEXIST, "File exists")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_oserror_einval_is_fatal(self):
        exc = OSError(errno.EINVAL, "Invalid argument")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_oserror_enospc_is_fatal(self):
        exc = OSError(errno.ENOSPC, "No space left on device")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.FATAL)

    def test_oserror_eagain_is_recoverable(self):
        exc = OSError(errno.EAGAIN, "Resource temporarily unavailable")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_oserror_ewouldblock_is_recoverable(self):
        exc = OSError(errno.EWOULDBLOCK, "Operation would block")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_oserror_etimedout_is_recoverable(self):
        exc = OSError(errno.ETIMEDOUT, "Connection timed out")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_oserror_econnrefused_is_recoverable(self):
        exc = OSError(errno.ECONNREFUSED, "Connection refused")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_oserror_econnreset_is_recoverable(self):
        exc = OSError(errno.ECONNRESET, "Connection reset by peer")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_oserror_econnaborted_is_recoverable(self):
        exc = OSError(errno.ECONNABORTED, "Connection aborted")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_oserror_epipe_is_recoverable(self):
        exc = OSError(errno.EPIPE, "Broken pipe")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.RECOVERABLE)

    def test_oserror_eintr_is_interrupted(self):
        exc = OSError(errno.EINTR, "Interrupted system call")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.INTERRUPTED)

    def test_oserror_unknown_errno_is_unknown(self):
        # Use an errno that's not in our map
        exc = OSError(99999, "Unknown error")
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.UNKNOWN)
        self.assertEqual(result.errno, 99999)

    def test_oserror_none_errno_is_unknown(self):
        exc = OSError("OS error without errno")
        exc.errno = None
        result = classify_error(exc)
        self.assertEqual(result.error_class, ErrorClass.UNKNOWN)

    def test_all_errno_mappings_valid(self):
        """Verify all errno mappings are valid ErrorClass values."""
        for errno_val, error_class in _ERRNO_CLASSIFICATION.items():
            self.assertIn(error_class, ErrorClass)

    # ──────────────────────────────────────────────────────────────────────────
    # Windows-specific error handling
    # ──────────────────────────────────────────────────────────────────────────

    def test_windows_error_access_denied_is_fatal(self):
        # ERROR_ACCESS_DENIED = 5
        exc = OSError(5, "Access is denied")
        result = classify_error(exc)
        # On Windows, should be FATAL; on POSIX, errno 5 is EIO (not in map -> UNKNOWN)
        # We test that it doesn't crash and returns a valid classification
        self.assertIn(result.error_class, ErrorClass)

    def test_windows_error_file_not_found_is_fatal(self):
        # ERROR_FILE_NOT_FOUND = 2
        exc = OSError(2, "The system cannot find the file specified")
        result = classify_error(exc)
        self.assertIn(result.error_class, ErrorClass)

    def test_windows_error_invalid_param_is_fatal(self):
        # ERROR_INVALID_PARAMETER = 87
        exc = OSError(87, "The parameter is incorrect")
        result = classify_error(exc)
        self.assertIn(result.error_class, ErrorClass)

    def test_windows_error_operation_aborted_is_interrupted(self):
        # ERROR_OPERATION_ABORTED = 995
        exc = OSError(995, "The I/O operation has been aborted")
        result = classify_error(exc)
        self.assertIn(result.error_class, ErrorClass)

    def test_windows_error_connection_errors_are_recoverable(self):
        for win_errno in [10053, 10054, 10060, 10061, 10065]:
            exc = OSError(win_errno, "Windows socket error")
            result = classify_error(exc)
            self.assertIn(result.error_class, ErrorClass)

    # ──────────────────────────────────────────────────────────────────────────
    # Original exception preservation
    # ──────────────────────────────────────────────────────────────────────────

    def test_original_exception_preserved(self):
        original = ValueError("test message")
        result = classify_error(original)
        self.assertIs(result.original, original)

    def test_original_exception_preserved_for_oserror(self):
        original = OSError(errno.ENOENT, "file not found")
        result = classify_error(original)
        self.assertIs(result.original, original)

    def test_original_exception_preserved_for_keyboard_interrupt(self):
        original = KeyboardInterrupt()
        result = classify_error(original)
        self.assertIs(result.original, original)

    def test_exception_type_name_captured(self):
        exc = ValueError("test")
        result = classify_error(exc)
        self.assertEqual(result.exception_type, "ValueError")

    # ──────────────────────────────────────────────────────────────────────────
    # No-retry behaviour for UNKNOWN and INTERRUPTED
    # ──────────────────────────────────────────────────────────────────────────

    def test_unknown_not_retry_eligible(self):
        class CustomError(Exception):
            pass

        classified = classify_error(CustomError("test"))
        self.assertFalse(is_retry_eligible(classified, is_idempotent=True))
        self.assertFalse(is_retry_eligible(classified, is_idempotent=False))

    def test_interrupted_not_retry_eligible(self):
        classified = classify_error(KeyboardInterrupt())
        self.assertFalse(is_retry_eligible(classified, is_idempotent=True))
        self.assertFalse(is_retry_eligible(classified, is_idempotent=False))

    def test_fatal_not_retry_eligible(self):
        classified = classify_error(ValueError("test"))
        self.assertFalse(is_retry_eligible(classified, is_idempotent=True))
        self.assertFalse(is_retry_eligible(classified, is_idempotent=False))

    def test_recoverable_is_retry_eligible(self):
        classified = classify_error(ConnectionError("test"))
        self.assertTrue(is_retry_eligible(classified, is_idempotent=True))
        self.assertTrue(is_retry_eligible(classified, is_idempotent=False))

    def test_non_idempotent_timeout_retry_depends_on_idempotency(self):
        classified = ClassifiedError(
            error_class=ErrorClass.NON_IDEMPOTENT_TIMEOUT,
            reason="test",
        )
        self.assertFalse(is_retry_eligible(classified, is_idempotent=False))
        self.assertTrue(is_retry_eligible(classified, is_idempotent=True))

    # ──────────────────────────────────────────────────────────────────────────
    # Backward compatibility: string-based classification
    # ──────────────────────────────────────────────────────────────────────────

    def test_classify_error_string_fatal_keywords(self):
        for msg in ["Permission denied", "Authentication failed", "File missing", "Invalid parameters", "Circular dependency"]:
            result = classify_error_string(msg)
            self.assertEqual(result, ErrorClass.FATAL, f"'{msg}' should be FATAL")

    def test_classify_error_string_recoverable_keywords(self):
        for msg in ["Connection reset", "Timeout waiting", "Connection refused", "Temporary failure", "Resource busy"]:
            result = classify_error_string(msg)
            self.assertEqual(result, ErrorClass.RECOVERABLE, f"'{msg}' should be RECOVERABLE")

    def test_classify_error_string_unknown_default(self):
        result = classify_error_string("Some completely unknown error message")
        self.assertEqual(result, ErrorClass.UNKNOWN)

    def test_classify_error_string_case_insensitive(self):
        result = classify_error_string("PERMISSION DENIED")
        self.assertEqual(result, ErrorClass.FATAL)


class TestTaskMonitoringIntegration(unittest.TestCase):
    """Integration tests ensuring task_monitoring.py still works with new classifier."""

    def test_import_works(self):
        from core.task_monitoring import (
            ErrorClassification,
            classify_error,
            get_backoff_delay,
            TaskMonitor,
            TaskRecovery,
            MAX_RETRIES,
            STEP_TIMEOUT,
        )
        self.assertIs(ErrorClassification, ErrorClass)

    def test_classify_error_string_compat(self):
        from core.task_monitoring import classify_error
        # Old string-based API should still work
        result = classify_error("Permission denied")
        self.assertEqual(result, ErrorClass.FATAL)
        result = classify_error("Connection timeout")
        self.assertEqual(result, ErrorClass.RECOVERABLE)

    def test_task_recovery_handle_failure_string(self):
        from core.autonomous_agent import TaskStep
        from core.task_monitoring import TaskRecovery

        step = TaskStep(id="s1", description="test", tool="file_controller")
        step.retry_count = 0

        # String error - should use legacy classification
        self.assertTrue(TaskRecovery.handle_failure(step, "Connection reset"))
        self.assertFalse(TaskRecovery.handle_failure(step, "Permission denied"))

    def test_task_recovery_handle_failure_exception(self):
        from core.autonomous_agent import TaskStep
        from core.task_monitoring import TaskRecovery

        step = TaskStep(id="s1", description="test", tool="file_controller")
        step.retry_count = 0

        # Exception - should use new typed classification
        self.assertTrue(TaskRecovery.handle_failure(step, ConnectionError("test")))
        self.assertFalse(TaskRecovery.handle_failure(step, ValueError("test")))
        self.assertFalse(TaskRecovery.handle_failure(step, KeyboardInterrupt()))

    def test_task_recovery_handle_failure_classified_error(self):
        from core.autonomous_agent import TaskStep
        from core.task_monitoring import TaskRecovery
        from core.error_classification import ClassifiedError, ErrorClass

        step = TaskStep(id="s1", description="test", tool="file_controller")
        step.retry_count = 0

        # Pre-classified error
        classified = ClassifiedError(error_class=ErrorClass.RECOVERABLE, reason="test")
        self.assertTrue(TaskRecovery.handle_failure(step, classified))

        classified = ClassifiedError(error_class=ErrorClass.FATAL, reason="test")
        self.assertFalse(TaskRecovery.handle_failure(step, classified))

    def test_task_recovery_respects_max_retries(self):
        from core.autonomous_agent import TaskStep
        from core.task_monitoring import TaskRecovery, MAX_RETRIES

        step = TaskStep(id="s1", description="test", tool="file_controller")
        step.retry_count = MAX_RETRIES

        self.assertFalse(TaskRecovery.handle_failure(step, "Connection reset"))

    def test_backoff_delay(self):
        from core.task_monitoring import get_backoff_delay
        self.assertEqual(get_backoff_delay(1), 1.0)
        self.assertEqual(get_backoff_delay(2), 2.0)
        self.assertEqual(get_backoff_delay(3), 4.0)


if __name__ == "__main__":
    unittest.main()