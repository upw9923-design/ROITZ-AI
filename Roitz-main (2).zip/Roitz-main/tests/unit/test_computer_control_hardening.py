"""
Unit tests for Phase 4 Batch 2: Input Simulation Hardening.

Tests the validation, safety, and reliability improvements to computer_control.py
input actions (mouse/keyboard).

Run with: python -m pytest tests/unit/test_computer_control_hardening.py -v
"""
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from actions import computer_control as cc_module
from actions.computer_control import computer_control


def _set_verified_focus(title: str = "Test Window"):
    """Helper to set verified focus state for tests."""
    with cc_module._FOCUS_STATE_LOCK:
        cc_module._LAST_VERIFIED_FOCUS = {
            "title": title,
            "timestamp": time.time(),
            "verified": True,
        }


def _clear_focus_state():
    """Helper to clear focus state for tests."""
    with cc_module._FOCUS_STATE_LOCK:
        cc_module._LAST_VERIFIED_FOCUS = None


class TestTypeValidation(unittest.TestCase):
    """Test input validation for type action."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_type_valid_text(self, mock_pyautogui, mock_require):
        """Valid text should work - returns unverified since appearance not confirmed."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "type", "text": "hello world"})
        self.assertIn("status=unverified", result)
        self.assertIn("action=type", result)
        self.assertIn("text sent; appearance not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_type_empty_text(self, mock_pyautogui, mock_require):
        """Empty text should work (just types nothing) - returns unverified."""
        result = computer_control({"action": "type", "text": ""})
        self.assertIn("status=unverified", result)
        self.assertIn("text sent; appearance not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_type_text_too_long(self, mock_pyautogui, mock_require):
        """Text exceeding 5000 chars should fail."""
        long_text = "x" * 5001
        result = computer_control({"action": "type", "text": long_text})
        self.assertIn("status=failed", result)
        self.assertIn("exceeds maximum 5000", result)


class TestSmartTypeValidation(unittest.TestCase):
    """Test input validation for smart_type action."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control._require_pyperclip", return_value=True)
    @patch("actions.computer_control.pyperclip")
    @patch("actions.computer_control.pyautogui")
    def test_smart_type_valid(self, mock_pyautogui, mock_pyperclip, mock_require_clip, mock_require):
        """Valid text should work - uses clipboard for text > 20 chars, returns unverified."""
        mock_pyautogui.size.return_value = (1920, 1080)
        # Use text longer than 20 chars to trigger clipboard path
        long_text = "hello world this is a longer text"
        result = computer_control({"action": "smart_type", "text": long_text})
        self.assertIn("status=unverified", result)
        self.assertIn("method=clipboard", result)
        self.assertIn("text sent via clipboard; appearance not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control._require_pyperclip", return_value=False)
    @patch("actions.computer_control.pyautogui")
    def test_smart_type_fallback_to_typewrite(self, mock_pyautogui, mock_require_clip, mock_require):
        """Should fall back to typewrite when clipboard unavailable - returns unverified."""
        result = computer_control({"action": "smart_type", "text": "hello world"})
        self.assertIn("status=unverified", result)
        self.assertIn("method=typewrite", result)
        self.assertIn("text sent via typewrite; appearance not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_smart_type_text_too_long(self, mock_pyautogui, mock_require):
        """Text exceeding 5000 chars should fail."""
        long_text = "x" * 5001
        result = computer_control({"action": "smart_type", "text": long_text})
        self.assertIn("status=failed", result)
        self.assertIn("exceeds maximum 5000", result)


class TestClickValidation(unittest.TestCase):
    """Test input validation for click actions."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_click_valid_coordinates(self, mock_pyautogui, mock_require):
        """Valid coordinates should work - returns unverified."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "click", "x": 100, "y": 200})
        self.assertIn("status=unverified", result)
        self.assertIn("x=100", result)
        self.assertIn("y=200", result)
        self.assertIn("click sent at coordinates; target not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_click_current_position(self, mock_pyautogui, mock_require):
        """Click without coordinates should work at current position - returns unverified."""
        result = computer_control({"action": "click"})
        self.assertIn("status=unverified", result)
        self.assertIn("position=current", result)
        self.assertIn("click sent at current position; target not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_click_negative_coordinates(self, mock_pyautogui, mock_require):
        """Negative coordinates should fail."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "click", "x": -10, "y": 100})
        self.assertIn("status=failed", result)
        self.assertIn("cannot be negative", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_click_out_of_bounds(self, mock_pyautogui, mock_require):
        """Coordinates beyond screen should fail."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "click", "x": 2000, "y": 100})
        self.assertIn("status=failed", result)
        self.assertIn("out of screen bounds", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_click_invalid_button(self, mock_pyautogui, mock_require):
        """Invalid button should fail."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "click", "x": 100, "y": 100, "button": "invalid"})
        self.assertIn("status=failed", result)
        self.assertIn("Invalid button", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_click_invalid_clicks(self, mock_pyautogui, mock_require):
        """Invalid clicks value should fail."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "click", "x": 100, "y": 100, "clicks": 3})
        self.assertIn("status=failed", result)
        self.assertIn("Invalid clicks", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_double_click(self, mock_pyautogui, mock_require):
        """Double click should work - returns unverified."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "double_click", "x": 100, "y": 200})
        self.assertIn("status=unverified", result)
        self.assertIn("clicks=2", result)
        self.assertIn("click sent at coordinates; target not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_right_click(self, mock_pyautogui, mock_require):
        """Right click should work - returns unverified."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "right_click", "x": 100, "y": 200})
        self.assertIn("status=unverified", result)
        self.assertIn("button=right", result)
        self.assertIn("click sent at coordinates; target not verified", result)


class TestMoveValidation(unittest.TestCase):
    """Test input validation for move action."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_move_valid(self, mock_pyautogui, mock_require):
        """Valid move should work - returns unverified."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "move", "x": 100, "y": 200})
        self.assertIn("status=unverified", result)
        self.assertIn("mouse move sent; position not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_move_negative_coordinates(self, mock_pyautogui, mock_require):
        """Negative coordinates should fail."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "move", "x": -10, "y": 100})
        self.assertIn("status=failed", result)
        self.assertIn("cannot be negative", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_move_out_of_bounds(self, mock_pyautogui, mock_require):
        """Coordinates beyond screen should fail."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "move", "x": 2000, "y": 100})
        self.assertIn("status=failed", result)
        self.assertIn("out of screen bounds", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_move_invalid_duration(self, mock_pyautogui, mock_require):
        """Negative duration should fail."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "move", "x": 100, "y": 100, "duration": -1})
        self.assertIn("status=failed", result)
        self.assertIn("cannot be negative", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_move_duration_too_long(self, mock_pyautogui, mock_require):
        """Duration > 10s should fail."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "move", "x": 100, "y": 100, "duration": 15})
        self.assertIn("status=failed", result)
        self.assertIn("exceeds maximum 10s", result)


class TestDragValidation(unittest.TestCase):
    """Test input validation for drag action."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_drag_valid(self, mock_pyautogui, mock_require):
        """Valid drag should work - returns unverified."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "drag", "x1": 100, "y1": 100, "x2": 200, "y2": 200})
        self.assertIn("status=unverified", result)
        self.assertIn("drag sent; result not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_drag_invalid_start_coords(self, mock_pyautogui, mock_require):
        """Invalid start coordinates should fail."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "drag", "x1": -10, "y1": 100, "x2": 200, "y2": 200})
        self.assertIn("status=failed", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_drag_invalid_end_coords(self, mock_pyautogui, mock_require):
        """Invalid end coordinates should fail."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "drag", "x1": 100, "y1": 100, "x2": 2000, "y2": 200})
        self.assertIn("status=failed", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_drag_invalid_duration(self, mock_pyautogui, mock_require):
        """Negative duration should fail."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "drag", "x1": 100, "y1": 100, "x2": 200, "y2": 200, "duration": -1})
        self.assertIn("status=failed", result)
        self.assertIn("cannot be negative", result)


class TestHotkeyValidation(unittest.TestCase):
    """Test input validation for hotkey action."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_hotkey_valid(self, mock_pyautogui, mock_require):
        """Valid hotkey should work - returns unverified."""
        result = computer_control({"action": "hotkey", "keys": "ctrl+c"})
        self.assertIn("status=unverified", result)
        self.assertIn("keys=ctrl+c", result)
        self.assertIn("hotkey sent; effect not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_hotkey_multiple_keys(self, mock_pyautogui, mock_require):
        """Multiple key combination should work - returns unverified."""
        result = computer_control({"action": "hotkey", "keys": "ctrl+shift+esc"})
        self.assertIn("status=unverified", result)
        self.assertIn("keys=ctrl+shift+esc", result)
        self.assertIn("hotkey sent; effect not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_hotkey_empty(self, mock_pyautogui, mock_require):
        """Empty keys should fail."""
        result = computer_control({"action": "hotkey", "keys": ""})
        self.assertIn("status=failed", result)
        self.assertIn("no keys provided", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_hotkey_function_keys(self, mock_pyautogui, mock_require):
        """Function keys should work - returns unverified."""
        result = computer_control({"action": "hotkey", "keys": "f1"})
        self.assertIn("status=unverified", result)
        self.assertIn("keys=f1", result)
        self.assertIn("hotkey sent; effect not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_hotkey_special_keys(self, mock_pyautogui, mock_require):
        """Special keys (enter, tab, etc.) should work - returns unverified."""
        for key in ["enter", "tab", "space", "escape", "up", "down", "left", "right"]:
            with self.subTest(key=key):
                result = computer_control({"action": "hotkey", "keys": key})
                self.assertIn("status=unverified", result)
                self.assertIn("hotkey sent; effect not verified", result)


class TestPressValidation(unittest.TestCase):
    """Test input validation for press action."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_press_valid(self, mock_pyautogui, mock_require):
        """Valid key press should work - returns unverified."""
        result = computer_control({"action": "press", "key": "enter"})
        self.assertIn("status=unverified", result)
        self.assertIn("key=enter", result)
        self.assertIn("key press sent; effect not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_press_function_key(self, mock_pyautogui, mock_require):
        """Function key should work - returns unverified."""
        result = computer_control({"action": "press", "key": "f5"})
        self.assertIn("status=unverified", result)
        self.assertIn("key=f5", result)
        self.assertIn("key press sent; effect not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_press_empty(self, mock_pyautogui, mock_require):
        """Empty key should fail."""
        result = computer_control({"action": "press", "key": ""})
        self.assertIn("status=failed", result)
        self.assertIn("no keys provided", result)


class TestScrollValidation(unittest.TestCase):
    """Test input validation for scroll action."""

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_scroll_valid_up(self, mock_pyautogui, mock_require):
        """Scroll up should work - returns unverified."""
        result = computer_control({"action": "scroll", "direction": "up", "amount": 5})
        self.assertIn("status=unverified", result)
        self.assertIn("direction=up", result)
        self.assertIn("amount=5", result)
        self.assertIn("scroll sent; effect not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_scroll_valid_down(self, mock_pyautogui, mock_require):
        """Scroll down should work - returns unverified."""
        result = computer_control({"action": "scroll", "direction": "down", "amount": 3})
        self.assertIn("status=unverified", result)
        self.assertIn("scroll sent; effect not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_scroll_valid_horizontal(self, mock_pyautogui, mock_require):
        """Horizontal scroll should work - returns unverified."""
        result = computer_control({"action": "scroll", "direction": "left", "amount": 2})
        self.assertIn("status=unverified", result)
        self.assertIn("scroll sent; effect not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_scroll_invalid_direction(self, mock_pyautogui, mock_require):
        """Invalid direction should fail."""
        result = computer_control({"action": "scroll", "direction": "diagonal", "amount": 3})
        self.assertIn("status=failed", result)
        self.assertIn("Invalid direction", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_scroll_zero_amount(self, mock_pyautogui, mock_require):
        """Zero amount should fail."""
        result = computer_control({"action": "scroll", "direction": "down", "amount": 0})
        self.assertIn("status=failed", result)
        self.assertIn("must be positive", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_scroll_negative_amount(self, mock_pyautogui, mock_require):
        """Negative amount should fail."""
        result = computer_control({"action": "scroll", "direction": "down", "amount": -5})
        self.assertIn("status=failed", result)
        self.assertIn("must be positive", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_scroll_amount_too_large(self, mock_pyautogui, mock_require):
        """Amount > 100 should fail."""
        result = computer_control({"action": "scroll", "direction": "down", "amount": 150})
        self.assertIn("status=failed", result)
        self.assertIn("exceeds maximum 100", result)


class TestCopyPasteValidation(unittest.TestCase):
    """Test copy/paste actions."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control._require_pyperclip", return_value=True)
    @patch("actions.computer_control.pyperclip")
    def test_copy_with_pyperclip(self, mock_pyperclip, mock_require_clip, mock_require):
        """Copy with pyperclip should work - returns verified since content is read."""
        mock_pyperclip.paste.return_value = "clipboard content"
        result = computer_control({"action": "copy"})
        self.assertIn("status=done", result)
        self.assertIn("verified=true", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control._require_pyperclip", return_value=False)
    @patch("actions.computer_control.pyautogui")
    def test_copy_without_pyperclip(self, mock_pyautogui, mock_require_clip, mock_require):
        """Copy without pyperclip should use hotkey fallback - returns unverified."""
        result = computer_control({"action": "copy"})
        self.assertIn("status=unverified", result)
        self.assertIn("pyperclip unavailable", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control._require_pyperclip", return_value=True)
    @patch("actions.computer_control.pyperclip")
    @patch("actions.computer_control.pyautogui")
    def test_paste_with_pyperclip(self, mock_pyautogui, mock_pyperclip, mock_require_clip, mock_require):
        """Paste with pyperclip should work - returns unverified since appearance not verified."""
        result = computer_control({"action": "paste", "text": "hello"})
        self.assertIn("status=unverified", result)
        self.assertIn("method=clipboard", result)
        self.assertIn("paste sent via clipboard; appearance not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control._require_pyperclip", return_value=False)
    @patch("actions.computer_control.pyautogui")
    def test_paste_without_pyperclip(self, mock_pyautogui, mock_require_clip, mock_require):
        """Paste without pyperclip should fail."""
        result = computer_control({"action": "paste", "text": "hello"})
        self.assertIn("status=failed", result)
        self.assertIn("pyperclip not available", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control._require_pyperclip", return_value=True)
    @patch("actions.computer_control.pyperclip")
    @patch("actions.computer_control.pyautogui")
    def test_paste_text_too_long(self, mock_pyautogui, mock_pyperclip, mock_require_clip, mock_require):
        """Paste text > 5000 chars should fail."""
        long_text = "x" * 5001
        result = computer_control({"action": "paste", "text": long_text})
        self.assertIn("status=failed", result)
        self.assertIn("exceeds maximum 5000", result)


class TestScreenshotValidation(unittest.TestCase):
    """Test screenshot action."""

    @patch("actions.computer_control.capture_primary_monitor")
    @patch("pathlib.Path.read_bytes")
    def test_screenshot_default_path(self, mock_read_bytes, mock_capture):
        """Screenshot with default path should work - returns verified since file write verified."""
        mock_capture.return_value = (b"fake_image_data", "image/jpeg")
        mock_read_bytes.return_value = b"fake_image_data"
        with patch("builtins.open", unittest.mock.mock_open()):
            result = computer_control({"action": "screenshot"})
            self.assertIn("status=done", result)
            self.assertIn("verified=true", result)

    @patch("actions.computer_control.capture_primary_monitor")
    @patch("pathlib.Path.read_bytes")
    def test_screenshot_custom_path(self, mock_read_bytes, mock_capture):
        """Screenshot with custom path should work - returns verified since file write verified."""
        mock_capture.return_value = (b"fake_image_data", "image/jpeg")
        mock_read_bytes.return_value = b"fake_image_data"
        with patch("builtins.open", unittest.mock.mock_open()):
            result = computer_control({"action": "screenshot", "path": "~/Desktop/test.png"})
            self.assertIn("status=done", result)
            self.assertIn("verified=true", result)


class TestWaitValidation(unittest.TestCase):
    """Test wait action."""

    @patch("actions.computer_control.time")
    def test_wait_valid(self, mock_time):
        """Valid wait should work."""
        result = computer_control({"action": "wait", "seconds": 2.5})
        self.assertIn("status=done", result)
        self.assertIn("seconds=2.5", result)

    @patch("actions.computer_control.time")
    def test_wait_max_cap(self, mock_time):
        """Wait should cap at 30 seconds."""
        result = computer_control({"action": "wait", "seconds": 100})
        self.assertIn("status=done", result)
        self.assertIn("seconds=30.0", result)


class TestClearField(unittest.TestCase):
    """Test clear_field action."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_clear_field(self, mock_pyautogui, mock_require):
        """Clear field should work - returns unverified since field state not verified."""
        result = computer_control({"action": "clear_field"})
        self.assertIn("status=unverified", result)
        self.assertIn("action=clear_field", result)
        self.assertIn("clear sent; field state not verified", result)


class TestFocusWindow(unittest.TestCase):
    """Test focus_window action."""

    def test_focus_window_empty_title(self):
        """Empty title should fail."""
        result = computer_control({"action": "focus_window", "title": ""})
        self.assertIn("status=failed", result)
        self.assertIn("title is required", result)

    def test_focus_window_no_title(self):
        """Missing title should fail."""
        result = computer_control({"action": "focus_window"})
        self.assertIn("status=failed", result)
        self.assertIn("title is required", result)


class TestScreenFindClick(unittest.TestCase):
    """Test screen_find and screen_click actions."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._screen_find")
    def test_screen_find_found(self, mock_find):
        """Screen find with result should return done - coordinates validated against screen bounds."""
        from actions.computer_control import ScreenFindResult
        mock_find.return_value = ScreenFindResult(
            x=100, y=200, confidence=0.8,
            bounding_box=(90, 190, 20, 20), raw_response='{"x":100,"y":200,"confidence":0.8}'
        )
        result = computer_control({"action": "screen_find", "description": "button"})
        self.assertIn("status=done", result)
        self.assertIn("x=100", result)
        self.assertIn("y=200", result)
        self.assertIn("confidence=0.8", result)
        self.assertIn("verified=true", result)

    @patch("actions.computer_control._screen_find")
    def test_screen_find_not_found(self, mock_find):
        """Screen find without result should return failed."""
        mock_find.return_value = None
        result = computer_control({"action": "screen_find", "description": "button"})
        self.assertIn("status=failed", result)
        self.assertIn("Element not found", result)

    @patch("actions.computer_control._screen_find")
    def test_screen_find_empty_description(self, mock_find):
        """Empty description should fail."""
        result = computer_control({"action": "screen_find", "description": ""})
        self.assertIn("status=failed", result)
        self.assertIn("description is required", result)

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control._click")
    def test_screen_click_found(self, mock_click, mock_find):
        """Screen click with found element should work - returns unverified (post-click state not verified)."""
        from actions.computer_control import ScreenFindResult
        mock_find.return_value = ScreenFindResult(
            x=100, y=200, confidence=0.8,
            bounding_box=(90, 190, 20, 20), raw_response='{"x":100,"y":200,"confidence":0.8}'
        )
        mock_click.return_value = "status=unverified action=click x=100 y=200 button=left clicks=1 reason=\"click sent at coordinates; target not verified\""
        result = computer_control({"action": "screen_click", "description": "button"})
        self.assertIn("status=unverified", result)
        self.assertIn("action=screen_click", result)
        self.assertIn("AI find + click sent; target activation not verified", result)
        self.assertIn("confidence=0.8", result)

    @patch("actions.computer_control._screen_find")
    def test_screen_click_not_found(self, mock_find):
        """Screen click without found element should return failed."""
        mock_find.return_value = None
        result = computer_control({"action": "screen_click", "description": "button"})
        self.assertIn("status=failed", result)
        self.assertIn("Element not found", result)

    @patch("actions.computer_control._screen_find")
    def test_screen_click_empty_description(self, mock_find):
        """Empty description should fail."""
        result = computer_control({"action": "screen_click", "description": ""})
        self.assertIn("status=failed", result)
        self.assertIn("description is required", result)

    @patch("actions.computer_control._screen_find")
    def test_screen_find_low_confidence(self, mock_find):
        """Screen find with low confidence should return failed."""
        from actions.computer_control import ScreenFindResult
        mock_find.return_value = ScreenFindResult(
            x=100, y=200, confidence=0.3,
            bounding_box=None, raw_response='{"x":100,"y":200,"confidence":0.3}'
        )
        result = computer_control({"action": "screen_find", "description": "button"})
        self.assertIn("status=failed", result)
        self.assertIn("Low confidence", result)

    @patch("actions.computer_control._screen_find")
    def test_screen_click_low_confidence(self, mock_find):
        """Screen click with low confidence should return failed (refuse to click blindly)."""
        from actions.computer_control import ScreenFindResult
        mock_find.return_value = ScreenFindResult(
            x=100, y=200, confidence=0.3,
            bounding_box=None, raw_response='{"x":100,"y":200,"confidence":0.3}'
        )
        result = computer_control({"action": "screen_click", "description": "button"})
        self.assertIn("status=failed", result)
        self.assertIn("Low confidence", result)
        self.assertIn("refusing to click blindly", result)

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_find_out_of_bounds(self, mock_require, mock_pyautogui, mock_find):
        """Screen find with out-of-bounds coordinates should return failed."""
        from actions.computer_control import ScreenFindResult
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=2000, y=2000, confidence=0.8,
            bounding_box=None, raw_response='{"x":2000,"y":2000,"confidence":0.8}'
        )
        result = computer_control({"action": "screen_find", "description": "button"})
        self.assertIn("status=failed", result)
        self.assertIn("out of screen bounds", result)


class TestRandomDataUserData(unittest.TestCase):
    """Test random_data and user_data actions."""

    def test_random_data(self):
        """Random data generation should work."""
        result = computer_control({"action": "random_data", "type": "email"})
        self.assertIn("status=done", result)
        self.assertIn("type=email", result)
        self.assertIn("verified=true", result)

    @patch("actions.computer_control._user_profile", return_value={"name": "John"})
    def test_user_data_from_memory(self, mock_profile):
        """User data from memory should work."""
        result = computer_control({"action": "user_data", "field": "name"})
        self.assertIn("status=done", result)
        self.assertIn("source=memory", result)

    @patch("actions.computer_control._user_profile", return_value={})
    def test_user_data_fallback_random(self, mock_profile):
        """User data should fall back to random when not in memory."""
        result = computer_control({"action": "user_data", "field": "email"})
        self.assertIn("status=done", result)
        self.assertIn("source=random", result)


class TestUnknownAction(unittest.TestCase):
    """Test unknown action handling."""

    def test_unknown_action(self):
        """Unknown action should return failed."""
        result = computer_control({"action": "invalid_action"})
        self.assertIn("status=failed", result)
        self.assertIn("Unknown action", result)


class TestFAILSAFEPreserved(unittest.TestCase):
    """Test that PyAutoGUI FAILSAFE is preserved."""

    @patch("actions.computer_control.pyautogui")
    def test_failsafe_enabled(self, mock_pyautogui):
        """FAILSAFE should be True after configuration."""
        # The _configure_pyautogui sets FAILSAFE = True
        # This is tested implicitly by the lazy import mechanism
        # We verify the module was configured
        self.assertTrue(hasattr(mock_pyautogui, 'FAILSAFE'))


class TestVerifiedFlagCorrectness(unittest.TestCase):
    """Test that verified=true is only returned when result is genuinely confirmed."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_type_returns_unverified_not_verified(self, mock_pyautogui, mock_require):
        """type should return unverified - only confirms command sent, not text appeared."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "type", "text": "hello"})
        # Now correctly returns unverified
        self.assertIn("status=unverified", result)
        self.assertIn("text sent; appearance not verified", result)
        self.assertNotIn("verified=true", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_click_returns_unverified_not_verified(self, mock_pyautogui, mock_require):
        """click should return unverified - only confirms command sent, not click landed."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "click", "x": 100, "y": 100})
        self.assertIn("status=unverified", result)
        self.assertIn("click sent at coordinates; target not verified", result)
        self.assertNotIn("verified=true", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_hotkey_returns_unverified_not_verified(self, mock_pyautogui, mock_require):
        """hotkey should return unverified - only confirms command sent."""
        result = computer_control({"action": "hotkey", "keys": "ctrl+c"})
        self.assertIn("status=unverified", result)
        self.assertIn("hotkey sent; effect not verified", result)
        self.assertNotIn("verified=true", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_scroll_returns_unverified_not_verified(self, mock_pyautogui, mock_require):
        """scroll should return unverified - only confirms command sent."""
        result = computer_control({"action": "scroll", "direction": "down", "amount": 3})
        self.assertIn("status=unverified", result)
        self.assertIn("scroll sent; effect not verified", result)
        self.assertNotIn("verified=true", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_move_returns_unverified_not_verified(self, mock_pyautogui, mock_require):
        """move should return unverified - only confirms command sent."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "move", "x": 100, "y": 100})
        self.assertIn("status=unverified", result)
        self.assertIn("mouse move sent; position not verified", result)
        self.assertNotIn("verified=true", result)


class TestCoordinateValidationEdgeCases(unittest.TestCase):
    """Test coordinate validation for edge cases - defects now fixed."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_click_string_coordinate_fails_gracefully(self, mock_pyautogui, mock_require):
        """Non-integer string coordinates should fail gracefully with structured error."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "click", "x": "abc", "y": 100})
        # FIXED: Returns structured validation error via outcome.failed()
        self.assertIn("status=failed", result)
        self.assertIn("coordinates must be int or float", result)
        self.assertIn("got str", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_click_float_coordinate_converted_to_int(self, mock_pyautogui, mock_require):
        """Float coordinates should be converted to int (truncated) and work."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "click", "x": 100.5, "y": 100})
        # FIXED: Float converted to int (100), returns unverified
        self.assertIn("status=unverified", result)
        self.assertIn("x=100", result)  # truncated to 100
        self.assertIn("click sent at coordinates; target not verified", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_move_string_coordinate_fails_gracefully(self, mock_pyautogui, mock_require):
        """move with string coordinates should fail gracefully with structured error."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "move", "x": "abc", "y": 100})
        # FIXED: Returns structured validation error via outcome.failed()
        self.assertIn("status=failed", result)
        self.assertIn("coordinates must be int or float", result)
        self.assertIn("got str", result)

    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.pyautogui")
    def test_drag_string_coordinate_fails_gracefully(self, mock_pyautogui, mock_require):
        """drag with string coordinates should fail gracefully with structured error."""
        mock_pyautogui.size.return_value = (1920, 1080)
        result = computer_control({"action": "drag", "x1": "abc", "y1": 100, "x2": 200, "y2": 200})
        # FIXED: Returns structured validation error via outcome.failed()
        self.assertIn("status=failed", result)
        self.assertIn("coordinates must be int or float", result)
        self.assertIn("got str", result)


class TestVerifyWindowFocusUnused(unittest.TestCase):
    """Test that _verify_window_focus behavior is documented (currently unused)."""

    def test_verify_window_focus_exists_but_unused(self):
        """_verify_window_focus is defined but not called by any action."""
        from actions.computer_control import _verify_window_focus
        # Function exists
        self.assertTrue(callable(_verify_window_focus))
        # On macOS/Linux it returns True unconditionally (fails open)
        # On Windows it checks but result is never used
        # This test documents the current state - function is dead code


if __name__ == "__main__":
    unittest.main()