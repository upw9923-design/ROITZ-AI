"""
Unit tests for Dashboard History Endpoints (Milestone 5).

These tests exercise the two new history endpoints:
    GET /api/sessions              — list conversations (paginated)
    GET /api/sessions/{id}/messages — get messages for a conversation (paginated)

Test types:
    - Authentication: valid/expired/missing/invalid tokens
    - Pagination: offset/limit validation, has_more flag, boundaries
    - Error handling: 401, 404, 400 scenarios
    - Data integrity: conversation/message content, ordering

Run with:  py -m pytest tests/unit/test_dashboard_history.py -v
"""

import sys
import time
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

# ── conditional import: tests skip cleanly if fastapi is not available ──────
_SKIP_REASON = None
try:
    from fastapi.testclient import TestClient
except ImportError:
    _SKIP_REASON = "fastapi not installed"

from memory.conversation_store import ConversationStore
from memory.conversation_models import Conversation, Message


# ── helpers ─────────────────────────────────────────────────────────────────

def _make_store(tmp: str) -> ConversationStore:
    """Create a ConversationStore in a temporary directory."""
    db_path = Path(tmp) / "test_history.sqlite3"
    return ConversationStore(db_path)


def _seed_conversations(store: ConversationStore, count: int) -> list[Conversation]:
    """Insert `count` conversations and return them in creation order."""
    convs = []
    base_ts = 1700000000000
    for i in range(count):
        conv = Conversation(
            id=f"conv-{i:04d}",
            title=f"Test Session {i}",
            started_at=base_ts + i * 60_000,
            turn_count=i + 1,
            summary=f"Summary of session {i}",
            language="en",
            engine="gemini_live",
        )
        created = store.create_conversation(conv)
        convs.append(created)
    return convs


def _seed_messages(store: ConversationStore, conversation_id: str,
                   count: int) -> list[Message]:
    """Insert `count` messages into a conversation and return them."""
    msgs = []
    base_ts = 1700000000000
    for i in range(count):
        role = "user" if i % 2 == 0 else "assistant"
        msg = Message(
            conversation_id=conversation_id,
            role=role,
            content=f"Message {i} content",
            content_type="text",
            timestamp_ms=base_ts + i * 1000,
        )
        appended = store.append_message(msg)
        msgs.append(appended)
    return msgs


# ── base test class ─────────────────────────────────────────────────────────

@unittest.skipIf(_SKIP_REASON, _SKIP_REASON or "")
class DashboardHistoryTestBase(unittest.TestCase):
    """Base class that wires up a DashboardServer with a temporary
    ConversationStore and a FastAPI TestClient."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.store = _make_store(self.temp_dir.name)

        # Import here so skip decorator takes effect first
        from dashboard.server import DashboardServer

        self.server = DashboardServer()

        # Inject the store into the server so endpoints can use it.
        # The implementation will access this via self._conversation_store.
        self.server._conversation_store = self.store

        self.client = TestClient(self.server.app)

        # Create a valid token by using the server's key mechanism
        self._session_key = self.server.new_key(expiry_secs=3600)
        # Login to get a token
        resp = self.client.post("/login", json={"pin": self._session_key})
        self.assertEqual(resp.status_code, 200, f"Login failed: {resp.json()}")
        self.token = resp.json()["token"]
        self.auth_header = {"Authorization": f"Bearer {self.token}"}

    def tearDown(self):
        # Close the store and checkpoint WAL
        if hasattr(self, 'store'):
            self.store.close()

        # Windows-specific: SQLite WAL mode can keep file locks briefly
        # Catch PermissionError so tests don't fail during tempdir cleanup
        try:
            self.temp_dir.cleanup()
        except PermissionError:
            pass


# ═══════════════════════════════════════════════════════════════════════════
# 1. AUTHENTICATION TESTS
# ═══════════════════════════════════════════════════════════════════════════

@unittest.skipIf(_SKIP_REASON, _SKIP_REASON or "")
class TestSessionsAuthentication(DashboardHistoryTestBase):
    """Authentication tests for GET /api/sessions."""

    def test_valid_token_returns_200(self):
        """Authenticated request returns 200 OK."""
        resp = self.client.get("/api/sessions", headers=self.auth_header)
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data["ok"])

    def test_missing_token_returns_401(self):
        """No Authorization header → 401."""
        resp = self.client.get("/api/sessions")
        self.assertEqual(resp.status_code, 401)
        data = resp.json()
        self.assertIn("error", data)

    def test_invalid_token_returns_401(self):
        """Garbage token → 401."""
        resp = self.client.get(
            "/api/sessions",
            headers={"Authorization": "Bearer totally-invalid-token"},
        )
        self.assertEqual(resp.status_code, 401)

    def test_empty_bearer_returns_401(self):
        """Empty Bearer value → 401."""
        resp = self.client.get(
            "/api/sessions",
            headers={"Authorization": "Bearer "},
        )
        self.assertEqual(resp.status_code, 401)

    def test_expired_token_returns_401(self):
        """Token past TTL → 401."""
        from dashboard import server as srv
        original_ttl = srv._TOKEN_TTL_SECONDS
        try:
            # Temporarily set TTL to 0 so the existing token is expired
            srv._TOKEN_TTL_SECONDS = 0
            resp = self.client.get("/api/sessions", headers=self.auth_header)
            self.assertEqual(resp.status_code, 401)
        finally:
            srv._TOKEN_TTL_SECONDS = original_ttl


@unittest.skipIf(_SKIP_REASON, _SKIP_REASON or "")
class TestMessagesAuthentication(DashboardHistoryTestBase):
    """Authentication tests for GET /api/sessions/{id}/messages."""

    def setUp(self):
        super().setUp()
        convs = _seed_conversations(self.store, 1)
        self.conv_id = convs[0].id
        _seed_messages(self.store, self.conv_id, 3)

    def test_valid_token_returns_200(self):
        """Authenticated request to messages returns 200."""
        resp = self.client.get(
            f"/api/sessions/{self.conv_id}/messages",
            headers=self.auth_header,
        )
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data["ok"])

    def test_missing_token_returns_401(self):
        """No Authorization header on messages → 401."""
        resp = self.client.get(f"/api/sessions/{self.conv_id}/messages")
        self.assertEqual(resp.status_code, 401)

    def test_invalid_token_returns_401(self):
        """Bad token on messages → 401."""
        resp = self.client.get(
            f"/api/sessions/{self.conv_id}/messages",
            headers={"Authorization": "Bearer bad-token"},
        )
        self.assertEqual(resp.status_code, 401)


# ═══════════════════════════════════════════════════════════════════════════
# 2. LIST SESSIONS TESTS
# ═══════════════════════════════════════════════════════════════════════════

@unittest.skipIf(_SKIP_REASON, _SKIP_REASON or "")
class TestListSessions(DashboardHistoryTestBase):
    """Functional tests for GET /api/sessions."""

    def test_empty_store_returns_empty_list(self):
        """No conversations → empty sessions array with pagination."""
        resp = self.client.get("/api/sessions", headers=self.auth_header)
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data["ok"])
        self.assertEqual(data["sessions"], [])
        self.assertEqual(data["pagination"]["total"], 0)
        self.assertFalse(data["pagination"]["has_more"])

    def test_returns_sessions_with_fields(self):
        """Seeded conversations appear with expected fields."""
        _seed_conversations(self.store, 3)
        resp = self.client.get("/api/sessions", headers=self.auth_header)
        data = resp.json()
        self.assertEqual(len(data["sessions"]), 3)

        session = data["sessions"][0]
        # Verify all required fields per API spec
        # Note: ConversationSummary does not include created_at/updated_at
        for field in ("id", "title", "started_at", "turn_count", "summary", "engine", "language"):
            self.assertIn(field, session, f"Missing field: {field}")

    def test_default_order_descending_by_started_at(self):
        """Default sort is started_at descending (newest first)."""
        _seed_conversations(self.store, 5)
        resp = self.client.get("/api/sessions", headers=self.auth_header)
        data = resp.json()
        sessions = data["sessions"]
        timestamps = [s["started_at"] for s in sessions]
        self.assertEqual(timestamps, sorted(timestamps, reverse=True))

    def test_ascending_order(self):
        """?descending=false returns oldest first."""
        _seed_conversations(self.store, 5)
        resp = self.client.get(
            "/api/sessions?descending=false",
            headers=self.auth_header,
        )
        data = resp.json()
        sessions = data["sessions"]
        timestamps = [s["started_at"] for s in sessions]
        self.assertEqual(timestamps, sorted(timestamps))


# ═══════════════════════════════════════════════════════════════════════════
# 3. PAGINATION TESTS
# ═══════════════════════════════════════════════════════════════════════════

@unittest.skipIf(_SKIP_REASON, _SKIP_REASON or "")
class TestSessionsPagination(DashboardHistoryTestBase):
    """Pagination tests for GET /api/sessions."""

    def setUp(self):
        super().setUp()
        _seed_conversations(self.store, 10)

    def test_default_pagination(self):
        """Default: offset=0, limit=50, returns all 10."""
        resp = self.client.get("/api/sessions", headers=self.auth_header)
        data = resp.json()
        self.assertEqual(len(data["sessions"]), 10)
        pag = data["pagination"]
        self.assertEqual(pag["offset"], 0)
        self.assertEqual(pag["limit"], 50)
        self.assertEqual(pag["total"], 10)
        self.assertFalse(pag["has_more"])

    def test_limit_restricts_count(self):
        """?limit=3 returns exactly 3 sessions."""
        resp = self.client.get(
            "/api/sessions?limit=3",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertEqual(len(data["sessions"]), 3)
        pag = data["pagination"]
        self.assertEqual(pag["limit"], 3)
        self.assertEqual(pag["total"], 10)
        self.assertTrue(pag["has_more"])

    def test_offset_skips_records(self):
        """?offset=7 skips first 7, returns remaining 3."""
        resp = self.client.get(
            "/api/sessions?offset=7",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertEqual(len(data["sessions"]), 3)
        pag = data["pagination"]
        self.assertEqual(pag["offset"], 7)
        self.assertFalse(pag["has_more"])

    def test_offset_plus_limit_has_more(self):
        """?offset=2&limit=3 → has_more=true (5 remain after this page)."""
        resp = self.client.get(
            "/api/sessions?offset=2&limit=3",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertEqual(len(data["sessions"]), 3)
        pag = data["pagination"]
        self.assertTrue(pag["has_more"])

    def test_offset_beyond_total(self):
        """offset > total → empty list, has_more=false."""
        resp = self.client.get(
            "/api/sessions?offset=100",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertEqual(len(data["sessions"]), 0)
        self.assertFalse(data["pagination"]["has_more"])
        self.assertEqual(data["pagination"]["total"], 10)


@unittest.skipIf(_SKIP_REASON, _SKIP_REASON or "")
class TestMessagesPagination(DashboardHistoryTestBase):
    """Pagination tests for GET /api/sessions/{id}/messages."""

    def setUp(self):
        super().setUp()
        convs = _seed_conversations(self.store, 1)
        self.conv_id = convs[0].id
        _seed_messages(self.store, self.conv_id, 20)

    def test_default_pagination(self):
        """Default returns all 20 messages (limit=100)."""
        resp = self.client.get(
            f"/api/sessions/{self.conv_id}/messages",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertEqual(len(data["messages"]), 20)
        pag = data["pagination"]
        self.assertEqual(pag["total"], 20)
        self.assertFalse(pag["has_more"])

    def test_limit_restricts_messages(self):
        """?limit=5 returns exactly 5 messages."""
        resp = self.client.get(
            f"/api/sessions/{self.conv_id}/messages?limit=5",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertEqual(len(data["messages"]), 5)
        pag = data["pagination"]
        self.assertTrue(pag["has_more"])

    def test_offset_skips_messages(self):
        """?offset=15 returns remaining 5 messages."""
        resp = self.client.get(
            f"/api/sessions/{self.conv_id}/messages?offset=15",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertEqual(len(data["messages"]), 5)
        self.assertFalse(data["pagination"]["has_more"])

    def test_messages_ordered_by_sequence(self):
        """Messages are returned in sequence order (ascending)."""
        resp = self.client.get(
            f"/api/sessions/{self.conv_id}/messages",
            headers=self.auth_header,
        )
        data = resp.json()
        sequences = [m["sequence"] for m in data["messages"]]
        self.assertEqual(sequences, sorted(sequences))

    def test_message_fields_present(self):
        """Each message has all required fields."""
        resp = self.client.get(
            f"/api/sessions/{self.conv_id}/messages",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertGreater(len(data["messages"]), 0)
        msg = data["messages"][0]
        for field in ("id", "conversation_id", "role", "content",
                      "content_type", "sequence", "timestamp_ms",
                      "meta_json", "created_at"):
            self.assertIn(field, msg, f"Missing field: {field}")

    def test_conversation_id_in_response(self):
        """Response includes the conversation_id field."""
        resp = self.client.get(
            f"/api/sessions/{self.conv_id}/messages",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertEqual(data["conversation_id"], self.conv_id)


# ═══════════════════════════════════════════════════════════════════════════
# 4. PARAMETER VALIDATION TESTS
# ═══════════════════════════════════════════════════════════════════════════

@unittest.skipIf(_SKIP_REASON, _SKIP_REASON or "")
class TestParameterValidation(DashboardHistoryTestBase):
    """Validation of query parameters for both endpoints."""

    def test_negative_offset_returns_400(self):
        """offset=-1 → 400."""
        resp = self.client.get(
            "/api/sessions?offset=-1",
            headers=self.auth_header,
        )
        self.assertEqual(resp.status_code, 400)

    def test_zero_limit_returns_400(self):
        """limit=0 → 400."""
        resp = self.client.get(
            "/api/sessions?limit=0",
            headers=self.auth_header,
        )
        self.assertEqual(resp.status_code, 400)

    def test_negative_limit_returns_400(self):
        """limit=-5 → 400."""
        resp = self.client.get(
            "/api/sessions?limit=-5",
            headers=self.auth_header,
        )
        self.assertEqual(resp.status_code, 400)

    def test_sessions_limit_capped_at_200(self):
        """limit=999 capped to 200 sessions max."""
        _seed_conversations(self.store, 5)
        resp = self.client.get(
            "/api/sessions?limit=999",
            headers=self.auth_header,
        )
        # Should succeed, capping at max (not error)
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertLessEqual(data["pagination"]["limit"], 200)

    def test_messages_limit_capped_at_500(self):
        """limit=999 capped to 500 messages max."""
        convs = _seed_conversations(self.store, 1)
        _seed_messages(self.store, convs[0].id, 3)
        resp = self.client.get(
            f"/api/sessions/{convs[0].id}/messages?limit=999",
            headers=self.auth_header,
        )
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertLessEqual(data["pagination"]["limit"], 500)

    def test_messages_negative_offset_returns_400(self):
        """offset=-1 on messages → 400."""
        convs = _seed_conversations(self.store, 1)
        resp = self.client.get(
            f"/api/sessions/{convs[0].id}/messages?offset=-1",
            headers=self.auth_header,
        )
        self.assertEqual(resp.status_code, 400)

    def test_messages_zero_limit_returns_400(self):
        """limit=0 on messages → 400."""
        convs = _seed_conversations(self.store, 1)
        resp = self.client.get(
            f"/api/sessions/{convs[0].id}/messages?limit=0",
            headers=self.auth_header,
        )
        self.assertEqual(resp.status_code, 400)


# ═══════════════════════════════════════════════════════════════════════════
# 5. ERROR HANDLING TESTS
# ═══════════════════════════════════════════════════════════════════════════

@unittest.skipIf(_SKIP_REASON, _SKIP_REASON or "")
class TestErrorHandling(DashboardHistoryTestBase):
    """Error scenarios for both endpoints."""

    def test_conversation_not_found_returns_404(self):
        """Non-existent conversation ID → 404."""
        resp = self.client.get(
            "/api/sessions/nonexistent-id-12345/messages",
            headers=self.auth_header,
        )
        self.assertEqual(resp.status_code, 404)
        data = resp.json()
        self.assertIn("error", data)

    def test_empty_conversation_id_returns_404(self):
        """Empty conversation ID → 404 (no route match or explicit 404)."""
        resp = self.client.get(
            "/api/sessions//messages",
            headers=self.auth_header,
        )
        # Either 404 or 405/422 depending on routing; must not be 200
        self.assertNotEqual(resp.status_code, 200)

    def test_conversation_with_no_messages(self):
        """Conversation exists but has no messages → empty list, 200 OK."""
        convs = _seed_conversations(self.store, 1)
        resp = self.client.get(
            f"/api/sessions/{convs[0].id}/messages",
            headers=self.auth_header,
        )
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data["ok"])
        self.assertEqual(data["messages"], [])
        self.assertEqual(data["pagination"]["total"], 0)


# ═══════════════════════════════════════════════════════════════════════════
# 6. DATA INTEGRITY TESTS
# ═══════════════════════════════════════════════════════════════════════════

@unittest.skipIf(_SKIP_REASON, _SKIP_REASON or "")
class TestDataIntegrity(DashboardHistoryTestBase):
    """Verify data returned matches what is stored."""

    def test_session_data_matches_stored(self):
        """Returned session fields match the Conversation in the store."""
        convs = _seed_conversations(self.store, 1)
        conv = convs[0]
        resp = self.client.get("/api/sessions", headers=self.auth_header)
        data = resp.json()
        self.assertEqual(len(data["sessions"]), 1)
        s = data["sessions"][0]
        self.assertEqual(s["id"], conv.id)
        self.assertEqual(s["title"], conv.title)
        self.assertEqual(s["started_at"], conv.started_at)
        self.assertEqual(s["turn_count"], conv.turn_count)
        self.assertEqual(s["engine"], conv.engine)

    def test_message_data_matches_stored(self):
        """Returned message fields match the Messages in the store."""
        convs = _seed_conversations(self.store, 1)
        msgs = _seed_messages(self.store, convs[0].id, 3)
        resp = self.client.get(
            f"/api/sessions/{convs[0].id}/messages",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertEqual(len(data["messages"]), 3)
        for i, m in enumerate(data["messages"]):
            self.assertEqual(m["conversation_id"], convs[0].id)
            self.assertEqual(m["content"], msgs[i].content)
            self.assertEqual(m["role"], msgs[i].role)

    def test_messages_belong_to_correct_conversation(self):
        """Messages from one conversation don't leak into another."""
        convs = _seed_conversations(self.store, 2)
        _seed_messages(self.store, convs[0].id, 5)
        _seed_messages(self.store, convs[1].id, 3)

        # Get messages for first conversation only
        resp = self.client.get(
            f"/api/sessions/{convs[0].id}/messages",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertEqual(len(data["messages"]), 5)
        for m in data["messages"]:
            self.assertEqual(m["conversation_id"], convs[0].id)

        # Verify second conversation has its own count
        resp2 = self.client.get(
            f"/api/sessions/{convs[1].id}/messages",
            headers=self.auth_header,
        )
        data2 = resp2.json()
        self.assertEqual(len(data2["messages"]), 3)
        for m in data2["messages"]:
            self.assertEqual(m["conversation_id"], convs[1].id)

    def test_pagination_total_is_consistent(self):
        """Total count in pagination remains consistent across pages."""
        _seed_conversations(self.store, 10)

        page1 = self.client.get(
            "/api/sessions?offset=0&limit=3",
            headers=self.auth_header,
        ).json()
        page2 = self.client.get(
            "/api/sessions?offset=3&limit=3",
            headers=self.auth_header,
        ).json()

        self.assertEqual(page1["pagination"]["total"],
                         page2["pagination"]["total"])
        self.assertEqual(page1["pagination"]["total"], 10)

    def test_no_duplicate_sessions_across_pages(self):
        """Sessions don't repeat when paginating."""
        _seed_conversations(self.store, 10)

        all_ids = set()
        offset = 0
        limit = 3
        while True:
            resp = self.client.get(
                f"/api/sessions?offset={offset}&limit={limit}",
                headers=self.auth_header,
            )
            data = resp.json()
            page_ids = {s["id"] for s in data["sessions"]}
            # No overlap with previously seen IDs
            self.assertEqual(len(page_ids & all_ids), 0,
                             f"Duplicate IDs found at offset {offset}")
            all_ids |= page_ids
            if not data["pagination"]["has_more"]:
                break
            offset += limit

        self.assertEqual(len(all_ids), 10)


# ═══════════════════════════════════════════════════════════════════════════
# 7. RESPONSE FORMAT TESTS
# ═══════════════════════════════════════════════════════════════════════════

@unittest.skipIf(_SKIP_REASON, _SKIP_REASON or "")
class TestResponseFormat(DashboardHistoryTestBase):
    """Verify JSON response structure matches the API specification."""

    def test_sessions_response_structure(self):
        """GET /api/sessions response has 'ok', 'sessions', 'pagination'."""
        resp = self.client.get("/api/sessions", headers=self.auth_header)
        data = resp.json()
        self.assertIn("ok", data)
        self.assertIn("sessions", data)
        self.assertIn("pagination", data)
        # Pagination sub-fields
        pag = data["pagination"]
        for field in ("offset", "limit", "total", "has_more"):
            self.assertIn(field, pag, f"Missing pagination field: {field}")

    def test_messages_response_structure(self):
        """GET /api/sessions/{id}/messages has 'ok', 'conversation_id', 'messages', 'pagination'."""
        convs = _seed_conversations(self.store, 1)
        resp = self.client.get(
            f"/api/sessions/{convs[0].id}/messages",
            headers=self.auth_header,
        )
        data = resp.json()
        self.assertIn("ok", data)
        self.assertIn("conversation_id", data)
        self.assertIn("messages", data)
        self.assertIn("pagination", data)

    def test_error_response_structure(self):
        """Error responses have 'error' key."""
        resp = self.client.get("/api/sessions")  # no auth
        data = resp.json()
        self.assertIn("error", data)


if __name__ == "__main__":
    unittest.main()
