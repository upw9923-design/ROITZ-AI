"""
Unit tests for Phase 4 Batch 3: Visual Element Interaction.

Tests the improved visual interaction workflow:
- Successful element detection with confidence
- Missing and ambiguous elements
- Low-confidence detections
- Invalid and out-of-bounds coordinates
- Stale screen captures
- Foreground-window changes
- Permission denial
- WorkerRegistry conflicts
- Successful and unsuccessful post-action verification
- Structured outcome correctness

Uses mocks for unit tests. No uncontrolled real desktop interactions.
"""
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from actions import computer_control as cc_module
from actions.computer_control import computer_control, ScreenFindResult


TEST_HWND = 12345

def _set_verified_focus(title: str = "Test Window", hwnd: int = TEST_HWND):
    """Helper to set verified focus state for tests."""
    with cc_module._FOCUS_STATE_LOCK:
        cc_module._LAST_VERIFIED_FOCUS = {
            "title": title,
            "hwnd": hwnd,
            "timestamp": time.time(),
            "verified": True,
        }


def _clear_focus_state():
    """Helper to clear focus state for tests."""
    with cc_module._FOCUS_STATE_LOCK:
        cc_module._LAST_VERIFIED_FOCUS = None


def _mock_foreground_window(hwnd: int = TEST_HWND):
    """Decorator to mock GetForegroundWindow for Windows focus verification."""
    return patch("ctypes.windll.user32.GetForegroundWindow", return_value=hwnd)


class TestSuccessfulElementDetection(unittest.TestCase):
    """Test successful element detection with confidence and evidence."""

    def setUp(self):
        _set_verified_focus("Test Window")
        self.mock_result = ScreenFindResult(
            x=500, y=300, confidence=0.85,
            bounding_box=(490, 290, 20, 20), raw_response='{"x":500,"y":300,"confidence":0.85}'
        )

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_find_returns_done_with_verified_true(self, mock_require, mock_pyautogui, mock_find):
        """Successful detection should return done with verified=true (coordinates validated)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = self.mock_result

        result = computer_control({"action": "screen_find", "description": "submit button"})

        self.assertIn("status=done", result)
        self.assertIn("verified=true", result)
        self.assertIn("x=500", result)
        self.assertIn("y=300", result)
        self.assertIn("confidence=0.85", result)
        self.assertIn('bounding_box="(490, 290, 20, 20)"', result)
        self.assertIn('description="submit button"', result)

    @_mock_foreground_window()
    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control._click")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_click_returns_unverified_with_confidence(self, mock_require, mock_pyautogui, mock_click, mock_find, mock_get_fg):
        """screen_click should return unverified with confidence evidence (post-click not verified)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = self.mock_result
        mock_click.return_value = "status=unverified action=click x=500 y=300 button=left clicks=1 reason=\"click sent at coordinates; target not verified\""

        result = computer_control({"action": "screen_click", "description": "submit button"})

        self.assertIn("status=unverified", result)
        self.assertIn("confidence=0.85", result)
        self.assertIn('bounding_box="(490, 290, 20, 20)"', result)
        self.assertIn("AI find + click sent; target activation not verified", result)


class TestMissingAndAmbiguousElements(unittest.TestCase):
    """Test missing and ambiguous element handling."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_find_element_not_found_returns_failed(self, mock_require, mock_pyautogui, mock_find):
        """Missing element should return failed (not unverified)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = None

        result = computer_control({"action": "screen_find", "description": "nonexistent button"})

        self.assertIn("status=failed", result)
        self.assertIn("Element not found on screen", result)

    @_mock_foreground_window()
    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_click_element_not_found_returns_failed(self, mock_require, mock_pyautogui, mock_find, mock_get_fg):
        """Click on missing element should return failed."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = None

        result = computer_control({"action": "screen_click", "description": "nonexistent button"})

        self.assertIn("status=failed", result)
        self.assertIn("Element not found on screen", result)

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_empty_description_returns_failed(self, mock_require, mock_pyautogui, mock_find):
        """Empty description should return failed for both actions."""
        result = computer_control({"action": "screen_find", "description": ""})
        self.assertIn("status=failed", result)
        self.assertIn("description is required", result)

        # screen_click with empty description fails at validation before focus check
        result = computer_control({"action": "screen_click", "description": ""})
        self.assertIn("status=failed", result)
        self.assertIn("description is required", result)


class TestLowConfidenceDetections(unittest.TestCase):
    """Test low-confidence detection rejection."""

    def setUp(self):
        _set_verified_focus("Test Window")
        self.low_confidence_result = ScreenFindResult(
            x=500, y=300, confidence=0.3,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.3}'
        )

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_find_low_confidence_returns_failed(self, mock_require, mock_pyautogui, mock_find):
        """Low confidence detection should return failed for screen_find."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = self.low_confidence_result

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=failed", result)
        self.assertIn("Low confidence detection", result)
        self.assertIn("0.30", result)

    @_mock_foreground_window()
    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_click_low_confidence_returns_failed(self, mock_require, mock_pyautogui, mock_find, mock_get_fg):
        """Low confidence detection should return failed for screen_click (refuse to click blindly)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = self.low_confidence_result

        result = computer_control({"action": "screen_click", "description": "button"})

        self.assertIn("status=failed", result)
        self.assertIn("Low confidence detection", result)
        self.assertIn("refusing to click blindly", result)

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_confidence_boundary_at_threshold(self, mock_require, mock_pyautogui, mock_find):
        """Confidence exactly at threshold (0.5) should pass."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=500, y=300, confidence=0.5,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.5}'
        )

        result = computer_control({"action": "screen_find", "description": "button"})
        self.assertIn("status=done", result)

        mock_find.return_value = ScreenFindResult(
            x=500, y=300, confidence=0.49,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.49}'
        )

        result = computer_control({"action": "screen_find", "description": "button"})
        self.assertIn("status=failed", result)


class TestInvalidAndOutOfBoundsCoordinates(unittest.TestCase):
    """Test invalid and out-of-bounds coordinate rejection."""

    def setUp(self):
        _set_verified_focus("Test Window")

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_out_of_bounds_coordinates_returns_failed(self, mock_require, mock_pyautogui, mock_find):
        """Coordinates beyond screen dimensions should return failed."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=2000, y=2000, confidence=0.8,
            bounding_box=None, raw_response='{"x":2000,"y":2000,"confidence":0.8}'
        )

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=failed", result)
        self.assertIn("out of screen bounds", result)

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_negative_coordinates_returns_failed(self, mock_require, mock_pyautogui, mock_find):
        """Negative coordinates should return failed."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=-100, y=-50, confidence=0.8,
            bounding_box=None, raw_response='{"x":-100,"y":-50,"confidence":0.8}'
        )

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=failed", result)
        self.assertIn("out of screen bounds", result)

    @_mock_foreground_window()
    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_click_out_of_bounds_returns_failed(self, mock_require, mock_pyautogui, mock_find, mock_get_fg):
        """screen_click with out-of-bounds coordinates should return failed."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=2000, y=2000, confidence=0.8,
            bounding_box=None, raw_response='{"x":2000,"y":2000,"confidence":0.8}'
        )

        result = computer_control({"action": "screen_click", "description": "button"})

        self.assertIn("status=failed", result)
        self.assertIn("out of screen bounds", result)


class TestStaleScreenCaptures(unittest.TestCase):
    """Test stale screen capture detection."""

    def setUp(self):
        _set_verified_focus("Test Window")
        self.valid_result = ScreenFindResult(
            x=500, y=300, confidence=0.8,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.8}'
        )

    def tearDown(self):
        _clear_focus_state()

    @_mock_foreground_window()
    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.capture_primary_monitor")
    def test_stale_capture_detected_via_dimension_change(self, mock_capture, mock_require, mock_pyautogui, mock_find, mock_get_fg):
        """Screen dimension change between find and click should be detected."""
        # First capture: 1920x1080
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = self.valid_result
        mock_capture.return_value = (b"fake", "image/jpeg")

        # After find, screen size changes to 2560x1440
        # The click handler re-queries pyautogui.size() - use side_effect on the mock
        mock_pyautogui.size.side_effect = [(1920, 1080), (2560, 1440), (2560, 1440)]

        result = computer_control({"action": "screen_click", "description": "button"})

        # Should fail because screen dimensions changed
        self.assertIn("status=failed", result)
        self.assertIn("Screen dimensions changed between find and click", result)

    @_mock_foreground_window()
    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("actions.computer_control.capture_primary_monitor")
    @patch("actions.computer_control._compare_screen_region")
    def test_stale_capture_detected_via_content_change(self, mock_compare, mock_capture, mock_require, mock_pyautogui, mock_find, mock_get_fg):
        """Content change with identical dimensions should be detected and block click."""
        # Screen dimensions stay the same
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = self.valid_result
        # First capture for original, second for fresh comparison
        mock_capture.side_effect = [
            (b"original_image", "image/jpeg"),  # original capture
            (b"fresh_image", "image/jpeg"),     # fresh capture for comparison
        ]
        # Content changed - similarity below threshold
        mock_compare.return_value = (False, "Region changed (similarity=0.500 < 0.85)")

        result = computer_control({"action": "screen_click", "description": "button"})

        # Should fail because content changed
        self.assertIn("status=failed", result)
        self.assertIn("Stale capture detected", result)
        # Verify _compare_screen_region was called
        mock_compare.assert_called_once()


class TestForegroundWindowChanges(unittest.TestCase):
    """Test foreground window change detection during visual interaction."""

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control._click")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("ctypes.windll.user32.GetForegroundWindow")
    def test_foreground_change_blocks_screen_click(self, mock_get_fg, mock_require, mock_pyautogui, mock_click, mock_find):
        """Foreground window change during screen_click should block the click."""
        from actions.computer_control import ScreenFindResult

        _set_verified_focus("Notepad", hwnd=12345)
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=500, y=300, confidence=0.8,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.8}'
        )
        # Different HWND returned during live verification
        mock_get_fg.return_value = 99999

        result = computer_control({"action": "screen_click", "description": "button"})

        self.assertIn("status=failed", result)
        self.assertIn("focus mismatch", result)
        self.assertIn("foreground window changed", result)
        # State should be cleared
        with cc_module._FOCUS_STATE_LOCK:
            self.assertIsNone(cc_module._LAST_VERIFIED_FOCUS)


class TestPermissionDenial(unittest.TestCase):
    """Test permission denial for visual interactions."""

    def setUp(self):
        _clear_focus_state()

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_find_without_focus_verification_works(self, mock_require, mock_pyautogui, mock_find):
        """screen_find should work without focus verification (read-only)."""
        from actions.computer_control import ScreenFindResult
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=500, y=300, confidence=0.8,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.8}'
        )

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=done", result)
        self.assertIn("verified=true", result)

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_click_without_focus_verification_blocked(self, mock_require, mock_pyautogui, mock_find):
        """screen_click should be blocked without focus verification."""
        from actions.computer_control import ScreenFindResult
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=500, y=300, confidence=0.8,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.8}'
        )

        # No focus verification set
        result = computer_control({"action": "screen_click", "description": "button"})

        self.assertIn("status=failed", result)
        self.assertIn("focus verification required", result)


class TestWorkerRegistryConflicts(unittest.TestCase):
    """Test WorkerRegistry resource conflict handling for visual interactions."""

    def setUp(self):
        _clear_focus_state()

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_find_reserves_global_display(self, mock_require, mock_pyautogui, mock_find):
        """screen_find should work when global:display is available."""
        from actions.computer_control import ScreenFindResult
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=500, y=300, confidence=0.8,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.8}'
        )

        result = computer_control({"action": "screen_find", "description": "button"})
        self.assertIn("status=done", result)

    @_mock_foreground_window()
    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_click_reserves_global_display_and_input(self, mock_require, mock_pyautogui, mock_find, mock_get_fg):
        """screen_click should reserve both global:display and global:input."""
        from actions.computer_control import ScreenFindResult
        _set_verified_focus("Test Window")
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=500, y=300, confidence=0.8,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.8}'
        )

        with patch("actions.computer_control._click") as mock_click:
            mock_click.return_value = "status=unverified action=click x=500 y=300 button=left clicks=1 reason=\"click sent at coordinates; target not verified\""
            result = computer_control({"action": "screen_click", "description": "button"})
            self.assertIn("status=unverified", result)


class TestPostActionVerification(unittest.TestCase):
    """Test post-action verification outcomes."""

    def setUp(self):
        _set_verified_focus("Test Window")
        self.valid_result = ScreenFindResult(
            x=500, y=300, confidence=0.8,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.8}'
        )

    def tearDown(self):
        _clear_focus_state()

    @_mock_foreground_window()
    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control._click")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_click_returns_unverified_post_action(self, mock_require, mock_pyautogui, mock_click, mock_find, mock_get_fg):
        """screen_click should return unverified (post-click state not verified)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = self.valid_result
        mock_click.return_value = "status=unverified action=click x=500 y=300 button=left clicks=1 reason=\"click sent at coordinates; target not verified\""

        result = computer_control({"action": "screen_click", "description": "button"})

        self.assertIn("status=unverified", result)
        self.assertIn("target activation not verified", result)

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_find_returns_done_verified_coordinates(self, mock_require, mock_pyautogui, mock_find):
        """screen_find should return done with verified=true (coordinates validated against screen)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = self.valid_result

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=done", result)
        self.assertIn("verified=true", result)


class TestStructuredOutcomeCorrectness(unittest.TestCase):
    """Test structured outcome format correctness."""

    def setUp(self):
        _set_verified_focus("Test Window")
        self.valid_result = ScreenFindResult(
            x=500, y=300, confidence=0.85,
            bounding_box=(490, 290, 20, 20), raw_response='{"x":500,"y":300,"confidence":0.85,"bbox":[490,290,20,20]}'
        )

    def tearDown(self):
        _clear_focus_state()

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_find_outcome_structure(self, mock_require, mock_pyautogui, mock_find):
        """screen_find outcome should have all required fields."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = self.valid_result

        result = computer_control({"action": "screen_find", "description": "submit button"})

        # Check required fields
        self.assertIn("status=done", result)
        self.assertIn("action=screen_find", result)
        self.assertIn('description="submit button"', result)
        self.assertIn("x=500", result)
        self.assertIn("y=300", result)
        self.assertIn("confidence=0.85", result)
        self.assertIn("verified=true", result)

    @_mock_foreground_window()
    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control._click")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_click_outcome_structure(self, mock_require, mock_pyautogui, mock_click, mock_find, mock_get_fg):
        """screen_click outcome should have all required fields."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = self.valid_result
        mock_click.return_value = "status=unverified action=click x=500 y=300 button=left clicks=1 reason=\"click sent at coordinates; target not verified\""

        result = computer_control({"action": "screen_click", "description": "submit button"})

        # Check required fields
        self.assertIn("status=unverified", result)
        self.assertIn("action=screen_click", result)
        self.assertIn('description="submit button"', result)
        self.assertIn("x=500", result)
        self.assertIn("y=300", result)
        self.assertIn("confidence=0.85", result)
        self.assertIn('bounding_box="(490, 290, 20, 20)"', result)

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_low_confidence_outcome_includes_confidence_value(self, mock_require, mock_pyautogui, mock_find):
        """Failed outcome for low confidence should include the confidence value."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=500, y=300, confidence=0.3,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.3}'
        )

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=failed", result)
        self.assertIn("confidence=0.3", result)


class TestScreenFindResultDataclass(unittest.TestCase):
    """Test ScreenFindResult dataclass methods."""

    def test_is_valid_within_bounds(self):
        """is_valid should return True for coordinates within screen bounds."""
        result = ScreenFindResult(x=100, y=100, confidence=0.8, bounding_box=None, raw_response="")
        self.assertTrue(result.is_valid(1920, 1080))

    def test_is_valid_out_of_bounds(self):
        """is_valid should return False for coordinates outside screen bounds."""
        result = ScreenFindResult(x=2000, y=2000, confidence=0.8, bounding_box=None, raw_response="")
        self.assertFalse(result.is_valid(1920, 1080))

    def test_is_valid_negative_coordinates(self):
        """is_valid should return False for negative coordinates."""
        result = ScreenFindResult(x=-10, y=-10, confidence=0.8, bounding_box=None, raw_response="")
        self.assertFalse(result.is_valid(1920, 1080))

    def test_is_high_confidence_above_threshold(self):
        """is_high_confidence should return True for confidence above threshold."""
        result = ScreenFindResult(x=100, y=100, confidence=0.8, bounding_box=None, raw_response="")
        self.assertTrue(result.is_high_confidence(0.7))

    def test_is_high_confidence_below_threshold(self):
        """is_high_confidence should return False for confidence below threshold."""
        result = ScreenFindResult(x=100, y=100, confidence=0.5, bounding_box=None, raw_response="")
        self.assertFalse(result.is_high_confidence(0.7))

    def test_is_high_confidence_at_threshold(self):
        """is_high_confidence should return True for confidence at threshold."""
        result = ScreenFindResult(x=100, y=100, confidence=0.7, bounding_box=None, raw_response="")
        self.assertTrue(result.is_high_confidence(0.7))


class TestMalformedJsonHandling(unittest.TestCase):
    """Test handling of malformed JSON from model responses."""

    def setUp(self):
        _set_verified_focus("Test Window")
        self.api_key_patcher = patch("actions.computer_control._get_api_key", return_value="test-key")
        self.api_key_patcher.start()

    def tearDown(self):
        _clear_focus_state()
        self.api_key_patcher.stop()

    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("core.gemini.call")
    def test_malformed_json_returns_failed(self, mock_call, mock_require, mock_pyautogui):
        """Malformed JSON from model should return failed, not crash."""
        mock_pyautogui.size.return_value = (1920, 1080)
        # Return invalid JSON (non-JSON text)
        mock_response = Mock()
        mock_response.text = "not valid json at all"
        mock_call.return_value = mock_response

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=failed", result)
        self.assertIn("Element not found on screen", result)

    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("core.gemini.call")
    def test_missing_x_y_in_json_returns_failed(self, mock_call, mock_require, mock_pyautogui):
        """JSON missing x/y coordinates defaults to (0,0) which passes validation."""
        mock_pyautogui.size.return_value = (1920, 1080)
        # Return JSON without x/y - defaults to 0,0
        mock_response = Mock()
        mock_response.text = '{"confidence": 0.8, "bbox": [100, 100, 50, 50]}'
        mock_call.return_value = mock_response

        result = computer_control({"action": "screen_find", "description": "button"})

        # Current behavior: defaults to x=0, y=0 which is valid
        self.assertIn("status=done", result)
        self.assertIn("x=0", result)
        self.assertIn("y=0", result)

    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("core.gemini.call")
    def test_non_numeric_x_y_returns_failed(self, mock_call, mock_require, mock_pyautogui):
        """Non-numeric x/y in JSON should return failed."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_response = Mock()
        mock_response.text = '{"x": "abc", "y": "def", "confidence": 0.8}'
        mock_call.return_value = mock_response

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=failed", result)


class TestConfidenceClamping(unittest.TestCase):
    """Test confidence value clamping and validation."""

    def setUp(self):
        _set_verified_focus("Test Window")
        self.api_key_patcher = patch("actions.computer_control._get_api_key", return_value="test-key")
        self.api_key_patcher.start()

    def tearDown(self):
        _clear_focus_state()
        self.api_key_patcher.stop()

    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("core.gemini.call")
    def test_negative_confidence_clamped_to_zero(self, mock_call, mock_require, mock_pyautogui):
        """Negative confidence should be treated as low confidence (failed)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_response = Mock()
        mock_response.text = '{"x": 500, "y": 300, "confidence": -0.5}'
        mock_call.return_value = mock_response

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=failed", result)
        self.assertIn("Low confidence detection", result)

    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("core.gemini.call")
    def test_confidence_above_one_clamped_to_one(self, mock_call, mock_require, mock_pyautogui):
        """Confidence > 1 should be treated as high confidence (pass threshold check)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_response = Mock()
        mock_response.text = '{"x": 500, "y": 300, "confidence": 1.5}'
        mock_call.return_value = mock_response

        result = computer_control({"action": "screen_find", "description": "button"})

        # Should pass (treated as 1.0 > 0.5)
        self.assertIn("status=done", result)

    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("core.gemini.call")
    def test_missing_confidence_defaults_to_zero(self, mock_call, mock_require, mock_pyautogui):
        """Missing confidence defaults to 0.5 (at threshold, passes)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_response = Mock()
        mock_response.text = '{"x": 500, "y": 300}'  # no confidence
        mock_call.return_value = mock_response

        result = computer_control({"action": "screen_find", "description": "button"})

        # Current behavior: defaults to 0.5 which is at threshold
        self.assertIn("status=done", result)
        self.assertIn("confidence=0.5", result)


class TestBBoxParsing(unittest.TestCase):
    """Test bounding box parsing from model responses."""

    def setUp(self):
        _set_verified_focus("Test Window")
        self.api_key_patcher = patch("actions.computer_control._get_api_key", return_value="test-key")
        self.api_key_patcher.start()

    def tearDown(self):
        _clear_focus_state()
        self.api_key_patcher.stop()

    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("core.gemini.call")
    def test_valid_bbox_parsed_correctly(self, mock_call, mock_require, mock_pyautogui):
        """Valid bbox array should be parsed correctly."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_response = Mock()
        mock_response.text = '{"x": 500, "y": 300, "confidence": 0.8, "bbox": [490, 290, 20, 20]}'
        mock_call.return_value = mock_response

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=done", result)
        self.assertIn('bounding_box="(490, 290, 20, 20)"', result)

    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("core.gemini.call")
    def test_missing_bbox_is_none(self, mock_call, mock_require, mock_pyautogui):
        """Missing bbox should result in None bounding_box (not included in outcome)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_response = Mock()
        mock_response.text = '{"x": 500, "y": 300, "confidence": 0.8}'
        mock_call.return_value = mock_response

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=done", result)
        self.assertNotIn("bounding_box", result)

    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("core.gemini.call")
    def test_non_list_bbox_is_none(self, mock_call, mock_require, mock_pyautogui):
        """Non-list bbox should result in None bounding_box (not included in outcome)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_response = Mock()
        mock_response.text = '{"x": 500, "y": 300, "confidence": 0.8, "bbox": "invalid"}'
        mock_call.return_value = mock_response

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=done", result)
        self.assertNotIn("bounding_box", result)

    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("core.gemini.call")
    def test_bbox_wrong_length_is_none(self, mock_call, mock_require, mock_pyautogui):
        """BBox with wrong number of elements should result in None (not included in outcome)."""
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_response = Mock()
        mock_response.text = '{"x": 500, "y": 300, "confidence": 0.8, "bbox": [100, 100, 50]}'
        mock_call.return_value = mock_response

        result = computer_control({"action": "screen_find", "description": "button"})

        self.assertIn("status=done", result)
        self.assertNotIn("bounding_box", result)


class TestAmbiguityRejection(unittest.TestCase):
    """Test rejection of ambiguous detections (multiple candidates)."""

    def setUp(self):
        _set_verified_focus("Test Window")
        self.api_key_patcher = patch("actions.computer_control._get_api_key", return_value="test-key")
        self.api_key_patcher.start()

    def tearDown(self):
        _clear_focus_state()
        self.api_key_patcher.stop()

    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    @patch("core.gemini.call")
    def test_multiple_candidates_returns_failed(self, mock_call, mock_require, mock_pyautogui):
        """Multiple candidate elements (JSON array) should return failed."""
        mock_pyautogui.size.return_value = (1920, 1080)
        # Return list of candidates instead of single object (as JSON array)
        mock_response = Mock()
        mock_response.text = '[{"x": 500, "y": 300, "confidence": 0.8}, {"x": 600, "y": 400, "confidence": 0.75}]'
        mock_call.return_value = mock_response

        result = computer_control({"action": "screen_find", "description": "button"})

        # Current behavior: exception caught, returns "Element not found on screen"
        self.assertIn("status=failed", result)
        self.assertIn("Element not found on screen", result)


class TestActualWorkerRegistryConflicts(unittest.TestCase):
    """Test actual WorkerRegistry resource conflict detection via Executor."""

    def setUp(self):
        _clear_focus_state()
        # Import here to avoid circular issues
        from core.worker_registry import WorkerRegistry
        WorkerRegistry._instance = None  # Reset singleton for clean test

    def tearDown(self):
        _clear_focus_state()
        from core.worker_registry import WorkerRegistry
        WorkerRegistry._instance = None

    def test_extract_resource_keys_for_screen_find(self):
        """screen_find should extract global:display resource key."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("computer_control", {"action": "screen_find"}, "screen_find")
        self.assertIn("global:display", keys)

    def test_extract_resource_keys_for_screen_click(self):
        """screen_click should extract global:display and global:input resource keys."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("computer_control", {"action": "screen_click"}, "screen_click")
        self.assertIn("global:display", keys)
        self.assertIn("global:input", keys)

    def test_extract_resource_keys_for_other_actions(self):
        """Other computer_control actions should extract appropriate resource keys."""
        from core.worker_registry import extract_resource_keys
        # click action
        keys = extract_resource_keys("computer_control", {"action": "click"}, "click")
        self.assertIn("global:input", keys)
        # type action
        keys = extract_resource_keys("computer_control", {"action": "type"}, "type")
        self.assertIn("global:input", keys)
        # screenshot action
        keys = extract_resource_keys("computer_control", {"action": "screenshot"}, "screenshot")
        self.assertIn("global:display", keys)

    def test_worker_registry_admit_worker_conflict_detection(self):
        """WorkerRegistry.admit_worker should detect conflicts via resource keys."""
        from core.worker_registry import WorkerRegistry, WorkerRecord, WorkerState
        import threading
        import uuid

        registry = WorkerRegistry()

        # Create first worker with global:display key
        worker1 = WorkerRecord(
            attempt_id=str(uuid.uuid4()),
            task_id="task1",
            step_id="step1",
            tool_name="computer_control",
            operation_name="screen_find",
            resource_keys=("global:display",),
            resource_scope="display",
        )
        worker1.mark_running(threading.current_thread(), threading.Event())

        # Admit first worker
        admitted, reason = registry.admit_worker(worker1)
        self.assertTrue(admitted)

        # Create second worker with same resource key
        worker2 = WorkerRecord(
            attempt_id=str(uuid.uuid4()),
            task_id="task2",
            step_id="step2",
            tool_name="computer_control",
            operation_name="screen_find",
            resource_keys=("global:display",),
            resource_scope="display",
        )
        worker2.mark_running(threading.current_thread(), threading.Event())

        # Second worker should be rejected
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted)
        self.assertIn("global:display", reason)


# Rename TestWorkerRegistryConflicts to TestBasicVisualInteractionFunctionality
class TestBasicVisualInteractionFunctionality(unittest.TestCase):
    """Test basic visual interaction functionality (formerly TestWorkerRegistryConflicts)."""

    def setUp(self):
        _clear_focus_state()

    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_find_reserves_global_display(self, mock_require, mock_pyautogui, mock_find):
        """screen_find should work when global:display is available."""
        from actions.computer_control import ScreenFindResult
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=500, y=300, confidence=0.8,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.8}'
        )

        result = computer_control({"action": "screen_find", "description": "button"})
        self.assertIn("status=done", result)

    @_mock_foreground_window()
    @patch("actions.computer_control._screen_find")
    @patch("actions.computer_control.pyautogui")
    @patch("actions.computer_control._require_pyautogui")
    def test_screen_click_reserves_global_display_and_input(self, mock_require, mock_pyautogui, mock_find, mock_get_fg):
        """screen_click should reserve both global:display and global:input."""
        from actions.computer_control import ScreenFindResult
        _set_verified_focus("Test Window")
        mock_pyautogui.size.return_value = (1920, 1080)
        mock_find.return_value = ScreenFindResult(
            x=500, y=300, confidence=0.8,
            bounding_box=None, raw_response='{"x":500,"y":300,"confidence":0.8}'
        )

        with patch("actions.computer_control._click") as mock_click:
            mock_click.return_value = "status=unverified action=click x=500 y=300 button=left clicks=1 reason=\"click sent at coordinates; target not verified\""
            result = computer_control({"action": "screen_click", "description": "button"})
            self.assertIn("status=unverified", result)


if __name__ == "__main__":
    unittest.main()