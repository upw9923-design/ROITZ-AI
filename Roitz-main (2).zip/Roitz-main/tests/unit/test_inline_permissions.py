"""
Unit tests for Correction B: Direct main.py permission enforcement for 8 inline handlers.

Tests that all 8 inline tools in main.py have proper permission enforcement:
- save_memory
- recall_memory
- undo (and undo:list)
- screen_process:screen / screen_process:camera
- close_camera
- system_status
- manage_monitor:add / manage_monitor:remove / manage_monitor:list
- shutdown_jarvis

Run with: python -m unittest tests/unit/test_inline_permissions.py -v
"""
import sys
import unittest
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.permission_guard import OPERATION_SPECS, get_permission_guard, PermissionGuard
from core.permission_manager import PermissionManager, PermissionResult, OWNER_APPROVAL_REQUIRED
from core.permission_fingerprint import OperationIdentity
from memory.config_manager import BASE_DIR


class TestInlineOperationSpecsExist(unittest.TestCase):
    """Test that all 8 inline tools have OPERATION_SPECS entries."""

    def test_save_memory_spec(self):
        """save_memory should have correct spec."""
        spec = OPERATION_SPECS["save_memory"]
        self.assertEqual(spec.capability, "memory.write")
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope.value, "user_profile")

    def test_recall_memory_spec(self):
        """recall_memory should have correct spec."""
        spec = OPERATION_SPECS["recall_memory"]
        self.assertEqual(spec.capability, "fs.read")
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope.value, "local_file")

    def test_undo_spec(self):
        """undo should have correct spec."""
        spec = OPERATION_SPECS["undo"]
        self.assertEqual(spec.capability, "fs.move")
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope.value, "local_file")

    def test_undo_list_spec(self):
        """undo:list should have correct spec (read-only)."""
        spec = OPERATION_SPECS["undo:list"]
        self.assertEqual(spec.capability, "fs.read")
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope.value, "local_file")

    def test_screen_process_specs(self):
        """screen_process:screen and :camera should have correct specs."""
        for op in ["screen_process:screen", "screen_process:camera"]:
            spec = OPERATION_SPECS[op]
            self.assertEqual(spec.capability, "screen.capture")
            self.assertTrue(spec.idempotent)
            self.assertTrue(spec.read_only)
            self.assertEqual(spec.resource_scope.value, "local_system")

    def test_close_camera_spec(self):
        """close_camera should have correct spec."""
        spec = OPERATION_SPECS["close_camera"]
        self.assertEqual(spec.capability, "screen.capture")
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope.value, "local_system")

    def test_system_status_spec(self):
        """system_status should have correct spec."""
        spec = OPERATION_SPECS["system_status"]
        self.assertEqual(spec.capability, "system.monitor")
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope.value, "local_system")

    def test_manage_monitor_specs(self):
        """manage_monitor:add/remove/list should have correct specs."""
        # add and remove: mutating, not idempotent
        for op in ["manage_monitor:add", "manage_monitor:remove"]:
            spec = OPERATION_SPECS[op]
            self.assertEqual(spec.capability, "net.egress")
            self.assertFalse(spec.idempotent)
            self.assertFalse(spec.read_only)
            self.assertEqual(spec.resource_scope.value, "network_egress")

        # list: read-only, idempotent
        spec = OPERATION_SPECS["manage_monitor:list"]
        self.assertEqual(spec.capability, "net.egress")
        self.assertTrue(spec.idempotent)
        self.assertTrue(spec.read_only)
        self.assertEqual(spec.resource_scope.value, "network_egress")

    def test_shutdown_jarvis_spec(self):
        """shutdown_jarvis should have correct spec."""
        spec = OPERATION_SPECS["shutdown_jarvis"]
        self.assertEqual(spec.capability, "system.shutdown")
        self.assertFalse(spec.idempotent)
        self.assertFalse(spec.read_only)
        self.assertEqual(spec.resource_scope.value, "local_system")


class TestInlinePermissionsEnforcement(unittest.TestCase):
    """Test that permission guard enforces permissions for inline tools."""

    def setUp(self):
        self.pm = Mock(spec=PermissionManager)
        self.guard = PermissionGuard(self.pm)
        self.guard.initialize()

    def test_save_memory_requires_approval(self):
        """save_memory should require owner approval (memory.write in OWNER_APPROVAL_REQUIRED)."""
        self.pm.check.return_value = PermissionResult(False, "owner_approval_required", requires_approval=True)

        result = self.guard.check_operation("save_memory", {"category": "identity", "key": "name", "value": "John"})

        self.assertFalse(result.allowed)
        self.assertTrue(result.requires_approval)
        self.assertEqual(result.reason, "owner_approval_required")

    def test_save_memory_allowed_with_grant(self):
        """save_memory should be allowed with memory.write grant (after approval)."""
        self.pm.check.return_value = PermissionResult(True, "granted")

        result = self.guard.check_operation("save_memory", {"category": "identity", "key": "name", "value": "John"})

        self.assertTrue(result.allowed)

    def test_recall_memory_auto_allowed(self):
        """recall_memory should be auto-allowed (fs.read is in AUTO_ALLOW)."""
        self.pm.check.return_value = PermissionResult(True, "auto_allow")

        result = self.guard.check_operation("recall_memory", {"query": "name"})

        self.assertTrue(result.allowed)

    def test_undo_requires_approval(self):
        """undo (mutating) should require owner approval (fs.move in OWNER_APPROVAL_REQUIRED)."""
        self.pm.check.return_value = PermissionResult(False, "owner_approval_required", requires_approval=True)

        result = self.guard.check_operation("undo", {"action": "undo"})

        self.assertFalse(result.allowed)
        self.assertTrue(result.requires_approval)

    def test_undo_list_auto_allowed(self):
        """undo:list (read-only) should be auto-allowed (fs.read in AUTO_ALLOW)."""
        self.pm.check.return_value = PermissionResult(True, "auto_allow")

        result = self.guard.check_operation("undo:list", {"action": "list"})

        self.assertTrue(result.allowed)

    def test_screen_process_auto_allowed(self):
        """screen_process should be auto-allowed (screen.capture in AUTO_ALLOW)."""
        self.pm.check.return_value = PermissionResult(True, "auto_allow")

        for op in ["screen_process:screen", "screen_process:camera"]:
            result = self.guard.check_operation(op, {"angle": op.split(":")[1], "text": "What do you see?"})
            self.assertTrue(result.allowed, f"{op} should be auto-allowed")

    def test_close_camera_auto_allowed(self):
        """close_camera should be auto-allowed (screen.capture in AUTO_ALLOW)."""
        self.pm.check.return_value = PermissionResult(True, "auto_allow")

        result = self.guard.check_operation("close_camera", {})

        self.assertTrue(result.allowed)

    def test_system_status_auto_allowed(self):
        """system_status should be auto-allowed (system.monitor in AUTO_ALLOW)."""
        self.pm.check.return_value = PermissionResult(True, "auto_allow")

        result = self.guard.check_operation("system_status", {})

        self.assertTrue(result.allowed)

    def test_manage_monitor_add_requires_approval(self):
        """manage_monitor:add should require owner approval (net.egress in OWNER_APPROVAL_REQUIRED)."""
        self.pm.check.return_value = PermissionResult(False, "owner_approval_required", requires_approval=True)

        result = self.guard.check_operation("manage_monitor:add", {"action": "add", "topic": "AI news"})

        self.assertFalse(result.allowed)
        self.assertTrue(result.requires_approval)

    def test_manage_monitor_remove_requires_approval(self):
        """manage_monitor:remove should require owner approval (net.egress in OWNER_APPROVAL_REQUIRED)."""
        self.pm.check.return_value = PermissionResult(False, "owner_approval_required", requires_approval=True)

        result = self.guard.check_operation("manage_monitor:remove", {"action": "remove", "topic": "AI news"})

        self.assertFalse(result.allowed)
        self.assertTrue(result.requires_approval)

    def test_manage_monitor_list_auto_allowed(self):
        """manage_monitor:list should be allowed (net.egress not in AUTO_ALLOW but has grant)."""
        # net.egress is NOT in AUTO_ALLOW, so it needs a grant or approval
        self.pm.check.return_value = PermissionResult(True, "granted")

        result = self.guard.check_operation("manage_monitor:list", {"action": "list"})

        self.assertTrue(result.allowed)

    def test_shutdown_jarvis_requires_approval(self):
        """shutdown_jarvis should require owner approval (system.shutdown in OWNER_APPROVAL_REQUIRED)."""
        self.pm.check.return_value = PermissionResult(False, "owner_approval_required", requires_approval=True)

        result = self.guard.check_operation("shutdown_jarvis", {})

        self.assertFalse(result.allowed)
        self.assertTrue(result.requires_approval)


class TestComputerControlPermissionsEnforcement(unittest.TestCase):
    """Test that permission guard enforces permissions for computer_control operations."""

    def setUp(self):
        self.pm = Mock(spec=PermissionManager)
        self.guard = PermissionGuard(self.pm)
        self.guard.initialize()

    def test_computer_control_screenshot_auto_allowed(self):
        """computer_control:screenshot should be auto-allowed (screen.capture in AUTO_ALLOW)."""
        self.pm.check.return_value = PermissionResult(True, "auto_allow")

        result = self.guard.check_operation("computer_control:screenshot", {"action": "screenshot"})

        self.assertTrue(result.allowed)

    def test_computer_control_close_app_requires_approval(self):
        """computer_control:close_app should require owner approval (app.manage in OWNER_APPROVAL_REQUIRED)."""
        self.pm.check.return_value = PermissionResult(False, "owner_approval_required", requires_approval=True)

        result = self.guard.check_operation("computer_control:close_app", {"action": "close_app", "app_name": "Notepad"})

        self.assertFalse(result.allowed)
        self.assertTrue(result.requires_approval)
        self.assertEqual(result.reason, "owner_approval_required")

    def test_computer_control_close_app_allowed_with_grant(self):
        """computer_control:close_app should be allowed with app.manage grant (after approval)."""
        self.pm.check.return_value = PermissionResult(True, "granted")

        result = self.guard.check_operation("computer_control:close_app", {"action": "close_app", "app_name": "Notepad"})

        self.assertTrue(result.allowed)

    def test_computer_control_focus_window_requires_approval(self):
        """computer_control:focus_window should require owner approval (app.manage in OWNER_APPROVAL_REQUIRED)."""
        self.pm.check.return_value = PermissionResult(False, "owner_approval_required", requires_approval=True)

        result = self.guard.check_operation("computer_control:focus_window", {"action": "focus_window", "title": "Notepad"})

        self.assertFalse(result.allowed)
        self.assertTrue(result.requires_approval)

    def test_computer_control_focus_window_allowed_with_grant(self):
        """computer_control:focus_window should be allowed with app.manage grant (after approval)."""
        self.pm.check.return_value = PermissionResult(True, "granted")

        result = self.guard.check_operation("computer_control:focus_window", {"action": "focus_window", "title": "Notepad"})

        self.assertTrue(result.allowed)


class TestInlinePermissionsCapabilities(unittest.TestCase):
    """Test that new capabilities are properly defined."""

    def test_system_monitor_capability_exists(self):
        """system.monitor capability should exist in CAPABILITIES."""
        from core.permission_manager import CAPABILITIES
        self.assertIn("system.monitor", CAPABILITIES)
        self.assertEqual(CAPABILITIES["system.monitor"]["risk"], "low")

    def test_system_shutdown_capability_exists(self):
        """system.shutdown capability should exist in CAPABILITIES."""
        from core.permission_manager import CAPABILITIES
        self.assertIn("system.shutdown", CAPABILITIES)
        self.assertEqual(CAPABILITIES["system.shutdown"]["risk"], "high")

    def test_system_monitor_in_auto_allow(self):
        """system.monitor should be in AUTO_ALLOW."""
        from core.permission_manager import AUTO_ALLOW
        self.assertIn("system.monitor", AUTO_ALLOW)

    def test_system_shutdown_in_owner_approval_required(self):
        """system.shutdown should be in OWNER_APPROVAL_REQUIRED."""
        from core.permission_manager import OWNER_APPROVAL_REQUIRED
        self.assertIn("system.shutdown", OWNER_APPROVAL_REQUIRED)

    def test_memory_write_capability_exists(self):
        """memory.write capability should exist in CAPABILITIES."""
        from core.permission_manager import CAPABILITIES
        self.assertIn("memory.write", CAPABILITIES)
        self.assertEqual(CAPABILITIES["memory.write"]["risk"], "high")

    def test_memory_write_in_owner_approval_required(self):
        """memory.write should be in OWNER_APPROVAL_REQUIRED."""
        from core.permission_manager import OWNER_APPROVAL_REQUIRED
        self.assertIn("memory.write", OWNER_APPROVAL_REQUIRED)

    def test_memory_write_not_in_auto_allow(self):
        """memory.write should NOT be in AUTO_ALLOW."""
        from core.permission_manager import AUTO_ALLOW
        self.assertNotIn("memory.write", AUTO_ALLOW)

    def test_app_manage_capability_exists(self):
        """app.manage capability should exist in CAPABILITIES."""
        from core.permission_manager import CAPABILITIES
        self.assertIn("app.manage", CAPABILITIES)
        self.assertEqual(CAPABILITIES["app.manage"]["risk"], "high")

    def test_app_manage_in_owner_approval_required(self):
        """app.manage should be in OWNER_APPROVAL_REQUIRED."""
        from core.permission_manager import OWNER_APPROVAL_REQUIRED
        self.assertIn("app.manage", OWNER_APPROVAL_REQUIRED)

    def test_app_manage_not_in_auto_allow(self):
        """app.manage should NOT be in AUTO_ALLOW."""
        from core.permission_manager import AUTO_ALLOW
        self.assertNotIn("app.manage", AUTO_ALLOW)

    def test_screen_capture_in_auto_allow(self):
        """screen.capture should be in AUTO_ALLOW for local operations."""
        from core.permission_manager import AUTO_ALLOW
        self.assertIn("screen.capture", AUTO_ALLOW)


class TestMainPyPermissionCheckIntegration(unittest.TestCase):
    """Integration tests simulating main.py's _execute_tool permission checks."""

    @patch("core.permission_guard.get_permission_guard")
    def test_save_memory_permission_check_in_main(self, mock_get_guard):
        """main.py should call permission guard for save_memory."""
        mock_guard = Mock()
        mock_guard.check_operation.return_value = PermissionResult(True, "granted")
        mock_get_guard.return_value = mock_guard

        # Import the actual function logic (simulated)
        from core.permission_guard import get_permission_guard as real_get_guard
        # This tests the pattern used in main.py
        guard = real_get_guard()
        guard.initialize()

        # Verify the pattern works
        result = guard.check_operation("save_memory", {"category": "identity", "key": "name", "value": "John"})
        # In real test, we'd mock the permission manager

    @patch("main.JarvisLive._execute_tool")
    def test_all_inline_tools_have_permission_checks(self, mock_execute_tool):
        """Verify all 8 inline tools would have permission checks."""
        # This is a structural test - we verify the code pattern exists
        # by checking the main.py source
        main_py = Path(__file__).parent.parent.parent / "main.py"
        content = main_py.read_text(encoding="utf-8")

        # Check that each tool has a permission check call
        # We check for the guard.check_operation pattern with the tool name
        inline_tools = [
            "save_memory",
            "recall_memory",
            "undo",
            "screen_process",
            "close_camera",
            "system_status",
            "manage_monitor",
            "shutdown_jarvis",
        ]

        for tool in inline_tools:
            # Check that there's a permission check pattern for each tool
            # The pattern in main.py is: guard.check_operation("tool_name", args)
            # or guard.check_operation(operation_name, args) where operation_name is a variable
            # We search for the tool name near a check_operation call
            # For tools with dynamic operation_name, we check the tool handler has permission check logic
            if tool in ("undo", "screen_process", "manage_monitor"):
                # These use dynamic operation_name variable
                self.assertIn(f'name == "{tool}"', content, f"Tool {tool} handler not found")
                # Check that check_operation is called in this handler
                handler_start = content.find(f'name == "{tool}"')
                handler_end = content.find("elif name ==", handler_start)
                if handler_end == -1:
                    handler_end = content.find("else:", handler_start)
                handler_code = content[handler_start:handler_end] if handler_end != -1 else content[handler_start:]
                self.assertIn("check_operation", handler_code, f"Tool {tool} missing check_operation call")
            else:
                # These use string literal
                self.assertIn(f'check_operation("{tool}"', content, f"Tool {tool} missing permission check in main.py")


class TestRegressionInlineToolsStillWork(unittest.TestCase):
    """Regression tests to ensure inline tools still function when allowed."""

    def setUp(self):
        self.pm = Mock(spec=PermissionManager)
        self.guard = PermissionGuard(self.pm)
        self.guard.initialize()

    def test_save_memory_with_valid_grant(self):
        """save_memory works with valid grant."""
        self.pm.check.return_value = PermissionResult(True, "granted")

        result = self.guard.check_operation("save_memory", {"category": "identity", "key": "name", "value": "John"})
        self.assertTrue(result.allowed)

    def test_recall_memory_works(self):
        """recall_memory works (auto-allow)."""
        self.pm.check.return_value = PermissionResult(True, "auto_allow")

        result = self.guard.check_operation("recall_memory", {"query": "name"})
        self.assertTrue(result.allowed)

    def test_undo_works_with_approval(self):
        """undo works after owner approval."""
        # First check returns approval_required
        # After approval, grant is created
        self.pm.check.return_value = PermissionResult(True, "approved")

        result = self.guard.check_operation("undo", {"action": "undo"})
        self.assertTrue(result.allowed)

    def test_shutdown_jarvis_works_with_approval(self):
        """shutdown_jarvis works after owner approval."""
        self.pm.check.return_value = PermissionResult(True, "approved")

        result = self.guard.check_operation("shutdown_jarvis", {})
        self.assertTrue(result.allowed)

    def test_computer_control_screenshot_works(self):
        """computer_control:screenshot works (auto-allow)."""
        self.pm.check.return_value = PermissionResult(True, "auto_allow")

        result = self.guard.check_operation("computer_control:screenshot", {"action": "screenshot"})
        self.assertTrue(result.allowed)

    def test_computer_control_close_app_works_with_approval(self):
        """computer_control:close_app works after owner approval."""
        self.pm.check.return_value = PermissionResult(True, "approved")

        result = self.guard.check_operation("computer_control:close_app", {"action": "close_app", "app_name": "Notepad"})
        self.assertTrue(result.allowed)

    def test_computer_control_focus_window_works_with_approval(self):
        """computer_control:focus_window works after owner approval."""
        self.pm.check.return_value = PermissionResult(True, "approved")

        result = self.guard.check_operation("computer_control:focus_window", {"action": "focus_window", "title": "Notepad"})
        self.assertTrue(result.allowed)


class TestScreenCapturePrivacyPolicy(unittest.TestCase):
    """Test screen capture privacy: local vs remote, explicit user control."""

    def setUp(self):
        self.pm = Mock(spec=PermissionManager)
        self.guard = PermissionGuard(self.pm)
        self.guard.initialize()

    def test_screen_capture_auto_allowed_for_local(self):
        """screen.capture capability is AUTO_ALLOW for local user-initiated operations."""
        from core.permission_manager import AUTO_ALLOW
        self.assertIn("screen.capture", AUTO_ALLOW)

        self.pm.check.return_value = PermissionResult(True, "auto_allow")

        # Local screen capture operations
        for op in ["screen_process:screen", "screen_process:camera",
                   "computer_control:screen_find", "computer_control:screenshot",
                   "browser_control:screenshot"]:
            result = self.guard.check_operation(op, {"action": op.split(":")[-1]})
            self.assertTrue(result.allowed, f"{op} should be auto-allowed for local")

    def test_screen_capture_not_auto_allowed_for_remote_without_approval(self):
        """Remote-initiated screen capture should require approval if capability requires it.

        Note: screen.capture is in AUTO_ALLOW, so it will be allowed even for remote.
        The protection against remote monitoring is at the Telegram bot level:
        - telegram_bot:command requires remote.command (OWNER_APPROVAL_REQUIRED)
        - telegram_bot:send requires messaging.send (OWNER_APPROVAL_REQUIRED)
        - telegram_bot:poll requires net.egress (OWNER_APPROVAL_REQUIRED)
        So remote commands cannot bypass the Telegram bot's own approval requirements.
        """
        from core.permission_manager import AUTO_ALLOW, OWNER_APPROVAL_REQUIRED

        # screen.capture is in AUTO_ALLOW - this is intentional for local usability
        self.assertIn("screen.capture", AUTO_ALLOW)

        # But the remote command capabilities require approval
        self.assertIn("remote.command", OWNER_APPROVAL_REQUIRED)
        self.assertIn("messaging.send", OWNER_APPROVAL_REQUIRED)
        self.assertIn("net.egress", OWNER_APPROVAL_REQUIRED)

        # If a remote command tries to trigger screen capture, it must first pass
        # the Telegram bot's own permission checks (which require approval)
        self.pm.check.return_value = PermissionResult(True, "auto_allow")
        result = self.guard.check_operation("screen_process:screen", {"angle": "screen", "text": "test"})
        self.assertTrue(result.allowed)  # screen.capture itself is auto-allow

        # But the remote command that would trigger it (telegram_bot:command) requires approval
        self.pm.check.return_value = PermissionResult(False, "owner_approval_required", requires_approval=True)
        result = self.guard.check_operation("telegram_bot:command", {"action": "command", "command": "screenshot"})
        self.assertFalse(result.allowed)
        self.assertTrue(result.requires_approval)

    def test_remote_access_cannot_bypass_permission_guard(self):
        """Remote access (Telegram) operations require their own approval, cannot bypass guard."""
        # telegram_bot operations all require approval or grants
        remote_ops = [
            "telegram_bot:command",
            "telegram_bot:send",
            "telegram_bot:poll",
            "telegram_bot:start_polling",
            "telegram_bot:stop_polling",
        ]

        for op in remote_ops:
            spec = OPERATION_SPECS[op]
            # Each remote operation has its own capability that requires approval
            self.assertIn(spec.capability, OWNER_APPROVAL_REQUIRED or ["remote.command", "messaging.send", "net.egress"])

        # Verify permission guard checks each operation independently
        self.pm.check.return_value = PermissionResult(False, "owner_approval_required", requires_approval=True)

        for op in remote_ops:
            result = self.guard.check_operation(op, {"action": "test"})
            self.assertFalse(result.allowed, f"{op} should require approval")
            self.assertTrue(result.requires_approval, f"{op} should require approval")


class TestRemoteAccessPolicy(unittest.TestCase):
    """Test that remote access cannot bypass owner authentication or permission checks."""

    def setUp(self):
        self.pm = Mock(spec=PermissionManager)
        self.guard = PermissionGuard(self.pm)
        self.guard.initialize()

    def test_telegram_bot_operations_require_approval(self):
        """All telegram_bot operations that could trigger screen capture require approval."""
        from core.permission_manager import OWNER_APPROVAL_REQUIRED

        # These capabilities are in OWNER_APPROVAL_REQUIRED
        self.assertIn("remote.command", OWNER_APPROVAL_REQUIRED)
        self.assertIn("messaging.send", OWNER_APPROVAL_REQUIRED)
        self.assertIn("net.egress", OWNER_APPROVAL_REQUIRED)

    def test_send_message_requires_approval(self):
        """send_message (WhatsApp/Telegram) requires owner approval."""
        from core.permission_manager import OWNER_APPROVAL_REQUIRED
        self.assertIn("messaging.send", OWNER_APPROVAL_REQUIRED)

        self.pm.check.return_value = PermissionResult(False, "owner_approval_required", requires_approval=True)

        for op in ["send_message:whatsapp", "send_message:telegram"]:
            result = self.guard.check_operation(op, {"platform": op.split(":")[1], "message": "test"})
            self.assertFalse(result.allowed)
            self.assertTrue(result.requires_approval)

    def test_no_parallel_permission_system(self):
        """Verify we use existing permission architecture, not a parallel system."""
        # All permission checks go through PermissionGuard.check_operation
        # which uses PermissionManager.check which enforces CAPABILITIES, AUTO_ALLOW, OWNER_APPROVAL_REQUIRED
        # There is no separate "remote consent" or "session consent" mechanism
        # The existing architecture already provides:
        # - AUTO_ALLOW for low-risk local operations
        # - OWNER_APPROVAL_REQUIRED for high-risk operations
        # - Persistent grants after explicit approval
        # This test documents the design decision
        from core.permission_manager import CAPABILITIES, AUTO_ALLOW, OWNER_APPROVAL_REQUIRED

        # screen.capture is in AUTO_ALLOW (local user control via explicit tool calls)
        self.assertIn("screen.capture", AUTO_ALLOW)
        # High-risk remote capabilities require approval
        self.assertIn("remote.command", OWNER_APPROVAL_REQUIRED)
        self.assertIn("messaging.send", OWNER_APPROVAL_REQUIRED)
        self.assertIn("net.egress", OWNER_APPROVAL_REQUIRED)
        # app.manage requires approval (closing/focusing apps)
        self.assertIn("app.manage", OWNER_APPROVAL_REQUIRED)


if __name__ == "__main__":
    unittest.main()