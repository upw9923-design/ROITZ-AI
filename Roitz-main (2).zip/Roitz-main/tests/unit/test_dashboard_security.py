"""
Unit tests for Dashboard Security Hardening (Milestone 7).

Tests:
1. CallerIdentity creation and attributes for dashboard callers
2. Owner vs Guest distinction:
   - First session is assigned Owner
   - Subsequent distinct sessions are assigned Guest
3. Privilege enforcement:
   - Owner-only endpoints (/api/command, /api/revoke-devices, /api/claude-task)
   - Owner access -> Allowed (200/expected)
   - Guest access -> Rejected with 403 Forbidden
4. Thread-local identity lifecycle:
   - set_current_identity / clear_current_identity around requests
"""

import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import AsyncMock

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

_SKIP_REASON = None
try:
    from fastapi.testclient import TestClient
except ImportError:
    _SKIP_REASON = "fastapi not installed"

from core.identity import get_current_identity, IDENTITY_SOURCE_DASHBOARD


@unittest.skipIf(_SKIP_REASON, _SKIP_REASON or "")
class TestDashboardSecurityHardening(unittest.TestCase):
    """Test suite for Milestone 7 security hardening."""

    def setUp(self):
        from dashboard.server import DashboardServer

        self.server = DashboardServer()
        self.client = TestClient(self.server.app)

        # 1. Establish Owner Session (first login)
        self.owner_pin = self.server.new_key(expiry_secs=3600)
        resp_owner = self.client.post("/login", json={"pin": self.owner_pin})
        self.assertEqual(resp_owner.status_code, 200)
        self.owner_token = resp_owner.json()["token"]
        self.owner_header = {"Authorization": f"Bearer {self.owner_token}"}

        # 2. Establish Guest Session (second login with distinct pin)
        self.guest_pin = self.server.new_key(expiry_secs=3600)
        resp_guest = self.client.post("/login", json={"pin": self.guest_pin})
        self.assertEqual(resp_guest.status_code, 200)
        self.guest_token = resp_guest.json()["token"]
        self.guest_header = {"Authorization": f"Bearer {self.guest_token}"}

    def test_owner_and_guest_identity_assignment(self):
        """First authenticated token is marked owner, subsequent is guest."""
        self.assertEqual(self.server._owner_token, self.owner_token)
        self.assertNotEqual(self.guest_token, self.owner_token)

    def test_unauthorized_access_rejected_401(self):
        """Unauthenticated requests to protected endpoints return 401."""
        resp = self.client.post("/api/command", json={"text": "hello"})
        self.assertEqual(resp.status_code, 401)

        resp2 = self.client.post("/api/revoke-devices")
        self.assertEqual(resp2.status_code, 401)

        resp3 = self.client.post("/api/claude-task", json={"prompt": "test"})
        self.assertEqual(resp3.status_code, 401)

    def test_command_endpoint_owner_allowed_guest_forbidden(self):
        """Owner can send commands, guest is blocked with 403."""
        # Guest caller -> 403 Forbidden
        resp_guest = self.client.post(
            "/api/command",
            headers=self.guest_header,
            json={"text": "open notepad"}
        )
        self.assertEqual(resp_guest.status_code, 403)
        self.assertIn("Owner access required", resp_guest.json().get("error", ""))

        # Owner caller -> 200 OK
        resp_owner = self.client.post(
            "/api/command",
            headers=self.owner_header,
            json={"text": "open notepad"}
        )
        self.assertEqual(resp_owner.status_code, 200)
        self.assertTrue(resp_owner.json().get("ok"))

    def test_revoke_devices_endpoint_owner_allowed_guest_forbidden(self):
        """Owner can revoke devices, guest is blocked with 403."""
        # Guest caller -> 403 Forbidden
        resp_guest = self.client.post(
            "/api/revoke-devices",
            headers=self.guest_header
        )
        self.assertEqual(resp_guest.status_code, 403)
        self.assertIn("Owner access required", resp_guest.json().get("error", ""))

        # Owner caller -> 200 OK
        resp_owner = self.client.post(
            "/api/revoke-devices",
            headers=self.owner_header
        )
        self.assertEqual(resp_owner.status_code, 200)
        self.assertTrue(resp_owner.json().get("ok"))

    def test_claude_task_endpoint_owner_allowed_guest_forbidden(self):
        """Owner can execute Claude tasks, guest is blocked with 403."""
        # Setup mock callback on server
        mock_cb = AsyncMock(return_value={"ok": True, "task_id": "test-123"})
        self.server._claude_task_callback = mock_cb

        # Guest caller -> 403 Forbidden
        resp_guest = self.client.post(
            "/api/claude-task",
            headers=self.guest_header,
            json={"prompt": "Do something"}
        )
        self.assertEqual(resp_guest.status_code, 403)
        self.assertIn("Owner access required", resp_guest.json().get("error", ""))
        mock_cb.assert_not_called()

        # Owner caller -> 200 OK
        resp_owner = self.client.post(
            "/api/claude-task",
            headers=self.owner_header,
            json={"prompt": "Do something"}
        )
        self.assertEqual(resp_owner.status_code, 200)
        self.assertTrue(resp_owner.json().get("ok"))
        mock_cb.assert_called_once()

    def test_thread_local_identity_cleared_after_request(self):
        """Identity injected into thread-local storage during request is cleaned up after."""
        self.assertIsNone(get_current_identity())

        # Make an authenticated request
        resp = self.client.post(
            "/api/command",
            headers=self.owner_header,
            json={"text": "status"}
        )
        self.assertEqual(resp.status_code, 200)

        # Thread local must be clear after request finishes
        self.assertIsNone(get_current_identity())


if __name__ == "__main__":
    unittest.main()
