#!/usr/bin/env python3
"""Unit tests for history panel session resumption."""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

import uuid
import tempfile
from pathlib import Path
from PyQt6.QtWidgets import QApplication
from PyQt6.QtTest import QTest
from PyQt6.QtCore import Qt
import pytest

from memory.conversation_store import ConversationStore
from ui import JarvisUI


@pytest.fixture
def test_ui():
    """Create a test UI instance."""
    app = QApplication.instance() or QApplication(sys.argv)
    ui = JarvisUI("test_face.png")
    # Create minimal mock conversation store for testing
    db_path = Path(tempfile.mktemp(suffix=".db"))
    ui._conv_store = ConversationStore(db_path)
    yield ui
    # Cleanup
    ui.close()
    if db_path.exists():
        db_path.unlink()


def test_history_panel_session_resumed_signal():
    """Test that history panel emits session_resumed signal."""
    from history_panel import HistoryPanel

    app = QApplication.instance() or QApplication(sys.argv)
    panel = HistoryPanel()

    # Connect a test slot
    test_conversation_id = None
    def test_slot(conv_id):
        nonlocal test_conversation_id
        test_conversation_id = conv_id

    panel.session_resumed.connect(test_slot)

    # Set a conversation ID
    panel._selected_conversation_id = "test-conv-123"

    # Emit the signal directly
    panel.session_resumed.emit("test-conv-123")

    # Verify the signal was received
    assert test_conversation_id == "test-conv-123"

    panel.deleteLater()


def test_resume_button_visibility():
    """Test that resume button appears when conversation detail is shown."""
    from history_panel import HistoryPanel

    app = QApplication.instance() or QApplication(sys.argv)
    panel = HistoryPanel()

    # Check initial state - button should not exist
    assert not hasattr(panel, '_resume_btn') or panel._resume_btn is None

    # Show a conversation detail
    test_conv_id = str(uuid.uuid4())
    panel.set_message_detail(
        conversation_id=test_conv_id,
        title="Test Conversation",
        messages=[
            {"role": "user", "content": "Hello", "timestamp": 1234567890},
            {"role": "assistant", "content": "Hi there!", "timestamp": 1234567891}
        ]
    )

    # Button should now exist and be visible
    assert hasattr(panel, '_resume_btn')
    assert panel._resume_btn is not None
    assert panel._resume_btn.isVisible()
    assert panel._resume_btn.text() == "RESUME SESSION"

    panel.deleteLater()


def test_ui_session_resume_callback():
    """Test UI handles session resume callback."""
    app = QApplication.instance() or QApplication(sys.argv)
    ui = JarvisUI("test_face.png")

    # Set up a mock callback
    callback_called = False
    callback_conversation_id = None

    def mock_callback(conv_id):
        nonlocal callback_called, callback_conversation_id
        callback_called = True
        callback_conversation_id = conv_id

    ui._session_resume_callback = mock_callback

    # Call the handler
    test_id = "test-conv-456"
    ui._on_history_session_resumed(test_id)

    # Verify callback was called with correct ID
    assert callback_called
    assert callback_conversation_id == test_id

    ui.close()


def test_resume_button_click():
    """Test that clicking resume button emits signal."""
    from history_panel import HistoryPanel

    app = QApplication.instance() or QApplication(sys.argv)
    panel = HistoryPanel()

    # Setup
    test_conv_id = str(uuid.uuid4())
    panel.set_message_detail(
        conversation_id=test_conv_id,
        title="Test Conversation",
        messages=[
            {"role": "user", "content": "Hello", "timestamp": 1234567890}
        ]
    )

    # Connect test slot
    signal_received = False
    received_id = None

    def test_slot(conv_id):
        nonlocal signal_received, received_id
        signal_received = True
        received_id = conv_id

    panel.session_resumed.connect(test_slot)

    # Simulate button click
    QTest.mouseClick(panel._resume_btn, Qt.MouseButton.LeftButton)

    # Verify signal was emitted
    assert signal_received
    assert received_id == test_conv_id

    panel.deleteLater()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])