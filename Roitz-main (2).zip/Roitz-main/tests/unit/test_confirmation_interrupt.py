"""
Unit tests for Batch 3: Confirmation Emergency Denial.

Run with: py -m pytest tests/unit/test_confirmation_interrupt.py -v
"""
import sys
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.confirm import (
    request as confirm_request,
    resolve as confirm_resolve,
    pending_title,
    cancel_for_task as cancel_confirm_for_task,
    bind as confirm_bind,
    TIMEOUT_SECONDS,
)
from core.auth_dialog import (
    request_auth,
    resolve_auth,
    cancel_for_task as cancel_auth_for_task,
    bind as auth_bind,
    AUTH_TIMEOUT_SECONDS,
)
from core.permission_fingerprint import ApprovalToken, OperationIdentity
from core.permission_manager import get_permission_manager, initialize_permission_manager_for_test
from core.permission_guard import get_permission_guard
from core.autonomous_agent import (
    Executor,
    TaskPlan,
    TaskStep,
    TaskState,
    StepState,
    ActionRegistry,
    PluginRegistry,
)
from core.worker_registry import (
    WorkerRegistry,
    WorkerRecord,
    WorkerState,
    create_worker_record,
    get_global_registry,
    reset_global_registry,
)


class TestConfirmationCancelForTask(unittest.TestCase):
    """Tests for confirm.cancel_for_task()"""

    def setUp(self):
        # Bind dummy callbacks
        confirm_bind(show=lambda t, d: None, hide=lambda: None, log=lambda m: None)
        # Clear any pending
        from core import confirm
        with confirm._lock:
            confirm._pending = None

    def tearDown(self):
        from core import confirm
        with confirm._lock:
            confirm._pending = None

    def test_cancel_for_task_no_pending(self):
        """Cancel on non-existent task returns False."""
        result = cancel_confirm_for_task("task_123")
        self.assertFalse(result)

    def test_cancel_for_task_matches_key(self):
        """Cancel finds and cancels confirmation with matching task_id prefix."""
        # Create a pending confirmation with task_id in key
        def dummy_run():
            return "done"

        confirm_request(
            key="task_task123_step_1",
            title="Confirm deletion",
            detail="Delete file.txt",
            run=dummy_run
        )

        # Verify it's pending
        self.assertEqual(pending_title(), "Confirm deletion")

        # Cancel for that task
        result = cancel_confirm_for_task("task123")
        self.assertTrue(result)

        # Should no longer be pending
        self.assertEqual(pending_title(), "")

    def test_cancel_for_task_different_task_not_affected(self):
        """Cancel for task_1 does not affect task_2's confirmation."""
        def dummy_run():
            return "done"

        # Confirmation for task_1
        confirm_request(
            key="task_task1_step_1",
            title="Confirm task 1",
            detail="Detail 1",
            run=dummy_run
        )

        # Try to cancel for task_2
        result = cancel_confirm_for_task("task2")
        self.assertFalse(result)

        # task_1 confirmation should still be pending
        self.assertEqual(pending_title(), "Confirm task 1")

    def test_cancel_for_task_idempotent(self):
        """Repeated cancel calls are safe."""
        def dummy_run():
            return "done"

        confirm_request(
            key="task_task1_step_1",
            title="Confirm",
            detail="Detail",
            run=dummy_run
        )

        self.assertTrue(cancel_confirm_for_task("task1"))
        self.assertFalse(cancel_confirm_for_task("task1"))  # Already cancelled
        self.assertFalse(cancel_confirm_for_task("task1"))  # Still no pending

    def test_cancel_for_task_logs_cancellation(self):
        """Cancellation is logged."""
        logs = []
        confirm_bind(show=lambda t, d: None, hide=lambda: None, log=lambda m: logs.append(m))

        def dummy_run():
            return "done"

        confirm_request(
            key="task_task1_step_1",
            title="Confirm deletion",
            detail="Delete file.txt",
            run=dummy_run
        )

        cancel_confirm_for_task("task1")

        self.assertTrue(any("cancelled by interrupt" in log.lower() for log in logs))


class TestAuthDialogCancelForTask(unittest.TestCase):
    """Tests for auth_dialog.cancel_for_task()"""

    @classmethod
    def setUpClass(cls):
        initialize_permission_manager_for_test()
        guard = get_permission_guard()
        guard.initialize()

    def setUp(self):
        # Bind dummy callbacks
        auth_bind(show=lambda h, t, d: None, hide=lambda: None, log=lambda m: None)
        # Clear pending
        from core import auth_dialog
        with auth_dialog._auth_lock:
            auth_dialog._pending_auth.clear()
        # Clear grants cache and file for test isolation
        from core.permission_manager import _pending_lock, _grants_cache, _PERMISSIONS_FILE
        with _pending_lock:
            _grants_cache.clear()
        if _PERMISSIONS_FILE.exists():
            _PERMISSIONS_FILE.unlink()

    def tearDown(self):
        from core import auth_dialog
        with auth_dialog._auth_lock:
            auth_dialog._pending_auth.clear()
        # Clear grants cache and file for test isolation
        from core.permission_manager import _pending_lock, _grants_cache, _PERMISSIONS_FILE
        with _pending_lock:
            _grants_cache.clear()
        if _PERMISSIONS_FILE.exists():
            _PERMISSIONS_FILE.unlink()

    def test_cancel_for_task_no_pending(self):
        """Cancel on non-existent task returns 0."""
        result = cancel_auth_for_task("task_123")
        self.assertEqual(result, 0)

    def test_cancel_for_task_matches(self):
        """Cancel finds and cancels auth for matching task_id."""
        # Create a mock token
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        # Request auth with task_id
        request_auth(token, "Owner Approval", "Delete file", lambda v: None, task_id="task123")

        # Cancel for that task
        result = cancel_auth_for_task("task123")
        self.assertEqual(result, 1)

    def test_cancel_for_task_different_task_not_affected(self):
        """Cancel for task_1 does not affect task_2's auth."""
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        # Auth for task_1
        request_auth(token, "Owner Approval", "Delete file", lambda v: None, task_id="task1")

        # Cancel for task_2
        result = cancel_auth_for_task("task2")
        self.assertEqual(result, 0)

    def test_cancel_for_task_does_not_call_callback(self):
        """Cancelled auth does NOT call callback (preserves cancelled approval in permission_manager)."""
        results = []
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        def resolve_cb(verified):
            results.append(verified)

        request_auth(token, "Owner Approval", "Delete file", resolve_cb, task_id="task1")

        # Cancel
        cancel_auth_for_task("task1")

        # Callback should NOT have been called (approval stays cancelled in permission_manager)
        self.assertEqual(len(results), 0)

        # Verify approval is marked cancelled in permission_manager
        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals
        with _pending_lock:
            for pending in _pending_approvals.values():
                if pending.task_id == "task1":
                    self.assertTrue(pending.cancelled)

    def test_cancel_for_task_idempotent(self):
        """Repeated cancel calls are safe."""
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        request_auth(token, "Owner Approval", "Delete file", lambda v: None, task_id="task1")

        self.assertEqual(cancel_auth_for_task("task1"), 1)
        self.assertEqual(cancel_auth_for_task("task1"), 0)  # Already cancelled


class TestPermissionManagerCancelForTask(unittest.TestCase):
    """Tests for permission_manager.cancel_for_task()"""

    @classmethod
    def setUpClass(cls):
        initialize_permission_manager_for_test()

    def setUp(self):
        # Clear pending approvals
        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals, _grants_cache, _PERMISSIONS_FILE
        with _pending_lock:
            _pending_approvals.clear()
        # Clear grants cache and file for test isolation
        with _pending_lock:
            _grants_cache.clear()
        if _PERMISSIONS_FILE.exists():
            _PERMISSIONS_FILE.unlink()

    def tearDown(self):
        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals, _grants_cache, _PERMISSIONS_FILE
        with _pending_lock:
            _pending_approvals.clear()
        # Clear grants cache and file for test isolation
        with _pending_lock:
            _grants_cache.clear()
        if _PERMISSIONS_FILE.exists():
            _PERMISSIONS_FILE.unlink()

    def test_cancel_for_task_no_pending(self):
        """Cancel on non-existent task returns 0."""
        pm = get_permission_manager()
        result = pm.cancel_for_task("task_123")
        self.assertEqual(result, 0)

    def test_cancel_for_task_matches(self):
        """Cancel marks pending approval as cancelled for matching task_id."""
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        # Request approval (this registers pending approval)
        pm = get_permission_manager()
        pm._request_approval(identity, token, task_id="task123")

        # Cancel for that task
        result = pm.cancel_for_task("task123")
        self.assertEqual(result, 1)

    def test_cancel_for_task_different_task_not_affected(self):
        """Cancel for task_1 does not affect task_2's approval."""
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        pm = get_permission_manager()
        pm._request_approval(identity, token, task_id="task1")

        # Cancel for task_2
        result = pm.cancel_for_task("task2")
        self.assertEqual(result, 0)

    def test_cancel_for_task_cannot_consume_cancelled(self):
        """Cancelled approval cannot be consumed."""
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        pm = get_permission_manager()
        pm._request_approval(identity, token, task_id="task1")

        # Cancel
        pm.cancel_for_task("task1")

        # Try to consume - should fail with approval_cancelled_by_interrupt
        result = pm._consume_approval(token, verified=True)
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "approval_cancelled_by_interrupt")

    def test_cancel_for_task_idempotent(self):
        """Repeated cancel calls are safe."""
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        pm = get_permission_manager()
        pm._request_approval(identity, token, task_id="task1")

        self.assertEqual(pm.cancel_for_task("task1"), 1)
        self.assertEqual(pm.cancel_for_task("task1"), 0)  # Already cancelled


class TestInterruptCancelsConfirmations(unittest.TestCase):
    """Integration tests: voice interrupt cancels relevant confirmations."""

    @classmethod
    def setUpClass(cls):
        initialize_permission_manager_for_test()
        guard = get_permission_guard()
        guard.initialize()

    def setUp(self):
        reset_global_registry()
        self.registry = get_global_registry()

        # Bind dummy callbacks
        confirm_bind(show=lambda t, d: None, hide=lambda: None, log=lambda m: None)
        auth_bind(show=lambda h, t, d: None, hide=lambda: None, log=lambda m: None)

        # Clear pending
        from core import confirm, auth_dialog
        with confirm._lock:
            confirm._pending = None
        with auth_dialog._auth_lock:
            auth_dialog._pending_auth.clear()

        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals
        with _pending_lock:
            _pending_approvals.clear()

    def tearDown(self):
        reset_global_registry()
        from core import confirm, auth_dialog
        with confirm._lock:
            confirm._pending = None
        with auth_dialog._auth_lock:
            auth_dialog._pending_auth.clear()
        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals
        with _pending_lock:
            _pending_approvals.clear()

    def _create_executor_with_task(self, task_id="task_1"):
        """Create an executor with a mock action/plugin registry."""
        mock_action_reg = Mock(spec=ActionRegistry)
        mock_plugin_reg = Mock(spec=PluginRegistry)
        mock_action_reg.has.return_value = True
        mock_action_reg.run.return_value = "Done"
        mock_plugin_reg.has.return_value = False

        executor = Executor(
            action_registry=mock_action_reg,
            plugin_registry=mock_plugin_reg,
            worker_registry=self.registry,
        )
        return executor

    def test_interrupt_cancels_confirmation_for_active_task(self):
        """Voice interrupt cancels confirmation for the interrupted task."""
        from core import confirm
        from actions import task_agent as ta

        # Create a task with a pending confirmation
        executor = self._create_executor_with_task("task_1")

        # Simulate a pending confirmation for this task
        def dummy_run():
            return "deleted"

        confirm_request(
            key="task_task_1_step_1",
            title="Confirm: Delete file",
            detail="Delete test.txt",
            run=dummy_run
        )

        self.assertEqual(pending_title(), "Confirm: Delete file")

        # Register executor as active
        with ta._executors_lock:
            ta._active_executors["task_1"] = executor

        # Simulate interrupt by calling the cancellation logic
        with ta._executors_lock:
            for tid, exec_ in ta._active_executors.items():
                exec_.cancel_task(tid)
                exec_.cancel()
                # Also cancel confirmations (this is what main.py interrupt() does)
                from core.confirm import cancel_for_task as cancel_confirm
                cancel_confirm(tid)

        # Confirmation should be cancelled
        self.assertEqual(pending_title(), "")

        # Cleanup
        with ta._executors_lock:
            ta._active_executors.clear()

    def test_interrupt_cancels_auth_for_active_task(self):
        """Voice interrupt cancels owner auth for the interrupted task."""
        from actions import task_agent as ta
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        # Request auth for this task
        results = []
        def resolve_cb(verified):
            results.append(verified)

        request_auth(token, "Owner Approval", "Delete file", resolve_cb, task_id="task_1")

        # Create executor and register
        executor = self._create_executor_with_task("task_1")
        with ta._executors_lock:
            ta._active_executors["task_1"] = executor

        # Simulate interrupt
        with ta._executors_lock:
            for tid, exec_ in ta._active_executors.items():
                from core.auth_dialog import cancel_for_task as cancel_auth
                cancel_auth(tid)

        # Auth should be cancelled - callback NOT called (preserves cancelled approval)
        self.assertEqual(len(results), 0)

        # Verify approval is marked cancelled in permission_manager
        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals
        with _pending_lock:
            for pending in _pending_approvals.values():
                if pending.task_id == "task_1":
                    self.assertTrue(pending.cancelled)

        with ta._executors_lock:
            ta._active_executors.clear()

    def test_interrupt_cancels_approval_for_active_task(self):
        """Voice interrupt cancels pending approval for the interrupted task."""
        from actions import task_agent as ta
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        # Request approval for this task
        pm = get_permission_manager()
        pm._request_approval(identity, token, task_id="task_1")

        # Create executor and register
        executor = self._create_executor_with_task("task_1")
        with ta._executors_lock:
            ta._active_executors["task_1"] = executor

        # Simulate interrupt
        with ta._executors_lock:
            for tid, exec_ in ta._active_executors.items():
                from core.permission_guard import get_permission_guard
                guard = get_permission_guard()
                if guard._initialized:
                    guard.pm.cancel_for_task(tid)

        # Approval should be cancelled - cannot be consumed
        result = pm._consume_approval(token, verified=True)
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "approval_cancelled_by_interrupt")

        with ta._executors_lock:
            ta._active_executors.clear()

    def test_interrupt_does_not_affect_unrelated_tasks(self):
        """Voice interrupt for task_1 does not cancel task_2's confirmations."""
        from core import confirm
        from actions import task_agent as ta

        # Confirmations for both tasks
        def dummy_run():
            return "done"

        confirm_request(key="task_task_1_step_1", title="Task 1", detail="D1", run=dummy_run)
        confirm_request(key="task_task_2_step_1", title="Task 2", detail="D2", run=dummy_run)

        # Only task_1 has active executor
        executor = self._create_executor_with_task("task_1")
        with ta._executors_lock:
            ta._active_executors["task_1"] = executor

        # Simulate interrupt for task_1
        with ta._executors_lock:
            for tid, exec_ in ta._active_executors.items():
                from core.confirm import cancel_for_task as cancel_confirm
                cancel_confirm(tid)

        # task_1 confirmation cancelled, task_2 still pending
        # Note: pending_title() only returns one, so we check the key was cleared
        # by checking that task_1's key is no longer valid
        from core import confirm as confirm_module
        with confirm_module._lock:
            p = confirm_module._pending
            if p:
                self.assertNotEqual(p.key, "task_task_1_step_1")

        with ta._executors_lock:
            ta._active_executors.clear()


class TestRaceConditions(unittest.TestCase):
    """Tests for race conditions between approval and cancellation."""

    @classmethod
    def setUpClass(cls):
        initialize_permission_manager_for_test()
        guard = get_permission_guard()
        guard.initialize()

    def setUp(self):
        reset_global_registry()
        self.registry = get_global_registry()

        # Bind dummy callbacks
        confirm_bind(show=lambda t, d: None, hide=lambda: None, log=lambda m: None)
        auth_bind(show=lambda h, t, d: None, hide=lambda: None, log=lambda m: None)

        from core import confirm, auth_dialog
        with confirm._lock:
            confirm._pending = None
        with auth_dialog._auth_lock:
            auth_dialog._pending_auth.clear()

        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals
        with _pending_lock:
            _pending_approvals.clear()

    def tearDown(self):
        reset_global_registry()
        from core import confirm, auth_dialog
        with confirm._lock:
            confirm._pending = None
        with auth_dialog._auth_lock:
            auth_dialog._pending_auth.clear()
        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals
        with _pending_lock:
            _pending_approvals.clear()

    def test_concurrent_approval_and_cancellation(self):
        """Concurrent approval and cancellation cannot both succeed."""
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        pm = get_permission_manager()
        pm._request_approval(identity, token, task_id="task1")

        # Simulate concurrent cancel and approve
        cancel_done = threading.Event()
        approve_done = threading.Event()
        cancel_result = []
        approve_result = []

        def do_cancel():
            result = pm.cancel_for_task("task1")
            cancel_result.append(result)
            cancel_done.set()

        def do_approve():
            result = pm._consume_approval(token, verified=True)
            approve_result.append(result)
            approve_done.set()

        t1 = threading.Thread(target=do_cancel)
        t2 = threading.Thread(target=do_approve)

        t1.start()
        t2.start()

        cancel_done.wait(timeout=1.0)
        approve_done.wait(timeout=1.0)

        t1.join()
        t2.join()

        # One should succeed, one should fail
        # Either cancel returns 1 and approve fails, or vice versa
        # But both should NOT succeed
        cancel_succeeded = cancel_result[0] == 1 if cancel_result else False
        approve_succeeded = approve_result[0].allowed if approve_result else False

        self.assertFalse(cancel_succeeded and approve_succeeded,
                         "Both cancellation and approval succeeded - race condition!")

    def test_duplicate_cancellation_safe(self):
        """Duplicate cancellation calls are safe and idempotent."""
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        pm = get_permission_manager()
        pm._request_approval(identity, token, task_id="task1")

        # Cancel multiple times concurrently
        results = []
        def do_cancel():
            results.append(pm.cancel_for_task("task1"))

        threads = [threading.Thread(target=do_cancel) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # First call returns 1, rest return 0
        self.assertEqual(sum(results), 1)
        self.assertTrue(all(r >= 0 for r in results))


class TestExecutionSafety(unittest.TestCase):
    """Tests that execution safety is preserved during cancellation."""

    @classmethod
    def setUpClass(cls):
        initialize_permission_manager_for_test()
        guard = get_permission_guard()
        guard.initialize()

    def setUp(self):
        reset_global_registry()
        self.registry = get_global_registry()

        # Bind dummy callbacks
        confirm_bind(show=lambda t, d: None, hide=lambda: None, log=lambda m: None)
        auth_bind(show=lambda h, t, d: None, hide=lambda: None, log=lambda m: None)

        from core import confirm, auth_dialog
        with confirm._lock:
            confirm._pending = None
        with auth_dialog._auth_lock:
            auth_dialog._pending_auth.clear()

        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals, _grants_cache, _PERMISSIONS_FILE
        with _pending_lock:
            _pending_approvals.clear()
        # Clear grants cache and file for test isolation
        with _pending_lock:
            _grants_cache.clear()
        if _PERMISSIONS_FILE.exists():
            _PERMISSIONS_FILE.unlink()

    def tearDown(self):
        reset_global_registry()
        from core import confirm, auth_dialog
        with confirm._lock:
            confirm._pending = None
        with auth_dialog._auth_lock:
            auth_dialog._pending_auth.clear()
        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals, _grants_cache, _PERMISSIONS_FILE
        with _pending_lock:
            _pending_approvals.clear()
        # Clear grants cache and file for test isolation
        with _pending_lock:
            _grants_cache.clear()
        if _PERMISSIONS_FILE.exists():
            _PERMISSIONS_FILE.unlink()

    def test_cancelled_confirmation_does_not_execute(self):
        """Cancelled confirmation never executes its run() callback."""
        executed = []

        def run_callback():
            executed.append(True)
            return "done"

        confirm_request(
            key="task_task1_step_1",
            title="Confirm",
            detail="Detail",
            run=run_callback
        )

        # Cancel it
        cancel_confirm_for_task("task1")

        # Try to resolve (simulate user clicking CONFIRM after cancel)
        confirm_resolve(True)

        # run_callback should NOT have been called
        self.assertEqual(len(executed), 0)

    def test_cancelled_auth_does_not_grant_permission(self):
        """Cancelled auth dialog does not grant persistent permission."""
        from memory.config_manager import BASE_DIR
        test_path = BASE_DIR / "test_project"

        identity = OperationIdentity.create(
            capability="fs.delete",
            project_path=test_path,
            template_id="delete",
            args={"action": "delete", "path": "test.txt"},
            requesting_component="task_agent"
        )
        token = ApprovalToken.create(identity)

        # Request auth
        request_auth(token, "Owner Approval", "Delete file", lambda v: None, task_id="task1")

        # Cancel via interrupt
        cancel_auth_for_task("task1")

        # Simulate user clicking CONFIRM after cancel
        token_hash = token.token_hash()
        resolve_auth(token_hash, accepted=True, provided_secret=b"secret")

        # Permission should NOT be granted (no grant written to persistent store)
        from core.permission_manager import _load_grants
        grants = _load_grants()
        self.assertNotIn(identity.identity_hash(), grants)

    def test_worker_registry_resources_preserved(self):
        """WorkerRegistry resources remain reserved while worker is alive after cancellation."""
        worker = create_worker_record(
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/tmp/test.txt"},
            operation_name="file_controller:write",
            resource_scope=None,
            is_idempotent=False,
        )
        cancel_event = threading.Event()
        worker.mark_running(threading.current_thread(), cancel_event)
        self.registry.register(worker)

        # Verify resource is reserved
        self.assertIn("/tmp/test.txt", self.registry._resource_reservations)

        # Cancel confirmation (simulates interrupt)
        cancel_confirm_for_task("task_1")

        # Resource should still be reserved (worker still alive)
        self.assertIn("/tmp/test.txt", self.registry._resource_reservations)

    def test_cancelled_confirmation_not_terminated_worker(self):
        """Cancellation doesn't claim worker terminated if still running."""
        worker = create_worker_record(
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/tmp/test.txt"},
            operation_name="file_controller:write",
            resource_scope=None,
            is_idempotent=False,
        )
        cancel_event = threading.Event()
        worker.mark_running(threading.current_thread(), cancel_event)
        self.registry.register(worker)

        self.assertTrue(worker.is_alive())
        self.assertEqual(worker.state, WorkerState.RUNNING)

        # Cancel confirmation
        cancel_confirm_for_task("task_1")

        # Worker should still be RUNNING (not terminated)
        self.assertTrue(worker.is_alive())
        self.assertEqual(worker.state, WorkerState.RUNNING)


class TestBatch1Batch2Regression(unittest.TestCase):
    """Regression tests: Batch 1 and Batch 2 behavior intact."""

    @classmethod
    def setUpClass(cls):
        initialize_permission_manager_for_test()
        guard = get_permission_guard()
        guard.initialize()

    def setUp(self):
        reset_global_registry()
        self.registry = get_global_registry()

        confirm_bind(show=lambda t, d: None, hide=lambda: None, log=lambda m: None)
        auth_bind(show=lambda h, t, d: None, hide=lambda: None, log=lambda m: None)

        from core import confirm, auth_dialog
        with confirm._lock:
            confirm._pending = None
        with auth_dialog._auth_lock:
            auth_dialog._pending_auth.clear()

        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals
        with _pending_lock:
            _pending_approvals.clear()

    def tearDown(self):
        reset_global_registry()
        from core import confirm, auth_dialog
        with confirm._lock:
            confirm._pending = None
        with auth_dialog._auth_lock:
            auth_dialog._pending_auth.clear()
        pm = get_permission_manager()
        from core.permission_manager import _pending_lock, _pending_approvals
        with _pending_lock:
            _pending_approvals.clear()

    def test_batch1_voice_interrupt_still_works(self):
        """Batch 1 voice interrupt logic still functions."""
        # The interrupt() method in main.py should still work
        # We can't easily test the full main.py here, but we can test
        # that the pieces it calls still work

        from core.worker_registry import WorkerState
        worker = create_worker_record(
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            parameters={"action": "read", "path": "/tmp/test.txt"},
            operation_name="file_controller:read",
            resource_scope=None,
            is_idempotent=True,
        )
        cancel_event = threading.Event()
        worker.mark_running(threading.current_thread(), cancel_event)
        self.registry.register(worker)

        # Simulate Batch 1 interrupt: cancel_task + cancel
        count = self.registry.request_task_cancellation("task_1")
        self.assertEqual(count, 1)
        self.assertEqual(worker.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertTrue(cancel_event.is_set())

    def test_batch2_worker_cancellation_still_works(self):
        """Batch 2 worker cancellation still works with new confirmation cancel."""
        from core.worker_registry import WorkerState
        from core.autonomous_agent import Executor
        from unittest.mock import Mock

        mock_action_reg = Mock(spec=ActionRegistry)
        mock_plugin_reg = Mock(spec=PluginRegistry)
        mock_action_reg.has.return_value = True
        mock_action_reg.run.return_value = "Done"
        mock_plugin_reg.has.return_value = False

        executor = Executor(
            action_registry=mock_action_reg,
            plugin_registry=mock_plugin_reg,
            worker_registry=self.registry,
        )

        worker = create_worker_record(
            task_id="task_1",
            step_id="step_1",
            tool_name="file_controller",
            parameters={"action": "read", "path": "/tmp/test.txt"},
            operation_name="file_controller:read",
            resource_scope=None,
            is_idempotent=True,
        )
        cancel_event = threading.Event()
        worker.mark_running(threading.current_thread(), cancel_event)
        self.registry.register(worker)

        executor._active_attempt_id = worker.attempt_id
        executor._active_step_id = "step_1"

        # Cancel
        executor.cancel()

        self.assertEqual(worker.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertTrue(cancel_event.is_set())

    def test_confirmation_timeout_still_works(self):
        """Confirmation timeout behavior unchanged."""
        from core.confirm import TIMEOUT_SECONDS

        # The timeout constant should still be 90 seconds
        self.assertEqual(TIMEOUT_SECONDS, 90.0)

    def test_auth_timeout_still_works(self):
        """Auth timeout behavior unchanged."""
        from core.auth_dialog import AUTH_TIMEOUT_SECONDS

        # The timeout constant should still be 60 seconds
        self.assertEqual(AUTH_TIMEOUT_SECONDS, 60.0)


if __name__ == "__main__":
    unittest.main()