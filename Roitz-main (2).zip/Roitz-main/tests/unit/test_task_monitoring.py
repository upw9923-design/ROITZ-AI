"""
Unit tests for Task 3 Batch 3 (Monitoring & Recovery).
"""
import unittest
import time
import threading
from unittest.mock import Mock, patch

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.task_monitoring import (
    classify_error,
    ErrorClassification,
    get_backoff_delay,
    TaskMonitor,
    TaskRecovery,
    MAX_RETRIES,
    STEP_TIMEOUT,
)
from core.autonomous_agent import TaskPlan, TaskStep, StepState, TaskState, Executor
from core.worker_registry import WorkerRecord, WorkerState, WorkerRegistry, reset_global_registry, get_global_registry
from core.error_classification import ErrorClass, ClassifiedError


class TestTaskMonitoringAndRecovery(unittest.TestCase):

    def test_error_classification(self):
        self.assertEqual(classify_error("Permission denied"), ErrorClassification.FATAL)
        self.assertEqual(classify_error("Authentication failed"), ErrorClassification.FATAL)
        self.assertEqual(classify_error("File missing"), ErrorClassification.FATAL)
        self.assertEqual(classify_error("Invalid parameters"), ErrorClassification.FATAL)
        self.assertEqual(classify_error("Circular dependency"), ErrorClassification.FATAL)
        self.assertEqual(classify_error("Connection reset"), ErrorClassification.RECOVERABLE)
        self.assertEqual(classify_error("Timeout waiting for resource"), ErrorClassification.RECOVERABLE)

    def test_backoff_delay(self):
        self.assertEqual(get_backoff_delay(1), 1.0)
        self.assertEqual(get_backoff_delay(2), 2.0)
        self.assertEqual(get_backoff_delay(3), 4.0)

    def test_task_monitor_timeout(self):
        plan = TaskPlan(task_id="t1", goal="test")
        monitor = TaskMonitor(plan)
        self.assertFalse(monitor.check_overall_timeout())

    def test_task_recovery_retry_limits(self):
        step = TaskStep(id="s1", description="test", tool="file_controller")

        # Recoverable error, retry 0 -> should retry
        step.retry_count = 0
        self.assertTrue(TaskRecovery.handle_failure(step, "Connection reset"))

        # Fatal error -> should not retry
        self.assertFalse(TaskRecovery.handle_failure(step, "Permission denied"))

        # Max retries reached -> should not retry
        step.retry_count = MAX_RETRIES
        self.assertFalse(TaskRecovery.handle_failure(step, "Connection reset"))


class TestExecutorBatch3Integration(unittest.TestCase):

    def setUp(self):
        reset_global_registry()

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_blocked_worker_and_no_overlap(self, mock_get_guard):
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"count": 0, "concurrent": 0, "max_concurrent": 0}
        lock = threading.Lock()

        class SlowActionRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                with lock:
                    calls["count"] += 1
                    calls["concurrent"] += 1
                    if calls["concurrent"] > calls["max_concurrent"]:
                        calls["max_concurrent"] = calls["concurrent"]
                try:
                    if calls["count"] == 1:
                        time.sleep(0.2)  # Blocks longer than STEP_TIMEOUT (0.05s)
                        raise ConnectionResetError("Connection reset")
                    # Second attempt: fast success (no timeout)
                    return "Success after wait"
                finally:
                    with lock:
                        calls["concurrent"] -= 1

        executor = Executor(SlowActionRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_slow",
            goal="Slow task",
            steps=[TaskStep(id="s1", description="Slow step", tool="file_controller", parameters={"action": "write"})]
        )

        result = executor.execute(plan)
        # Verify that max concurrent execution never exceeds 1 (no overlapping retry)
        self.assertEqual(calls["max_concurrent"], 1)
        self.assertTrue(result.success)
        self.assertEqual(plan.steps[0].retry_count, 1)

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_stale_result_rejection(self, mock_get_guard):
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"count": 0}

        class StaleActionRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["count"] += 1
                if calls["count"] == 1:
                    time.sleep(0.15)  # timeout, finishes late as stale
                    return "Stale success"
                return "Fresh success"

        executor = Executor(StaleActionRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_stale",
            goal="Stale task",
            steps=[TaskStep(id="s1", description="Stale step", tool="file_controller", parameters={"action": "read"})]
        )

        result = executor.execute(plan)
        self.assertTrue(result.success)
        # Should have retried because first attempt timed out and stale result was ignored
        self.assertEqual(calls["count"], 2)
        self.assertEqual(plan.steps[0].result, "Fresh success")


class TestExecutorSafety(unittest.TestCase):
    """Tests for C2/C3 safety guarantees in Executor."""

    def setUp(self):
        reset_global_registry()

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_concurrent_worker_prevention(self, mock_get_guard):
        """Verify that a retry never starts while the previous worker is still alive."""
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"count": 0, "concurrent": 0, "max_concurrent": 0}
        lock = threading.Lock()

        class SlowActionRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                with lock:
                    calls["count"] += 1
                    calls["concurrent"] += 1
                    if calls["concurrent"] > calls["max_concurrent"]:
                        calls["max_concurrent"] = calls["concurrent"]
                try:
                    if calls["count"] == 1:
                        time.sleep(0.2)  # Blocks longer than STEP_TIMEOUT (0.05s)
                        raise ConnectionResetError("Connection reset")
                    # Second attempt: fast success (no timeout)
                    return "Success after wait"
                finally:
                    with lock:
                        calls["concurrent"] -= 1

        executor = Executor(SlowActionRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_slow",
            goal="Slow task",
            steps=[TaskStep(id="s1", description="Slow step", tool="file_controller", parameters={"action": "read"})]
        )

        result = executor.execute(plan)
        # Verify that max concurrent execution never exceeds 1 (no overlapping retry)
        self.assertEqual(calls["max_concurrent"], 1)
        self.assertTrue(result.success)
        self.assertEqual(plan.steps[0].retry_count, 1)

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_uncertain_timeout_after_side_effect(self, mock_get_guard):
        """
        Test that a timeout on a non-idempotent operation marks outcome as uncertain
        and does NOT retry, even if the worker eventually completes.
        """
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"count": 0}

        class SideEffectActionRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["count"] += 1
                if calls["count"] == 1:
                    time.sleep(0.15)  # Simulates side effect completing after timeout
                    return "Side effect completed"
                return "Fresh attempt"

        # Use non-idempotent operation (write)
        executor = Executor(SideEffectActionRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_uncertain",
            goal="Uncertain timeout task",
            steps=[TaskStep(id="s1", description="Write step", tool="file_controller", parameters={"action": "write"})]
        )

        result = executor.execute(plan)
        # Should NOT retry (non-idempotent), should fail with uncertain timeout
        self.assertFalse(result.success)
        self.assertEqual(calls["count"], 1)  # Only one attempt, no retry
        self.assertEqual(plan.steps[0].retry_count, 0)
        # Error should indicate timeout/uncertain
        error_str = str(plan.steps[0].error).lower()
        self.assertIn("timeout", error_str)

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_unresolved_operation_not_reported_successful(self, mock_get_guard):
        """
        Test that an operation that times out but eventually succeeds
        is NOT reported as successful when non-idempotent (uncertain outcome).
        """
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"count": 0}

        class EventuallySucceedsRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["count"] += 1
                if calls["count"] == 1:
                    time.sleep(0.15)  # Completes after timeout
                    return "Actually succeeded"
                return "Fresh attempt"

        # Use non-idempotent operation (delete)
        executor = Executor(EventuallySucceedsRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_unresolved",
            goal="Unresolved task",
            steps=[TaskStep(id="s1", description="Delete step", tool="file_controller", parameters={"action": "delete"})]
        )

        result = executor.execute(plan)
        # Should NOT report success (uncertain outcome for non-idempotent)
        self.assertFalse(result.success)
        self.assertEqual(calls["count"], 1)  # No retry
        self.assertEqual(plan.steps[0].retry_count, 0)
        # Error should indicate timeout/uncertain
        error_str = str(plan.steps[0].error).lower()
        self.assertIn("timeout", error_str)

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_idempotent_operation_accepts_delayed_success(self, mock_get_guard):
        """
        Test that an idempotent operation that times out but eventually succeeds
        IS retried and can succeed on retry (or accept delayed result).
        """
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"count": 0}

        class EventuallySucceedsRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["count"] += 1
                if calls["count"] == 1:
                    time.sleep(0.15)  # Completes after timeout
                    return "Actually succeeded"
                return "Fresh attempt"

        # Use idempotent operation (read)
        executor = Executor(EventuallySucceedsRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_idempotent_delayed",
            goal="Idempotent delayed task",
            steps=[TaskStep(id="s1", description="Read step", tool="file_controller", parameters={"action": "read"})]
        )

        result = executor.execute(plan)
        # Should retry (idempotent) and succeed on retry
        self.assertTrue(result.success)
        self.assertEqual(calls["count"], 2)  # Retried once
        self.assertEqual(plan.steps[0].retry_count, 1)


class TestWorkerLifecycleTracking(unittest.TestCase):
    """Tests for WorkerState transitions and WorkerRecord behavior."""

    def test_worker_state_transitions(self):
        """WorkerRecord should track state transitions correctly."""

        worker = WorkerRecord(
            attempt_id="test-123",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )

        # Initial state
        self.assertEqual(worker.state, WorkerState.CREATED)
        self.assertFalse(worker.is_alive())

        # mark_running
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        cancel_event = threading.Event()
        worker.mark_running(mock_thread, cancel_event)
        self.assertEqual(worker.state, WorkerState.RUNNING)
        self.assertTrue(worker.is_alive())

        # mark_completed - thread still exists but state is COMPLETED
        worker.mark_completed("test result")
        self.assertEqual(worker.state, WorkerState.COMPLETED)
        # is_alive() checks thread.is_alive(), which is still True for mock
        # (mark_completed doesn't clear the thread reference)
        self.assertTrue(worker.is_alive())

    def test_worker_failed_state(self):
        """WorkerRecord mark_failed should set FAILED state."""

        worker = WorkerRecord(
            attempt_id="test-123",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:delete",
            resource_scope="local_file",
            is_idempotent=False,
        )
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        worker.mark_running(mock_thread, threading.Event())
        worker.mark_failed(Exception("Test error"))
        self.assertEqual(worker.state, WorkerState.FAILED)
        # is_alive() still True for mock thread
        self.assertTrue(worker.is_alive())

    def test_worker_timed_out_state(self):
        """WorkerRecord mark_timed_out should set TIMED_OUT state."""

        worker = WorkerRecord(
            attempt_id="test-123",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        worker.mark_running(mock_thread, threading.Event())
        worker.mark_timed_out()
        self.assertEqual(worker.state, WorkerState.TIMED_OUT)
        self.assertTrue(worker.is_alive())

    def test_worker_unresolved_state(self):
        """WorkerRecord mark_unresolved should set UNRESOLVED state."""

        worker = WorkerRecord(
            attempt_id="test-123",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:delete",
            resource_scope="local_file",
            is_idempotent=False,
        )
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        worker.mark_running(mock_thread, threading.Event())
        worker.mark_unresolved()
        self.assertEqual(worker.state, WorkerState.UNRESOLVED)
        self.assertTrue(worker.is_alive())  # UNRESOLVED workers are still "alive"

    def test_worker_terminated_state(self):
        """WorkerRecord mark_terminated should set TERMINATED state."""

        worker = WorkerRecord(
            attempt_id="test-123",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        worker.mark_running(mock_thread, threading.Event())
        worker.mark_terminated()
        self.assertEqual(worker.state, WorkerState.TERMINATED)
        # is_alive() checks thread.is_alive(), which is still True for mock
        # (mark_terminated doesn't clear the thread reference)
        self.assertTrue(worker.is_alive())

    def test_worker_cancellation_requested(self):
        """WorkerRecord request_cancellation should set CANCELLATION_REQUESTED and set event."""

        worker = WorkerRecord(
            attempt_id="test-123",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        worker.mark_running(mock_thread, threading.Event())
        worker.request_cancellation()
        self.assertEqual(worker.state, WorkerState.CANCELLATION_REQUESTED)
        self.assertTrue(worker.cancel_event.is_set())

    def test_conflicts_with_same_resource_scope(self):
        """WorkerRecord.conflicts_with should detect same resource scope."""

        worker1 = WorkerRecord(
            attempt_id="test-1",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker2 = WorkerRecord(
            attempt_id="test-2",
            task_id="test-task",
            step_id="s2",
            tool_name="file_controller",
            operation_name="file_controller:delete",
            resource_scope="local_file",
            is_idempotent=False,
        )
        # Same resource scope should conflict
        self.assertTrue(worker1.conflicts_with(worker2))
        self.assertTrue(worker2.conflicts_with(worker1))

    def test_conflicts_with_different_resource_scope(self):
        """WorkerRecord.conflicts_with should not conflict on different scopes."""

        worker1 = WorkerRecord(
            attempt_id="test-1",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker2 = WorkerRecord(
            attempt_id="test-2",
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )
        # Different resource scope should NOT conflict
        self.assertFalse(worker1.conflicts_with(worker2))

    def test_conflicts_with_none_resource_scope_is_conservative(self):
        """WorkerRecord.conflicts_with should return True (conservative) if either has None scope."""

        worker1 = WorkerRecord(
            attempt_id="test-1",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker2 = WorkerRecord(
            attempt_id="test-2",
            task_id="test-task",
            step_id="s2",
            tool_name="unknown",
            operation_name=None,
            resource_scope=None,
            is_idempotent=False,
        )
        # Conservative: unknown scope = potential conflict
        self.assertTrue(worker1.conflicts_with(worker2))

    def test_computer_control_screenshot_resource_key(self):
        """computer_control:screenshot should extract global:display resource key."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("computer_control", {"action": "screenshot"}, "computer_control:screenshot")
        self.assertIn("global:display", keys)

    def test_computer_control_close_app_resource_key(self):
        """computer_control:close_app should extract app:manage resource key."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("computer_control", {"action": "close_app", "app_name": "Notepad"}, "computer_control:close_app")
        self.assertIn("app:manage", keys)

    def test_computer_control_focus_window_resource_key(self):
        """computer_control:focus_window should extract app:manage resource key."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("computer_control", {"action": "focus_window", "title": "Notepad"}, "computer_control:focus_window")
        self.assertIn("app:manage", keys)

    def test_resource_key_conflict_screenshot_vs_screen_find(self):
        """computer_control:screenshot and screen_find should conflict (same display resource)."""
        from core.worker_registry import WorkerRecord, WorkerState, create_worker_record
        import threading
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: screen_find
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_control",
            parameters={"action": "screen_find", "description": "button"},
            operation_name="computer_control:screen_find",
            resource_scope="local_system",
            is_idempotent=True,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Second worker: screenshot
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "screenshot"},
            operation_name="computer_control:screenshot",
            resource_scope="local_system",
            is_idempotent=True,
        )

        # They should conflict on global:display resource key
        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted)
        self.assertEqual(reason, "resource_key:global:display")

    def test_resource_key_no_conflict_screenshot_vs_type(self):
        """computer_control:screenshot and type should NOT conflict (different resources)."""
        from core.worker_registry import WorkerRecord, WorkerState, create_worker_record
        import threading
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: type (input)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_control",
            parameters={"action": "type", "text": "hello"},
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Second worker: screenshot (display)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "screenshot"},
            operation_name="computer_control:screenshot",
            resource_scope="local_system",
            is_idempotent=True,
        )

        # They should NOT conflict - different resource keys
        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertTrue(admitted, f"Should be admitted, got: {reason}")

    def test_resource_key_conflict_close_app_vs_focus_window(self):
        """computer_control:close_app and focus_window should conflict (same app:manage resource)."""
        from core.worker_registry import WorkerRecord, WorkerState, create_worker_record
        import threading
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: close_app
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_control",
            parameters={"action": "close_app", "app_name": "Notepad"},
            operation_name="computer_control:close_app",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Second worker: focus_window
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "focus_window", "title": "Notepad"},
            operation_name="computer_control:focus_window",
            resource_scope="local_system",
            is_idempotent=False,
        )

        # They should conflict on app:manage resource key
        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted)
        self.assertEqual(reason, "resource_key:app:manage")

    def test_resource_key_no_conflict_browser_screenshot_vs_os_screenshot(self):
        """browser_control:screenshot and computer_control:screenshot should NOT conflict (different resource keys)."""
        from core.worker_registry import WorkerRecord, WorkerState, create_worker_record
        import threading
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: browser_control:screenshot
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="browser_control",
            parameters={"action": "screenshot", "url": "https://example.com"},
            operation_name="browser_control:screenshot",
            resource_scope="local_system",
            is_idempotent=True,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Second worker: computer_control:screenshot
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "screenshot"},
            operation_name="computer_control:screenshot",
            resource_scope="local_system",
            is_idempotent=True,
        )

        # They should NOT conflict - different resource keys (browser:... vs global:display)
        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertTrue(admitted, f"Should be admitted, got: {reason}")

    def test_unknown_resource_handling_conservative(self):
        """Unknown tool/resource should remain conservative (conflict with everything)."""
        from core.worker_registry import WorkerRecord, WorkerState, create_worker_record
        import threading
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: unknown tool (no resource keys, no operation_name)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="unknown_tool",
            parameters={},
            operation_name=None,
            resource_scope=None,
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Second worker: known tool
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "type", "text": "hello"},
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )

        # Should conflict (conservative: unknown scope = potential conflict)
        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted)
        self.assertEqual(reason, "resource_scope:local_system")

    def test_screen_click_resource_keys(self):
        """computer_control:screen_click should reserve both global:display and global:input."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("computer_control", {"action": "screen_click", "description": "button"}, "computer_control:screen_click")
        self.assertIn("global:display", keys)
        self.assertIn("global:input", keys)
        self.assertEqual(len(keys), 2)

    def test_screen_find_does_not_reserve_input(self):
        """Read-only screen_find should only reserve global:display, not global:input."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("computer_control", {"action": "screen_find", "description": "button"}, "computer_control:screen_find")
        self.assertIn("global:display", keys)
        self.assertNotIn("global:input", keys)
        self.assertEqual(len(keys), 1)

    def test_screen_click_conflicts_with_input_operations(self):
        """screen_click should conflict with click, type, and hotkey (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: screen_click (display + input)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_control",
            parameters={"action": "screen_click", "description": "button"},
            operation_name="computer_control:screen_click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Test conflicts with click
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "click", "x": 100, "y": 100},
            operation_name="computer_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"screen_click should conflict with click, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

        # Reset registry
        registry = WorkerRegistry()
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_control",
            parameters={"action": "screen_click", "description": "button"},
            operation_name="computer_control:screen_click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Test conflicts with type
        worker3 = create_worker_record(
            task_id="test-task",
            step_id="s3",
            tool_name="computer_control",
            parameters={"action": "type", "text": "hello"},
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker3)
        self.assertFalse(admitted, f"screen_click should conflict with type, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

        # Reset registry
        registry = WorkerRegistry()
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_control",
            parameters={"action": "screen_click", "description": "button"},
            operation_name="computer_control:screen_click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Test conflicts with hotkey
        worker4 = create_worker_record(
            task_id="test-task",
            step_id="s4",
            tool_name="computer_control",
            parameters={"action": "hotkey", "keys": ["ctrl", "c"]},
            operation_name="computer_control:hotkey",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker4)
        self.assertFalse(admitted, f"screen_click should conflict with hotkey, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_screen_click_conflicts_with_display_operations(self):
        """screen_click should conflict with screen_find and screenshot (shared global:display)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: screen_click (display + input)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_control",
            parameters={"action": "screen_click", "description": "button"},
            operation_name="computer_control:screen_click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Test conflicts with screen_find
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "screen_find", "description": "button"},
            operation_name="computer_control:screen_find",
            resource_scope="local_system",
            is_idempotent=True,
        )
        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"screen_click should conflict with screen_find, got: {reason}")
        self.assertEqual(reason, "resource_key:global:display")

        # Reset registry
        registry = WorkerRegistry()
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_control",
            parameters={"action": "screen_click", "description": "button"},
            operation_name="computer_control:screen_click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Test conflicts with screenshot
        worker3 = create_worker_record(
            task_id="test-task",
            step_id="s3",
            tool_name="computer_control",
            parameters={"action": "screenshot"},
            operation_name="computer_control:screenshot",
            resource_scope="local_system",
            is_idempotent=True,
        )
        admitted, reason = registry.admit_worker(worker3)
        self.assertFalse(admitted, f"screen_click should conflict with screenshot, got: {reason}")
        self.assertEqual(reason, "resource_key:global:display")

    def test_browser_screenshot_independent_from_os_display_and_input(self):
        """browser_control:screenshot should not conflict with OS display or input operations."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: browser_control:screenshot (browser:{url})
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="browser_control",
            parameters={"action": "screenshot", "url": "https://example.com"},
            operation_name="browser_control:screenshot",
            resource_scope="local_system",
            is_idempotent=True,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Second worker: computer_control:screen_find (global:display)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "screen_find", "description": "button"},
            operation_name="computer_control:screen_find",
            resource_scope="local_system",
            is_idempotent=True,
        )
        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertTrue(admitted, f"browser screenshot should not conflict with screen_find, got: {reason}")

        # Third worker: computer_control:click (global:input)
        worker3 = create_worker_record(
            task_id="test-task",
            step_id="s3",
            tool_name="computer_control",
            parameters={"action": "click", "x": 100, "y": 100},
            operation_name="computer_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker3)
        self.assertTrue(admitted, f"browser screenshot should not conflict with click, got: {reason}")

    def test_unresolved_worker_reservations_protected(self):
        """Unresolved worker reservations should block conflicting new workers."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: screen_click (UNRESOLVED state - still alive)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_control",
            parameters={"action": "screen_click", "description": "button"},
            operation_name="computer_control:screen_click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.UNRESOLVED  # Unresolved but thread may still be alive
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True  # Thread still alive

        registry.register(worker1)

        # Second worker: click should be blocked by unresolved worker's global:input reservation
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "click", "x": 100, "y": 100},
            operation_name="computer_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"Unresolved worker should block click, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

        # Third worker: screen_find should be blocked by unresolved worker's global:display reservation
        worker3 = create_worker_record(
            task_id="test-task",
            step_id="s3",
            tool_name="computer_control",
            parameters={"action": "screen_find", "description": "button"},
            operation_name="computer_control:screen_find",
            resource_scope="local_system",
            is_idempotent=True,
        )
        admitted, reason = registry.admit_worker(worker3)
        self.assertFalse(admitted, f"Unresolved worker should block screen_find, got: {reason}")
        self.assertEqual(reason, "resource_key:global:display")

    # ─── Browser Control Resource Conflict Tests ────────────────────────────────

    def test_browser_same_session_conflict(self):
        """Operations on the same browser session should conflict."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: click on chrome session
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="browser_control",
            parameters={"action": "click", "browser": "chrome", "selector": "button"},
            operation_name="browser_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Second worker: type on same chrome session - should conflict
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="browser_control",
            parameters={"action": "type", "browser": "chrome", "text": "hello"},
            operation_name="browser_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )

        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"Same session operations should conflict, got: {reason}")
        self.assertEqual(reason, "resource_key:browser:session:chrome")

    def test_browser_independent_sessions_no_conflict(self):
        """Operations on different browser sessions should NOT conflict."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: click on chrome session
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="browser_control",
            parameters={"action": "click", "browser": "chrome", "selector": "button"},
            operation_name="browser_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Second worker: click on firefox session - should NOT conflict
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="browser_control",
            parameters={"action": "click", "browser": "firefox", "selector": "button"},
            operation_name="browser_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )

        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertTrue(admitted, f"Different sessions should not conflict, got: {reason}")

    def test_browser_navigation_conflicts_with_interactive(self):
        """Navigation on a session should conflict with interactive actions on same session."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: navigate on chrome
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="browser_control",
            parameters={"action": "go_to", "browser": "chrome", "url": "https://example.com"},
            operation_name="browser_control:go_to",
            resource_scope="network_egress",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Second worker: click on same chrome session - should conflict on session key
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="browser_control",
            parameters={"action": "click", "browser": "chrome", "selector": "button"},
            operation_name="browser_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )

        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"Navigation should conflict with interactive on same session, got: {reason}")
        self.assertEqual(reason, "resource_key:browser:session:chrome")

    def test_browser_screenshot_conflicts_with_navigation(self):
        """Screenshot on a session should conflict with navigation on same session."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: screenshot on chrome
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="browser_control",
            parameters={"action": "screenshot", "browser": "chrome"},
            operation_name="browser_control:screenshot",
            resource_scope="local_system",
            is_idempotent=True,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        # Second worker: navigate on same chrome session - should conflict
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="browser_control",
            parameters={"action": "go_to", "browser": "chrome", "url": "https://example.com"},
            operation_name="browser_control:go_to",
            resource_scope="network_egress",
            is_idempotent=False,
        )

        registry.register(worker1)
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"Screenshot should conflict with navigation on same session, got: {reason}")
        self.assertEqual(reason, "resource_key:browser:session:chrome")

    def test_browser_network_egress_resource_keys(self):
        """Navigation actions should reserve network:{domain} keys."""
        from core.worker_registry import extract_resource_keys

        keys = extract_resource_keys("browser_control", {"action": "go_to", "browser": "chrome", "url": "https://example.com/path"}, "browser_control:go_to")
        self.assertIn("browser:session:chrome", keys)
        self.assertIn("network:example.com", keys)
        self.assertEqual(len(keys), 2)

    def test_browser_search_reserves_network_key(self):
        """Search action should reserve network key for search engine."""
        from core.worker_registry import extract_resource_keys

        keys = extract_resource_keys("browser_control", {"action": "search", "browser": "chrome", "query": "test", "engine": "google"}, "browser_control:search")
        self.assertIn("browser:session:chrome", keys)
        self.assertIn("network:www.google.com", keys)

    def test_browser_session_management_resource_keys(self):
        """Session management actions should reserve appropriate keys."""
        from core.worker_registry import extract_resource_keys

        # close and switch reserve session key
        keys = extract_resource_keys("browser_control", {"action": "close", "browser": "chrome"}, "browser_control:close")
        self.assertIn("browser:session:chrome", keys)

        keys = extract_resource_keys("browser_control", {"action": "switch", "browser": "firefox"}, "browser_control:switch")
        self.assertIn("browser:session:firefox", keys)

        # list_browsers and close_all reserve registry key
        keys = extract_resource_keys("browser_control", {"action": "list_browsers"}, "browser_control:list_browsers")
        self.assertIn("browser:registry", keys)

        keys = extract_resource_keys("browser_control", {"action": "close_all"}, "browser_control:close_all")
        self.assertIn("browser:registry", keys)

    def test_browser_unresolved_worker_blocks_new_operations(self):
        """Unresolved browser worker should block new operations on same session."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: click on chrome (UNRESOLVED)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="browser_control",
            parameters={"action": "click", "browser": "chrome", "selector": "button"},
            operation_name="browser_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.UNRESOLVED
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        registry.register(worker1)

        # Second worker: type on same session should be blocked
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="browser_control",
            parameters={"action": "type", "browser": "chrome", "text": "hello"},
            operation_name="browser_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"Unresolved worker should block new operation, got: {reason}")
        self.assertEqual(reason, "resource_key:browser:session:chrome")


class TestWorkerRegistry(unittest.TestCase):
    """Tests for WorkerRegistry thread-safe operations."""

    def test_register_and_get(self):
        """WorkerRegistry should register and retrieve workers."""

        registry = WorkerRegistry()
        worker = WorkerRecord(
            attempt_id="test-123",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )
        registry.register(worker)
        retrieved = registry.get("test-123")
        self.assertIs(retrieved, worker)

    def test_get_nonexistent(self):
        """WorkerRegistry.get should return None for unknown IDs."""
        from core.autonomous_agent import WorkerRegistry

        registry = WorkerRegistry()
        self.assertIsNone(registry.get("nonexistent"))

    def test_get_active_for_step(self):
        """WorkerRegistry.get_active_for_step should return active workers for a step."""

        registry = WorkerRegistry()

        worker1 = WorkerRecord(
            attempt_id="test-1",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        worker2 = WorkerRecord(
            attempt_id="test-2",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker2.state = WorkerState.COMPLETED

        worker3 = WorkerRecord(
            attempt_id="test-3",
            task_id="test-task",
            step_id="s2",
            tool_name="file_controller",
            operation_name="file_controller:delete",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker3.state = WorkerState.RUNNING
        worker3.thread = Mock()
        worker3.thread.is_alive.return_value = True

        registry.register(worker1)
        registry.register(worker2)
        registry.register(worker3)

        # get_active_for_step returns workers not in TERMINATED state
        active_for_s1 = registry.get_active_for_step("s1")
        self.assertEqual(len(active_for_s1), 2)  # RUNNING + COMPLETED
        self.assertIn("test-1", [w.attempt_id for w in active_for_s1])
        self.assertIn("test-2", [w.attempt_id for w in active_for_s1])

        active_for_s2 = registry.get_active_for_step("s2")
        self.assertEqual(len(active_for_s2), 1)
        self.assertEqual(active_for_s2[0].attempt_id, "test-3")

    def test_get_unresolved_workers(self):
        """WorkerRegistry.get_unresolved_workers should return only UNRESOLVED workers."""

        registry = WorkerRegistry()

        worker1 = WorkerRecord(
            attempt_id="test-1",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )
        worker1.state = WorkerState.UNRESOLVED
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        worker2 = WorkerRecord(
            attempt_id="test-2",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker2.state = WorkerState.RUNNING
        worker2.thread = Mock()
        worker2.thread.is_alive.return_value = True

        worker3 = WorkerRecord(
            attempt_id="test-3",
            task_id="test-task",
            step_id="s2",
            tool_name="file_controller",
            operation_name="file_controller:delete",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker3.state = WorkerState.TERMINATED

        registry.register(worker1)
        registry.register(worker2)
        registry.register(worker3)

        unresolved = registry.get_unresolved_workers()
        self.assertEqual(len(unresolved), 1)
        self.assertEqual(unresolved[0].attempt_id, "test-1")

    def test_get_live_workers(self):
        """WorkerRegistry.get_live_workers should return all alive workers."""

        registry = WorkerRegistry()

        worker1 = WorkerRecord(
            attempt_id="test-1",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        worker2 = WorkerRecord(
            attempt_id="test-2",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker2.state = WorkerState.UNRESOLVED
        worker2.thread = Mock()
        worker2.thread.is_alive.return_value = True

        worker3 = WorkerRecord(
            attempt_id="test-3",
            task_id="test-task",
            step_id="s2",
            tool_name="file_controller",
            operation_name="file_controller:delete",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker3.state = WorkerState.COMPLETED

        registry.register(worker1)
        registry.register(worker2)
        registry.register(worker3)

        live = registry.get_live_workers()
        self.assertEqual(len(live), 2)
        self.assertIn("test-1", [w.attempt_id for w in live])
        self.assertIn("test-2", [w.attempt_id for w in live])

    def test_has_conflicting_worker(self):
        """WorkerRegistry.has_conflicting_worker should detect conflicts with live workers."""

        registry = WorkerRegistry()

        # Unresolved worker on local_file
        worker1 = WorkerRecord(
            attempt_id="test-1",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker1.state = WorkerState.UNRESOLVED
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        registry.register(worker1)

        # New worker on same resource scope
        worker2 = WorkerRecord(
            attempt_id="test-2",
            task_id="test-task",
            step_id="s2",
            tool_name="file_controller",
            operation_name="file_controller:delete",
            resource_scope="local_file",
            is_idempotent=False,
        )

        self.assertTrue(registry.has_conflicting_worker(worker2))

        # New worker on different resource scope
        worker3 = WorkerRecord(
            attempt_id="test-3",
            task_id="test-task",
            step_id="s3",
            tool_name="computer_control",
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )

        self.assertFalse(registry.has_conflicting_worker(worker3))

    def test_wait_for_worker(self):
        """WorkerRegistry.wait_for_worker should wait for thread to finish."""
        import time

        registry = WorkerRegistry()

        worker = WorkerRecord(
            attempt_id="test-1",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )

        # Create a real thread that finishes quickly
        def quick_task():
            time.sleep(0.01)

        thread = threading.Thread(target=quick_task)
        thread.start()  # Must start thread before waiting
        worker.mark_running(thread, threading.Event())
        registry.register(worker)

        # Should return True (worker finished)
        result = registry.wait_for_worker("test-1", timeout=1.0)
        self.assertTrue(result)
        # State not changed by wait_for_worker (still RUNNING until mark_terminated called)
        self.assertEqual(worker.state, WorkerState.RUNNING)

    def test_cleanup_terminated(self):
        """WorkerRegistry.cleanup_terminated should remove TERMINATED workers."""

        registry = WorkerRegistry()

        worker1 = WorkerRecord(
            attempt_id="test-1",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )
        worker1.state = WorkerState.TERMINATED

        worker2 = WorkerRecord(
            attempt_id="test-2",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker2.state = WorkerState.RUNNING
        worker2.thread = Mock()
        worker2.thread.is_alive.return_value = True

        registry.register(worker1)
        registry.register(worker2)

        removed = registry.cleanup_terminated()
        self.assertEqual(removed, 1)
        self.assertIsNone(registry.get("test-1"))
        self.assertIsNotNone(registry.get("test-2"))

    def test_get_diagnostics(self):
        """WorkerRegistry.get_diagnostics should return state summary."""

        registry = WorkerRegistry()

        worker1 = WorkerRecord(
            attempt_id="test-1",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True

        worker2 = WorkerRecord(
            attempt_id="test-2",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker2.state = WorkerState.UNRESOLVED
        worker2.thread = Mock()
        worker2.thread.is_alive.return_value = True

        worker3 = WorkerRecord(
            attempt_id="test-3",
            task_id="test-task",
            step_id="s2",
            tool_name="file_controller",
            operation_name="file_controller:delete",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker3.state = WorkerState.COMPLETED

        registry.register(worker1)
        registry.register(worker2)
        registry.register(worker3)

        diagnostics = registry.get_diagnostics()
        self.assertEqual(diagnostics["total"], 3)
        self.assertEqual(diagnostics["by_state"]["running"], 1)
        self.assertEqual(diagnostics["by_state"]["unresolved"], 1)
        self.assertEqual(diagnostics["by_state"]["completed"], 1)
        self.assertEqual(diagnostics["unresolved"], 1)


class TestExecutorWorkerSafety(unittest.TestCase):
    """Integration tests for Executor with WorkerRegistry safety."""

    def setUp(self):
        reset_global_registry()

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_retry_waits_for_previous_worker(self, mock_get_guard):
        """Retry should wait for previous worker to terminate before starting."""
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"count": 0, "worker_started": []}
        lock = threading.Lock()

        class SlowActionRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                with lock:
                    calls["count"] += 1
                    calls["worker_started"].append(time.time())
                try:
                    if calls["count"] == 1:
                        time.sleep(0.2)  # Blocks longer than STEP_TIMEOUT (0.05s)
                        raise ConnectionResetError("Connection reset")
                    return "Success after wait"
                finally:
                    pass

        executor = Executor(SlowActionRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_retry_wait",
            goal="Retry wait task",
            steps=[TaskStep(id="s1", description="Slow step", tool="file_controller", parameters={"action": "read"})]
        )

        result = executor.execute(plan)
        # Should have retried after first worker finished
        self.assertTrue(result.success)
        self.assertEqual(calls["count"], 2)
        self.assertEqual(plan.steps[0].retry_count, 1)

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_non_idempotent_timeout_no_retry(self, mock_get_guard):
        """Non-idempotent operation timeout should not retry."""
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"count": 0}

        class TimeoutActionRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["count"] += 1
                time.sleep(0.15)  # Longer than STEP_TIMEOUT
                return "Completed late"

        # Use non-idempotent operation (delete)
        executor = Executor(TimeoutActionRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_no_retry",
            goal="No retry task",
            steps=[TaskStep(id="s1", description="Delete step", tool="file_controller", parameters={"action": "delete"})]
        )

        result = executor.execute(plan)
        # Should NOT retry (non-idempotent), should fail
        self.assertFalse(result.success)
        self.assertEqual(calls["count"], 1)
        self.assertEqual(plan.steps[0].retry_count, 0)

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_idempotent_timeout_retries(self, mock_get_guard):
        """Idempotent operation timeout should retry."""
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"count": 0}

        class TimeoutThenSuccessRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["count"] += 1
                if calls["count"] == 1:
                    time.sleep(0.15)  # Timeout on first attempt
                    return "Completed late"
                return "Success on retry"

        # Use idempotent operation (read)
        executor = Executor(TimeoutThenSuccessRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_idempotent_retry",
            goal="Idempotent retry task",
            steps=[TaskStep(id="s1", description="Read step", tool="file_controller", parameters={"action": "read"})]
        )

        result = executor.execute(plan)
        # Should retry (idempotent) and succeed
        self.assertTrue(result.success)
        self.assertEqual(calls["count"], 2)
        self.assertEqual(plan.steps[0].retry_count, 1)

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_unresolved_worker_logged_on_completion(self, mock_get_guard):
        """Unresolved workers should be logged when task completes."""
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"count": 0}
        logs = []

        def mock_log(msg):
            logs.append(msg)

        class TimeoutActionRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["count"] += 1
                time.sleep(5)  # Longer than grace period (2s) to ensure UNRESOLVED
                return "Completed late"

        executor = Executor(TimeoutActionRegistry(), Mock())
        # Patch the _log method
        executor._log = mock_log

        plan = TaskPlan(
            task_id="t_logged",
            goal="Logged task",
            steps=[TaskStep(id="s1", description="Write step", tool="file_controller", parameters={"action": "write"})]
        )

        result = executor.execute(plan)
        # Should fail (non-idempotent timeout)
        self.assertFalse(result.success)
        # Should have logged unresolved worker
        unresolved_logs = [l for l in logs if "UNRESOLVED" in l or "unresolved" in l.lower()]
        self.assertTrue(len(unresolved_logs) > 0, f"Expected unresolved log, got: {logs}")


class TestUnresolvedWorkerHandling(unittest.TestCase):
    """Tests for handling UNRESOLVED workers across steps."""

    def setUp(self):
        reset_global_registry()

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_unresolved_worker_from_previous_step_blocks_same_scope(self, mock_get_guard):
        """
        Test that retry is blocked when previous worker remains alive (Correction A).

        Step 1 uses an idempotent operation (read) with a long-running handler (10s).
        First attempt times out, worker marked UNRESOLVED.
        Retry logic waits for previous worker (5s join) but it's still alive.
        Retry should be aborted, step 1 fails with 'previous_worker_still_alive'.
        Step 2 never runs because task fails at step 1.
        """
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"step1_attempts": 0, "step2_attempts": 0}
        step1_done = threading.Event()

        class CombinedRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                action = params.get("action", "")
                if action == "read":
                    calls["step1_attempts"] += 1
                    if calls["step1_attempts"] == 1:
                        time.sleep(10)  # Long - worker stays alive through grace+backoff+retry join
                        step1_done.set()
                        return "Step1 attempt 1"
                    return "Step1 retry"
                elif action == "write":
                    calls["step2_attempts"] += 1
                    return "Step2 done"
                return "Unknown"

        executor = Executor(CombinedRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_cross_step_conflict",
            goal="Cross step conflict task",
            steps=[
                TaskStep(id="s1", description="Read step", tool="file_controller", parameters={"action": "read"}),  # idempotent
                TaskStep(id="s2", description="Write step", tool="file_controller", parameters={"action": "write"}),  # same scope
            ]
        )

        result = executor.execute(plan)
        # Step 1 retry blocked by previous worker still alive
        self.assertFalse(result.success)
        self.assertEqual(calls["step1_attempts"], 1)  # Only first attempt, retry blocked
        self.assertEqual(calls["step2_attempts"], 0)  # Step 2 never started (task failed at step 1)
        self.assertEqual(plan.steps[0].error, "previous_worker_still_alive")
        self.assertIn("previous worker still alive", result.error.lower())

        # Wait for the original worker to actually finish
        step1_done.wait(timeout=15)

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_different_scope_allows_next_step(self, mock_get_guard):
        """
        Test that retry is blocked when previous worker remains alive, regardless of scope (Correction A).

        Step 1 uses an idempotent operation (read) with a long-running handler (10s).
        First attempt times out, worker marked UNRESOLVED.
        Retry logic waits for previous worker (5s join) but it's still alive.
        Retry should be aborted, step 1 fails with 'previous_worker_still_alive'.
        Step 2 never runs because task fails at step 1.
        The different scope of step 2 is irrelevant because step 1 fails first.
        """
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"step1_attempts": 0, "step2_attempts": 0}
        step1_done = threading.Event()

        class CombinedRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                action = params.get("action", "")
                if action == "read":
                    calls["step1_attempts"] += 1
                    if calls["step1_attempts"] == 1:
                        time.sleep(10)  # Long - worker stays alive through grace+backoff+retry join
                        step1_done.set()
                        return "Step1 attempt 1"
                    return "Step1 retry"
                elif action == "type":
                    calls["step2_attempts"] += 1
                    return "Step2 done"
                return "Unknown"

        executor = Executor(CombinedRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_cross_step_different_scope",
            goal="Cross step different scope task",
            steps=[
                TaskStep(id="s1", description="Read step", tool="file_controller", parameters={"action": "read"}),  # idempotent, local_file
                TaskStep(id="s2", description="Type step", tool="computer_control", parameters={"action": "type"}),  # local_system
            ]
        )

        result = executor.execute(plan)
        # Step 1 retry blocked by previous worker still alive
        self.assertFalse(result.success)
        self.assertEqual(calls["step1_attempts"], 1)  # Only first attempt, retry blocked
        self.assertEqual(calls["step2_attempts"], 0)  # Step 2 never started (task failed at step 1)
        self.assertEqual(plan.steps[0].error, "previous_worker_still_alive")
        self.assertIn("previous worker still alive", result.error.lower())

        # Wait for the original worker to actually finish
        step1_done.wait(timeout=15)


class TestCorrectionAReggressions(unittest.TestCase):
    """Regression tests for Correction A: Worker Lifecycle Safety fixes."""

    def setUp(self):
        reset_global_registry()

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_retry_blocked_when_previous_worker_still_alive(self, mock_get_guard):
        """
        Test A: Retry blocked when previous worker remains alive.

        First attempt runs a long operation (10s). It times out, grace period elapses,
        worker marked UNRESOLVED. Retry condition is met (idempotent + recoverable).
        Executor waits for previous worker (5s join) but it's still alive.
        Retry should be aborted, step failed with 'previous_worker_still_alive'.
        Original worker remains tracked as UNRESOLVED until it actually terminates.
        """
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"attempts": 0, "worker1_done": threading.Event()}
        lock = threading.Lock()

        class LongRunningRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                with lock:
                    calls["attempts"] += 1
                    attempt_num = calls["attempts"]
                if attempt_num == 1:
                    # First attempt: run for 10s (longer than grace + retry wait)
                    time.sleep(10)
                    calls["worker1_done"].set()
                    return "First attempt done"
                # Should never reach here if retry is blocked
                return "Should not execute"

        executor = Executor(LongRunningRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_retry_blocked",
            goal="Retry blocked test",
            steps=[TaskStep(id="s1", description="Long read", tool="file_controller", parameters={"action": "read"})]
        )

        result = executor.execute(plan)

        # Retry should be aborted, step should fail
        self.assertFalse(result.success)
        self.assertEqual(calls["attempts"], 1)  # Only first attempt ran
        self.assertEqual(plan.steps[0].retry_count, 0)  # No retry incremented
        self.assertEqual(plan.steps[0].error, "previous_worker_still_alive")
        self.assertIn("previous worker still alive", result.error.lower())

        # Original worker should still be tracked (UNRESOLVED until it terminates)
        # Wait for it to actually finish
        calls["worker1_done"].wait(timeout=15)
        self.assertTrue(calls["worker1_done"].is_set())

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_cross_step_conflict_blocked_by_unresolved_worker(self, mock_get_guard):
        """
        Test B: Retry cross-step conflict blocked by unresolved worker from another step.

        This tests the cross-step conflict check in the RETRY logic.
        Verifies WorkerRegistry.has_conflicting_worker detects conflicts
        with live unresolved workers from other steps.
        """
        mock_get_guard.return_value.initialize.return_value = None

        from core.autonomous_agent import WorkerRegistry, WorkerRecord
        import threading
        import time

        registry = WorkerRegistry()

        # Create an unresolved worker from "step 1" (local_file scope)
        worker1 = WorkerRecord(
            attempt_id="step1-worker",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )

        def long_task():
            time.sleep(2)

        thread1 = threading.Thread(target=long_task)
        thread1.start()
        worker1.mark_running(thread1, threading.Event())
        worker1.mark_unresolved()
        registry.register(worker1)

        # Create a new worker for "step 2" retry (same local_file scope)
        worker2 = WorkerRecord(
            attempt_id="step2-retry",
            task_id="test-task",
            step_id="s2",
            tool_name="file_controller",
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )

        # has_conflicting_worker should detect the conflict
        self.assertTrue(registry.has_conflicting_worker(worker2))

        # Wait for worker1 to finish
        thread1.join(timeout=5)

        # After termination, worker1 should be marked terminated and conflict resolved
        worker1.mark_terminated()
        registry.cleanup_terminated()

        # Now conflict should be resolved
        self.assertFalse(registry.has_conflicting_worker(worker2))

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_different_scope_allows_execution(self, mock_get_guard):
        """
        Test C: Different resource scope allows execution despite unresolved worker.

        Verifies that WorkerRegistry.has_conflicting_worker returns False for
        different resource scopes, even when the other worker is unresolved and alive.
        """
        mock_get_guard.return_value.initialize.return_value = None

        from core.autonomous_agent import WorkerRegistry, WorkerRecord
        import threading
        import time

        registry = WorkerRegistry()

        # Create an unresolved worker on local_file scope
        worker1 = WorkerRecord(
            attempt_id="step1-worker",
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )

        def long_task():
            time.sleep(2)

        thread1 = threading.Thread(target=long_task)
        thread1.start()
        worker1.mark_running(thread1, threading.Event())
        worker1.mark_unresolved()
        registry.register(worker1)

        # Create a new worker for different scope (local_system)
        worker2 = WorkerRecord(
            attempt_id="step2-retry",
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )

        # Different scope should NOT conflict
        self.assertFalse(registry.has_conflicting_worker(worker2))

        # Same scope SHOULD conflict
        worker3 = WorkerRecord(
            attempt_id="step3-retry",
            task_id="test-task",
            step_id="s3",
            tool_name="file_controller",
            operation_name="file_controller:delete",
            resource_scope="local_file",
            is_idempotent=False,
        )
        self.assertTrue(registry.has_conflicting_worker(worker3))

        thread1.join(timeout=5)
        worker1.mark_terminated()
        registry.cleanup_terminated()

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_cancellation_event_signaling_does_not_terminate_thread(self, mock_get_guard):
        """
        Test D: Cancellation event signaling does not falsely report thread termination.

        A worker runs for 10s. Timeout occurs, cancel_event is set.
        The thread continues running (handler doesn't check cancel_event).
        After grace period, worker is marked UNRESOLVED, not TERMINATED.
        The thread remains alive until it naturally completes.
        """
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"attempts": 0, "handler_started": threading.Event(), "handler_finished": threading.Event()}

        class LongRunningRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["attempts"] += 1
                calls["handler_started"].set()
                time.sleep(10)  # Longer than timeout + grace
                calls["handler_finished"].set()
                return "Done"

        executor = Executor(LongRunningRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_cancel_semantics",
            goal="Cancellation semantics test",
            steps=[TaskStep(id="s1", description="Long write", tool="file_controller", parameters={"action": "write"})]
        )

        result = executor.execute(plan)

        # Should fail (non-idempotent timeout, no retry)
        self.assertFalse(result.success)
        self.assertEqual(calls["attempts"], 1)

        # Handler should still be running (not terminated by cancel_event)
        self.assertTrue(calls["handler_started"].is_set())
        self.assertFalse(calls["handler_finished"].is_set())

        # Wait for handler to actually finish
        calls["handler_finished"].wait(timeout=15)
        self.assertTrue(calls["handler_finished"].is_set())

        # Worker record should have been UNRESOLVED (not TERMINATED) during execution
        # This is verified by the fact that the executor returned while thread was alive


class TestCrossExecutorSharedRegistry(unittest.TestCase):
    """Regression tests for Correction C: Cross-Executor Shared Worker Registry."""

    def setUp(self):
        reset_global_registry()

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_two_executors_share_default_registry(self, mock_get_guard):
        """Two separate Executor instances should share the default registry."""
        mock_get_guard.return_value.initialize.return_value = None

        executor1 = Executor(Mock(), Mock())
        executor2 = Executor(Mock(), Mock())

        # Both should use the same global registry instance
        self.assertIs(executor1.worker_registry, executor2.worker_registry)
        self.assertIs(executor1.worker_registry, get_global_registry())

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_executor_a_reserves_resource_blocks_executor_b(self, mock_get_guard):
        """Executor A reserves a resource; Executor B cannot concurrently reserve the same resource."""
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"a_started": threading.Event(), "b_blocked": False}
        lock = threading.Lock()

        class SlowRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                with lock:
                    calls["a_started"].set()
                time.sleep(10)  # Long-running
                return "Done"

        class FastRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                with lock:
                    calls["b_blocked"] = True  # Should not reach here if blocked
                return "Fast"

        # Executor A starts a long-running file write (local_file scope)
        executor_a = Executor(SlowRegistry(), Mock())
        plan_a = TaskPlan(
            task_id="task_a",
            goal="Task A",
            steps=[TaskStep(id="s1", description="Write file", tool="file_controller", parameters={"action": "write", "path": "/shared/file.txt"})]
        )

        # Executor B tries to write to the same file (same resource key)
        executor_b = Executor(FastRegistry(), Mock())
        plan_b = TaskPlan(
            task_id="task_b",
            goal="Task B",
            steps=[TaskStep(id="s1", description="Write same file", tool="file_controller", parameters={"action": "write", "path": "/shared/file.txt"})]
        )

        # Start executor A in background
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future_a = pool.submit(executor_a.execute, plan_a)

            # Wait for A to start and admit worker (which reserves the resource)
            calls["a_started"].wait(timeout=2.0)

            # Now executor B tries to execute - should be blocked by resource conflict
            result_b = executor_b.execute(plan_b)

            # B should fail due to resource admission blocked
            self.assertFalse(result_b.success)
            self.assertIn("resource admission blocked", result_b.error.lower())

            # A should still be running
            self.assertFalse(future_a.done())

        # Wait for A to complete
        future_a.result(timeout=15)

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_different_resources_execute_independently(self, mock_get_guard):
        """Different resources can execute independently across executors."""
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"a_done": False, "b_done": False}
        lock = threading.Lock()

        class FastRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                action = params.get("action", "")
                if action == "write":
                    with lock:
                        calls["a_done"] = True
                    return "File A written"
                elif action == "read":
                    with lock:
                        calls["b_done"] = True
                    return "File B read"
                return "Unknown"

        executor_a = Executor(FastRegistry(), Mock())
        plan_a = TaskPlan(
            task_id="task_a",
            goal="Task A",
            steps=[TaskStep(id="s1", description="Write file A", tool="file_controller", parameters={"action": "write", "path": "/file_a.txt"})]
        )

        executor_b = Executor(FastRegistry(), Mock())
        plan_b = TaskPlan(
            task_id="task_b",
            goal="Task B",
            steps=[TaskStep(id="s1", description="Read file B", tool="file_controller", parameters={"action": "read", "path": "/file_b.txt"})]
        )

        # Both should succeed independently (different resource keys)
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            future_a = pool.submit(executor_a.execute, plan_a)
            future_b = pool.submit(executor_b.execute, plan_b)

            result_a = future_a.result(timeout=5)
            result_b = future_b.result(timeout=5)

        self.assertTrue(result_a.success)
        self.assertTrue(result_b.success)
        self.assertTrue(calls["a_done"])
        self.assertTrue(calls["b_done"])

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_unresolved_worker_in_executor_a_blocks_executor_b(self, mock_get_guard):
        """An unresolved worker in Executor A blocks conflicting work in Executor B."""
        mock_get_guard.return_value.initialize.return_value = None

        step1_started = threading.Event()
        step1_done = threading.Event()

        class LongRunningRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                step1_started.set()
                time.sleep(10)
                step1_done.set()
                return "Done"

        class FastRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                return "Fast"

        # Executor A starts a long-running file write (idempotent read, so it will retry on timeout)
        executor_a = Executor(LongRunningRegistry(), Mock())
        plan_a = TaskPlan(
            task_id="task_a",
            goal="Task A",
            steps=[TaskStep(id="s1", description="Read file", tool="file_controller", parameters={"action": "read", "path": "/shared/file.txt"})]
        )

        # Executor B tries to write to the same file
        executor_b = Executor(FastRegistry(), Mock())
        plan_b = TaskPlan(
            task_id="task_b",
            goal="Task B",
            steps=[TaskStep(id="s1", description="Write same file", tool="file_controller", parameters={"action": "write", "path": "/shared/file.txt"})]
        )

        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future_a = pool.submit(executor_a.execute, plan_a)

            # Wait for A to start
            step1_started.wait(timeout=2.0)
            # Give it time to timeout and become UNRESOLVED
            time.sleep(0.3)  # STEP_TIMEOUT=0.05 + grace=2.0, but we just need it to be UNRESOLVED

            # Now executor B tries - should be blocked by unresolved worker from A
            result_b = executor_b.execute(plan_b)

            # B should fail due to conflict with unresolved worker
            self.assertFalse(result_b.success)
            self.assertIn("resource admission blocked", result_b.error.lower())

            # Wait for A to complete
            step1_done.wait(timeout=15)

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_completing_unrelated_worker_does_not_release_other_reservation(self, mock_get_guard):
        """Completing an unrelated worker does not release another worker's reservation."""
        mock_get_guard.return_value.initialize.return_value = None

        calls = {"a_done": threading.Event(), "b_started": threading.Event()}

        class RegistryA:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["a_done"].set()
                return "A done"

        class RegistryB:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["b_started"].set()
                time.sleep(10)
                return "B done"

        executor_a = Executor(RegistryA(), Mock())
        plan_a = TaskPlan(
            task_id="task_a",
            goal="Task A",
            steps=[TaskStep(id="s1", description="Read file A", tool="file_controller", parameters={"action": "read", "path": "/file_a.txt"})]
        )

        executor_b = Executor(RegistryB(), Mock())
        plan_b = TaskPlan(
            task_id="task_b",
            goal="Task B",
            steps=[TaskStep(id="s1", description="Write file B", tool="file_controller", parameters={"action": "write", "path": "/file_b.txt"})]
        )

        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            future_a = pool.submit(executor_a.execute, plan_a)
            future_b = pool.submit(executor_b.execute, plan_b)

            # A completes quickly
            result_a = future_a.result(timeout=5)
            self.assertTrue(result_a.success)
            calls["a_done"].wait(timeout=2)

            # B should still be running (not affected by A's completion)
            self.assertFalse(future_b.done())
            self.assertTrue(calls["b_started"].is_set())

            # Wait for B to complete
            future_b.result(timeout=15)

    def test_explicit_injected_registry_remains_isolated(self):
        """Explicitly injected registries remain isolated from global state."""
        registry1 = WorkerRegistry()
        registry2 = WorkerRegistry()

        executor1 = Executor(Mock(), Mock(), worker_registry=registry1)
        executor2 = Executor(Mock(), Mock(), worker_registry=registry2)

        # Each should use its own registry
        self.assertIs(executor1.worker_registry, registry1)
        self.assertIs(executor2.worker_registry, registry2)
        self.assertIsNot(executor1.worker_registry, executor2.worker_registry)
        self.assertIsNot(executor1.worker_registry, get_global_registry())
        self.assertIsNot(executor2.worker_registry, get_global_registry())

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_cleanup_completed_does_not_remove_active_unresolved(self, mock_get_guard):
        """Completed worker cleanup does not remove active or unresolved reservations."""
        mock_get_guard.return_value.initialize.return_value = None

        from core.worker_registry import get_global_registry as get_reg
        registry = get_reg()

        # Create an unresolved worker manually
        worker_unresolved = WorkerRecord(
            attempt_id="unresolved-1",
            task_id="task_x",
            step_id="s1",
            tool_name="file_controller",
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        worker_unresolved.mark_running(mock_thread, threading.Event())
        worker_unresolved.mark_unresolved()
        registry.register(worker_unresolved)

        # Create a TERMINATED worker (cleanup_terminated only removes TERMINATED)
        worker_terminated = WorkerRecord(
            attempt_id="terminated-1",
            task_id="task_y",
            step_id="s2",
            tool_name="file_controller",
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )
        worker_terminated.state = WorkerState.TERMINATED
        worker_terminated.finished_at = time.time()
        registry.register(worker_terminated)

        # Verify both exist
        self.assertEqual(len(registry.get_all_workers()), 2)
        self.assertEqual(len(registry.get_live_workers()), 1)  # unresolved is alive

        # Cleanup terminated - should only remove TERMINATED (not UNRESOLVED)
        removed = registry.cleanup_terminated()
        self.assertEqual(removed, 1)

        # Unresolved worker should still be there with its reservation
        remaining = registry.get_all_workers()
        self.assertEqual(len(remaining), 1)
        self.assertEqual(remaining[0].attempt_id, "unresolved-1")
        self.assertEqual(remaining[0].state, WorkerState.UNRESOLVED)

        # Resource scope should still be reserved
        scope_workers = registry.get_workers_by_resource_scope("local_file")
        self.assertEqual(len(scope_workers), 1)
        self.assertEqual(scope_workers[0].attempt_id, "unresolved-1")


class TestComputerSettingsResourceConflicts(unittest.TestCase):
    """Regression tests for computer_settings resource conflicts after window resource coordination fix."""

    def setUp(self):
        reset_global_registry()

    def test_computer_settings_scroll_actions_conflict(self):
        """computer_settings:scroll_up and scroll_down should conflict (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: scroll_up
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "scroll_up"},
            operation_name="computer_settings:scroll_up",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: scroll_down should be blocked
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_settings",
            parameters={"action": "scroll_down"},
            operation_name="computer_settings:scroll_down",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"scroll_up should conflict with scroll_down, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_computer_settings_tab_navigation_conflict(self):
        """computer_settings:next_tab and prev_tab should conflict (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: next_tab
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "next_tab"},
            operation_name="computer_settings:next_tab",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: prev_tab should be blocked
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_settings",
            parameters={"action": "prev_tab"},
            operation_name="computer_settings:prev_tab",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"next_tab should conflict with prev_tab, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_computer_settings_copy_paste_conflict(self):
        """computer_settings:copy and paste should conflict (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: copy
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "copy"},
            operation_name="computer_settings:copy",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: paste should be blocked
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_settings",
            parameters={"action": "paste"},
            operation_name="computer_settings:paste",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"copy should conflict with paste, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_computer_settings_type_vs_press_key_conflict(self):
        """computer_settings:type_text and press_key should conflict (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: type_text
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "type_text", "text": "hello"},
            operation_name="computer_settings:type_text",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: press_key should be blocked
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_settings",
            parameters={"action": "press_key", "key": "enter"},
            operation_name="computer_settings:press_key",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"type_text should conflict with press_key, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_computer_settings_input_vs_computer_control_input_conflict(self):
        """computer_settings input actions should conflict with computer_control input actions (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: computer_settings type_text
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "type_text", "text": "hello"},
            operation_name="computer_settings:type_text",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control click should be blocked
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "click", "x": 100, "y": 100},
            operation_name="computer_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"computer_settings type_text should conflict with computer_control click, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

        # Reset registry
        registry = WorkerRegistry()

        # First worker: computer_control type
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_control",
            parameters={"action": "type", "text": "hello"},
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_settings press_key should be blocked
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_settings",
            parameters={"action": "press_key", "key": "enter"},
            operation_name="computer_settings:press_key",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"computer_control type should conflict with computer_settings press_key, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")


class TestWorkerRegistryIntegration(unittest.TestCase):
    """Integration tests for WorkerRegistry with open_app, computer_settings, and inline tools."""

    def setUp(self):
        reset_global_registry()

    def test_open_app_admission_and_lifecycle(self):
        """open_app should properly admit worker, track lifecycle, and cleanup."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # Create open_app worker
        worker = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="open_app",
            parameters={"app_name": "Notepad"},
            operation_name="open_app",
            resource_scope="local_system",
            is_idempotent=False,
        )

        # Should be admitted (no conflicts initially)
        admitted, reason = registry.admit_worker(worker)
        self.assertTrue(admitted, f"open_app should be admitted, got: {reason}")

        # Worker should be registered
        self.assertIsNotNone(registry.get(worker.attempt_id))

        # Mark as running
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        cancel_event = threading.Event()
        worker.mark_running(mock_thread, cancel_event)
        self.assertEqual(worker.state, WorkerState.RUNNING)

        # Mark as completed and release resources
        worker.mark_completed({"launched": True})
        registry.release_resources(worker.attempt_id)

        # Resources should be released
        self.assertEqual(worker.state, WorkerState.COMPLETED)

    def test_computer_settings_admission_and_conflicts(self):
        """computer_settings should properly admit worker and handle conflicts."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # Create computer_settings worker for volume_up
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "volume_up"},
            operation_name="computer_settings:volume_up",
            resource_scope="local_system",
            is_idempotent=True,
        )

        admitted, reason = registry.admit_worker(worker1)
        self.assertTrue(admitted, f"computer_settings volume_up should be admitted, got: {reason}")

        # Mark as running
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        worker1.mark_running(mock_thread, threading.Event())
        self.assertEqual(worker1.state, WorkerState.RUNNING)

        # Another computer_settings action should conflict (both use global:input)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_settings",
            parameters={"action": "brightness_up"},
            operation_name="computer_settings:brightness_up",
            resource_scope="local_system",
            is_idempotent=True,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"volume_up should conflict with brightness_up, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_inline_run_with_worker_registry_sync_path(self, mock_get_guard):
        """_run_with_worker_registry should handle synchronous operations correctly."""
        mock_get_guard.return_value.initialize.return_value = None

        # Import the executor which uses _run_with_worker_registry
        from core.autonomous_agent import Executor, TaskPlan, TaskStep

        calls = {"count": 0}

        class SyncActionRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["count"] += 1
                return "Sync success"

        executor = Executor(SyncActionRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_sync",
            goal="Sync task",
            steps=[TaskStep(id="s1", description="Sync step", tool="file_controller", parameters={"action": "read"})]
        )

        result = executor.execute(plan)
        self.assertTrue(result.success)
        self.assertEqual(calls["count"], 1)

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_inline_run_with_worker_registry_async_path(self, mock_get_guard):
        """_run_with_worker_registry should handle async operations (timeout/retry) correctly."""
        mock_get_guard.return_value.initialize.return_value = None

        from core.autonomous_agent import Executor, TaskPlan, TaskStep

        calls = {"count": 0}

        class SlowThenSuccessRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["count"] += 1
                if calls["count"] == 1:
                    time.sleep(0.15)  # Longer than STEP_TIMEOUT (0.05s)
                    return "Late success"
                return "Success on retry"

        executor = Executor(SlowThenSuccessRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_async",
            goal="Async task",
            steps=[TaskStep(id="s1", description="Read step", tool="file_controller", parameters={"action": "read"})]
        )

        result = executor.execute(plan)
        # Should retry (idempotent) and succeed
        self.assertTrue(result.success)
        self.assertEqual(calls["count"], 2)
        self.assertEqual(plan.steps[0].retry_count, 1)

    def test_unresolved_worker_reservation_retention(self):
        """Unresolved worker should retain resource reservation until terminated."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # Create unresolved worker
        worker = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "type_text", "text": "hello"},
            operation_name="computer_settings:type_text",
            resource_scope="local_system",
            is_idempotent=False,
        )
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        worker.mark_running(mock_thread, threading.Event())
        worker.mark_unresolved()
        registry.register(worker)

        # Verify worker is tracked as unresolved
        unresolved = registry.get_unresolved_workers()
        self.assertEqual(len(unresolved), 1)
        self.assertEqual(unresolved[0].attempt_id, worker.attempt_id)

        # Resource should still be reserved
        scope_workers = registry.get_workers_by_resource_scope("local_system")
        self.assertEqual(len(scope_workers), 1)
        self.assertEqual(scope_workers[0].attempt_id, worker.attempt_id)

        # New worker with same resource should be blocked
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "type", "text": "world"},
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"Unresolved worker should block new worker, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

        # Only after marking terminated and cleanup should resources be released
        worker.mark_terminated()
        registry.cleanup_terminated()

        # Now new worker should be admitted
        worker3 = create_worker_record(
            task_id="test-task",
            step_id="s3",
            tool_name="computer_control",
            parameters={"action": "type", "text": "world"},
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker3)
        self.assertTrue(admitted, f"After cleanup, new worker should be admitted, got: {reason}")

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_thread_start_failure_cleanup(self, mock_get_guard):
        """Thread start failure should properly cleanup worker resources."""
        mock_get_guard.return_value.initialize.return_value = None

        from core.autonomous_agent import Executor, TaskPlan, TaskStep

        calls = {"started": False}

        class FailToStartRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["started"] = True
                raise RuntimeError("Failed to start thread")

        executor = Executor(FailToStartRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_thread_fail",
            goal="Thread fail task",
            steps=[TaskStep(id="s1", description="Write step", tool="file_controller", parameters={"action": "write"})]
        )

        result = executor.execute(plan)
        # Should fail
        self.assertFalse(result.success)
        self.assertTrue(calls["started"])

    def test_open_app_thread_start_failure_releases_resources(self):
        """open_app thread.start() failure should mark worker failed, release resources."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState, get_global_registry, reset_global_registry
        from unittest.mock import Mock, patch
        import threading

        reset_global_registry()
        registry = get_global_registry()

        # Create open_app worker
        worker = create_worker_record(
            task_id="test-task",
            step_id="open_app",
            tool_name="open_app",
            parameters={"app_name": "Notepad"},
            operation_name="open_app",
            resource_scope="local_system",
            is_idempotent=False,
        )

        # Admit worker (reserves resources)
        admitted, reason = registry.admit_worker(worker)
        self.assertTrue(admitted, f"open_app should be admitted: {reason}")
        self.assertIn("app:Notepad", registry._resource_reservations)

        # Simulate thread.start() failure by patching threading.Thread.start
        original_start = threading.Thread.start
        def failing_start(self):
            raise RuntimeError("can't start new thread")

        with patch.object(threading.Thread, 'start', failing_start):
            try:
                # This mimics the fixed open_app code path
                cancel_event = threading.Event()
                thread = threading.Thread(target=lambda: None, daemon=True)
                try:
                    thread.start()
                except RuntimeError:
                    worker.mark_failed("thread start failed: can't start new thread")
                    worker.mark_terminated()
                    registry.release_resources(worker.attempt_id)
                    raise
                worker.mark_running(thread, cancel_event)
            except RuntimeError:
                pass  # Expected

        # Verify cleanup - mark_failed sets FAILED, then mark_terminated sets TERMINATED
        self.assertEqual(worker.state, WorkerState.TERMINATED)
        # Resources should be released
        self.assertNotIn("app:Notepad", registry._resource_reservations)
        self.assertEqual(len(registry._scope_reservations.get("local_system", set())), 0)

        # New worker with same resource should now be admitted
        worker2 = create_worker_record(
            task_id="test-task-2",
            step_id="open_app",
            tool_name="open_app",
            parameters={"app_name": "Notepad"},
            operation_name="open_app",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertTrue(admitted, f"New worker should be admitted after cleanup: {reason}")

    @patch("core.autonomous_agent.get_permission_guard")
    def test_run_with_worker_registry_sync_success(self, mock_get_guard):
        """_run_with_worker_registry sync path: successful execution."""
        mock_get_guard.return_value.initialize.return_value = None

        import main
        import asyncio
        from unittest.mock import Mock

        mock_ui = Mock()
        mock_ui.muted = True
        jarvis = main.JarvisLive(mock_ui)

        async def run_test():
            def sync_handler(args):
                return "sync result"

            result = await jarvis._run_with_worker_registry(
                tool_name="test_tool",
                operation_name="test_op",
                args={"param": "value"},
                handler=sync_handler,
                is_async=False
            )
            return result

        result = asyncio.run(run_test())
        self.assertEqual(result, "sync result")

        # Verify worker was cleaned up
        from core.worker_registry import get_global_registry
        registry = get_global_registry()
        # Resources should be released
        self.assertEqual(len(registry._resource_reservations), 0)

    @patch("core.autonomous_agent.get_permission_guard")
    def test_run_with_worker_registry_async_success(self, mock_get_guard):
        """_run_with_worker_registry async path: successful execution."""
        mock_get_guard.return_value.initialize.return_value = None

        import main
        import asyncio
        from unittest.mock import Mock

        mock_ui = Mock()
        mock_ui.muted = True
        jarvis = main.JarvisLive(mock_ui)

        async def run_test():
            async def async_handler(args):
                await asyncio.sleep(0.01)
                return "async result"

            result = await jarvis._run_with_worker_registry(
                tool_name="test_tool",
                operation_name="test_op",
                args={"param": "value"},
                handler=async_handler,
                is_async=True
            )
            return result

        result = asyncio.run(run_test())
        self.assertEqual(result, "async result")

        from core.worker_registry import get_global_registry
        registry = get_global_registry()
        self.assertEqual(len(registry._resource_reservations), 0)

    @patch("core.autonomous_agent.get_permission_guard")
    def test_run_with_worker_registry_exception_cleanup(self, mock_get_guard):
        """_run_with_worker_registry exception path: cleanup on failure."""
        mock_get_guard.return_value.initialize.return_value = None

        import main
        import asyncio
        from unittest.mock import Mock

        mock_ui = Mock()
        mock_ui.muted = True
        jarvis = main.JarvisLive(mock_ui)

        async def run_test():
            def failing_handler(args):
                raise ValueError("Handler error")

            try:
                await jarvis._run_with_worker_registry(
                    tool_name="test_tool",
                    operation_name="test_op",
                    args={"param": "value"},
                    handler=failing_handler,
                    is_async=False
                )
            except ValueError:
                pass  # Expected

        asyncio.run(run_test())

        from core.worker_registry import get_global_registry
        registry = get_global_registry()
        # Resources should be released even on exception
        self.assertEqual(len(registry._resource_reservations), 0)

    @patch("core.autonomous_agent.get_permission_guard")
    def test_run_with_worker_registry_admission_blocked(self, mock_get_guard):
        """_run_with_worker_registry: admission blocked returns failed outcome."""
        mock_get_guard.return_value.initialize.return_value = None

        import main
        import asyncio
        from unittest.mock import Mock

        mock_ui = Mock()
        mock_ui.muted = True
        jarvis = main.JarvisLive(mock_ui)

        # Pre-populate registry with a running worker holding the same resource
        from core.worker_registry import create_worker_record, WorkerState, get_global_registry, reset_global_registry
        reset_global_registry()
        registry = get_global_registry()

        blocking_worker = create_worker_record(
            task_id="blocking",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "type_text"},
            operation_name="computer_settings:type_text",
            resource_scope="local_system",
            is_idempotent=False,
        )
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        blocking_worker.mark_running(mock_thread, threading.Event())
        registry.register(blocking_worker)

        async def run_test():
            def handler(args):
                return "should not run"

            from core import outcome
            result = await jarvis._run_with_worker_registry(
                tool_name="computer_settings",
                operation_name="computer_settings:type_text",
                args={"action": "type_text", "text": "hello"},
                handler=handler,
                is_async=False
            )
            return result

        result = asyncio.run(run_test())
        # Result should be a failed outcome string
        self.assertIn("failed", result.lower())
        self.assertIn("resource admission blocked", result.lower())

    @patch("core.autonomous_agent.get_permission_guard")
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    @patch("core.task_monitoring.STEP_TIMEOUT", 0.05)
    def test_exception_during_execution_cleanup(self, mock_get_guard):
        """Exception during execution should properly cleanup worker."""
        mock_get_guard.return_value.initialize.return_value = None

        from core.autonomous_agent import Executor, TaskPlan, TaskStep

        calls = {"count": 0}

        class ExceptionRegistry:
            def has(self, name): return True
            def run(self, name, params, ctx):
                calls["count"] += 1
                if calls["count"] == 1:
                    raise ValueError("Test exception")
                return "Success"

        executor = Executor(ExceptionRegistry(), Mock())
        plan = TaskPlan(
            task_id="t_exception",
            goal="Exception task",
            steps=[TaskStep(id="s1", description="Read step", tool="file_controller", parameters={"action": "read"})]
        )

        result = executor.execute(plan)
        # Should fail (non-retry for exception on non-idempotent? Actually read is idempotent but exception is not recoverable)
        self.assertFalse(result.success)
        # Exception should be captured


# ─── send_message Resource Conflict Tests ─────────────────────────────────────

class TestSendMessageResourceConflicts(unittest.TestCase):
    """Tests for send_message resource conflicts with other modules."""

    def setUp(self):
        reset_global_registry()

    def test_send_message_telegram_vs_computer_control_type(self):
        """send_message:telegram should conflict with computer_control:type (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: send_message telegram (uses global:input + app:manage)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="send_message",
            parameters={"platform": "telegram", "receiver": "John", "message_text": "hello"},
            operation_name="send_message:telegram",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control type (uses global:input) - should conflict
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "type", "text": "world"},
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"telegram should conflict with type (global:input), got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_send_message_signal_vs_computer_control_click(self):
        """send_message:signal should conflict with computer_control:click (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: send_message signal
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="send_message",
            parameters={"platform": "signal", "receiver": "John", "message_text": "hello"},
            operation_name="send_message:signal",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control click - should conflict
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "click", "x": 100, "y": 100},
            operation_name="computer_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"signal should conflict with click (global:input), got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_send_message_discord_vs_computer_settings_type_text(self):
        """send_message:discord should conflict with computer_settings:type_text (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: send_message discord
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="send_message",
            parameters={"platform": "discord", "receiver": "John", "message_text": "hello"},
            operation_name="send_message:discord",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_settings type_text - should conflict
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_settings",
            parameters={"action": "type_text", "text": "world"},
            operation_name="computer_settings:type_text",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"discord should conflict with type_text (global:input), got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_send_message_instagram_vs_browser_control_go_to(self):
        """send_message:instagram should conflict with browser_control:go_to (shared network:egress)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: send_message instagram (browser + pyautogui) - uses network:www.instagram.com
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="send_message",
            parameters={"platform": "instagram", "receiver": "John", "message_text": "hello"},
            operation_name="send_message:instagram",
            resource_scope="remote_service",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: browser_control go_to to instagram.com - should conflict on network:www.instagram.com
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="browser_control",
            parameters={"action": "go_to", "browser": "chrome", "url": "https://www.instagram.com"},
            operation_name="browser_control:go_to",
            resource_scope="network_egress",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"instagram should conflict with go_to (network:www.instagram.com), got: {reason}")
        self.assertEqual(reason, "resource_key:network:www.instagram.com")

    def test_send_message_messenger_vs_browser_control_search(self):
        """send_message:messenger should conflict with browser_control:search (shared network:egress)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: send_message messenger - uses network:www.messenger.com
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="send_message",
            parameters={"platform": "messenger", "receiver": "John", "message_text": "hello"},
            operation_name="send_message:messenger",
            resource_scope="remote_service",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: browser_control search using google - should conflict on network:www.google.com
        # Actually messenger uses www.messenger.com, search uses www.google.com - different domains
        # So they should NOT conflict on network key, but they could conflict on global:input
        # Let me check what keys each reserves
        # messenger: messaging:messenger, network:www.messenger.com, global:input
        # search: browser:session:chrome, network:www.google.com
        # These should NOT conflict on network keys, so this test should expect NO conflict
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="browser_control",
            parameters={"action": "search", "browser": "chrome", "query": "test"},
            operation_name="browser_control:search",
            resource_scope="network_egress",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different network domains, so no conflict on network
        # But messenger also uses global:input, search only uses browser session
        # So they should be admitted
        self.assertTrue(admitted, f"messenger and search should NOT conflict (different network domains), got: {reason}")

    def test_send_message_whatsapp_driver_vs_computer_control_click(self):
        """send_message:whatsapp (driver path) should NOT conflict with computer_control:click (no shared keys)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: send_message whatsapp (driver - no pyautogui)
        # Note: whatsapp fallback uses pyautogui, but primary path is driver only
        # Resource keys for whatsapp: messaging:whatsapp, global:input, app:manage
        # The test verifies that the keys are what we expect
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="send_message",
            parameters={"platform": "whatsapp", "receiver": "John", "message_text": "hello"},
            operation_name="send_message:whatsapp",
            resource_scope="remote_service",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # The whatsapp keys include global:input and app:manage (for fallback)
        # So it SHOULD conflict with computer_control:click on global:input
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "click", "x": 100, "y": 100},
            operation_name="computer_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Whatsapp reserves global:input (for fallback), so it should conflict
        self.assertFalse(admitted, f"whatsapp should conflict with click (global:input fallback), got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_send_message_different_platforms_no_conflict(self):
        """Different send_message platforms should NOT conflict on messaging keys (isolated per platform)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: telegram
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="send_message",
            parameters={"platform": "telegram", "receiver": "John", "message_text": "hello"},
            operation_name="send_message:telegram",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: signal - different messaging key, but both use global:input
        # They SHOULD conflict on global:input even though messaging keys differ
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="send_message",
            parameters={"platform": "signal", "receiver": "Jane", "message_text": "world"},
            operation_name="send_message:signal",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Both use global:input + app:manage, so they conflict
        self.assertFalse(admitted, f"telegram and signal should conflict (global:input), got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_send_message_whatsapp_reserves_messaging_and_underlying_keys(self):
        """send_message:whatsapp should reserve messaging:whatsapp + global:input + app:manage."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("send_message", {"platform": "whatsapp", "receiver": "John", "message_text": "hello"}, "send_message:whatsapp")
        self.assertIn("messaging:whatsapp", keys)
        self.assertIn("global:input", keys)
        self.assertIn("app:manage", keys)
        self.assertEqual(len(keys), 3)

    def test_send_message_telegram_reserves_messaging_and_underlying_keys(self):
        """send_message:telegram should reserve messaging:telegram + global:input + app:manage."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("send_message", {"platform": "telegram", "receiver": "John", "message_text": "hello"}, "send_message:telegram")
        self.assertIn("messaging:telegram", keys)
        self.assertIn("global:input", keys)
        self.assertIn("app:manage", keys)
        self.assertEqual(len(keys), 3)

    def test_send_message_instagram_reserves_messaging_network_input(self):
        """send_message:instagram should reserve messaging:instagram + network:www.instagram.com + global:input."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("send_message", {"platform": "instagram", "receiver": "John", "message_text": "hello"}, "send_message:instagram")
        self.assertIn("messaging:instagram", keys)
        self.assertIn("network:www.instagram.com", keys)
        self.assertIn("global:input", keys)
        self.assertEqual(len(keys), 3)

    def test_send_message_messenger_reserves_messaging_network_input(self):
        """send_message:messenger should reserve messaging:messenger + network:www.messenger.com + global:input."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("send_message", {"platform": "messenger", "receiver": "John", "message_text": "hello"}, "send_message:messenger")
        self.assertIn("messaging:messenger", keys)
        self.assertIn("network:www.messenger.com", keys)
        self.assertIn("global:input", keys)
        self.assertEqual(len(keys), 3)

    def test_send_message_signal_reserves_messaging_input_app(self):
        """send_message:signal should reserve messaging:signal + global:input + app:manage."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("send_message", {"platform": "signal", "receiver": "John", "message_text": "hello"}, "send_message:signal")
        self.assertIn("messaging:signal", keys)
        self.assertIn("global:input", keys)
        self.assertIn("app:manage", keys)
        self.assertEqual(len(keys), 3)

    def test_send_message_discord_reserves_messaging_input_app(self):
        """send_message:discord should reserve messaging:discord + global:input + app:manage."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("send_message", {"platform": "discord", "receiver": "John", "message_text": "hello"}, "send_message:discord")
        self.assertIn("messaging:discord", keys)
        self.assertIn("global:input", keys)
        self.assertIn("app:manage", keys)
        self.assertEqual(len(keys), 3)


# ─── send_message Permission Denial Tests ──────────────────────────────────────

class TestSendMessagePermissionDenial(unittest.TestCase):
    """Tests for permission denial in send_message."""

    def setUp(self):
        reset_global_registry()

    @patch("actions.send_message.get_permission_guard")
    def test_send_message_whatsapp_requires_approval(self, mock_get_guard):
        """send_message:whatsapp should require owner approval (messaging.send in OWNER_APPROVAL_REQUIRED)."""
        from core.permission_manager import OWNER_APPROVAL_REQUIRED, PermissionResult
        self.assertIn("messaging.send", OWNER_APPROVAL_REQUIRED)

        mock_guard = Mock()
        mock_guard.initialize.return_value = None
        mock_guard._initialized = True
        mock_guard.check_operation.return_value = PermissionResult(False, "owner_approval_required",
                                                                    instruction="Please approve this operation",
                                                                    requires_approval=True)
        mock_get_guard.return_value = mock_guard

        from actions.send_message import send_message
        result = send_message({"platform": "whatsapp", "receiver": "John", "message_text": "hello"})
        # Should return approval instruction
        self.assertIn("approve", result.lower())

    @patch("actions.send_message.get_permission_guard")
    def test_send_message_instagram_requires_approval(self, mock_get_guard):
        """send_message:instagram should require owner approval."""
        from core.permission_manager import OWNER_APPROVAL_REQUIRED, PermissionResult
        self.assertIn("messaging.send", OWNER_APPROVAL_REQUIRED)

        mock_guard = Mock()
        mock_guard.initialize.return_value = None
        mock_guard._initialized = True
        mock_guard.check_operation.return_value = PermissionResult(False, "owner_approval_required",
                                                                    instruction="Please approve this operation",
                                                                    requires_approval=True)
        mock_get_guard.return_value = mock_guard

        from actions.send_message import send_message
        result = send_message({"platform": "instagram", "receiver": "John", "message_text": "hello"})
        self.assertIn("approve", result.lower())


# ─── send_message WorkerRegistry Admission Denial Tests ────────────────────────

class TestSendMessageAdmissionDenial(unittest.TestCase):
    """Tests for WorkerRegistry admission denial in send_message."""

    def setUp(self):
        reset_global_registry()

    @patch("actions.send_message.get_permission_guard")
    @patch("actions.send_message.get_global_registry")
    def test_send_message_admission_blocked_by_conflict(self, mock_get_registry, mock_get_guard):
        """send_message should fail with resource conflict when admission denied."""
        from core.permission_manager import PermissionResult
        mock_guard = Mock()
        mock_guard.initialize.return_value = None
        mock_guard.check_operation.return_value = PermissionResult(True, "granted")
        mock_get_guard.return_value = mock_guard

        # Pre-populate registry with a blocking worker
        from core.worker_registry import create_worker_record, WorkerState, get_global_registry
        registry = get_global_registry()
        blocking_worker = create_worker_record(
            task_id="blocking",
            step_id="s1",
            tool_name="computer_control",
            parameters={"action": "type", "text": "hello"},
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        blocking_worker.mark_running(mock_thread, threading.Event())
        registry.register(blocking_worker)

        mock_get_registry.return_value = registry

        from actions.send_message import send_message
        result = send_message({"platform": "telegram", "receiver": "John", "message_text": "hello"})
        self.assertIn("failed", result.lower())
        self.assertIn("resource conflict", result.lower())


# ─── dev_agent Resource Conflict Tests ────────────────────────────────────────────

class TestDevAgentResourceConflicts(unittest.TestCase):
    """Tests for dev_agent resource conflicts with other modules."""

    def setUp(self):
        reset_global_registry()

    def test_dev_agent_improve_reserves_underlying_keys(self):
        """dev_agent:improve should reserve project:{path} + proc:exec + network:egress."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("dev_agent", {"mode": "improve", "folder": "/home/user/project"}, "dev_agent:improve")
        self.assertIn("project:/home/user/project", keys)
        self.assertIn("proc:exec", keys)
        self.assertIn("network:egress", keys)
        # improve does NOT use app:manage (that's only for build)
        self.assertNotIn("app:manage", keys)
        self.assertEqual(len(keys), 3)

    def test_dev_agent_build_reserves_underlying_keys(self):
        """dev_agent:build should reserve project:{path} + proc:exec + network:egress + app:manage."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("dev_agent", {"mode": "build", "project_name": "my_project"}, "dev_agent:build")
        self.assertIn("project:", keys[0])  # project key with path
        self.assertIn("proc:exec", keys)
        self.assertIn("network:egress", keys)
        self.assertIn("app:manage", keys)
        self.assertEqual(len(keys), 4)

    def test_dev_agent_status_reserves_project_key(self):
        """dev_agent:status should reserve only project key (read-only)."""
        from core.worker_registry import extract_resource_keys
        keys = extract_resource_keys("dev_agent", {"mode": "status", "folder": "/home/user/project"}, "dev_agent:status")
        self.assertIn("project:/home/user/project", keys)
        # status is read-only - no proc:exec, network:egress, or app:manage
        self.assertNotIn("proc:exec", keys)
        self.assertNotIn("network:egress", keys)
        self.assertNotIn("app:manage", keys)
        self.assertEqual(len(keys), 1)

    def test_dev_agent_improve_conflicts_with_file_controller_write(self):
        """dev_agent:improve should conflict with file_controller:write (proc:exec vs fs.write are different, but same project path)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent improve (reserves project path + proc:exec + network:egress)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "improve", "folder": "/shared/project"},
            operation_name="dev_agent:improve",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: file_controller write to same project - should conflict on project key
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/shared/project/main.py", "content": "x=1"},
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # They share the project path resource key
        self.assertFalse(admitted, f"dev_agent improve should conflict with file_controller write (same project), got: {reason}")
        self.assertEqual(reason, "resource_key:project:/shared/project")

    def test_dev_agent_build_conflicts_with_open_app(self):
        """dev_agent:build should conflict with open_app (both use app:manage)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent build (uses app:manage to open VSCode)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "build", "project_name": "my_project"},
            operation_name="dev_agent:build",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_settings open_settings - should conflict on app:manage
        # (open_app uses app:{app_name}, not app:manage)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_settings",
            parameters={"action": "open_settings"},
            operation_name="computer_settings:open_settings",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"dev_agent build should conflict with computer_settings open_settings (app:manage), got: {reason}")
        self.assertEqual(reason, "resource_key:app:manage")

    def test_dev_agent_improve_conflicts_with_send_message_telegram(self):
        """dev_agent:improve should conflict with send_message:telegram (both use proc:exec)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent improve (uses proc:exec for subprocesses)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "improve", "folder": "/project"},
            operation_name="dev_agent:improve",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: send_message telegram (uses pyautogui which uses proc:exec indirectly)
        # Actually send_message uses pyautogui, not subprocess directly. Let me check...
        # send_message telegram uses global:input + app:manage, not proc:exec
        # So this test should verify NO conflict on proc:exec
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="send_message",
            parameters={"platform": "telegram", "receiver": "John", "message_text": "hello"},
            operation_name="send_message:telegram",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # They DON'T share proc:exec - dev_agent uses subprocess, send_message uses pyautogui
        # So they should be admitted (different resource keys)
        self.assertTrue(admitted, f"dev_agent improve and send_message telegram should NOT conflict (different underlying resources), got: {reason}")

    def test_dev_agent_improve_conflicts_with_computer_control_click(self):
        """dev_agent:improve should NOT conflict with computer_control:click (different resources)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent improve (proc:exec + network:egress)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "improve", "folder": "/project"},
            operation_name="dev_agent:improve",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control click (global:input)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "click", "x": 100, "y": 100},
            operation_name="computer_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different resources - should be admitted
        self.assertTrue(admitted, f"dev_agent improve and computer_control click should NOT conflict, got: {reason}")

    def test_dev_agent_improve_conflicts_with_computer_settings_type_text(self):
        """dev_agent:improve should NOT conflict with computer_settings:type_text (different resources)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent improve (proc:exec + network:egress)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "improve", "folder": "/project"},
            operation_name="dev_agent:improve",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_settings type_text (global:input)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_settings",
            parameters={"action": "type_text", "text": "hello"},
            operation_name="computer_settings:type_text",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different resources - should be admitted
        self.assertTrue(admitted, f"dev_agent improve and computer_settings type_text should NOT conflict, got: {reason}")

    def test_dev_agent_build_conflicts_with_send_message_instagram(self):
        """dev_agent:build should conflict with send_message:instagram (both use network:egress)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent build (uses network:egress for pip install)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "build", "project_name": "my_project"},
            operation_name="dev_agent:build",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: send_message instagram (uses network:www.instagram.com)
        # They both use network:egress but different network keys - network:egress is the scope
        # The extract_resource_keys for dev_agent returns "network:egress" as a generic key
        # while instagram returns "network:www.instagram.com" - these are DIFFERENT keys
        # So they should NOT conflict on the specific network key
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="send_message",
            parameters={"platform": "instagram", "receiver": "John", "message_text": "hello"},
            operation_name="send_message:instagram",
            resource_scope="remote_service",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different network keys - should be admitted
        self.assertTrue(admitted, f"dev_agent build and send_message instagram should NOT conflict (different network keys), got: {reason}")

    def test_dev_agent_build_conflicts_with_browser_control_go_to(self):
        """dev_agent:build should NOT conflict with browser_control:go_to (different network keys)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent build (network:egress)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "build", "project_name": "my_project"},
            operation_name="dev_agent:build",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: browser_control go_to (network:example.com)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="browser_control",
            parameters={"action": "go_to", "browser": "chrome", "url": "https://example.com"},
            operation_name="browser_control:go_to",
            resource_scope="network_egress",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different network keys - should be admitted
        self.assertTrue(admitted, f"dev_agent build and browser_control go_to should NOT conflict (different network keys), got: {reason}")

    def test_dev_agent_improve_unresolved_blocks_new_operations(self):
        """Unresolved dev_agent worker should block conflicting new operations."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent improve (UNRESOLVED)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "improve", "folder": "/project"},
            operation_name="dev_agent:improve",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.UNRESOLVED
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: file_controller write to same project - should be blocked
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/project/main.py", "content": "x=1"},
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"Unresolved dev_agent should block file_controller on same project, got: {reason}")
        self.assertEqual(reason, "resource_key:project:/project")

    def test_dev_agent_build_admission_blocked_by_existing_dev_agent(self):
        """dev_agent:build should be blocked if another dev_agent is running on same project."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent improve on /project
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "improve", "folder": "/project"},
            operation_name="dev_agent:improve",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: dev_agent build on same project - should conflict on proc:exec (global resource)
        # Both dev_agent improve and build use proc:exec, so first conflict detected is proc:exec
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="dev_agent",
            parameters={"mode": "build", "project_name": "project"},
            operation_name="dev_agent:build",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"dev_agent build should conflict with improve on same project, got: {reason}")
        self.assertEqual(reason, "resource_key:proc:exec")

    def test_dev_agent_different_projects_conflict_on_proc_exec(self):
        """dev_agent on different projects still conflict on proc:exec (global resource)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent improve on /project1
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "improve", "folder": "/project1"},
            operation_name="dev_agent:improve",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: dev_agent build on /project2 - SHOULD conflict on proc:exec
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="dev_agent",
            parameters={"mode": "build", "project_name": "project2"},
            operation_name="dev_agent:build",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"dev_agent on different projects should conflict on proc:exec, got: {reason}")
        self.assertEqual(reason, "resource_key:proc:exec")


# ─── dev_agent Permission Denial Tests ────────────────────────────────────────────

class TestDevAgentPermissionDenial(unittest.TestCase):
    """Tests for permission denial in dev_agent."""

    def setUp(self):
        reset_global_registry()

    @patch("actions.dev_agent._refusal", return_value="")
    @patch("actions.dev_agent._resolve_folder")
    @patch("actions.dev_agent.get_permission_guard")
    def test_dev_agent_improve_requires_approval(self, mock_get_guard, mock_resolve, mock_refusal):
        """dev_agent:improve should require owner approval (proc.exec in OWNER_APPROVAL_REQUIRED)."""
        from core.permission_manager import OWNER_APPROVAL_REQUIRED, PermissionResult
        self.assertIn("proc.exec", OWNER_APPROVAL_REQUIRED)

        # Mock folder resolution to return a valid path
        from pathlib import Path
        mock_resolve.return_value = Path("/fake/project")

        mock_guard = Mock()
        mock_guard.initialize.return_value = None
        mock_guard._initialized = True
        mock_guard.check_operation.return_value = PermissionResult(False, "owner_approval_required",
                                                                    instruction="Please approve this operation",
                                                                    requires_approval=True)
        mock_get_guard.return_value = mock_guard

        from actions.dev_agent import dev_agent
        result = dev_agent({"mode": "improve", "folder": "/project", "description": "add feature"})
        self.assertIn("approve", result.lower())

    @patch("actions.dev_agent._refusal", return_value="")
    @patch("actions.dev_agent._resolve_folder")
    @patch("actions.dev_agent.get_permission_guard")
    def test_dev_agent_build_requires_approval(self, mock_get_guard, mock_resolve, mock_refusal):
        """dev_agent:build should require owner approval (proc.exec in OWNER_APPROVAL_REQUIRED)."""
        from core.permission_manager import OWNER_APPROVAL_REQUIRED, PermissionResult
        self.assertIn("proc.exec", OWNER_APPROVAL_REQUIRED)
        self.assertIn("app.manage", OWNER_APPROVAL_REQUIRED)

        # Mock folder resolution to return a valid path
        from pathlib import Path
        mock_resolve.return_value = Path("/fake/project")

        mock_guard = Mock()
        mock_guard.initialize.return_value = None
        mock_guard._initialized = True
        mock_guard.check_operation.return_value = PermissionResult(False, "owner_approval_required",
                                                                    instruction="Please approve this operation",
                                                                    requires_approval=True)
        mock_get_guard.return_value = mock_guard

        from actions.dev_agent import dev_agent
        result = dev_agent({"mode": "build", "description": "new project", "project_name": "test"})
        self.assertIn("approve", result.lower())


# ─── dev_agent WorkerRegistry Admission Denial Tests ─────────────────────────────

class TestDevAgentAdmissionDenial(unittest.TestCase):
    """Tests for WorkerRegistry admission denial in dev_agent."""

    def setUp(self):
        reset_global_registry()

    @patch("actions.dev_agent._refusal", return_value="")
    @patch("actions.dev_agent._resolve_folder")
    @patch("actions.dev_agent._job_lock", new_callable=lambda: threading.Lock())
    @patch("actions.dev_agent.get_global_registry")
    @patch("actions.dev_agent.get_permission_guard")
    def test_dev_agent_improve_admission_blocked_by_conflict(self, mock_get_guard, mock_get_registry, mock_job_lock, mock_resolve, mock_refusal):
        """dev_agent:improve should fail with resource conflict when admission denied."""
        from core.permission_manager import PermissionResult
        from pathlib import Path
        # Use the same path for both the mock and the blocking worker
        mock_resolve.return_value = Path("/project")

        mock_guard = Mock()
        mock_guard.initialize.return_value = None
        mock_guard._initialized = True
        mock_guard.check_operation.return_value = PermissionResult(True, "granted")
        mock_get_guard.return_value = mock_guard

        # Pre-populate registry with a blocking worker
        from core.worker_registry import create_worker_record, WorkerState, get_global_registry
        registry = get_global_registry()
        blocking_worker = create_worker_record(
            task_id="blocking",
            step_id="s1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/project/main.py", "content": "x=1"},
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        blocking_worker.mark_running(mock_thread, threading.Event())
        registry.register(blocking_worker)

        mock_get_registry.return_value = registry

        from actions.dev_agent import dev_agent
        result = dev_agent({"mode": "improve", "folder": "/project", "description": "add feature"})
        self.assertIn("resource conflict", result.lower())

    @patch("actions.dev_agent._refusal", return_value="")
    @patch("actions.dev_agent._resolve_folder")
    @patch("actions.dev_agent.get_global_registry")
    @patch("actions.dev_agent.get_permission_guard")
    def test_dev_agent_build_admission_blocked_by_conflict(self, mock_get_guard, mock_get_registry, mock_resolve, mock_refusal):
        """dev_agent:build should fail with resource conflict when admission denied."""
        from core.permission_manager import PermissionResult
        from pathlib import Path
        mock_resolve.return_value = Path("/fake/project")

        mock_guard = Mock()
        mock_guard.initialize.return_value = None
        mock_guard._initialized = True
        mock_guard.check_operation.return_value = PermissionResult(True, "granted")
        mock_get_guard.return_value = mock_guard

        # Pre-populate registry with a blocking worker on app:manage
        # (computer_settings open_settings uses app:manage, open_app uses app:{app_name})
        from core.worker_registry import create_worker_record, WorkerState, get_global_registry
        registry = get_global_registry()
        blocking_worker = create_worker_record(
            task_id="blocking",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "open_settings"},
            operation_name="computer_settings:open_settings",
            resource_scope="local_system",
            is_idempotent=False,
        )
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        blocking_worker.mark_running(mock_thread, threading.Event())
        registry.register(blocking_worker)

        mock_get_registry.return_value = registry

        from actions.dev_agent import dev_agent
        result = dev_agent({"mode": "build", "description": "new project", "project_name": "test"})
        self.assertIn("resource conflict", result.lower())
        self.assertIn("app:manage", result.lower())


# ─── B3 Cross-Module Coordination Tests ─────────────────────────────────────────────
# These tests verify the required conflict matrix from B3 specification:
# 1. send_message ↔ computer_control (already tested)
# 2. send_message ↔ browser_control (already tested)
# 3. dev_agent ↔ file_controller (already tested)
# 4. dev_agent ↔ send_message (already tested)
# 5. dev_agent ↔ open_app (partially tested - open_app vs dev_agent:build)
# 6. dev_agent ↔ computer_settings (already tested)
# 7. file_controller ↔ computer_control (NEW - verify no conflict)
# 8. browser_control ↔ computer_control (already tested - verify no conflict)
# 9. computer_settings ↔ computer_control (NEW - verify conflicts on global:input, app:manage, global:display)

class TestCrossModuleCoordination(unittest.TestCase):
    """B3: Cross-module resource coordination tests for required conflict matrix."""

    def setUp(self):
        reset_global_registry()

    # ─── file_controller ↔ computer_control ───

    def test_file_controller_vs_computer_control_click(self):
        """file_controller:write should NOT conflict with computer_control:click (different resources)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: file_controller write
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/project/main.py", "content": "x=1"},
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control click (global:input)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "click", "x": 100, "y": 100},
            operation_name="computer_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different resources - should be admitted
        self.assertTrue(admitted, f"file_controller write and computer_control click should NOT conflict, got: {reason}")

    def test_file_controller_vs_computer_control_type(self):
        """file_controller:read should NOT conflict with computer_control:type (different resources)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: file_controller read
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            parameters={"action": "read", "path": "/project/main.py"},
            operation_name="file_controller:read",
            resource_scope="local_file",
            is_idempotent=True,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control type (global:input)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "type", "text": "hello"},
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different resources - should be admitted
        self.assertTrue(admitted, f"file_controller read and computer_control type should NOT conflict, got: {reason}")

    def test_file_controller_vs_computer_control_screen_find(self):
        """file_controller:list should NOT conflict with computer_control:screen_find (different resources)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: file_controller list
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            parameters={"action": "list", "path": "/project"},
            operation_name="file_controller:list",
            resource_scope="local_file",
            is_idempotent=True,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control screen_find (global:display)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "screen_find", "template": "button.png"},
            operation_name="computer_control:screen_find",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different resources - should be admitted
        self.assertTrue(admitted, f"file_controller list and computer_control screen_find should NOT conflict, got: {reason}")

    def test_file_controller_vs_computer_control_close_app(self):
        """file_controller:delete should NOT conflict with computer_control:close_app (different resources)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: file_controller delete
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            parameters={"action": "delete", "path": "/project/temp.txt"},
            operation_name="file_controller:delete",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control close_app (app:manage)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "close_app", "app_name": "notepad"},
            operation_name="computer_control:close_app",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different resources - should be admitted
        self.assertTrue(admitted, f"file_controller delete and computer_control close_app should NOT conflict, got: {reason}")

    # ─── computer_settings ↔ computer_control ───

    def test_computer_settings_volume_vs_computer_control_click(self):
        """computer_settings:volume_up should conflict with computer_control:click (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: computer_settings volume_up (global:input)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "volume_up"},
            operation_name="computer_settings:volume_up",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control click (global:input)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "click", "x": 100, "y": 100},
            operation_name="computer_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"computer_settings volume_up should conflict with computer_control click (global:input), got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_computer_settings_brightness_vs_computer_control_type(self):
        """computer_settings:brightness_up should conflict with computer_control:type (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: computer_settings brightness_up (global:input)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "brightness_up"},
            operation_name="computer_settings:brightness_up",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control type (global:input)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "type", "text": "hello"},
            operation_name="computer_control:type",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"computer_settings brightness_up should conflict with computer_control type (global:input), got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    def test_computer_settings_open_settings_vs_computer_control_close_app(self):
        """computer_settings:open_settings should conflict with computer_control:close_app (shared app:manage)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: computer_settings open_settings (app:manage)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "open_settings"},
            operation_name="computer_settings:open_settings",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control close_app (app:manage)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "close_app", "app_name": "notepad"},
            operation_name="computer_control:close_app",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"computer_settings open_settings should conflict with computer_control close_app (app:manage), got: {reason}")
        self.assertEqual(reason, "resource_key:app:manage")

    def test_computer_settings_screenshot_vs_computer_control_screen_find(self):
        """computer_settings:screenshot should conflict with computer_control:screen_find (shared global:display)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: computer_settings screenshot (global:display)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "screenshot"},
            operation_name="computer_settings:screenshot",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control screen_find (global:display)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "screen_find", "template": "button.png"},
            operation_name="computer_control:screen_find",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"computer_settings screenshot should conflict with computer_control screen_find (global:display), got: {reason}")
        self.assertEqual(reason, "resource_key:global:display")

    def test_computer_settings_window_mgmt_vs_computer_control_hotkey(self):
        """computer_settings:window_management should conflict with computer_control:hotkey (shared global:input)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: computer_settings window management (global:input)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "window_management", "direction": "left"},
            operation_name="computer_settings:window_management",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control hotkey (global:input)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "hotkey", "keys": ["ctrl", "c"]},
            operation_name="computer_control:hotkey",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"computer_settings window_management should conflict with computer_control hotkey (global:input), got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    # ─── dev_agent ↔ open_app (actual open_app, not computer_settings) ───

    def test_dev_agent_build_vs_open_app_vscode(self):
        """dev_agent:build (app:manage) should NOT conflict with open_app:code (app:Code) - different app keys."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent build (app:manage)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "build", "project_name": "my_project"},
            operation_name="dev_agent:build",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: open_app VS Code (app:Visual Studio Code)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="open_app",
            parameters={"app_name": "Visual Studio Code"},
            operation_name="open_app",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different app keys - should be admitted
        self.assertTrue(admitted, f"dev_agent build (app:manage) and open_app VS Code (app:Visual Studio Code) should NOT conflict, got: {reason}")

    def test_dev_agent_build_vs_open_app_same_manage(self):
        """dev_agent:build (app:manage) SHOULD conflict with computer_settings:open_settings (app:manage)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: dev_agent build (app:manage)
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="dev_agent",
            parameters={"mode": "build", "project_name": "my_project"},
            operation_name="dev_agent:build",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_settings open_settings (app:manage)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_settings",
            parameters={"action": "open_settings"},
            operation_name="computer_settings:open_settings",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Same app:manage key - should conflict
        self.assertFalse(admitted, f"dev_agent build and computer_settings open_settings should conflict on app:manage, got: {reason}")
        self.assertEqual(reason, "resource_key:app:manage")

    # ─── Unresolved worker blocking for cross-module pairs ───

    def test_unresolved_file_controller_blocks_computer_control_on_same_project(self):
        """Unresolved file_controller should block computer_control on same project via project key."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: file_controller write (UNRESOLVED) - reserves project:/project
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/project/main.py", "content": "x=1"},
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker1.state = WorkerState.UNRESOLVED
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control click - should NOT be blocked (no shared keys)
        # But wait - computer_control doesn't use project keys
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "click", "x": 100, "y": 100},
            operation_name="computer_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different resources - should be admitted even with unresolved file_controller
        self.assertTrue(admitted, f"Unresolved file_controller should NOT block computer_control (different resources), got: {reason}")

    def test_unresolved_computer_settings_blocks_computer_control_same_resource(self):
        """Unresolved computer_settings should block computer_control on same resource."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: computer_settings volume_up (UNRESOLVED) - reserves global:input
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="computer_settings",
            parameters={"action": "volume_up"},
            operation_name="computer_settings:volume_up",
            resource_scope="local_system",
            is_idempotent=False,
        )
        worker1.state = WorkerState.UNRESOLVED
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_control click - should be blocked on global:input
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_control",
            parameters={"action": "click", "x": 100, "y": 100},
            operation_name="computer_control:click",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        self.assertFalse(admitted, f"Unresolved computer_settings should block computer_control on global:input, got: {reason}")
        self.assertEqual(reason, "resource_key:global:input")

    # ─── file_controller ↔ computer_settings (verify no conflict) ───

    def test_file_controller_vs_computer_settings_volume(self):
        """file_controller:write should NOT conflict with computer_settings:volume_up (different resources)."""
        from core.worker_registry import create_worker_record, WorkerRegistry, WorkerState
        from unittest.mock import Mock

        registry = WorkerRegistry()

        # First worker: file_controller write
        worker1 = create_worker_record(
            task_id="test-task",
            step_id="s1",
            tool_name="file_controller",
            parameters={"action": "write", "path": "/project/main.py", "content": "x=1"},
            operation_name="file_controller:write",
            resource_scope="local_file",
            is_idempotent=False,
        )
        worker1.state = WorkerState.RUNNING
        worker1.thread = Mock()
        worker1.thread.is_alive.return_value = True
        registry.register(worker1)

        # Second worker: computer_settings volume_up (global:input)
        worker2 = create_worker_record(
            task_id="test-task",
            step_id="s2",
            tool_name="computer_settings",
            parameters={"action": "volume_up"},
            operation_name="computer_settings:volume_up",
            resource_scope="local_system",
            is_idempotent=False,
        )
        admitted, reason = registry.admit_worker(worker2)
        # Different resources - should be admitted
        self.assertTrue(admitted, f"file_controller write and computer_settings volume_up should NOT conflict, got: {reason}")


if __name__ == "__main__":
    unittest.main()
