"""
Regression tests for Milestone 4 defects found in security audit.

Tests three specific defects:
1. Voice change (keep_context=False) does not clear stored resume handle
2. Server rejection does not clear stored resume handle
3. No API to explicitly clear stored resume handle

Run with: py -m pytest tests/unit/test_milestone4_defects.py -v
"""
import sys
import time
import json
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from memory.conversation_store import ConversationStore, ConversationNotFoundError
from memory.conversation_models import Conversation, Message


class TestMilestone4Defects(unittest.TestCase):
    """Regression tests for Milestone 4 defect closure."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.store = ConversationStore(self.db_path)

    def tearDown(self):
        self.store.close()
        self.temp_dir.cleanup()

    def _create_conversation_with_handle(self, handle: str = "test-handle-123"):
        """Helper: create conversation and store a resume handle."""
        conv = Conversation(
            title="Test Conversation",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
        )
        created = self.store.create_conversation(conv)
        conv_id = created.id

        # Store a resume handle
        self.store.set_resume_handle(conv_id, handle)

        # Verify it's stored
        stored = self.store.get_resume_handle(conv_id)
        self.assertEqual(stored, handle)

        return conv_id

    # ════════════════════════════════════════════════════════════════════════
    # DEFECT 1: Voice change (keep_context=False) does not clear stored handle
    # ════════════════════════════════════════════════════════════════════════

    def test_voice_change_clears_stored_handle(self):
        """
        REGRESSION TEST for Finding 2.1:
        When voice change occurs (keep_context=False), the stored resume handle
        must be cleared from the database so it's not reloaded on next session start.

        This simulates the Integration Point A logic in main.py after a voice change:
        - Voice change clears in-memory handle AND calls clear_resume_handle()
        - Next session start: Integration Point A reloads from store if handle is None
        - FIX: Stored handle is cleared, so it's not reloaded
        """
        conv_id = self._create_conversation_with_handle("voice-change-test-handle")

        # Simulate voice change: clear in-memory handle AND clear persisted handle
        # This is what main.py does after the fix
        self.store.clear_resume_handle(conv_id)

        # Simulate next session start (Integration Point A)
        # Check if handle would be reloaded
        reloaded_handle = self.store.get_resume_handle(conv_id)

        # AFTER FIX: this should be None
        self.assertIsNone(
            reloaded_handle,
            "Voice change should clear stored handle; "
            "reloaded handle should be None but got: {}".format(reloaded_handle)
        )

    # ════════════════════════════════════════════════════════════════════════
    # DEFECT 2: Server rejection does not clear stored handle
    # ════════════════════════════════════════════════════════════════════════

    def test_server_rejection_clears_stored_handle(self):
        """
        REGRESSION TEST for Finding 2.3:
        When server rejects resumption handle (expired, invalid, NOT_FOUND),
        the stored resume handle must be cleared from the database.

        This simulates the server rejection handler in main.py:3145-3155:
        - Server rejects handle, main.py sets self._resume_handle = None AND calls clear_resume_handle()
        - Loop continues, Integration Point A runs again
        - FIX: Stored handle is cleared, so it's not reloaded
        """
        conv_id = self._create_conversation_with_handle("server-rejection-test-handle")

        # Simulate server rejection: clear in-memory handle AND clear persisted handle
        # This is what main.py does after the fix
        self.store.clear_resume_handle(conv_id)

        # Simulate next session start (Integration Point A)
        reloaded_handle = self.store.get_resume_handle(conv_id)

        # AFTER FIX: this should be None
        self.assertIsNone(
            reloaded_handle,
            "Server rejection should clear stored handle; "
            "reloaded handle should be None but got: {}".format(reloaded_handle)
        )

    # ════════════════════════════════════════════════════════════════════════
    # DEFECT 3: No API to explicitly clear stored handle
    # ════════════════════════════════════════════════════════════════════════

    def test_clear_resume_handle_removes_from_meta_json(self):
        """
        REGRESSION TEST for Finding 2.2:
        There must be an API to explicitly clear a stored resume handle.

        Current behavior: set_resume_handle("") returns early without clearing.
        After fix: clear_resume_handle() should remove resume_handle from meta_json.
        """
        conv_id = self._create_conversation_with_handle("clear-test-handle")

        # Verify handle exists before clearing
        self.assertEqual(self.store.get_resume_handle(conv_id), "clear-test-handle")

        # Call the new clear method (will fail until implemented)
        self.store.clear_resume_handle(conv_id)

        # Verify handle is cleared
        reloaded = self.store.get_resume_handle(conv_id)
        self.assertIsNone(
            reloaded,
            "clear_resume_handle() should remove handle from meta_json; "
            "got: {}".format(reloaded)
        )

        # Verify other meta_json fields are preserved
        conv = self.store.get_conversation(conv_id)
        meta = json.loads(conv.meta_json) if conv.meta_json else {}
        self.assertNotIn("resume_handle", meta, "resume_handle key should be removed from meta_json")

    def test_clear_resume_handle_nonexistent_conversation_raises(self):
        """clear_resume_handle should raise ConversationNotFoundError for nonexistent conversation."""
        with self.assertRaises(ConversationNotFoundError):
            self.store.clear_resume_handle("nonexistent-id")

    def test_clear_resume_handle_preserves_other_metadata(self):
        """Clearing resume handle should not delete other meta_json fields."""
        conv_id = self._create_conversation_with_handle("preserve-meta-test")

        # Add some other metadata
        conv = self.store.get_conversation(conv_id)
        meta = json.loads(conv.meta_json) if conv.meta_json else {}
        meta["custom_field"] = "custom_value"
        meta["another_field"] = 42
        conv.meta_json = json.dumps(meta)
        self.store.update_conversation(conv)

        # Clear resume handle
        self.store.clear_resume_handle(conv_id)

        # Verify resume_handle is gone but other fields remain
        conv = self.store.get_conversation(conv_id)
        meta = json.loads(conv.meta_json) if conv.meta_json else {}
        self.assertNotIn("resume_handle", meta)
        self.assertEqual(meta.get("custom_field"), "custom_value")
        self.assertEqual(meta.get("another_field"), 42)

    def test_clear_resume_handle_idempotent(self):
        """Calling clear_resume_handle twice should not raise."""
        conv_id = self._create_conversation_with_handle("idempotent-test")

        # First clear
        self.store.clear_resume_handle(conv_id)
        self.assertIsNone(self.store.get_resume_handle(conv_id))

        # Second clear should not raise
        self.store.clear_resume_handle(conv_id)
        self.assertIsNone(self.store.get_resume_handle(conv_id))


class TestClearResumeHandleIntegration(unittest.TestCase):
    """Integration tests for clear_resume_handle with voice change and server rejection scenarios."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_conversations.sqlite3"
        self.store = ConversationStore(self.db_path)

    def tearDown(self):
        self.store.close()
        self.temp_dir.cleanup()

    def test_voice_change_scenario_end_to_end(self):
        """
        End-to-end test: voice change -> clear handle -> next session fresh.

        This simulates the full Integration Point A flow in main.py:
        1. Session 1: Creates conversation, gets resume handle from server, stores it
        2. Voice change: keep_context=False, clears stored handle
        3. Session 2 (reconnect): Integration Point A loads handle -> should get None
        """
        # ═══════════════════════════════════════════════════════════════════
        # SESSION 1: Normal session with resume handle
        # ═══════════════════════════════════════════════════════════════════
        conv = Conversation(
            title="",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
            meta_json=json.dumps({"resumed": "none"}),
        )
        created = self.store.create_conversation(conv)
        conv_id = created.id

        # Simulate server providing resume handle (Integration Point B)
        server_handle = "server-provided-handle-abc123"
        self.store.set_resume_handle(conv_id, server_handle)

        # Verify stored
        self.assertEqual(self.store.get_resume_handle(conv_id), server_handle)

        # ═══════════════════════════════════════════════════════════════════
        # VOICE CHANGE: keep_context=False
        # ═══════════════════════════════════════════════════════════════════
        # This is what main.py should do after fix:
        self.store.clear_resume_handle(conv_id)

        # ═══════════════════════════════════════════════════════════════════
        # SESSION 2: Reconnect - Integration Point A
        # ═══════════════════════════════════════════════════════════════════
        # Simulate new store instance (process restart or new session)
        store2 = ConversationStore(self.db_path)

        # Integration Point A: Load resume handle from store
        # In main.py: if self._resume_handle is None: stored = store.get_resume_handle(...)
        reloaded = store2.get_resume_handle(conv_id)

        # Should be None - fresh session
        self.assertIsNone(
            reloaded,
            "After voice change, reconnect should not reload stale handle; "
            "got: {}".format(reloaded)
        )

        store2.close()

    def test_server_rejection_scenario_end_to_end(self):
        """
        End-to-end test: server rejects handle -> clear handle -> next session fresh.

        This simulates the server rejection flow in main.py:3145-3155:
        1. Session 1: Creates conversation, stores resume handle
        2. Server rejects handle (expired/INVALID_ARGUMENT/NOT_FOUND)
        3. Session 2 (retry): Integration Point A loads handle -> should get None
        """
        # ═══════════════════════════════════════════════════════════════════
        # SESSION 1: Normal session with resume handle
        # ═══════════════════════════════════════════════════════════════════
        conv = Conversation(
            title="",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
            meta_json=json.dumps({"resumed": "none"}),
        )
        created = self.store.create_conversation(conv)
        conv_id = created.id

        server_handle = "server-provided-handle-xyz789"
        self.store.set_resume_handle(conv_id, server_handle)
        self.assertEqual(self.store.get_resume_handle(conv_id), server_handle)

        # ═══════════════════════════════════════════════════════════════════
        # SERVER REJECTION: handle expired/invalid
        # ═══════════════════════════════════════════════════════════════════
        # This is what main.py should do after fix:
        self.store.clear_resume_handle(conv_id)

        # ═══════════════════════════════════════════════════════════════════
        # SESSION 2: Retry - Integration Point A
        # ═══════════════════════════════════════════════════════════════════
        store2 = ConversationStore(self.db_path)

        reloaded = store2.get_resume_handle(conv_id)

        # Should be None - fresh session
        self.assertIsNone(
            reloaded,
            "After server rejection, retry should not reload stale handle; "
            "got: {}".format(reloaded)
        )

        store2.close()


if __name__ == "__main__":
    unittest.main()