"""
Unit tests for Batch 1: Voice Barge-in and Interrupt Wiring.

Run with: py -m pytest tests/unit/test_voice_barge_in.py -v
"""
import sys
import unittest
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock, PropertyMock
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.echo import EchoGuard, band_energies


class TestEchoGuardBargeIn(unittest.TestCase):
    """Tests for EchoGuard barge-in behavior."""

    def setUp(self):
        self.echo = EchoGuard()
        self.sr = 16000

    def _make_tone(self, freq: float, duration: float, sr: int = 16000) -> np.ndarray:
        t = np.arange(int(sr * duration)) / sr
        wave = np.sin(2 * np.pi * freq * t)
        return (wave * 10000).astype(np.int16)

    def test_uncalibrated_echo_guard_not_reliable(self):
        """Fresh EchoGuard is not calibrated."""
        self.assertFalse(self.echo.calibrated)
        # reliable depends on floor, which starts at 0.10 (< 0.22)
        self.assertTrue(self.echo.reliable)

    def test_echo_guard_calibrated_property(self):
        """calibrated property returns True when _seen >= 8."""
        self.echo._seen = 7
        self.assertFalse(self.echo.calibrated)
        self.echo._seen = 8
        self.assertTrue(self.echo.calibrated)
        self.echo._seen = 100
        self.assertTrue(self.echo.calibrated)

    def test_echo_guard_reliable_property(self):
        """reliable property returns True when floor < _UNRELIABLE_FLOOR."""
        self.echo._floor = 0.10
        self.assertTrue(self.echo.reliable)
        self.echo._floor = 0.22
        self.assertFalse(self.echo.reliable)
        self.echo._floor = 0.25
        self.assertFalse(self.echo.reliable)

    def test_echo_guard_threshold_property(self):
        """threshold property returns max(_MIN_USER, _head * _HEAD_MULT)."""
        self.echo._head = 0.10
        self.assertEqual(self.echo.threshold, 0.15)  # _MIN_USER = 0.15

        self.echo._head = 0.20
        self.assertAlmostEqual(self.echo.threshold, 0.20 * 1.15, places=3)

    def test_echo_guard_required_blocks_property(self):
        """required_blocks returns correct value based on reliability."""
        # Reliable room
        self.echo._floor = 0.10
        self.echo._seen = 10
        self.assertEqual(self.echo.required_blocks, 5)  # _BLOCKS_NORMAL

        # Unreliable room
        self.echo._floor = 0.25
        self.assertEqual(self.echo.required_blocks, 12)  # _BLOCKS_NOISY

    def test_echo_guard_reset_clears_history(self):
        """reset() clears history but keeps learned parameters."""
        self.echo._hist = [(1.0, np.ones(8), 0.5)]
        self.echo._last_sim = 0.5
        self.echo._seen = 10
        self.echo._floor = 0.12

        self.echo.reset()

        self.assertEqual(len(self.echo._hist), 0)
        self.assertEqual(self.echo._last_sim, 0.0)
        self.assertEqual(self.echo._seen, 10)  # preserved
        self.assertEqual(self.echo._floor, 0.12)  # preserved

    def test_echo_guard_note_output_records_history(self):
        """note_output() records output bands for later comparison."""
        output = self._make_tone(440, 0.1)
        level = 0.5

        self.echo.note_output(output, self.sr, level)

        self.assertEqual(len(self.echo._hist), 1)
        ts, bands, lvl = self.echo._hist[0]
        self.assertEqual(lvl, level)
        self.assertEqual(bands.shape, (8,))

    def test_echo_guard_is_user_speech_no_history_returns_true(self):
        """is_user_speech returns True when no output history (nothing to cancel)."""
        # No output recorded
        mic = self._make_tone(880, 0.1)
        level = 0.3

        result = self.echo.is_user_speech(mic, self.sr, level)

        self.assertTrue(result)

    def test_echo_guard_is_user_speech_low_level_returns_false(self):
        """is_user_speech returns False for very low microphone level."""
        mic = np.zeros(1600, dtype=np.int16)
        level = 0.01  # Below _MIN_LEVEL (0.06)

        result = self.echo.is_user_speech(mic, self.sr, level)

        self.assertFalse(result)

    def test_echo_guard_warmup_blocks_before_judging(self):
        """During warmup, is_user_speech returns False and learns from all blocks."""
        self.echo._residuals = []  # empty = warming

        output = self._make_tone(440, 0.1)
        level = 0.5
        self.echo.note_output(output, self.sr, level)

        # Feed echo-like input
        echo = (output * 0.3).astype(np.int16)
        echo_level = 0.15

        # During warmup, should return False
        result = self.echo.is_user_speech(echo, self.sr, echo_level)
        self.assertFalse(result)

        # Residuals should be recorded
        self.assertGreater(len(self.echo._residuals), 0)


class TestWakeWordDetectorInterrupt(unittest.TestCase):
    """Tests for wake word detector interrupt wiring."""

    @patch("core.wake_word.is_installed", return_value=True)
    @patch("core.wake_word.is_ready", return_value=True)
    def test_wake_detector_on_detect_calls_callback(self, mock_ready, mock_installed):
        """Wake detector calls on_detect callback on detection."""
        from core.wake_word import WakeWordDetector

        callback_called = []

        def mock_callback():
            callback_called.append(True)

        detector = WakeWordDetector(on_detect=mock_callback)

        # Manually call the callback (simulating detection)
        detector._on_detect = mock_callback
        detector._on_detect()

        self.assertTrue(callback_called)

    def test_wake_detector_feed_queues_frame(self):
        """feed() queues frame for processing thread."""
        from core.wake_word import WakeWordDetector

        detector = WakeWordDetector(on_detect=lambda: None)
        detector._running = True

        frame = np.zeros(1600, dtype=np.int16)
        detector.feed(frame)

        # Frame should be queued
        self.assertFalse(detector._queue.empty())


class TestInterruptIdempotency(unittest.TestCase):
    """Tests for interrupt() idempotency and duplicate protection."""

    def test_interrupt_flag_prevents_duplicate_work(self):
        """_interrupted flag prevents duplicate interrupt processing."""
        # Simulate the interrupt logic
        interrupted = False
        work_done = []

        def do_interrupt():
            nonlocal interrupted
            if interrupted:
                return
            interrupted = True
            work_done.append("interrupt")

        do_interrupt()
        do_interrupt()
        do_interrupt()

        self.assertTrue(interrupted)
        self.assertEqual(len(work_done), 1)

    def test_request_interrupt_uses_call_soon_threadsafe(self):
        """_request_interrupt dispatches to asyncio loop via call_soon_threadsafe."""
        mock_loop = Mock()
        mock_loop.call_soon_threadsafe = Mock()

        def request_interrupt():
            if mock_loop is not None:
                mock_loop.call_soon_threadsafe(lambda: None)

        request_interrupt()

        mock_loop.call_soon_threadsafe.assert_called_once()


class TestBargeInFlow(unittest.TestCase):
    """Integration-style tests for the barge-in event flow."""

    def test_barge_in_before_calibration_no_interrupt(self):
        """Before calibration, barge-in should not trigger interrupt."""
        echo = EchoGuard()
        self.assertFalse(echo.calibrated)

        # Simulate the callback logic
        jarvis_speaking = True
        interrupt_requested = []

        def mock_request_interrupt():
            interrupt_requested.append(True)

        # This mimics the callback logic in _listen_audio
        if jarvis_speaking:
            if echo.calibrated and echo.reliable:
                mock_request_interrupt()

        self.assertEqual(len(interrupt_requested), 0)

    def test_barge_in_after_calibration_triggers_interrupt(self):
        """After calibration and reliability, barge-in should trigger interrupt."""
        echo = EchoGuard()

        # Manually set calibrated and reliable
        echo._seen = 10
        echo._floor = 0.10

        self.assertTrue(echo.calibrated)
        self.assertTrue(echo.reliable)

        # Simulate the callback logic
        jarvis_speaking = True
        interrupt_requested = []

        def mock_request_interrupt():
            interrupt_requested.append(True)

        # Mock is_user_speech to return True (user speaking detected)
        echo.is_user_speech = Mock(return_value=True)

        if jarvis_speaking:
            if echo.calibrated and echo.reliable:
                if echo.is_user_speech(None, 16000, 0.5):
                    mock_request_interrupt()

        self.assertEqual(len(interrupt_requested), 1)
        echo.is_user_speech.assert_called_once()

    def test_barge_in_unreliable_requires_more_blocks(self):
        """Unreliable room requires more consecutive blocks."""
        echo = EchoGuard()
        echo._seen = 10
        echo._floor = 0.25  # Unreliable

        self.assertTrue(echo.calibrated)
        self.assertFalse(echo.reliable)
        self.assertEqual(echo.required_blocks, 12)


class TestExistingInterruptCleanup(unittest.TestCase):
    """Tests that existing interrupt cleanup behavior is preserved."""

    def test_interrupt_logic_clears_queue(self):
        """interrupt logic should drain the audio input queue."""
        # Test the core logic without importing JarvisLive
        q = Mock()
        drained = 0
        q.get_nowait.side_effect = [b"chunk1", b"chunk2", Exception("empty")]

        while True:
            try:
                q.get_nowait()
                drained += 1
            except Exception:
                break

        self.assertEqual(drained, 2)

    def test_interrupt_logic_resets_visemes_and_cursor(self):
        """interrupt logic should reset visemes and play cursor."""
        visemes = Mock()
        play_cursor = 100.0
        turn_done_event = Mock()

        # Simulate interrupt logic
        visemes.reset()
        play_cursor = 0.0
        turn_done_event.clear()

        visemes.reset.assert_called_once()
        self.assertEqual(play_cursor, 0.0)
        turn_done_event.clear.assert_called_once()

    def test_interrupt_logic_calls_engine_interrupt(self):
        """interrupt logic should call engine.interrupt() if present."""
        mock_engine = Mock()
        mock_engine.interrupt = Mock()

        # Simulate interrupt logic
        if mock_engine is not None:
            try:
                mock_engine.interrupt()
            except Exception:
                pass

        mock_engine.interrupt.assert_called_once()

    def test_interrupt_logs_to_ui(self):
        """interrupt logic should write to UI log."""
        mock_ui = Mock()
        mock_ui.write_log = Mock()

        mock_ui.write_log("SYS: Interrupted — listening...")

        mock_ui.write_log.assert_called_with("SYS: Interrupted — listening...")


class TestWakeWordDuringTTS(unittest.TestCase):
    """Tests for wake word detection during TTS."""

    def test_wake_detector_fed_during_tts(self):
        """Wake detector should be fed audio when JARVIS is speaking."""
        # This tests the logic added to the callback
        jarvis_speaking = True
        wake_enabled = True
        wake_detector = Mock()

        fed_frames = []
        def mock_feed(frame):
            fed_frames.append(frame)

        wake_detector.feed = mock_feed

        # Simulate the callback logic
        if jarvis_speaking:
            if wake_enabled and wake_detector is not None:
                frame = np.zeros(1600, dtype=np.int16)
                wake_detector.feed(frame)

        self.assertEqual(len(fed_frames), 1)

    def test_on_wake_detected_calls_interrupt_when_speaking(self):
        """_on_wake_detected should call interrupt when JARVIS is speaking."""
        is_speaking = True
        interrupt_called = []

        def mock_request_interrupt():
            interrupt_called.append(True)

        def mock_wake():
            pass

        # Simulate _on_wake_detected logic
        if is_speaking:
            mock_request_interrupt()
        else:
            mock_wake()

        self.assertEqual(len(interrupt_called), 1)

    def test_on_wake_detected_calls_wake_when_not_speaking(self):
        """_on_wake_detected should call wake when JARVIS is not speaking."""
        is_speaking = False
        wake_called = []

        def mock_request_interrupt():
            pass

        def mock_wake():
            wake_called.append(True)

        # Simulate _on_wake_detected logic
        if is_speaking:
            mock_request_interrupt()
        else:
            mock_wake()

        self.assertEqual(len(wake_called), 1)


if __name__ == "__main__":
    unittest.main()