"""
Unit tests for camera capture in actions.screen_processor.

Camera capture remains in actions/screen_processor.py (not in core.screen_capture)
as per Phase 4 Batch 1 scope correction.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from actions.screen_processor import _capture_camera


class TestScreenProcessorCamera(unittest.TestCase):
    """Test camera capture from actions.screen_processor."""

    def test_capture_camera_returns_bytes_or_raises(self):
        """_capture_camera should return bytes or raise RuntimeError if no camera."""
        try:
            img_bytes, mime_type = _capture_camera()
            self.assertIsInstance(img_bytes, bytes)
            self.assertGreater(len(img_bytes), 0)
            self.assertEqual(mime_type, "image/jpeg")
        except RuntimeError as e:
            # Acceptable if no camera is available
            self.assertIn("camera", str(e).lower())

    def test_capture_camera_mime_type(self):
        """Camera capture should return JPEG mime type."""
        try:
            _, mime_type = _capture_camera()
            self.assertEqual(mime_type, "image/jpeg")
        except RuntimeError:
            # No camera available - acceptable
            pass


class TestScreenProcessorScreenShim(unittest.TestCase):
    """Test that screen capture shim works via core.screen_capture."""

    def test_capture_screen_shim(self):
        """_capture_screen shim should delegate to core.screen_capture."""
        from actions.screen_processor import _capture_screen
        img_bytes, mime_type = _capture_screen()
        self.assertIsInstance(img_bytes, bytes)
        self.assertGreater(len(img_bytes), 0)
        self.assertTrue(mime_type.startswith("image/"))


if __name__ == "__main__":
    unittest.main()