"""
Unit tests for Plugin Auto-Reload System (Milestone 8).

Tests:
1. Initial discovery of plugins from directory.
2. Dynamic addition of a new plugin without restart (check_for_updates).
3. Dynamic modification of an existing plugin (code & metadata update).
4. Dynamic deletion of a plugin (cleanup of registry and sys.modules).
5. Isolation of syntax/runtime errors and schema validation rejections.
6. Collision prevention with core tools and other plugins.
7. Event notification callback firing on changes (register_on_change).
8. Background watcher thread lifecycle and automatic polling.
9. CallerIdentity propagation through plugin execution.
"""

import os
import sys
import time
import shutil
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.identity import CallerIdentity, get_current_identity, set_current_identity
from core.plugin_loader import discover_plugins, PluginRegistry, PluginRecord


class TestPluginAutoReload(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(prefix="roitz_plugins_test_")
        self.plugins_path = Path(self.temp_dir)
        self.logs = []
        self.notices = []
        self.logger = lambda msg: self.logs.append(msg)
        self.notify = lambda msg: self.notices.append(msg)

    def tearDown(self):
        if hasattr(self, "registry") and self.registry:
            self.registry.stop_watcher(timeout=2.0)
        # Clean up loaded modules from sys.modules
        for k in list(sys.modules.keys()):
            if k.startswith("plugins.test_"):
                sys.modules.pop(k, None)
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _write_plugin(self, filename: str, content: str, mtime_offset: float = 0.0) -> Path:
        p = self.plugins_path / filename
        p.write_text(content, encoding="utf-8")
        if mtime_offset != 0.0:
            target_time = time.time() + mtime_offset
            os.utime(str(p), (target_time, target_time))
        return p

    def test_initial_discovery(self):
        """Initial discover_plugins loads valid files and ignores invalid/helper files."""
        self._write_plugin("_helper.py", "x = 10\n")
        self._write_plugin("test_alpha.py", """
PLUGIN = {
    "name": "test_alpha",
    "description": "Alpha test plugin",
    "parameters": {"type": "OBJECT", "properties": {}},
}

def run(parameters, player=None, session_memory=None):
    return "alpha_ok"
""")
        self.registry = discover_plugins(
            plugins_dir=self.plugins_path,
            core_tool_names={"status", "clock"},
            logger=self.logger,
            notify=self.notify,
        )
        self.assertTrue(self.registry.has("test_alpha"))
        self.assertFalse(self.registry.has("_helper"))
        self.assertEqual(self.registry.run("test_alpha", {}), "alpha_ok")

    def test_plugin_addition(self):
        """New file created after initial discovery is detected and loaded dynamically."""
        self.registry = discover_plugins(
            plugins_dir=self.plugins_path,
            core_tool_names={"status"},
            logger=self.logger,
            notify=self.notify,
        )
        self.assertFalse(self.registry.has("test_beta"))

        # Add new plugin file
        self._write_plugin("test_beta.py", """
PLUGIN = {
    "name": "test_beta",
    "description": "Beta dynamic plugin",
    "parameters": {"type": "OBJECT", "properties": {}},
}

def run(parameters, player=None, session_memory=None):
    return "beta_ok"
""")
        updates = self.registry.check_for_updates()
        self.assertIn("test_beta.py", updates["added"])
        self.assertTrue(self.registry.has("test_beta"))
        self.assertEqual(self.registry.run("test_beta", {}), "beta_ok")

    def test_plugin_modification(self):
        """Modifying an existing file reloads the plugin logic and updates metadata."""
        p = self._write_plugin("test_gamma.py", """
PLUGIN = {
    "name": "test_gamma",
    "description": "Version 1",
    "parameters": {"type": "OBJECT", "properties": {}},
}

def run(parameters):
    return "v1"
""")
        self.registry = discover_plugins(
            plugins_dir=self.plugins_path,
            core_tool_names=set(),
            logger=self.logger,
            notify=self.notify,
        )
        self.assertEqual(self.registry.run("test_gamma", {}), "v1")

        # Wait or offset mtime to guarantee new timestamp
        time.sleep(0.05)
        self._write_plugin("test_gamma.py", """
PLUGIN = {
    "name": "test_gamma",
    "description": "Version 2",
    "parameters": {"type": "OBJECT", "properties": {}},
}

def run(parameters):
    return "v2_updated"
""", mtime_offset=2.0)

        updates = self.registry.check_for_updates()
        self.assertIn("test_gamma.py", updates["modified"])
        self.assertEqual(self.registry.run("test_gamma", {}), "v2_updated")

    def test_plugin_deletion(self):
        """Deleting a plugin file removes it from registry, tool declarations, and sys.modules."""
        p = self._write_plugin("test_delta.py", """
PLUGIN = {
    "name": "test_delta",
    "description": "Delta plugin",
    "parameters": {"type": "OBJECT", "properties": {}},
}

def run(parameters):
    return "delta"
""")
        self.registry = discover_plugins(
            plugins_dir=self.plugins_path,
            core_tool_names=set(),
            logger=self.logger,
            notify=self.notify,
        )
        self.assertTrue(self.registry.has("test_delta"))
        self.assertIn("plugins.test_delta", sys.modules)

        # Remove the file from disk
        p.unlink()
        updates = self.registry.check_for_updates()
        self.assertIn("test_delta.py", updates["deleted"])
        self.assertFalse(self.registry.has("test_delta"))
        self.assertNotIn("plugins.test_delta", sys.modules)
        self.assertIn("is not available", self.registry.run("test_delta", {}))

    def test_syntax_and_validation_errors_isolated(self):
        """Syntax errors or invalid PLUGIN schema do not crash registry and are reported."""
        self.registry = discover_plugins(
            plugins_dir=self.plugins_path,
            core_tool_names=set(),
            logger=self.logger,
            notify=self.notify,
        )

        # 1. Syntax Error
        self._write_plugin("test_broken_syntax.py", "def broken_code( : invalid syntax\n")
        updates = self.registry.check_for_updates()
        self.assertIn("test_broken_syntax.py", updates["added"])
        self.assertFalse(self.registry.has("test_broken_syntax"))

        # Verify list_for_ui reflects error
        ui_list = self.registry.list_for_ui()
        broken_entry = next((item for item in ui_list if item["file"] == "test_broken_syntax.py"), None)
        self.assertIsNotNone(broken_entry)
        self.assertFalse(broken_entry["valid"])
        self.assertTrue(len(broken_entry["error"]) > 0)

        # 2. Missing run function
        self._write_plugin("test_missing_run.py", """
PLUGIN = {
    "name": "test_missing_run",
    "description": "No run func",
    "parameters": {"type": "OBJECT", "properties": {}},
}
""")
        self.registry.check_for_updates()
        self.assertFalse(self.registry.has("test_missing_run"))

    def test_core_tool_collision_rejected(self):
        """Plugin attempting to overwrite a core tool name is rejected."""
        self._write_plugin("test_collide.py", """
PLUGIN = {
    "name": "clock",
    "description": "I collide with core clock tool",
    "parameters": {"type": "OBJECT", "properties": {}},
}

def run(parameters):
    return "clock"
""")
        self.registry = discover_plugins(
            plugins_dir=self.plugins_path,
            core_tool_names={"clock", "browse"},
            logger=self.logger,
            notify=self.notify,
        )
        self.assertFalse(self.registry.has("clock"))
        ui_list = self.registry.list_for_ui()
        entry = next((item for item in ui_list if item["file"] == "test_collide.py"), None)
        self.assertIsNotNone(entry)
        self.assertFalse(entry["valid"])
        self.assertIn("collides with a core tool", entry["error"])

    def test_on_change_callback_fires(self):
        """Registered on_change callbacks fire when changes are detected."""
        self.registry = discover_plugins(
            plugins_dir=self.plugins_path,
            core_tool_names=set(),
            logger=self.logger,
            notify=self.notify,
        )
        fired_count = 0

        def on_change():
            nonlocal fired_count
            fired_count += 1

        self.registry.register_on_change(on_change)

        # Add plugin -> callback fires
        self._write_plugin("test_cb.py", """
PLUGIN = {
    "name": "test_cb",
    "description": "Callback test",
    "parameters": {"type": "OBJECT", "properties": {}},
}
def run(parameters):
    return "ok"
""")
        self.registry.check_for_updates()
        self.assertEqual(fired_count, 1)

        # No changes -> callback does not fire
        self.registry.check_for_updates()
        self.assertEqual(fired_count, 1)

    def test_watcher_thread_background_polling(self):
        """Watcher thread automatically runs check_for_updates and reloads in background."""
        self.registry = discover_plugins(
            plugins_dir=self.plugins_path,
            core_tool_names=set(),
            logger=self.logger,
            notify=self.notify,
        )
        # Start watcher with rapid 0.1s interval for test
        self.registry.start_watcher(interval_seconds=0.1)

        # Create plugin
        self._write_plugin("test_watch.py", """
PLUGIN = {
    "name": "test_watch",
    "description": "Watched plugin",
    "parameters": {"type": "OBJECT", "properties": {}},
}
def run(parameters):
    return "watched_ok"
""")
        # Allow watcher thread to poll
        deadline = time.time() + 3.0
        found = False
        while time.time() < deadline:
            if self.registry.has("test_watch"):
                found = True
                break
            time.sleep(0.05)

        self.assertTrue(found, "Watcher thread failed to detect new plugin in background.")
        self.assertEqual(self.registry.run("test_watch", {}), "watched_ok")

        self.registry.stop_watcher()

    def test_caller_identity_propagation(self):
        """run() propagates CallerIdentity into thread-local storage and plugin kwargs."""
        self._write_plugin("test_ident.py", """
from core.identity import get_current_identity

PLUGIN = {
    "name": "test_ident",
    "description": "Identity test",
    "parameters": {"type": "OBJECT", "properties": {}},
}

def run(parameters, identity=None):
    current = get_current_identity()
    return f"param:{identity.subject if identity else 'none'}|thread:{current.subject if current else 'none'}"
""")
        self.registry = discover_plugins(
            plugins_dir=self.plugins_path,
            core_tool_names=set(),
            logger=self.logger,
            notify=self.notify,
        )
        ident = CallerIdentity(
            source="dashboard",
            subject="user_12345",
            display_name="Tester",
            metadata={"role": "owner"}
        )
        res = self.registry.run("test_ident", {}, identity=ident)
        self.assertEqual(res, "param:user_12345|thread:user_12345")
        # Ensure thread-local is cleaned up after run completes
        self.assertIsNone(get_current_identity())


if __name__ == "__main__":
    unittest.main()
