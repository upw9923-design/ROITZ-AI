"""
Unit tests for Phase 4 Batch 1: Unified Capture API (core.screen_capture).

Tests the centralized capture API supporting:
- Primary monitor capture
- Multi-monitor selection
- Region capture (absolute and relative)
- Monitor info enumeration
- Validation

Camera capture is tested separately in test_screen_processor_camera.py
since it remains in actions.screen_processor.py.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.screen_capture import (
    capture_primary_monitor,
    capture_monitor,
    capture_region,
    capture_region_relative,
    get_monitor_info,
    validate_monitor_index,
    validate_region,
    CaptureRegion,
    MonitorInfo,
)


class TestMonitorInfo(unittest.TestCase):
    """Test monitor enumeration and info."""

    def test_get_monitor_info_returns_list(self):
        """get_monitor_info should return a list of MonitorInfo."""
        monitors = get_monitor_info()
        self.assertIsInstance(monitors, list)
        self.assertGreater(len(monitors), 0)

    def test_monitor_info_structure(self):
        """Each MonitorInfo should have expected fields."""
        monitors = get_monitor_info()
        for mon in monitors:
            self.assertIsInstance(mon, MonitorInfo)
            self.assertIsInstance(mon.index, int)
            self.assertIsInstance(mon.x, int)
            self.assertIsInstance(mon.y, int)
            self.assertIsInstance(mon.width, int)
            self.assertIsInstance(mon.height, int)
            self.assertIsInstance(mon.is_primary, bool)

    def test_primary_monitor_is_index_1(self):
        """Monitor index 1 should be marked as primary."""
        monitors = get_monitor_info()
        primary_monitors = [m for m in monitors if m.is_primary]
        self.assertEqual(len(primary_monitors), 1)
        self.assertEqual(primary_monitors[0].index, 1)

    def test_monitor_zero_is_combined(self):
        """Monitor index 0 should be the combined virtual monitor."""
        monitors = get_monitor_info()
        combined = next((m for m in monitors if m.index == 0), None)
        self.assertIsNotNone(combined)
        # Combined monitor should encompass all others
        self.assertGreaterEqual(combined.width, max(m.width for m in monitors if m.index > 0))


class TestCapturePrimaryMonitor(unittest.TestCase):
    """Test primary monitor capture."""

    def test_capture_primary_monitor_returns_bytes_and_mime(self):
        """capture_primary_monitor should return (bytes, mime_type)."""
        img_bytes, mime_type = capture_primary_monitor()
        self.assertIsInstance(img_bytes, bytes)
        self.assertGreater(len(img_bytes), 0)
        self.assertIsInstance(mime_type, str)
        self.assertTrue(mime_type.startswith("image/"))

    def test_capture_primary_monitor_mime_type(self):
        """MIME type should be jpeg after compression (or png if PIL unavailable)."""
        _, mime_type = capture_primary_monitor()
        self.assertIn(mime_type, ("image/jpeg", "image/png"))


class TestCaptureMonitor(unittest.TestCase):
    """Test specific monitor capture."""

    def test_capture_monitor_primary(self):
        """Capture monitor 1 (primary) should work."""
        img_bytes, mime_type = capture_monitor(1)
        self.assertIsInstance(img_bytes, bytes)
        self.assertGreater(len(img_bytes), 0)
        self.assertTrue(mime_type.startswith("image/"))

    def test_capture_monitor_combined(self):
        """Capture monitor 0 (all combined) should work."""
        img_bytes, mime_type = capture_monitor(0)
        self.assertIsInstance(img_bytes, bytes)
        self.assertGreater(len(img_bytes), 0)
        self.assertTrue(mime_type.startswith("image/"))

    def test_capture_monitor_invalid_index_raises(self):
        """Invalid monitor index should raise ValueError."""
        monitors = get_monitor_info()
        max_index = len(monitors) - 1

        with self.assertRaises(ValueError) as ctx:
            capture_monitor(max_index + 1)
        self.assertIn("out of range", str(ctx.exception).lower())

        with self.assertRaises(ValueError) as ctx:
            capture_monitor(-1)
        self.assertIn("out of range", str(ctx.exception).lower())


class TestCaptureRegion(unittest.TestCase):
    """Test arbitrary region capture."""

    def test_capture_region_valid(self):
        """Capture a small valid region should work."""
        # Capture a 100x100 region at top-left of primary monitor
        img_bytes, mime_type = capture_region(0, 0, 100, 100, monitor_index=1)
        self.assertIsInstance(img_bytes, bytes)
        self.assertGreater(len(img_bytes), 0)
        self.assertTrue(mime_type.startswith("image/"))

    def test_capture_region_zero_size_raises(self):
        """Zero or negative width/height should raise ValueError."""
        with self.assertRaises(ValueError) as ctx:
            capture_region(0, 0, 0, 100)
        self.assertIn("positive", str(ctx.exception).lower())

        with self.assertRaises(ValueError) as ctx:
            capture_region(0, 0, 100, -1)
        self.assertIn("positive", str(ctx.exception).lower())

    def test_capture_region_negative_coords_raises(self):
        """Negative coordinates should raise ValueError."""
        with self.assertRaises(ValueError) as ctx:
            capture_region(-10, 0, 100, 100)
        self.assertIn("negative", str(ctx.exception).lower())

        with self.assertRaises(ValueError) as ctx:
            capture_region(0, -10, 100, 100)
        self.assertIn("negative", str(ctx.exception).lower())

    def test_capture_region_out_of_bounds_raises(self):
        """Region extending beyond monitor bounds should raise ValueError."""
        monitors = get_monitor_info()
        primary = next((m for m in monitors if m.index == 1), None)
        self.assertIsNotNone(primary)

        # Region extending beyond primary monitor width
        with self.assertRaises(ValueError) as ctx:
            capture_region(primary.width, 0, 100, 100, monitor_index=1)
        self.assertIn("beyond", str(ctx.exception).lower())

        # Region extending beyond primary monitor height
        with self.assertRaises(ValueError) as ctx:
            capture_region(0, primary.height, 100, 100, monitor_index=1)
        self.assertIn("beyond", str(ctx.exception).lower())


class TestCaptureRegionRelative(unittest.TestCase):
    """Test region capture relative to monitor origin."""

    def test_capture_region_relative_primary(self):
        """Capture relative region on primary monitor should work."""
        img_bytes, mime_type = capture_region_relative(0, 0, 100, 100, monitor_index=1)
        self.assertIsInstance(img_bytes, bytes)
        self.assertGreater(len(img_bytes), 0)
        self.assertTrue(mime_type.startswith("image/"))

    def test_capture_region_relative_invalid_monitor_raises(self):
        """Invalid monitor index should raise ValueError."""
        monitors = get_monitor_info()
        max_index = len(monitors) - 1

        with self.assertRaises(ValueError) as ctx:
            capture_region_relative(0, 0, 100, 100, monitor_index=max_index + 1)
        self.assertIn("out of range", str(ctx.exception).lower())

    def test_capture_region_relative_out_of_bounds_raises(self):
        """Relative region extending beyond monitor should raise ValueError."""
        monitors = get_monitor_info()
        primary = next((m for m in monitors if m.index == 1), None)
        self.assertIsNotNone(primary)

        with self.assertRaises(ValueError) as ctx:
            capture_region_relative(primary.width, 0, 100, 100, monitor_index=1)
        self.assertIn("beyond", str(ctx.exception).lower())


class TestValidationFunctions(unittest.TestCase):
    """Test validation helper functions."""

    def test_validate_monitor_index_valid(self):
        """Valid monitor indices should not raise."""
        monitors = get_monitor_info()
        for i in range(len(monitors)):
            validate_monitor_index(i)  # Should not raise

    def test_validate_monitor_index_invalid(self):
        """Invalid monitor indices should raise ValueError."""
        monitors = get_monitor_info()
        max_index = len(monitors) - 1

        with self.assertRaises(ValueError):
            validate_monitor_index(max_index + 1)

        with self.assertRaises(ValueError):
            validate_monitor_index(-1)

    def test_validate_region_valid(self):
        """Valid region within monitor should not raise."""
        monitors = get_monitor_info()
        primary = next((m for m in monitors if m.index == 1), None)
        if primary:
            region = CaptureRegion(x=primary.x, y=primary.y, width=100, height=100)
            validate_region(region, monitor_index=1)  # Should not raise

    def test_validate_region_out_of_bounds(self):
        """Region outside monitor bounds should raise ValueError."""
        monitors = get_monitor_info()
        primary = next((m for m in monitors if m.index == 1), None)
        if primary:
            region = CaptureRegion(x=primary.width + 100, y=primary.y, width=100, height=100)
            with self.assertRaises(ValueError):
                validate_region(region, monitor_index=1)


class TestCaptureRegionDataclass(unittest.TestCase):
    """Test CaptureRegion dataclass validation."""

    def test_capture_region_valid_creation(self):
        """Valid region creation should work."""
        region = CaptureRegion(x=0, y=0, width=100, height=100)
        self.assertEqual(region.x, 0)
        self.assertEqual(region.y, 0)
        self.assertEqual(region.width, 100)
        self.assertEqual(region.height, 100)

    def test_capture_region_zero_width_raises(self):
        """Zero width should raise ValueError on creation."""
        with self.assertRaises(ValueError) as ctx:
            CaptureRegion(x=0, y=0, width=0, height=100)
        self.assertIn("positive", str(ctx.exception).lower())

    def test_capture_region_negative_coords_raises(self):
        """Negative coordinates should raise ValueError on creation."""
        with self.assertRaises(ValueError) as ctx:
            CaptureRegion(x=-1, y=0, width=100, height=100)
        self.assertIn("negative", str(ctx.exception).lower())


class TestBackwardCompatibilityShims(unittest.TestCase):
    """Test that backward compatibility shims work."""

    def test_capture_screen_shim(self):
        """_capture_screen shim should work."""
        from core.screen_capture import _capture_screen
        img_bytes, mime_type = _capture_screen()
        self.assertIsInstance(img_bytes, bytes)
        self.assertGreater(len(img_bytes), 0)
        self.assertTrue(mime_type.startswith("image/"))


if __name__ == "__main__":
    unittest.main()