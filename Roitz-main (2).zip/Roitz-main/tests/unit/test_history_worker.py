"""
Tests for the History Worker background operations.

Verifies:
- Paginated conversation retrieval
- Message retrieval for a conversation
- Search result retrieval
- Successful result signaling
- Database error signaling
- Worker lifecycle and shutdown
- UI-thread safety (no Qt widgets created in worker threads)
- Concurrent request behavior
- Request ID propagation and stale response detection support
- Shutdown synchronization and thread admission race protection
- Accurate search pagination counts
- Signal emission failure handling
- Stale response rejection (deterministic synchronization)
"""

import unittest
import threading
import time
from tempfile import TemporaryDirectory
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch
from contextlib import contextmanager

from memory.conversation_store import ConversationStore
from memory.conversation_models import Conversation, Message
from actions.history_worker import HistoryWorker
from unittest.mock import patch


class ControlledStore:
    """
    Wrapper around ConversationStore that allows deterministic control
    over operation completion order using threading.Event barriers.

    Uses thread-local storage so each worker thread tracks its own request_id.
    """

    def __init__(self, store: ConversationStore):
        self._store = store
        self._barriers = {}  # request_id -> {"started": Event, "proceed": Event, "done": Event}
        self._lock = threading.Lock()
        self._thread_local = threading.local()

    def _get_barrier(self, request_id: str):
        with self._lock:
            if request_id not in self._barriers:
                self._barriers[request_id] = {
                    "started": threading.Event(),
                    "proceed": threading.Event(),
                    "done": threading.Event(),
                }
            return self._barriers[request_id]

    def _get_current_request_id(self) -> str | None:
        """Get the current request ID for the calling thread."""
        return getattr(self._thread_local, "current_request_id", None)

    def _set_current_request_id(self, request_id: str | None):
        """Set the current request ID for the calling thread."""
        if request_id is None:
            if hasattr(self._thread_local, "current_request_id"):
                del self._thread_local.current_request_id
        else:
            self._thread_local.current_request_id = request_id

    def register_thread_request(self, request_id: str):
        """Register a request ID for the calling thread (called at start of work)."""
        self._set_current_request_id(request_id)

    def unregister_thread_request(self):
        """Unregister the request ID for the calling thread (called at end of work)."""
        self._set_current_request_id(None)

    def wait_started(self, request_id: str, timeout: float = 5.0) -> bool:
        """Wait for the operation to signal it has started."""
        barrier = self._get_barrier(request_id)
        return barrier["started"].wait(timeout)

    def allow_proceed(self, request_id: str):
        """Allow the operation to proceed to completion."""
        barrier = self._get_barrier(request_id)
        barrier["proceed"].set()

    def wait_done(self, request_id: str, timeout: float = 5.0) -> bool:
        """Wait for the operation to complete."""
        barrier = self._get_barrier(request_id)
        return barrier["done"].wait(timeout)

    def reset_barrier(self, request_id: str):
        """Reset barrier for reuse."""
        with self._lock:
            if request_id in self._barriers:
                del self._barriers[request_id]

    @contextmanager
    def _controlled_call(self, operation_name: str):
        """Context manager for a controlled store call."""
        request_id = self._get_current_request_id()
        if request_id is None:
            yield
            return
        barrier = self._get_barrier(request_id)
        barrier["started"].set()
        if not barrier["proceed"].wait(timeout=10.0):
            raise TimeoutError(f"Timeout waiting for proceed signal for {operation_name} (req={request_id})")
        try:
            yield
        finally:
            barrier["done"].set()

    # Override store methods to add synchronization
    def list_conversations(self, *args, **kwargs):
        with self._controlled_call("list_conversations"):
            return self._store.list_conversations(*args, **kwargs)

    def count_conversations(self, *args, **kwargs):
        with self._controlled_call("count_conversations"):
            return self._store.count_conversations(*args, **kwargs)

    def get_conversation(self, *args, **kwargs):
        with self._controlled_call("get_conversation"):
            return self._store.get_conversation(*args, **kwargs)

    def get_messages(self, *args, **kwargs):
        with self._controlled_call("get_messages"):
            return self._store.get_messages(*args, **kwargs)

    def get_message_count(self, *args, **kwargs):
        with self._controlled_call("get_message_count"):
            return self._store.get_message_count(*args, **kwargs)

    def search_messages(self, *args, **kwargs):
        with self._controlled_call("search_messages"):
            return self._store.search_messages(*args, **kwargs)

    def count_search_messages(self, *args, **kwargs):
        with self._controlled_call("count_search_messages"):
            return self._store.count_search_messages(*args, **kwargs)

    # Delegate all other methods to the wrapped store
    def __getattr__(self, name):
        return getattr(self._store, name)


class MockPlayer:
    """Mock player that captures emitted signals for verification."""

    def __init__(self):
        self.history_list_calls = []
        self.history_detail_calls = []
        self.history_error_calls = []
        self.history_search_calls = []

    def show_history_list(self, conversations, page, total_pages, total_count, request_id=None):
        self.history_list_calls.append({
            "conversations": conversations,
            "page": page,
            "total_pages": total_pages,
            "total_count": total_count,
            "request_id": request_id,
        })

    def show_history_detail(self, conversation_id, title, messages, page, total_pages, total_count, request_id=None):
        self.history_detail_calls.append({
            "conversation_id": conversation_id,
            "title": title,
            "messages": messages,
            "page": page,
            "total_pages": total_pages,
            "total_count": total_count,
            "request_id": request_id,
        })

    def show_history_error(self, error, request_id=None):
        self.history_error_calls.append({
            "error": error,
            "request_id": request_id,
        })

    def show_history_search(self, query, request_id=None):
        self.history_search_calls.append({
            "query": query,
            "request_id": request_id,
        })

    def reset(self):
        """Clear all recorded calls."""
        self.history_list_calls.clear()
        self.history_detail_calls.clear()
        self.history_error_calls.clear()
        self.history_search_calls.clear()


class TestHistoryWorkerConversationList(unittest.TestCase):
    """Test paginated conversation list loading."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_history.sqlite3"
        self.store = ConversationStore(self.db_path)

        # Create test conversations
        for i in range(25):
            conv = Conversation(
                id=f"conv-{i:03d}",
                title=f"Conversation {i}",
                started_at=int(time.time() * 1000) - i * 3600000,
                ended_at=None if i < 5 else int(time.time() * 1000),
                turn_count=i % 10,
                summary=f"Summary {i}" if i % 3 == 0 else None,
                language="English",
                engine="gemini_live",
            )
            self.store.create_conversation(conv)

        self.player = MockPlayer()
        self.worker = HistoryWorker(self.player)

        # Replace store with our test instance
        self.worker._store = self.store

    def tearDown(self):
        self.store.close()
        self.worker.shutdown(wait=True, timeout=5.0)
        self.temp_dir.cleanup()

    def test_load_conversation_list_page_0(self):
        """Load first page of conversations."""
        request_id = self.worker.load_conversation_list(page=0, page_size=10)

        # Wait for worker thread
        time.sleep(0.5)

        self.assertEqual(len(self.player.history_list_calls), 1)
        call = self.player.history_list_calls[0]
        self.assertEqual(call["page"], 0)
        self.assertEqual(call["total_pages"], 3)  # 25 items / 10 per page = 3 pages
        self.assertEqual(call["total_count"], 25)
        self.assertEqual(len(call["conversations"]), 10)
        self.assertIsNotNone(call["request_id"])
        self.assertEqual(call["request_id"], request_id)

        # Verify conversation dict structure
        conv = call["conversations"][0]
        self.assertIn("id", conv)
        self.assertIn("title", conv)
        self.assertIn("started_at", conv)
        self.assertIn("ended_at", conv)
        self.assertIn("turn_count", conv)
        self.assertIn("summary", conv)
        self.assertIn("language", conv)
        self.assertIn("engine", conv)

    def test_load_conversation_list_page_1(self):
        """Load second page of conversations."""
        request_id = self.worker.load_conversation_list(page=1, page_size=10)

        time.sleep(0.5)

        self.assertEqual(len(self.player.history_list_calls), 1)
        call = self.player.history_list_calls[0]
        self.assertEqual(call["page"], 1)
        self.assertEqual(len(call["conversations"]), 10)
        self.assertEqual(call["request_id"], request_id)

    def test_load_conversation_list_last_page(self):
        """Load last page (partial)."""
        request_id = self.worker.load_conversation_list(page=2, page_size=10)

        time.sleep(0.5)

        call = self.player.history_list_calls[0]
        self.assertEqual(call["page"], 2)
        self.assertEqual(len(call["conversations"]), 5)  # Last page has 5 items
        self.assertEqual(call["request_id"], request_id)

    def test_unique_request_ids_per_call(self):
        """Each call generates a unique request ID."""
        ids = []
        for i in range(5):
            req_id = self.worker.load_conversation_list(page=i, page_size=5)
            ids.append(req_id)

        time.sleep(0.8)

        self.assertEqual(len(self.player.history_list_calls), 5)
        returned_ids = [call["request_id"] for call in self.player.history_list_calls]
        self.assertEqual(set(ids), set(returned_ids))
        self.assertEqual(len(set(ids)), 5)  # All unique


class TestHistoryWorkerConversationDetail(unittest.TestCase):
    """Test message detail loading for a conversation."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_history.sqlite3"
        self.store = ConversationStore(self.db_path)

        # Create conversation with messages
        conv = Conversation(
            id="detail-test",
            title="Detail Test Conversation",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
        )
        self.store.create_conversation(conv)

        # Add 15 messages (8 user, 7 assistant)
        for i in range(15):
            role = "user" if i % 2 == 0 else "assistant"
            self.store.append_message(Message(
                conversation_id="detail-test",
                role=role,
                content=f"Message {i}",
                content_type="text",
            ))

        self.player = MockPlayer()
        self.worker = HistoryWorker(self.player)
        self.worker._store = self.store

    def tearDown(self):
        self.store.close()
        self.worker.shutdown(wait=True, timeout=5.0)
        self.temp_dir.cleanup()

    def test_load_conversation_detail_page_0(self):
        """Load first page of messages."""
        request_id = self.worker.load_conversation_detail("detail-test", page=0, page_size=10)

        time.sleep(0.5)

        self.assertEqual(len(self.player.history_detail_calls), 1)
        call = self.player.history_detail_calls[0]
        self.assertEqual(call["conversation_id"], "detail-test")
        self.assertEqual(call["title"], "Detail Test Conversation")
        self.assertEqual(call["page"], 0)
        self.assertEqual(call["total_pages"], 2)  # 15 messages / 10 per page = 2 pages
        self.assertEqual(call["total_count"], 15)
        self.assertEqual(len(call["messages"]), 10)
        self.assertEqual(call["request_id"], request_id)

        # Verify message dict structure
        msg = call["messages"][0]
        self.assertIn("role", msg)
        self.assertIn("content", msg)
        self.assertIn("content_type", msg)
        self.assertIn("sequence", msg)
        self.assertIn("timestamp_ms", msg)

        # Verify order (oldest first, sequence ascending)
        sequences = [m["sequence"] for m in call["messages"]]
        self.assertEqual(sequences, list(range(1, 11)))

    def test_load_conversation_detail_page_1(self):
        """Load second page of messages."""
        request_id = self.worker.load_conversation_detail("detail-test", page=1, page_size=10)

        time.sleep(0.5)

        call = self.player.history_detail_calls[0]
        self.assertEqual(call["page"], 1)
        self.assertEqual(len(call["messages"]), 5)
        sequences = [m["sequence"] for m in call["messages"]]
        self.assertEqual(sequences, list(range(11, 16)))
        self.assertEqual(call["request_id"], request_id)

    def test_load_nonexistent_conversation(self):
        """Loading detail for missing conversation emits error with request_id."""
        request_id = self.worker.load_conversation_detail("nonexistent", page=0, page_size=10)

        time.sleep(0.5)

        self.assertEqual(len(self.player.history_error_calls), 1)
        self.assertIn("Conversation not found", self.player.history_error_calls[0]["error"])
        self.assertEqual(self.player.history_error_calls[0]["request_id"], request_id)
        self.assertEqual(len(self.player.history_detail_calls), 0)


class TestHistoryWorkerSearch(unittest.TestCase):
    """Test message search functionality."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_history.sqlite3"
        self.store = ConversationStore(self.db_path)

        # Create multiple conversations with searchable content
        for i in range(3):
            conv = Conversation(
                id=f"search-conv-{i}",
                title=f"Search Conversation {i}",
                started_at=int(time.time() * 1000),
                engine="gemini_live",
            )
            self.store.create_conversation(conv)

            # Add messages with searchable terms
            for j, (role, content) in enumerate([
                ("user", "Hello world"),
                ("assistant", "Hi there"),
                ("user", "Python programming"),
                ("assistant", "Python is great"),
            ]):
                self.store.append_message(Message(
                    conversation_id=f"search-conv-{i}",
                    role=role,
                    content=content,
                    content_type="text",
                ))

        self.player = MockPlayer()
        self.worker = HistoryWorker(self.player)
        self.worker._store = self.store

    def tearDown(self):
        self.store.close()
        self.worker.shutdown(wait=True, timeout=5.0)
        self.temp_dir.cleanup()

    def test_search_messages_basic(self):
        """Search for messages containing a term."""
        request_id = self.worker.search_messages("Python", page=0, page_size=10)

        time.sleep(1.0)  # Allow more time for worker thread

        self.assertEqual(len(self.player.history_list_calls), 1)
        call = self.player.history_list_calls[0]
        self.assertEqual(call["page"], 0)
        # Should find 3 conversations (each has "Python" messages)
        self.assertEqual(len(call["conversations"]), 3)
        # Total count should be 6 messages (2 per conversation * 3 conversations)
        self.assertEqual(call["total_count"], 6)
        self.assertEqual(call["request_id"], request_id)

    def test_search_messages_with_conversation_filter(self):
        """Search within a specific conversation."""
        request_id = self.worker.search_messages(
            "Python",
            conversation_id="search-conv-0",
            page=0,
            page_size=10,
        )

        time.sleep(0.5)

        call = self.player.history_list_calls[0]
        # Should only find 1 conversation (the filtered one)
        self.assertEqual(len(call["conversations"]), 1)
        self.assertEqual(call["conversations"][0]["id"], "search-conv-0")
        # Total count should be 2 messages in that conversation
        self.assertEqual(call["total_count"], 2)
        self.assertEqual(call["request_id"], request_id)

    def test_search_messages_with_role_filter(self):
        """Search with role filter."""
        request_id = self.worker.search_messages(
            "Python",
            role="assistant",
            page=0,
            page_size=10,
        )

        time.sleep(0.5)

        call = self.player.history_list_calls[0]
        # Should find conversations where assistant said "Python"
        self.assertEqual(len(call["conversations"]), 3)
        # Total count should be 3 messages (1 per conversation from assistant)
        self.assertEqual(call["total_count"], 3)
        self.assertEqual(call["request_id"], request_id)

    def test_search_empty_query(self):
        """Empty query returns no results without error, with request_id."""
        request_id = self.worker.search_messages("", page=0, page_size=10)

        time.sleep(0.3)

        # Empty query returns empty list immediately (no DB call)
        self.assertEqual(len(self.player.history_list_calls), 1)
        call = self.player.history_list_calls[0]
        self.assertEqual(len(call["conversations"]), 0)
        self.assertEqual(call["total_count"], 0)
        self.assertEqual(call["request_id"], request_id)

    def test_search_whitespace_only_query(self):
        """Whitespace-only query returns no results without error."""
        request_id = self.worker.search_messages("   ", page=0, page_size=10)

        time.sleep(0.3)

        self.assertEqual(len(self.player.history_list_calls), 1)
        call = self.player.history_list_calls[0]
        self.assertEqual(len(call["conversations"]), 0)
        self.assertEqual(call["total_count"], 0)
        self.assertEqual(call["request_id"], request_id)

    def test_search_pagination_multiple_pages(self):
        """Search results paginate correctly with accurate total_count."""
        # Add many messages matching "test" across conversations
        for i in range(10):
            conv = Conversation(
                id=f"page-conv-{i}",
                title=f"Page Conversation {i}",
                started_at=int(time.time() * 1000),
                engine="gemini_live",
            )
            self.store.create_conversation(conv)
            for j in range(3):
                self.store.append_message(Message(
                    conversation_id=f"page-conv-{i}",
                    role="user",
                    content=f"test message {j}",
                    content_type="text",
                ))

        # Search page 0
        req_id_0 = self.worker.search_messages("test", page=0, page_size=10)
        time.sleep(0.5)

        call_0 = self.player.history_list_calls[0]
        self.assertEqual(call_0["page"], 0)
        self.assertEqual(call_0["request_id"], req_id_0)
        # 30 total matches (10 convs * 3 msgs each), page_size=10 -> 3 pages
        self.assertEqual(call_0["total_count"], 30)
        self.assertEqual(call_0["total_pages"], 3)

        # Search page 1
        req_id_1 = self.worker.search_messages("test", page=1, page_size=10)
        time.sleep(0.5)

        call_1 = self.player.history_list_calls[1]
        self.assertEqual(call_1["page"], 1)
        self.assertEqual(call_1["request_id"], req_id_1)
        self.assertEqual(call_1["total_count"], 30)  # Same total
        self.assertEqual(call_1["total_pages"], 3)

    def test_search_combined_filters(self):
        """Search with both conversation_id and role filters."""
        request_id = self.worker.search_messages(
            "Python",
            conversation_id="search-conv-0",
            role="user",
            page=0,
            page_size=10,
        )

        time.sleep(0.5)

        call = self.player.history_list_calls[0]
        # Should only find user messages in search-conv-0 containing "Python"
        self.assertEqual(len(call["conversations"]), 1)
        self.assertEqual(call["conversations"][0]["id"], "search-conv-0")
        # 1 user message with "Python" in that conversation
        self.assertEqual(call["total_count"], 1)
        self.assertEqual(call["request_id"], request_id)


class TestHistoryWorkerConversationSearch(unittest.TestCase):
    """Test conversation-level search functionality (using search_conversations API)."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_history.sqlite3"
        self.store = ConversationStore(self.db_path)

        # Create multiple conversations with searchable content
        for i in range(3):
            conv = Conversation(
                id=f"conv-search-{i}",
                title=f"Conversation about Python {i}",
                started_at=int(time.time() * 1000),
                engine="gemini_live",
                summary=f"This is a summary about Python programming {i}" if i % 2 == 0 else None,
            )
            self.store.create_conversation(conv)

            # Add messages with searchable terms
            for j, (role, content) in enumerate([
                ("user", "Hello world"),
                ("assistant", "Hi there"),
                ("user", "Python programming"),
                ("assistant", "Python is great"),
            ]):
                self.store.append_message(Message(
                    conversation_id=f"conv-search-{i}",
                    role=role,
                    content=content,
                    content_type="text",
                ))

        # Create a conversation with no messages (to test metadata-only matching)
        conv_no_msgs = Conversation(
            id="conv-no-msgs",
            title="Conversation with no messages",
            started_at=int(time.time() * 1000),
            engine="gemini_live",
            summary="This conversation has no messages but has Python in summary",
        )
        self.store.create_conversation(conv_no_msgs)

        self.player = MockPlayer()
        self.worker = HistoryWorker(self.player)
        self.worker._store = self.store

    def tearDown(self):
        self.store.close()
        self.worker.shutdown(wait=True, timeout=5.0)
        self.temp_dir.cleanup()

    def test_search_conversations_basic(self):
        """Search conversations by title matching."""
        request_id = self.worker.search_conversations("Python", page=0, page_size=10)

        time.sleep(1.0)

        self.assertEqual(len(self.player.history_list_calls), 1)
        call = self.player.history_list_calls[0]
        self.assertEqual(call["page"], 0)
        # Should find 4 conversations: 3 with "Python" in title + 1 with "Python" in summary (conv-no-msgs)
        self.assertEqual(len(call["conversations"]), 4)
        # Total count should be 4 conversations
        self.assertEqual(call["total_count"], 4)
        self.assertEqual(call["request_id"], request_id)

    def test_search_conversations_by_summary(self):
        """Search conversations by summary matching."""
        request_id = self.worker.search_conversations("summary", page=0, page_size=10)

        time.sleep(0.5)

        call = self.player.history_list_calls[0]
        # Should find 3 conversations: 2 with "summary" in summary + 1 with "summary" in summary (conv-no-msgs has "summary" in its summary text)
        self.assertEqual(len(call["conversations"]), 3)
        self.assertEqual(call["total_count"], 3)
        self.assertEqual(call["request_id"], request_id)

    def test_search_conversations_by_message_content(self):
        """Search conversations by message content matching."""
        request_id = self.worker.search_conversations("world", page=0, page_size=10)

        time.sleep(0.5)

        call = self.player.history_list_calls[0]
        # Should find 3 conversations (each has "world" in a message)
        self.assertEqual(len(call["conversations"]), 3)
        self.assertEqual(call["total_count"], 3)
        self.assertEqual(call["request_id"], request_id)

    def test_search_conversations_conversation_with_no_messages(self):
        """Conversation with no messages but matching summary is found."""
        request_id = self.worker.search_conversations("no messages", page=0, page_size=10)

        time.sleep(0.5)

        call = self.player.history_list_calls[0]
        # Should find the conversation with no messages but matching summary
        self.assertEqual(len(call["conversations"]), 1)
        self.assertEqual(call["conversations"][0]["id"], "conv-no-msgs")
        self.assertEqual(call["total_count"], 1)
        self.assertEqual(call["request_id"], request_id)

    def test_search_conversations_with_conversation_filter(self):
        """Search within a specific conversation."""
        request_id = self.worker.search_conversations(
            "Python",
            conversation_id="conv-search-0",
            page=0,
            page_size=10,
        )

        time.sleep(0.5)

        call = self.player.history_list_calls[0]
        # Should only find 1 conversation (the filtered one)
        self.assertEqual(len(call["conversations"]), 1)
        self.assertEqual(call["conversations"][0]["id"], "conv-search-0")
        self.assertEqual(call["total_count"], 1)
        self.assertEqual(call["request_id"], request_id)

    def test_search_conversations_with_role_filter(self):
        """Search with role filter (applies to message content only)."""
        request_id = self.worker.search_conversations(
            "Python",
            role="assistant",
            page=0,
            page_size=10,
        )

        time.sleep(0.5)

        call = self.player.history_list_calls[0]
        # Should find 4 conversations: 3 where assistant said "Python" + 1 with "Python" in summary (conv-no-msgs, role filter doesn't apply to summary)
        self.assertEqual(len(call["conversations"]), 4)
        # Total count should be 4 conversations
        self.assertEqual(call["total_count"], 4)
        self.assertEqual(call["request_id"], request_id)

    def test_search_conversations_empty_query(self):
        """Empty query returns no results without error, with request_id."""
        request_id = self.worker.search_conversations("", page=0, page_size=10)

        time.sleep(0.3)

        # Empty query returns empty list immediately (no DB call)
        self.assertEqual(len(self.player.history_list_calls), 1)
        call = self.player.history_list_calls[0]
        self.assertEqual(len(call["conversations"]), 0)
        self.assertEqual(call["total_count"], 0)
        self.assertEqual(call["request_id"], request_id)

    def test_search_conversations_whitespace_only_query(self):
        """Whitespace-only query returns no results without error."""
        request_id = self.worker.search_conversations("   ", page=0, page_size=10)

        time.sleep(0.3)

        self.assertEqual(len(self.player.history_list_calls), 1)
        call = self.player.history_list_calls[0]
        self.assertEqual(len(call["conversations"]), 0)
        self.assertEqual(call["total_count"], 0)
        self.assertEqual(call["request_id"], request_id)

    def test_search_conversations_pagination(self):
        """Conversation search results paginate correctly with accurate total_count."""
        # Add many conversations matching "test"
        for i in range(15):
            conv = Conversation(
                id=f"page-conv-search-{i}",
                title=f"Test conversation {i}",
                started_at=int(time.time() * 1000),
                engine="gemini_live",
            )
            self.store.create_conversation(conv)

        # Search page 0
        req_id_0 = self.worker.search_conversations("Test", page=0, page_size=10)
        time.sleep(0.5)

        call_0 = self.player.history_list_calls[0]
        self.assertEqual(call_0["page"], 0)
        self.assertEqual(call_0["request_id"], req_id_0)
        # 15 total matches (15 new conversations with "Test" in title), page_size=10 -> 2 pages
        self.assertEqual(call_0["total_count"], 15)
        self.assertEqual(call_0["total_pages"], 2)

        # Search page 1
        req_id_1 = self.worker.search_conversations("Test", page=1, page_size=10)
        time.sleep(0.5)

        call_1 = self.player.history_list_calls[1]
        self.assertEqual(call_1["page"], 1)
        self.assertEqual(call_1["request_id"], req_id_1)
        self.assertEqual(call_1["total_count"], 15)  # Same total
        self.assertEqual(call_1["total_pages"], 2)

    def test_search_conversations_combined_filters(self):
        """Search with both conversation_id and role filters."""
        request_id = self.worker.search_conversations(
            "Python",
            conversation_id="conv-search-0",
            role="user",
            page=0,
            page_size=10,
        )

        time.sleep(0.5)

        call = self.player.history_list_calls[0]
        # Should only find user messages in conv-search-0 containing "Python"
        self.assertEqual(len(call["conversations"]), 1)
        self.assertEqual(call["conversations"][0]["id"], "conv-search-0")
        # 1 user message with "Python" in that conversation
        self.assertEqual(call["total_count"], 1)
        self.assertEqual(call["request_id"], request_id)

    def test_search_conversations_returns_request_id(self):
        """search_conversations returns request ID."""
        request_id = self.worker.search_conversations("test", page=0, page_size=10)
        self.assertIsInstance(request_id, str)
        self.assertEqual(len(request_id), 16)

    def test_search_conversations_request_id_in_response(self):
        """Search response contains the correct request ID."""
        request_id = self.worker.search_conversations("test", page=0, page_size=10)
        time.sleep(0.3)
        self.assertEqual(self.player.history_list_calls[0]["request_id"], request_id)


class TestHistoryWorkerErrorHandling(unittest.TestCase):
    """Test error signaling and edge cases."""

    def setUp(self):
        self.player = MockPlayer()
        self.worker = HistoryWorker(self.player)

    def tearDown(self):
        self.worker.shutdown(wait=True, timeout=5.0)

    def test_database_error_propagated(self):
        """Store errors are caught and emitted via error signal with request_id."""
        from unittest.mock import MagicMock
        from memory.conversation_store import ConversationStoreError
        mock_store = MagicMock()
        mock_store.list_conversations.side_effect = ConversationStoreError("Simulated DB error")
        mock_store.count_conversations.return_value = 0

        self.worker._store = mock_store
        request_id = self.worker.load_conversation_list(page=0, page_size=10)

        time.sleep(0.5)

        self.assertEqual(len(self.player.history_error_calls), 1)
        self.assertIn("Database error", self.player.history_error_calls[0]["error"])
        self.assertIn("Simulated DB error", self.player.history_error_calls[0]["error"])
        self.assertEqual(self.player.history_error_calls[0]["request_id"], request_id)

    def test_detail_database_error_propagated(self):
        """Store errors in detail loading are caught and emitted with request_id."""
        from unittest.mock import MagicMock
        from memory.conversation_store import ConversationStoreError
        mock_store = MagicMock()
        mock_store.get_conversation.side_effect = ConversationStoreError("DB error detail")

        self.worker._store = mock_store
        request_id = self.worker.load_conversation_detail("any-id", page=0, page_size=10)

        time.sleep(0.5)

        self.assertEqual(len(self.player.history_error_calls), 1)
        self.assertIn("Database error", self.player.history_error_calls[0]["error"])
        self.assertEqual(self.player.history_error_calls[0]["request_id"], request_id)

    def test_search_database_error_propagated(self):
        """Store errors in search are caught and emitted with request_id."""
        from unittest.mock import MagicMock
        from memory.conversation_store import ConversationStoreError
        mock_store = MagicMock()
        mock_store.search_messages.side_effect = ConversationStoreError("DB error search")

        self.worker._store = mock_store
        request_id = self.worker.search_messages("query", page=0, page_size=10)

        time.sleep(0.5)

        self.assertEqual(len(self.player.history_error_calls), 1)
        self.assertIn("Database error", self.player.history_error_calls[0]["error"])
        self.assertEqual(self.player.history_error_calls[0]["request_id"], request_id)


class TestHistoryWorkerLifecycle(unittest.TestCase):
    """Test worker lifecycle and shutdown."""

    def setUp(self):
        self.player = MockPlayer()
        self.worker = HistoryWorker(self.player)

    def test_shutdown_waits_for_threads(self):
        """Shutdown with wait=True joins active threads."""
        # Start a slow operation
        def slow_work():
            time.sleep(0.3)

        # Patch the internal _run_in_thread to use our slow work
        original_run = self.worker._run_in_thread

        def patched_run(target, *args, **kwargs):
            def wrapper():
                slow_work()
                target(*args, **kwargs)
            thread = threading.Thread(target=wrapper, daemon=True)
            with self.worker._lifecycle_lock:
                self.worker._active_threads.append(thread)
            thread.start()

        self.worker._run_in_thread = patched_run

        self.worker.load_conversation_list(page=0, page_size=10)

        # Shutdown should wait
        start = time.time()
        self.worker.shutdown(wait=True, timeout=2.0)
        elapsed = time.time() - start

        self.assertGreaterEqual(elapsed, 0.2)  # Waited for thread
        self.assertFalse(self.worker.is_busy())

    def test_shutdown_no_wait(self):
        """Shutdown with wait=False returns immediately."""
        def slow_work():
            time.sleep(0.5)

        def patched_run(target, *args, **kwargs):
            def wrapper():
                slow_work()
                target(*args, **kwargs)
            thread = threading.Thread(target=wrapper, daemon=True)
            with self.worker._lifecycle_lock:
                self.worker._active_threads.append(thread)
            thread.start()

        self.worker._run_in_thread = patched_run

        self.worker.load_conversation_list(page=0, page_size=10)

        start = time.time()
        self.worker.shutdown(wait=False)
        elapsed = time.time() - start

        self.assertLess(elapsed, 0.1)  # Returned immediately

    def test_is_busy_tracks_active_threads(self):
        """is_busy returns True while threads are running."""
        event = threading.Event()

        def blocking_work():
            event.wait(timeout=2.0)

        def patched_run(target, *args, **kwargs):
            def wrapper():
                blocking_work()
                target(*args, **kwargs)
            thread = threading.Thread(target=wrapper, daemon=True)
            with self.worker._lifecycle_lock:
                self.worker._active_threads.append(thread)
            thread.start()

        self.worker._run_in_thread = patched_run

        self.assertFalse(self.worker.is_busy())
        self.worker.load_conversation_list(page=0, page_size=10)
        time.sleep(0.1)
        self.assertTrue(self.worker.is_busy())
        event.set()
        time.sleep(0.2)
        self.assertFalse(self.worker.is_busy())

    def test_shutdown_clears_active_threads(self):
        """shutdown() clears the active threads list."""
        def slow_work():
            time.sleep(0.5)

        def patched_run(target, *args, **kwargs):
            def wrapper():
                slow_work()
                target(*args, **kwargs)
            thread = threading.Thread(target=wrapper, daemon=True)
            with self.worker._lifecycle_lock:
                self.worker._active_threads.append(thread)
            thread.start()

        self.worker._run_in_thread = patched_run

        self.worker.load_conversation_list(page=0, page_size=10)
        time.sleep(0.1)

        self.worker.shutdown(wait=True, timeout=2.0)
        self.assertEqual(len(self.worker._active_threads), 0)


class TestHistoryWorkerThreadSafety(unittest.TestCase):
    """Test that worker operations don't touch Qt widgets."""

    def setUp(self):
        self.player = MockPlayer()
        self.worker = HistoryWorker(self.player)

        temp_dir = TemporaryDirectory()
        self.db_path = Path(temp_dir.name) / "test.sqlite3"
        self.store = ConversationStore(self.db_path)

        conv = Conversation(id="thread-test", title="Thread Test", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)
        for i in range(5):
            self.store.append_message(Message(
                conversation_id="thread-test",
                role="user" if i % 2 == 0 else "assistant",
                content=f"Msg {i}",
            ))

        self.worker._store = self.store
        self.temp_dir = temp_dir

    def tearDown(self):
        self.store.close()
        self.worker.shutdown(wait=True, timeout=5.0)
        self.temp_dir.cleanup()

    def test_no_qt_import_in_worker_module(self):
        """Verify history_worker.py doesn't import Qt widgets."""
        import actions.history_worker as hw_module
        import sys

        # Check that no QtWidgets/QGui/etc are imported in the module
        qt_imports = [name for name in dir(hw_module)
                      if 'Qt' in name or 'PyQt' in name or 'pyqt' in name.lower()]
        # Only pyqtSignal should be referenced (for type hints), not imported
        self.assertEqual(len(qt_imports), 0)

    def test_concurrent_requests(self):
        """Multiple concurrent requests don't interfere and have unique request IDs."""
        # Start multiple requests rapidly
        request_ids = []
        for i in range(5):
            req_id = self.worker.load_conversation_list(page=i, page_size=5)
            request_ids.append(req_id)

        time.sleep(0.8)

        # All should complete (order may vary)
        self.assertEqual(len(self.player.history_list_calls), 5)
        returned_ids = [call["request_id"] for call in self.player.history_list_calls]
        self.assertEqual(set(request_ids), set(returned_ids))
        for call in self.player.history_list_calls:
            self.assertIn("conversations", call)
            self.assertIn("page", call)
            self.assertIn("total_pages", call)
            self.assertIn("total_count", call)


class TestHistoryWorkerWithNonePlayer(unittest.TestCase):
    """Test worker handles None player gracefully (for testing)."""

    def setUp(self):
        temp_dir = TemporaryDirectory()
        self.db_path = Path(temp_dir.name) / "test.sqlite3"
        self.store = ConversationStore(self.db_path)

        conv = Conversation(id="none-player", title="None Player Test", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)
        self.store.append_message(Message(
            conversation_id="none-player",
            role="user",
            content="Test",
        ))

        self.worker = HistoryWorker(player=None)
        self.worker._store = self.store
        self.temp_dir = temp_dir

    def tearDown(self):
        self.store.close()
        self.worker.shutdown(wait=True, timeout=5.0)
        self.temp_dir.cleanup()

    def test_none_player_no_crash(self):
        """Operations with None player complete without error."""
        # Should not raise
        self.worker.load_conversation_list(page=0, page_size=10)
        self.worker.load_conversation_detail("none-player", page=0, page_size=10)
        self.worker.search_messages("Test", page=0, page_size=10)

        time.sleep(0.5)

        # No exceptions, no assertions needed - just verifying no crash


class TestHistoryWorkerShutdownRace(unittest.TestCase):
    """Test shutdown race condition protection."""

    def setUp(self):
        self.player = MockPlayer()
        self.worker = HistoryWorker(self.player)

    def tearDown(self):
        self.worker.shutdown(wait=True, timeout=5.0)

    def test_no_new_threads_after_shutdown(self):
        """New requests after shutdown are rejected."""
        self.worker.shutdown(wait=False)

        # Try to start a new request after shutdown
        request_id = self.worker.load_conversation_list(page=0, page_size=10)

        # Should return a request_id but not actually start a thread
        # (the worker checks _shutdown under lock before admitting thread)
        time.sleep(0.2)

        # No calls should be made since thread was not admitted
        self.assertEqual(len(self.player.history_list_calls), 0)

    def test_concurrent_shutdown_and_request(self):
        """Concurrent shutdown and new request admission is safe."""
        # Start a slow operation
        barrier = threading.Barrier(2)

        def slow_work():
            barrier.wait(timeout=1.0)
            time.sleep(0.2)

        def patched_run(target, *args, **kwargs):
            def wrapper():
                slow_work()
                target(*args, **kwargs)
            thread = threading.Thread(target=wrapper, daemon=True)
            with self.worker._lifecycle_lock:
                if not self.worker._shutdown:
                    self.worker._active_threads.append(thread)
                    thread.start()

        self.worker._run_in_thread = patched_run

        # Start request and shutdown concurrently
        def do_request():
            self.worker.load_conversation_list(page=0, page_size=10)

        def do_shutdown():
            barrier.wait(timeout=1.0)
            self.worker.shutdown(wait=True, timeout=2.0)

        t1 = threading.Thread(target=do_request)
        t2 = threading.Thread(target=do_shutdown)
        t1.start()
        t2.start()
        t1.join(timeout=3.0)
        t2.join(timeout=3.0)

        # Should not crash or deadlock
        # Thread either admitted before shutdown or rejected after


class TestHistoryWorkerSignalEmissionFailure(unittest.TestCase):
    """Test signal emission failure handling."""

    def setUp(self):
        # Player that raises RuntimeError on emit (simulating destroyed MainWindow)
        self.player = Mock()
        self.player.show_history_list.side_effect = RuntimeError("Wrapped C/C++ object deleted")
        self.player.show_history_detail.side_effect = RuntimeError("Wrapped C/C++ object deleted")
        self.player.show_history_error.side_effect = RuntimeError("Wrapped C/C++ object deleted")
        self.player.show_history_search.side_effect = RuntimeError("Wrapped C/C++ object deleted")

        temp_dir = TemporaryDirectory()
        self.db_path = Path(temp_dir.name) / "test.sqlite3"
        self.store = ConversationStore(self.db_path)

        conv = Conversation(id="signal-test", title="Signal Test", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)
        self.store.append_message(Message(
            conversation_id="signal-test",
            role="user",
            content="Test",
        ))

        self.worker = HistoryWorker(self.player)
        self.worker._store = self.store
        self.temp_dir = temp_dir

    def tearDown(self):
        self.store.close()
        self.worker.shutdown(wait=True, timeout=5.0)
        self.temp_dir.cleanup()

    def test_list_signal_failure_no_crash(self):
        """RuntimeError on list signal emit doesn't crash worker."""
        self.worker.load_conversation_list(page=0, page_size=10)
        time.sleep(0.3)
        # Should not raise

    def test_detail_signal_failure_no_crash(self):
        """RuntimeError on detail signal emit doesn't crash worker."""
        self.worker.load_conversation_detail("signal-test", page=0, page_size=10)
        time.sleep(0.3)
        # Should not raise

    def test_error_signal_failure_no_crash(self):
        """RuntimeError on error signal emit doesn't crash worker."""
        from unittest.mock import MagicMock
        from memory.conversation_store import ConversationStoreError
        mock_store = MagicMock()
        mock_store.list_conversations.side_effect = ConversationStoreError("DB error")
        mock_store.count_conversations.return_value = 0
        self.worker._store = mock_store

        self.worker.load_conversation_list(page=0, page_size=10)
        time.sleep(0.3)
        # Should not raise

    def test_search_signal_failure_no_crash(self):
        """RuntimeError on search signal emit doesn't crash worker."""
        self.worker.search_messages("test", page=0, page_size=10)
        time.sleep(0.3)
        # Should not raise


class TestHistoryWorkerRequestIdPropagation(unittest.TestCase):
    """Test request ID propagation through all operations."""

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test.sqlite3"
        self.store = ConversationStore(self.db_path)

        conv = Conversation(id="req-test", title="Request ID Test", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)
        for i in range(3):
            self.store.append_message(Message(
                conversation_id="req-test",
                role="user" if i % 2 == 0 else "assistant",
                content=f"Msg {i}",
            ))

        self.player = MockPlayer()
        self.worker = HistoryWorker(self.player)
        self.worker._store = self.store

    def tearDown(self):
        self.store.close()
        self.worker.shutdown(wait=True, timeout=5.0)
        self.temp_dir.cleanup()

    def test_list_returns_request_id(self):
        """load_conversation_list returns request ID."""
        request_id = self.worker.load_conversation_list(page=0, page_size=10)
        self.assertIsInstance(request_id, str)
        self.assertEqual(len(request_id), 16)  # uuid4().hex[:16]

    def test_detail_returns_request_id(self):
        """load_conversation_detail returns request ID."""
        request_id = self.worker.load_conversation_detail("req-test", page=0, page_size=10)
        self.assertIsInstance(request_id, str)
        self.assertEqual(len(request_id), 16)

    def test_search_returns_request_id(self):
        """search_messages returns request ID."""
        request_id = self.worker.search_messages("test", page=0, page_size=10)
        self.assertIsInstance(request_id, str)
        self.assertEqual(len(request_id), 16)

    def test_request_id_in_list_response(self):
        """List response contains the correct request ID."""
        request_id = self.worker.load_conversation_list(page=0, page_size=10)
        time.sleep(0.5)
        self.assertEqual(self.player.history_list_calls[0]["request_id"], request_id)

    def test_request_id_in_detail_response(self):
        """Detail response contains the correct request ID."""
        request_id = self.worker.load_conversation_detail("req-test", page=0, page_size=10)
        time.sleep(0.3)
        self.assertEqual(self.player.history_detail_calls[0]["request_id"], request_id)

    def test_request_id_in_error_response(self):
        """Error response contains the correct request ID."""
        request_id = self.worker.load_conversation_detail("nonexistent", page=0, page_size=10)
        time.sleep(0.3)
        self.assertEqual(self.player.history_error_calls[0]["request_id"], request_id)

    def test_request_id_in_search_response(self):
        """Search response contains the correct request ID."""
        request_id = self.worker.search_messages("test", page=0, page_size=10)
        time.sleep(0.3)
        self.assertEqual(self.player.history_list_calls[0]["request_id"], request_id)


class TestHistoryWorkerStaleResponseRejection(unittest.TestCase):
    """
    Deterministic tests for stale response rejection using threading.Event barriers.

    These tests verify that out-of-order responses are correctly rejected by
    simulating concurrent requests with controlled completion order.

    Approach: Instead of trying to intercept the worker's internal threads
    (which is fragile), we test the MainWindow's stale rejection logic directly
    by simulating the player signal emissions in controlled order. The worker's
    responsibility is to emit signals with correct request_ids (tested elsewhere);
    the MainWindow's responsibility is to reject stale ones (tested here).
    """

    def setUp(self):
        # We don't need a real worker or database for these tests.
        # We simulate the player receiving signals and verify the rejection logic.
        self.player = MockPlayer()

    def _simulate_mainwindow_list(self, calls, current_request_id):
        """Simulate MainWindow's _show_history_list stale rejection."""
        accepted = []
        rejected = []
        for call in calls:
            if call["request_id"] == current_request_id:
                accepted.append(call)
            else:
                rejected.append(call)
        return accepted, rejected

    def _simulate_mainwindow_detail(self, calls, current_request_id, current_conv_id):
        """Simulate MainWindow's _show_history_detail stale rejection (double check)."""
        accepted = []
        rejected = []
        for call in calls:
            if call["request_id"] == current_request_id and call["conversation_id"] == current_conv_id:
                accepted.append(call)
            else:
                rejected.append(call)
        return accepted, rejected

    def _simulate_mainwindow_error(self, error_calls, detail_calls, current_detail_req, current_list_req):
        """Simulate MainWindow's _show_history_error handling."""
        detail_error_ignored = True
        list_error_ignored = True
        for call in error_calls:
            if call["request_id"] == current_detail_req:
                detail_error_ignored = False
            if call["request_id"] == current_list_req:
                list_error_ignored = False
        return detail_error_ignored, list_error_ignored

    def test_stale_detail_rejected(self):
        """Two detail requests; second response arrives first — first ignored."""
        req_a = "req-aaa"
        req_b = "req-bbb"

        # Simulate signals arriving OUT OF ORDER: req_b (newer) arrives first, then req_a (older)
        self.player.show_history_detail("conv-0", "Conv 0", [], 0, 1, 0, req_a)
        self.player.show_history_detail("conv-1", "Conv 1", [], 0, 1, 0, req_b)

        # MainWindow tracks req_b as current (it was the last request initiated)
        current_req = req_b
        current_conv = "conv-1"

        accepted, rejected = self._simulate_mainwindow_detail(
            self.player.history_detail_calls, current_req, current_conv
        )

        self.assertEqual(len(accepted), 1)
        self.assertEqual(accepted[0]["conversation_id"], "conv-1")
        self.assertEqual(accepted[0]["request_id"], req_b)
        self.assertEqual(len(rejected), 1)
        self.assertEqual(rejected[0]["conversation_id"], "conv-0")
        self.assertEqual(rejected[0]["request_id"], req_a)

    def test_stale_search_rejected(self):
        """Two search requests; first response arrives last — first ignored."""
        req_a = "req-aaa"
        req_b = "req-bbb"

        # Simulate signals arriving OUT OF ORDER: req_b (newer) arrives first, then req_a (older)
        self.player.show_history_list([], 0, 1, 0, req_a)
        self.player.show_history_list([], 0, 1, 0, req_b)

        current_req = req_b

        accepted, rejected = self._simulate_mainwindow_list(
            self.player.history_list_calls, current_req
        )

        self.assertEqual(len(accepted), 1)
        self.assertEqual(accepted[0]["request_id"], req_b)
        self.assertEqual(len(rejected), 1)
        self.assertEqual(rejected[0]["request_id"], req_a)

    def test_stale_list_rejected(self):
        """Page 1 then page 2; page 1 response arrives last — page 1 ignored."""
        req_a = "req-page-0"
        req_b = "req-page-1"

        # Simulate page 1 requested first, then page 2
        # But page 2 response arrives first
        self.player.show_history_list([{"id": "c1"}], 0, 2, 20, req_a)
        self.player.show_history_list([{"id": "c2"}], 1, 2, 20, req_b)

        current_req = req_b

        accepted, rejected = self._simulate_mainwindow_list(
            self.player.history_list_calls, current_req
        )

        self.assertEqual(len(accepted), 1)
        self.assertEqual(accepted[0]["page"], 1)
        self.assertEqual(accepted[0]["request_id"], req_b)
        self.assertEqual(len(rejected), 1)
        self.assertEqual(rejected[0]["page"], 0)
        self.assertEqual(rejected[0]["request_id"], req_a)

    def test_detail_and_search_independent(self):
        """Detail request + search request concurrent — each tracks independently."""
        req_detail = "req-detail"
        req_search = "req-search"

        # Both complete - they go to different signals
        self.player.show_history_detail("conv-0", "Conv 0", [], 0, 1, 5, req_detail)
        self.player.show_history_list([{"id": "conv-0"}], 0, 1, 5, req_search)

        # Detail tracking
        detail_accepted, detail_rejected = self._simulate_mainwindow_detail(
            self.player.history_detail_calls, req_detail, "conv-0"
        )
        # List/search tracking
        list_accepted, list_rejected = self._simulate_mainwindow_list(
            self.player.history_list_calls, req_search
        )

        self.assertEqual(len(detail_accepted), 1)
        self.assertEqual(detail_accepted[0]["request_id"], req_detail)
        self.assertEqual(len(detail_rejected), 0)

        self.assertEqual(len(list_accepted), 1)
        self.assertEqual(list_accepted[0]["request_id"], req_search)
        self.assertEqual(len(list_rejected), 0)

    def test_old_error_not_overwrite_success(self):
        """Detail request A succeeds, then request B fails — A's results preserved."""
        req_a = "req-success"
        req_b = "req-error"

        # Success arrives first (for req_a), then error for req_b
        self.player.show_history_detail("conv-0", "Conv 0", [{"role": "user", "content": "hi"}], 0, 1, 1, req_a)
        self.player.show_history_error("Conversation not found", req_b)

        current_detail_req = req_a

        # Error for req_b should be ignored (stale)
        detail_error_ignored, _ = self._simulate_mainwindow_error(
            self.player.history_error_calls,
            self.player.history_detail_calls,
            current_detail_req,
            "req-list-current"
        )

        self.assertTrue(detail_error_ignored)

        # Detail data for req_a should be preserved
        detail_accepted, _ = self._simulate_mainwindow_detail(
            self.player.history_detail_calls, current_detail_req, "conv-0"
        )
        self.assertEqual(len(detail_accepted), 1)
        self.assertEqual(detail_accepted[0]["request_id"], req_a)

    def test_loading_indicators_correct(self):
        """Stale response rejected — loading cleared only for accepted response."""
        req_a = "req-old"
        req_b = "req-new"

        # Simulate: A starts, B starts, B completes, A completes
        # MainWindow tracks req_b as current
        self.player.show_history_detail("conv-1", "Conv 1", [], 0, 1, 0, req_b)
        self.player.show_history_detail("conv-0", "Conv 0", [], 0, 1, 0, req_a)

        current_detail_req = req_b

        # Simulate MainWindow loading state tracking
        detail_loading = True
        detail_data = None
        detail_error = None

        for call in self.player.history_detail_calls:
            if call["request_id"] == current_detail_req:
                detail_data = call
                detail_loading = False

        for call in self.player.history_error_calls:
            if call["request_id"] == current_detail_req:
                detail_error = call["error"]
                detail_loading = False

        self.assertFalse(detail_loading)
        self.assertIsNotNone(detail_data)
        self.assertIsNone(detail_error)
        self.assertEqual(detail_data["conversation_id"], "conv-1")

    def test_cross_operation_isolation(self):
        """List + detail + search all active — each tracks own request ID independently."""
        req_list = "req-list"
        req_detail = "req-detail"
        req_search = "req-search"

        # All complete
        self.player.show_history_list([{"id": "c1"}], 0, 1, 1, req_list)
        self.player.show_history_detail("conv-0", "Conv 0", [], 0, 1, 5, req_detail)
        self.player.show_history_list([{"id": "c1"}], 0, 1, 1, req_search)

        # Each operation type tracks independently
        list_accepted, _ = self._simulate_mainwindow_list(
            self.player.history_list_calls, req_list
        )
        detail_accepted, _ = self._simulate_mainwindow_detail(
            self.player.history_detail_calls, req_detail, "conv-0"
        )
        search_accepted, _ = self._simulate_mainwindow_list(
            self.player.history_list_calls, req_search
        )

        # List and search both use history_list signal, so they share tracking
        # But in this test we're checking they all have correct request_ids
        self.assertIn(req_list, {c["request_id"] for c in self.player.history_list_calls})
        self.assertIn(req_search, {c["request_id"] for c in self.player.history_list_calls})
        self.assertIn(req_detail, {c["request_id"] for c in self.player.history_detail_calls})

        # Each operation type has distinct request IDs
        self.assertNotEqual(req_list, req_detail)
        self.assertNotEqual(req_list, req_search)
        self.assertNotEqual(req_detail, req_search)

    def test_detail_wrong_conversation_rejected(self):
        """Detail response for wrong conversation ID is rejected even if request_id matches."""
        req = "req-same"
        # Same request_id but different conversation
        self.player.show_history_detail("conv-0", "Conv 0", [], 0, 1, 5, req)
        self.player.show_history_detail("conv-1", "Conv 1", [], 0, 1, 5, req)

        # MainWindow expects conv-1 (last selected)
        accepted, rejected = self._simulate_mainwindow_detail(
            self.player.history_detail_calls, req, "conv-1"
        )

        self.assertEqual(len(accepted), 1)
        self.assertEqual(accepted[0]["conversation_id"], "conv-1")
        self.assertEqual(len(rejected), 1)
        self.assertEqual(rejected[0]["conversation_id"], "conv-0")


class TestHistoryWorkerStaleResponseWithRealWorker(unittest.TestCase):
    """
    Lightweight integration tests using real HistoryWorker with a mocked store.

    These tests verify that the worker correctly emits signals with request_ids.
    Stale rejection logic is tested in TestHistoryWorkerStaleResponseRejection above.
    """

    def setUp(self):
        self.player = MockPlayer()
        self.worker = HistoryWorker(self.player)

    def tearDown(self):
        self.worker.shutdown(wait=True, timeout=5.0)

    def _make_mock_store(self, conversation_exists=True):
        """Create a fresh mock store for each test to avoid interference."""
        from unittest.mock import MagicMock
        from memory.conversation_store import ConversationNotFoundError

        mock_store = MagicMock()
        mock_store.list_conversations.return_value = []
        mock_store.count_conversations.return_value = 0
        if conversation_exists:
            # Don't set side_effect - let tests set return_value as needed
            mock_store.get_conversation.return_value = None
        else:
            mock_store.get_conversation.side_effect = ConversationNotFoundError("Not found")
        mock_store.get_messages.return_value = []
        mock_store.get_message_count.return_value = 0
        mock_store.search_messages.return_value = []
        mock_store.count_search_messages.return_value = 0
        mock_store.close = MagicMock()
        return mock_store

    def test_worker_emits_request_id_on_list(self):
        """Worker emits show_history_list with correct request_id."""
        self.worker._store = self._make_mock_store(conversation_exists=False)
        req_id = self.worker.load_conversation_list(page=0, page_size=10)
        time.sleep(0.2)  # Wait for thread
        self.assertEqual(len(self.player.history_list_calls), 1)
        self.assertEqual(self.player.history_list_calls[0]["request_id"], req_id)

    def test_worker_emits_request_id_on_detail(self):
        """Worker emits show_history_detail with correct request_id."""
        from memory.conversation_models import Conversation
        mock_store = self._make_mock_store(conversation_exists=True)
        mock_store.get_conversation.return_value = Conversation(
            id="test", title="Test", started_at=123
        )
        self.worker._store = mock_store
        req_id = self.worker.load_conversation_detail("test", page=0, page_size=10)
        time.sleep(0.2)
        self.assertEqual(len(self.player.history_detail_calls), 1)
        self.assertEqual(self.player.history_detail_calls[0]["request_id"], req_id)

    def test_worker_emits_request_id_on_search(self):
        """Worker emits show_history_list (for search) with correct request_id."""
        self.worker._store = self._make_mock_store(conversation_exists=False)
        req_id = self.worker.search_messages("test", page=0, page_size=10)
        time.sleep(0.2)
        self.assertEqual(len(self.player.history_list_calls), 1)
        self.assertEqual(self.player.history_list_calls[0]["request_id"], req_id)

    def test_worker_emits_request_id_on_error(self):
        """Worker emits show_history_error with correct request_id."""
        from memory.conversation_store import ConversationStoreError
        mock_store = self._make_mock_store(conversation_exists=False)
        mock_store.list_conversations.side_effect = ConversationStoreError("DB error")
        self.worker._store = mock_store
        req_id = self.worker.load_conversation_list(page=0, page_size=10)
        time.sleep(0.2)
        self.assertEqual(len(self.player.history_error_calls), 1)
        self.assertEqual(self.player.history_error_calls[0]["request_id"], req_id)

    def test_worker_concurrent_requests_unique_ids(self):
        """Multiple concurrent requests get unique request IDs."""
        self.worker._store = self._make_mock_store(conversation_exists=False)
        req_ids = []
        for i in range(5):
            req_ids.append(self.worker.load_conversation_list(page=i, page_size=5))
        time.sleep(0.5)
        self.assertEqual(len(self.player.history_list_calls), 5)
        returned_ids = [c["request_id"] for c in self.player.history_list_calls]
        self.assertEqual(set(req_ids), set(returned_ids))
        self.assertEqual(len(set(req_ids)), 5)


class TestHistoryWorkerStaleResponseCrossOperation(unittest.TestCase):
    """
    Tests for cross-operation stale response rejection (Part B coverage).

    These tests extend the MainWindow stale rejection simulation to cover:
    - Search request invalidates older list request (shared _history_list_request_id)
    - List request invalidates older search request (shared _history_list_request_id)
    - Detail pagination rejects older page response
    - Stale detail error rejected (doesn't clear successful detail)
    """

    def setUp(self):
        # We don't need a real worker or database for these tests.
        # We simulate the player receiving signals and verify the rejection logic.
        self.player = MockPlayer()

    def _simulate_mainwindow_list(self, calls, current_request_id):
        """Simulate MainWindow's _show_history_list stale rejection."""
        accepted = []
        rejected = []
        for call in calls:
            if call["request_id"] == current_request_id:
                accepted.append(call)
            else:
                rejected.append(call)
        return accepted, rejected

    def _simulate_mainwindow_detail(self, calls, current_request_id, current_conv_id):
        """Simulate MainWindow's _show_history_detail stale rejection (double check)."""
        accepted = []
        rejected = []
        for call in calls:
            if call["request_id"] == current_request_id and call["conversation_id"] == current_conv_id:
                accepted.append(call)
            else:
                rejected.append(call)
        return accepted, rejected

    def _simulate_mainwindow_error(self, error_calls, current_detail_req, current_list_req):
        """Simulate MainWindow's _show_history_error handling."""
        detail_error_ignored = True
        list_error_ignored = True
        for call in error_calls:
            if call["request_id"] == current_detail_req:
                detail_error_ignored = False
            if call["request_id"] == current_list_req:
                list_error_ignored = False
        return detail_error_ignored, list_error_ignored

    def test_search_invalidates_older_list_request(self):
        """Search request invalidates an older list request (shared _history_list_request_id)."""
        req_list = "req-list-001"
        req_search = "req-search-002"

        # Simulate: list request starts, then search request starts
        # Both complete, but search is the "current" one
        self.player.show_history_list([{"id": "c1", "title": "Conv 1"}], 0, 1, 1, req_list)
        self.player.show_history_list([{"id": "c2", "title": "Conv 2"}], 0, 1, 1, req_search)

        # MainWindow tracks req_search as current (search overwrites list tracking)
        current_req = req_search

        accepted, rejected = self._simulate_mainwindow_list(
            self.player.history_list_calls, current_req
        )

        # Only search response should be accepted
        self.assertEqual(len(accepted), 1)
        self.assertEqual(accepted[0]["request_id"], req_search)
        self.assertEqual(len(rejected), 1)
        self.assertEqual(rejected[0]["request_id"], req_list)

    def test_list_request_invalidates_older_search_request(self):
        """New list request invalidates an older search request (shared _history_list_request_id)."""
        req_search = "req-search-001"
        req_list = "req-list-002"

        # Simulate: search request starts, then list request starts
        self.player.show_history_list([{"id": "c1", "title": "Conv 1"}], 0, 1, 1, req_search)
        self.player.show_history_list([{"id": "c2", "title": "Conv 2"}], 0, 1, 1, req_list)

        # MainWindow tracks req_list as current (list overwrites search tracking)
        current_req = req_list

        accepted, rejected = self._simulate_mainwindow_list(
            self.player.history_list_calls, current_req
        )

        # Only list response should be accepted
        self.assertEqual(len(accepted), 1)
        self.assertEqual(accepted[0]["request_id"], req_list)
        self.assertEqual(len(rejected), 1)
        self.assertEqual(rejected[0]["request_id"], req_search)

    def test_detail_pagination_rejects_older_page_response(self):
        """Detail pagination rejects an older page response."""
        req_page0 = "req-page-0"
        req_page1 = "req-page-1"
        conv_id = "conv-test"

        # Simulate: page 0 requested, then page 1 requested
        # Both complete, but page 1 is the current one
        self.player.show_history_detail(conv_id, "Test Conv", [], 0, 2, 20, req_page0)
        self.player.show_history_detail(conv_id, "Test Conv", [{"role": "user", "content": "msg1"}], 1, 2, 20, req_page1)

        # MainWindow tracks req_page1 as current
        current_req = req_page1

        accepted, rejected = self._simulate_mainwindow_detail(
            self.player.history_detail_calls, current_req, conv_id
        )

        # Only page 1 response should be accepted
        self.assertEqual(len(accepted), 1)
        self.assertEqual(accepted[0]["request_id"], req_page1)
        self.assertEqual(accepted[0]["page"], 1)
        self.assertEqual(len(rejected), 1)
        self.assertEqual(rejected[0]["request_id"], req_page0)
        self.assertEqual(rejected[0]["page"], 0)

    def test_stale_detail_error_rejected(self):
        """Stale detail error is rejected, doesn't clear successful detail."""
        req_success = "req-success"
        req_error = "req-error"
        conv_id = "conv-test"

        # Success response arrives first (for req_success)
        self.player.show_history_detail(conv_id, "Test Conv", [{"role": "user", "content": "Hello"}], 0, 1, 1, req_success)
        # Then error for a DIFFERENT request_id arrives
        self.player.show_history_error("Some database error", req_error)

        current_detail_req = req_success
        current_list_req = "req-list-current"

        # Error for req_error should be ignored (stale)
        detail_error_ignored, list_error_ignored = self._simulate_mainwindow_error(
            self.player.history_error_calls,
            current_detail_req,
            current_list_req
        )

        self.assertTrue(detail_error_ignored)  # Stale error ignored
        self.assertTrue(list_error_ignored)    # Not a list error

        # Detail data for req_success should be preserved
        detail_accepted, _ = self._simulate_mainwindow_detail(
            self.player.history_detail_calls, current_detail_req, conv_id
        )
        self.assertEqual(len(detail_accepted), 1)
        self.assertEqual(detail_accepted[0]["request_id"], req_success)


class TestHistoryWorkerLifecycleSafety(unittest.TestCase):
    """
    Lifecycle and regression safety tests (Part C coverage).

    Verifies:
    - Active requests handled safely during shutdown
    - No unexpectedly tracked worker threads remain
    - Repeated shutdown is safe
    - Existing HistoryPanel behavior remains unchanged
    """

    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test.sqlite3"
        self.store = ConversationStore(self.db_path)

        # Create test conversation
        conv = Conversation(id="life-test", title="Lifecycle Test", started_at=int(time.time() * 1000))
        self.store.create_conversation(conv)
        for i in range(5):
            self.store.append_message(Message(
                conversation_id="life-test",
                role="user" if i % 2 == 0 else "assistant",
                content=f"Msg {i}",
            ))

        self.player = MockPlayer()
        self.worker = HistoryWorker(self.player)
        self.worker._store = self.store

    def tearDown(self):
        self.store.close()
        self.worker.shutdown(wait=True, timeout=5.0)
        self.temp_dir.cleanup()

    def test_repeated_shutdown_safe(self):
        """Repeated shutdown calls are safe (idempotent)."""
        # First shutdown
        self.worker.shutdown(wait=True, timeout=2.0)
        self.assertFalse(self.worker.is_busy())
        self.assertEqual(len(self.worker._active_threads), 0)

        # Second shutdown should not crash
        self.worker.shutdown(wait=True, timeout=2.0)
        self.assertFalse(self.worker.is_busy())

        # Third shutdown with wait=False
        self.worker.shutdown(wait=False)
        self.assertFalse(self.worker.is_busy())

    def test_no_worker_threads_leaked(self):
        """No worker threads remain tracked after operations complete."""
        req_id = self.worker.load_conversation_list(page=0, page_size=10)
        time.sleep(0.5)  # Wait for completion

        # Worker should not be busy
        self.assertFalse(self.worker.is_busy())

        # Shutdown should be clean
        self.worker.shutdown(wait=True, timeout=2.0)
        self.assertEqual(len(self.worker._active_threads), 0)
        self.assertFalse(self.worker.is_busy())

    def test_shutdown_with_active_requests(self):
        """Shutdown while HistoryWorker requests are active is safe."""
        import threading

        # Create slow mock store
        slow_event = threading.Event()

        def slow_list_conversations(*args, **kwargs):
            slow_event.wait(timeout=5.0)
            return []

        def slow_count_conversations(*args, **kwargs):
            return 0

        mock_store = MagicMock()
        mock_store.list_conversations.side_effect = slow_list_conversations
        mock_store.count_conversations.side_effect = slow_count_conversations
        mock_store.close = MagicMock()
        self.worker._store = mock_store

        # Start a slow list request
        req_id = self.worker.load_conversation_list(page=0, page_size=10)
        time.sleep(0.1)  # Give thread time to start
        self.assertTrue(self.worker.is_busy())

        # Shutdown with wait=True should wait for the thread
        start = time.time()
        self.worker.shutdown(wait=True, timeout=3.0)
        elapsed = time.time() - start

        # Should have waited for the thread to complete
        self.assertGreaterEqual(elapsed, 0.05)  # Some time passed
        self.assertFalse(self.worker.is_busy())

        # Now release the slow operation
        slow_event.set()

        # Worker should be fully shut down
        self.assertEqual(len(self.worker._active_threads), 0)

    def test_shutdown_during_concurrent_operations(self):
        """Shutdown during concurrent operations is safe and cleans up all threads."""
        import threading

        # Create slow mock store
        slow_events = {}
        def make_slow(name):
            slow_events[name] = threading.Event()
            def slow_func(*args, **kwargs):
                slow_events[name].wait(timeout=5.0)
                return []
            return slow_func

        mock_store = MagicMock()
        mock_store.list_conversations.side_effect = make_slow("list")
        mock_store.count_conversations.side_effect = make_slow("count")
        mock_store.get_conversation.side_effect = make_slow("detail")
        mock_store.get_messages.side_effect = make_slow("messages")
        mock_store.get_message_count.side_effect = make_slow("msg_count")
        mock_store.search_messages.side_effect = make_slow("search")
        mock_store.count_search_messages.side_effect = make_slow("search_count")
        mock_store.close = MagicMock()
        self.worker._store = mock_store

        # Start multiple concurrent operations
        self.worker.load_conversation_list(page=0, page_size=10)
        self.worker.load_conversation_detail("life-test", page=0, page_size=10)
        self.worker.search_messages("test")

        time.sleep(0.1)  # Give threads time to start
        self.assertTrue(self.worker.is_busy())

        # Shutdown with wait=True
        start = time.time()
        self.worker.shutdown(wait=True, timeout=3.0)
        elapsed = time.time() - start

        # Should have waited for threads
        self.assertGreaterEqual(elapsed, 0.05)
        self.assertFalse(self.worker.is_busy())
        self.assertEqual(len(self.worker._active_threads), 0)

        # Release all slow operations to avoid thread leaks
        for evt in slow_events.values():
            evt.set()

    def test_concurrent_operations_independent_tracking(self):
        """Concurrent list, detail, and search get unique request IDs."""
        req_ids = []
        list_req_ids = []
        for i in range(5):
            req_id = self.worker.load_conversation_list(page=i, page_size=5)
            req_ids.append(req_id)
            list_req_ids.append(req_id)
        detail_req_id = self.worker.load_conversation_detail("life-test", page=0, page_size=5)
        req_ids.append(detail_req_id)
        search_req_id = self.worker.search_messages("test")
        req_ids.append(search_req_id)
        list_req_ids.append(search_req_id)

        time.sleep(0.3)  # Wait for completion

        # All request IDs should be unique
        self.assertEqual(len(set(req_ids)), len(req_ids))

        # All calls should have been emitted with correct request IDs
        self.assertEqual(len(self.player.history_list_calls), 6)  # 5 list + 1 search
        self.assertEqual(len(self.player.history_detail_calls), 1)

        # Verify all emitted request IDs match what was returned
        emitted_list_ids = {c["request_id"] for c in self.player.history_list_calls}
        emitted_detail_ids = {c["request_id"] for c in self.player.history_detail_calls}
        self.assertEqual(set(list_req_ids), emitted_list_ids)  # 5 list + 1 search
        self.assertEqual({detail_req_id}, emitted_detail_ids)  # Last is detail


if __name__ == "__main__":
    unittest.main()